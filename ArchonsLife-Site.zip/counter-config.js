/* Archon's Life: download counter settings.
   1. In Supabase, open your project, then Project Settings > API (or the Connect button).
   2. Paste the Project URL and the publishable key (the old name for it is "anon public") between the quotes below.
   3. Never paste a "secret" or "service_role" key here. This file is public.
   Leave the placeholders as they are to keep the counter switched off. */
window.ARCHON_COUNTER = {
  url: "https://aijewuqwxcojoxubetrq.supabase.co",
  key: "sb_publishable_dG1fzoOgGvrdES_cfFavFw_D9zDREs5"
};
