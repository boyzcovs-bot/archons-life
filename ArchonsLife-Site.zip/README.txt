ARCHON'S LIFE - DOWNLOAD SITE
==============================

This folder is the whole website. It is plain HTML, CSS and JavaScript with no build step.

  index.html          the landing page
  assets/             screenshots, tour video, the WebAssembly demo, icons
  downloads/          the three zips people download
  _headers            optional hosting settings (Netlify and Cloudflare Pages read it)

PUBLISH IT (free, about two minutes)
------------------------------------
Netlify:  go to app.netlify.com/drop and drag this whole folder onto the page.
          Then, in Site settings, set a name or attach your own domain.
Cloudflare Pages, GitHub Pages, Vercel: upload or commit the folder as-is.

The site is set up for archonslife.com: the page's canonical address and link-preview
(og:url, og:image) tags already point there. In Netlify, add archonslife.com under
Domain management and follow its DNS steps. If you ever use a different address, search
index.html for "archonslife.com" and change those three tags.

After it is live, open the page on a Windows PC and a Mac and click each download button once.

UPDATING THE SCREENSAVER
------------------------
1. Replace the zips in downloads/ (keep the same file names, or search index.html for
   "ArchonsLife-" and update every link).
2. Recompute the checksums and paste them into the "Check the download" boxes in index.html:
     Windows PowerShell:  Get-FileHash .\ArchonsLife-Windows.zip -Algorithm SHA256
     Mac or Linux:        shasum -a 256 ArchonsLife-Windows.zip
3. Update the version, date and file sizes (search for "2.2", "November 16, 2026", "552 KB", "1118 KB").

Current checksums (SHA-256):
  ArchonsLife-Windows.zip  ebb1076fe09c2dc210b70bed52ddefad456e63d403376e4582edb07bd5359bea
  ArchonsLife-Mac.zip      b7f61682e16457bb080543a0a75bea3bf1425f9e0e13327c1c71f6cd5d817885
  ArchonsLife-Source.zip   6a64e2779b66b539ea7ead8b265e4e1ddf36fbeabd9007b3914ad8148ab5f308

DOWNLOAD COUNTER (Supabase)
---------------------------
The page can count every click on the Windows and Mac download buttons, forever, in Supabase.
It stays switched off until you paste two values into counter-config.js:
 1. Supabase > your project > SQL Editor > New query. Paste all of download-counter.sql
    (delivered as its own file, kept out of this folder on purpose) and press Run.
 2. Project Settings > API (or the Connect button): copy the Project URL and the publishable key
    (older projects call it "anon public").
 3. Open counter-config.js, paste both between the quotes, save, and upload the site again.
Never paste a "secret" or "service_role" key into counter-config.js - that file is public.
To read the totals, open Table Editor > download_counts (two rows: windows and mac), or run
  select * from public.download_counts;
To start the totals from a number you already have, see the last lines of the .sql file.
A visitor's click is counted once every few seconds at most, but the counter has no server-side
protection, so anyone determined could still inflate it. Treat it as a friendly tally, not an audit.

COLOURS
-------
The page picks one of archonsworld.com's ten palettes (emerald, blue, pink, indigo, purple, red, orange,
teal, lime, yellow) at random on every visit, and the Palette button in the top bar reshuffles it.
The palettes live in the PALETTES list inside the <script> in the <head> of index.html. To pin one
palette, replace the last line of that script, pick();, with apply("purple");  (any name from the list).

THE LIVE DEMO
-------------
assets/archon.wasm is the real screensaver engine compiled to WebAssembly. If a visitor's browser
cannot run it, the page quietly switches to assets/tour.mp4. To rebuild the wasm, see
README-Source.txt inside ArchonsLife-Source.zip.

THINGS TO KNOW BEFORE YOU GO PUBLIC
-----------------------------------
- The page says "Free" and "No ads". Change the wording if that is not what you want.
- The screensaver files are not code-signed, so Windows SmartScreen and macOS Gatekeeper will warn.
  The install steps explain how to get past each warning. A Windows code-signing certificate and an
  Apple Developer ID are what remove the warnings.
- The "Use my local weather" button on the page sends the visitor's IP to ipwho.is and then
  api.open-meteo.com from their own browser. It only runs when they click it.
