#!/bin/bash
# Archon's Life - macOS installer. Double-click me (right-click -> Open the first time).
cd "$(dirname "$0")" || exit 1
SAVER="ArchonsLife.saver"
DEST="$HOME/Library/Screen Savers"

echo "Installing Archon's Life screen saver..."
if [ ! -d "$SAVER" ]; then
  echo "Can't find $SAVER next to this script."; read -n1 -r -p "Press any key to close"; exit 1
fi
mkdir -p "$DEST"
rm -rf "$DEST/$SAVER"
cp -R "$SAVER" "$DEST/"
xattr -cr "$DEST/$SAVER" 2>/dev/null || true               # drop the "downloaded from the internet" flag
codesign --force --deep --sign - "$DEST/$SAVER" 2>/dev/null \
  && echo "Signed for this Mac." || echo "(local signing skipped)"
killall legacyScreenSaver 2>/dev/null || true             # make sure the new copy gets loaded
echo
echo "Installed to: $DEST/$SAVER"
echo "Opening Screen Saver settings - choose \"Archon's Life\" in the list."
open "x-apple.systempreferences:com.apple.ScreenSaver-Settings.extension" 2>/dev/null \
  || open "/System/Library/PreferencePanes/DesktopScreenEffectsPref.prefPane" 2>/dev/null
sleep 2
