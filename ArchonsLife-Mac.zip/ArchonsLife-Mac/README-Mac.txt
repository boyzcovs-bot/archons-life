ARCHON'S LIFE  -  macOS screen saver  (v2.2)
=============================================

Archon travels through an endless, always-changing pixel world - meadows, deserts,
forests, dusk villages, ember wastes, starry nights, crystal twilight, frozen peaks -
while the TIME, DATE and TEMPERATURE drift past on signposts, blimps, balloon banners,
satellites and even underground and underwater. The seasons turn on their own, in an
order that never repeats: spring blossom, summer green, autumn leaves, winter snow.

Every so often Archon changes how he travels: he sprouts wings, drives a flying car,
blasts off in a rocket (pad countdown, up through the clouds, a cruise past the
planets, then a landing), floats in a hot-air balloon, rides a magic carpet or straps
on a jetpack. He can also go DOWN: he drives a drill-nosed digger deep underground
(hedgehogs, worms, moles and beetles live in little cave pockets down there), dives in
a yellow submarine past fish, jellyfish, turtles, crabs, octopuses and the odd whale,
or heads out on the water in a sailboat, a tugboat, a jet ski, a speedboat, a duck floatie
or a cruise ship (the dolphin likes to race them). On the road he pedals a
bicycle, rides a motorbike, a skateboard or a Segway, drives a roadster, an electric car,
a pickup with hay bales, a forklift, a semi truck or a school bus. Backdrops change too:
mountains, rolling hills, forests, a city skyline, a suburb, farmland and mesas. The clock,
date and temperature are carried by signposts, blimps, drones, flocks of birds and balloons of all
kinds (a beating heart, a fox, a rocket, a mirror ball, a sleepy moon, even Archon himself), each sign in its own LED colour. And now and then someone
unexpected shows up above ground: a fox, a corgi, a dalmatian, a husky, a slime, a robot, a
friend who looks just like Archon, wisps of fire/water/earth/air, a ghost, a flock of
birds, a wizard on a crescent moon, a dragon, a UFO... You never know what's next.

Universal build: runs on Apple Silicon (M-series) and Intel Macs, macOS 11 or later
(Intel: 10.13 or later).

NEW IN 2.2
----------
* The ground is full of rocks, crystals, fossils, dinosaur bones and little caves with stalagmites
  and stalactites - and now and then a dog bone, a worm or a mole.
* Archon goes deep sea in scuba gear or a snorkel: squid, octopuses, a sunken pirate ship, a
  giant clam and schools of small fish.
* He drives a 4x4 jeep up and down hills once in a while.
* Famous landmarks drift past at random: the Leaning Tower of Pisa, the Sphinx, Las Vegas, the
  Space Needle, the Eiffel Tower, the Statue of Liberty, Big Ben, the Taj Mahal, Stonehenge and the
  St. Louis Gateway Arch.
* The date is spelled out with the month, and sometimes shows the year.
* Be on the lookout for special holiday easter eggs! They follow your computer's calendar.

INSTALL - easiest way
---------------------
1. Unzip this folder.
2. Right-click  "Install Archon's Life.command"  ->  Open  ->  Open.
   (Right-click is needed the first time because the file isn't from the App Store.)
3. System Settings > Screen Saver opens - pick "Archon's Life" (under "Other").

INSTALL - by hand
-----------------
Double-click ArchonsLife.saver and choose "Install for this user only".
If macOS says it "can't verify" the file: open System Settings > Privacy & Security,
scroll down and click "Open Anyway" next to Archon's Life, then try again.
Or, in Terminal:   xattr -cr ~/Downloads/ArchonsLife.saver   and double-click it again.

IF THE PREVIEW IS BLANK / IT WON'T LOAD
---------------------------------------
Run "Build from source (only if the saver won't load).command". It compiles the
screen saver on your own Mac with Apple's compiler (the free Command Line Tools,
macOS offers to install them) and installs that copy instead. The source is in
the "source" folder.

ABOUT THE TEMPERATURE - PLEASE READ
-----------------------------------
The temperature sign is the only thing that uses the internet. While the saver is
running it:
  1. asks a free IP-geolocation service (ipwho.is, or get.geojs.io as a backup)
     roughly where your internet connection is - city level, no account;
  2. asks Open-Meteo (open-meteo.com, free, no account) for the current weather at that
     spot, rounded to 0.1 degree, and refreshes about every 20 minutes.
Nothing is saved and nothing else is sent. If you are offline - or macOS's screen-saver
sandbox blocks the connection - the temperature sign is simply left out and the saver
shows time and date only. The small preview in System Settings never goes online.

12/24-hour time and Fahrenheit/Celsius follow your Mac's Language & Region settings.
To override, or to turn the temperature off, paste into Terminal (then restart the saver):
   defaults write com.archonslife.screensaver Weather -bool NO     (offline saver)
   defaults write com.archonslife.screensaver Units -string C      (or F)
   defaults write com.archonslife.screensaver Clock -string 24     (or 12)
and to undo:   defaults delete com.archonslife.screensaver

REMOVE
------
Delete ~/Library/Screen Savers/ArchonsLife.saver  (Finder: Go > Go to Folder...)

NOTES
-----
* One world per display.
* Not code-signed with an Apple Developer ID (that costs $99/yr), so the one-time
  "Open Anyway" step above is expected.
