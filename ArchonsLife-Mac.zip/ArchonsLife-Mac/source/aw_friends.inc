/*
 * Archon's Life v3 - friends who live underground and underwater (and the dolphin who races the sailboat).
 * Included by aw_engine.c after aw_extra.inc.
 */

static int is_cave_guest(int t) { return t >= G_HEDGE && t <= G_BEETLE; }
static int is_sea_guest(int t)  { return t >= G_FISH && t <= G_WHALE; }
static int is_deep_guest(int t) { return is_cave_guest(t) || is_sea_guest(t) || t == G_DOLPHIN || t == G_LEAPER; }

/* How deep below the surface (px) each swimmer may be: [lo, hi] given the lake bed depth under it. */
static void sea_limits(int type, int bed, float *lo, float *hi) {
    switch (type) {
        case G_JELLY: *lo = 26.0f; *hi = (float)bed - 30.0f; break;
        case G_OCTO:  *lo = 12.0f; *hi = (float)bed - 20.0f; break;
        case G_WHALE: *lo = 22.0f; *hi = (float)bed - 24.0f; break;
        case G_TURTLE:*lo = 10.0f; *hi = (float)bed - 14.0f; break;
        default:      *lo = 12.0f; *hi = (float)bed - 14.0f; break;
    }
}
/* the lake only exists between lk_x0 and lk_x1; keep a margin from the shallow shore */
#define SHORE_MARGIN 60.0
static int in_deep_lake(const AWWorld *w, double x) {
    return w->lk_on && x >= w->lk_x0 + SHORE_MARGIN && x <= w->lk_x1 - SHORE_MARGIN;
}
/* true where there is real water to splash in / jump out of */
static int water_at(const AWWorld *w, double x) {
    return w->lk_on && x >= w->lk_x0 + 14.0 && x <= w->lk_x1 - 14.0 && lake_depth(w, (int)floor(x)) >= 10;
}

static void spawn_guest_deep(AWWorld *w, Guest *g, int type) {
    int camI = (int)floor(w->cam);
    g->life = 40.0f; g->dir = rng_f(w) < 0.5f ? 1 : -1;
    g->a = rng_r(w, 0.0f, 6.28f);
    /* these friends only make sense in their own realm */
    if (is_cave_guest(type) && !(w->mode == M_DIG && w->alt < -20.0f)) { g->type = G_NONE; return; }
    if (is_sea_guest(type) && !(w->lk_on && (w->mode == M_SUB || w->mode == M_BOAT || w->mode == M_DIVE))) { g->type = G_NONE; return; }
    if ((type == G_DOLPHIN || type == G_LEAPER) && w->mode != M_BOAT) { g->type = G_NONE; return; }
    if (is_cave_guest(type)) {
        g->x = (double)(camI + w->vw) + 34.0 + (double)rng_r(w, 0.0f, 40.0f);
        float side = rng_f(w) < 0.5f ? -1.0f : 1.0f;
        g->y = w->ay - 8.0f + side * rng_r(w, 31.0f, 38.0f);
        g->life = 90.0f;
        for (int k = 0; k < MAXGUEST; k++) {          /* keep little cave pockets from overlapping each other */
            const Guest *o = &w->guests[k];
            if (o == g || !is_cave_guest(o->type)) continue;
            if (fabs(o->x - g->x) < 52.0 && fabsf(o->y - g->y) < 24.0f) g->x = o->x + 54.0;
        }
    } else if (type == G_LEAPER) {
        g->x = (double)(camI + w->vw) + 30.0; g->dir = rng_f(w) < 0.65f ? -1 : 1; g->y = (float)w->gy;
        g->vx = (float)g->dir * rng_r(w, 9.0f, 20.0f); g->a = rng_r(w, 0.0f, 3.0f); g->life = 26.0f; g->c = 0.0f;
        if (!water_at(w, g->x)) { g->type = G_NONE; return; }
    } else if (type == G_DOLPHIN) {
        g->x = (double)camI - 24.0; g->y = (float)w->gy; g->vx = w->spd + rng_r(w, 22.0f, 32.0f); g->dir = 1;
        g->state = -1; g->life = 30.0f;
    } else {
        g->x = (double)(camI + w->vw) + 24.0;
        if (!in_deep_lake(w, g->x)) { g->type = G_NONE; return; }
        int bed = lake_depth(w, (int)g->x);
        float lo, hi; sea_limits(type, bed, &lo, &hi);
        if (hi < lo + 4.0f) { g->type = G_NONE; return; }
        float dy = (w->ay - (float)w->gy) + rng_r(w, -30.0f, 34.0f);
        g->y = (float)w->gy + clampf(dy, lo, hi);
        g->dir = -1;
        switch (type) {
            case G_FISH:   g->vx = -rng_r(w, 9.0f, 22.0f); if (rng_f(w) < 0.25f) { g->vx = rng_r(w, 5.0f, 12.0f); g->dir = 1; } break;
            case G_JELLY:  g->vx = -rng_r(w, 1.0f, 6.0f); break;
            case G_TURTLE: g->vx = -rng_r(w, 7.0f, 13.0f); break;
            case G_OCTO:   g->vx = -rng_r(w, 6.0f, 14.0f); break;
            case G_WHALE:  g->vx = -rng_r(w, 8.0f, 12.0f); g->life = 50.0f; break;
            case G_CRAB:   g->vx = (rng_f(w) < 0.5f ? -1.0f : 1.0f) * rng_r(w, 5.0f, 10.0f); g->y = (float)(w->gy + bed); break;
            default: break;
        }
    }
}

static void step_guest_deep(AWWorld *w, Guest *g, float dt) {
    int camI = (int)floor(w->cam);
    g->t += dt;
    int sx = (int)floor(g->x) - camI;
    if (is_cave_guest(g->type)) {
        if (w->mode != M_DIG) { g->type = G_NONE; return; }
        if (g->state == 0 && fabs(w->ax - g->x) < 34.0) { g->state = 1; g->b = 1.4f; hearts(w, g->x, g->y - 6.0f, 4); }
        if (g->b > 0.0f) g->b -= dt;
        if (sx < -50) g->type = G_NONE;
        return;
    }
    if (g->type == G_LEAPER) {   /* leaps clear of the water in a series of arcs, with a pause between */
        if (!w->lk_on || g->x < w->lk_x0 + 16.0 || g->x > w->lk_x1 - 6.0) { g->type = G_NONE; return; }
        g->x += (double)g->vx * dt;
        static const float LJ[6] = { 1.25f, 1.9f, 1.5f, 1.1f, 1.7f, 1.2f }, LT[6] = { 2.5f, 3.0f, 3.1f, 2.2f, 3.4f, 2.4f };
        int sp = (int)(g->h % 6u);
        float cyc = fmodf(g->t + g->a, LT[sp]), pc = g->c;
        g->c = cyc;
        if (water_at(w, g->x) && (cyc < pc || (pc < LJ[sp] && cyc >= LJ[sp])))
            for (int i = 0; i < 6; i++) spawn_spark(w, g->x + (rng_f(w) - 0.5f) * 8.0f, (float)w->gy, (rng_f(w) - 0.5f) * 30.0f, -16.0f - rng_f(w) * 18.0f, 0.45f + rng_f(w) * 0.3f, SK_FOAM, 0xFFFFFF);
        if (sx < -90 || sx > w->vw + 120 || g->t > g->life) g->type = G_NONE;
        return;
    }
    if (g->type == G_DOLPHIN) {
        if (!w->lk_on || g->x > w->lk_x1) { g->type = G_NONE; return; }
        g->x += (double)g->vx * dt;
        float ph = g->t * 2.1f + g->a;
        int arc = (int)floorf(ph / 3.14159f);
        if (arc != g->state) {
            g->state = arc;
            if (water_at(w, g->x)) for (int i = 0; i < 7; i++) spawn_spark(w, g->x + (rng_f(w) - 0.5f) * 8.0f, (float)w->gy, (rng_f(w) - 0.5f) * 36.0f, -18.0f - rng_f(w) * 22.0f, 0.5f + rng_f(w) * 0.3f, SK_FOAM, 0xFFFFFF);
        }
        g->y = (float)w->gy + 5.0f - 30.0f * fabsf(sinf(ph));
        if (sx > w->vw + 70 || g->t > g->life) g->type = G_NONE;
        return;
    }
    /* sea creatures swim in the water, which is fixed in the world; stay inside the lake */
    if (!w->lk_on || g->x < w->lk_x0 || g->x > w->lk_x1) { g->type = G_NONE; return; }   /* its lake is gone: never left stranded on land */
    g->x += (double)g->vx * dt;
    if (g->x > w->lk_x1 - SHORE_MARGIN) { g->x = w->lk_x1 - SHORE_MARGIN; g->vx = -fabsf(g->vx); g->dir = -1; }
    if (g->x < w->lk_x0 + SHORE_MARGIN) { g->x = w->lk_x0 + SHORE_MARGIN; g->vx = fabsf(g->vx); g->dir = 1; }
    if (g->type == G_CRAB) {
        g->b -= dt;
        if (g->b <= 0.0f) { g->b = rng_r(w, 1.2f, 3.0f); g->vx = (rng_f(w) < 0.5f ? -1.0f : 1.0f) * (rng_f(w) < 0.3f ? 0.0f : rng_r(w, 5.0f, 10.0f)); }
        g->dir = g->vx >= 0.0f ? 1 : -1;
        g->y = (float)(w->gy + lake_depth(w, (int)g->x));
    } else {
        g->dir = g->vx >= 0.0f ? 1 : -1;
        float lo, hi; sea_limits(g->type, lake_depth(w, (int)floor(g->x)), &lo, &hi);
        if (hi < lo) hi = lo;
        float want = clampf(g->y - (float)w->gy, lo, hi);
        g->y = (float)w->gy + (g->y - (float)w->gy) + (want - (g->y - (float)w->gy)) * fminf(1.0f, 5.0f * dt);
    }
    if (g->type == G_OCTO) g->x += (double)(g->vx * 2.0f * fmaxf(0.0f, sinf(g->t * 2.6f)) * dt);
    if (g->type == G_WHALE && sx > -80 && sx < w->vw + 20) {
        g->c -= dt;
        if (g->c <= 0.0f) { g->c = 0.5f; spawn_spark(w, g->x + (double)(g->dir * 14), g->y - 11.0f, (rng_f(w) - 0.5f) * 8.0f, -14.0f - rng_f(w) * 8.0f, 1.2f, SK_BUBBLE, 0xCFF3FF); }
    }
    if (g->t > g->life || sx < -100 || (sx > w->vw + 140)) g->type = G_NONE;
}

/* ---------------------------- drawing ---------------------------- */
static void draw_pocket(AWWorld *w, int cx, int cy, int rx, int ry) {
    const Pal *p = &w->cur;
    Col wall = lerpc(mulc(p->dirt_dk, 0.55f), 0x0C0706, 0.55f), rimc = lerpc(p->dirt_dk, 0x0C0706, 0.30f);
    ell_fill(w, cx, cy, (float)rx + 1.0f, (float)ry + 1.0f, 0, rimc, BIGY);
    ell_fill(w, cx, cy, (float)rx, (float)ry, 0, wall, BIGY);
    R(w, cx - rx + 4, cy + 7, 2 * rx - 8, 2, lerpc(p->dirt_lt, 0x0C0706, 0.45f));
    R(w, cx - rx + 4, cy + 7, 2 * rx - 8, 1, lerpc(p->dirt_lt, 0x0C0706, 0.25f));
    /* a little lamp glow so the friend can be seen */
    for (int dy = -ry; dy <= ry; dy++) for (int dx = -rx; dx <= rx; dx++) {
        float u = (float)dx / (float)rx, v = (float)dy / (float)ry;
        if (u * u + v * v < 0.8f && ((dx + dy) & 1) == 0) BLEND(w, cx + dx, cy + dy, 0xFFC860, 14);
    }
}

static void draw_fish(AWWorld *w, int x, int y, int dir, Col c1, Col c2, int style, int fr) {
    ell_fill(w, x, y, 3.8f, 2.2f, 0, c1, BIGY);
    PX(w, x - dir * 5, y - 1 + fr, c1); PX(w, x - dir * 5, y + fr, c1); PX(w, x - dir * 4, y, c1);
    PX(w, x - dir * 5, y + 1 - fr, mulc(c1, 0.85f));
    if (style == 1) { R(w, x - 1, y - 2, 1, 5, c2); }
    else if (style == 2) { R(w, x - 2, y - 2, 4, 1, c2); }
    else R(w, x - 2, y + 1, 4, 1, c2);
    PX(w, x + dir * 2, y - 1, 0x101018);
    PX(w, x + dir * 1, y - 2, mulc(c1, 1.2f));
}

static void draw_guest_deep(AWWorld *w, Guest *g, int camI) {
    float t = g->t;
    int sx = (int)floor(g->x) - camI;
    int y = (int)floorf(g->y);
    if (is_cave_guest(g->type)) {
        draw_pocket(w, sx, y, 18, 12);
        int floor_y = y + 7;
        int hop = g->b > 0.0f ? (int)(3.0f * fabsf(sinf(t * 9.0f)) + 0.5f) : 0;
        switch (g->type) {
            case G_HEDGE: {
                float s = sinf(t * 0.6f + g->a);
                int ox = (int)floorf(s * 5.0f + 0.5f), flip = cosf(t * 0.6f + g->a) < 0.0f;
                const Sp *sp = (((int)(t * 4.0f)) & 1) ? &HEDGE_A : &HEDGE_B;
                blit(w, sp, sx - 7 + ox, floor_y - 8 - hop, flip, 0);
            } break;
            case G_BEETLE: {
                int ox = (int)floorf(sinf(t * 0.5f + g->a) * 6.0f + 0.5f), flip = cosf(t * 0.5f + g->a) < 0.0f;
                const Sp *sp = (((int)(t * 5.0f)) & 1) ? &BEETLE_A : &BEETLE_B;
                blit(w, sp, sx - 5 + ox, floor_y - 5 - hop, flip, 0);
            } break;
            case G_MOLE: {
                float cyc = fmodf(t + g->a, 5.0f);
                int rise = cyc < 1.0f ? (int)(cyc * 9.0f) : (cyc < 3.5f ? 9 : (cyc < 4.5f ? (int)((4.5f - cyc) * 9.0f) : 0));
                if (g->b > 0.0f) rise = 9;
                R(w, sx - 8, floor_y - 2, 17, 2, lerpc(w->cur.dirt_lt, 0x0C0706, 0.2f)); R(w, sx - 6, floor_y - 3, 13, 1, lerpc(w->cur.dirt_lt, 0x0C0706, 0.1f));
                if (rise > 0) blit_rows(w, &MOLE, sx - 6, floor_y - 3 - rise + 9 - 9 + 0, 0, rise > 9 ? 9 : rise, 0);
            } break;
            case G_WORM: {
                float wig = g->b > 0.0f ? 7.0f : 3.0f;
                R(w, sx - 4, floor_y - 1, 9, 2, mulc(w->cur.dirt_dk, 0.6f));
                for (int i = 0; i < 10; i++) {
                    int ox = (int)floorf(sinf(t * wig - (float)i * 0.7f) * (0.5f + (float)i * 0.28f) + 0.5f);
                    Col c = (i % 3 == 0) ? 0xC8607A : 0xE89AA8;
                    R(w, sx + ox - 2, floor_y - 2 - i, 4, 1, c);
                    if (i % 3 == 1) PX(w, sx + ox - 1, floor_y - 2 - i, 0xF6C6CF);
                    if (i == 9) { PX(w, sx + ox - 1, floor_y - 2 - i, 0x1D1020); PX(w, sx + ox + 1, floor_y - 2 - i, 0x1D1020); PX(w, sx + ox - 1, floor_y - 3 - i, c); PX(w, sx + ox, floor_y - 3 - i, c); }
                }
            } break;
            default: break;
        }
        return;
    }
    if (g->type == G_DOLPHIN) {
        float ph = t * 2.1f + g->a;
        float vy = -30.0f * 2.1f * cosf(ph) * (sinf(ph) >= 0.0f ? 1.0f : -1.0f);
        float ang = atan2f(vy * 0.1f, g->vx * 0.5f);
        int cx = sx, cy = y;
        if (cy >= w->gy + 2) return;
        if (!water_at(w, g->x - 14.0) || !water_at(w, g->x) || !water_at(w, g->x + 14.0)) return;   /* no hopping over the shore */
        int ym = w->gy + 1;
        float ca = cosf(ang), sa = sinf(ang);
        ell_fill(w, cx, cy, 12.0f, 4.4f, ang, 0x27457A, ym);                                   /* outline */
        ell_fill(w, cx - (int)(ca * 12.0f), cy - (int)(sa * 12.0f), 3.2f, 3.2f, ang + 0.8f, 0x27457A, ym);
        ell_fill(w, cx - (int)(ca * 15.0f), cy - (int)(sa * 15.0f), 1.9f, 4.6f, ang, 0x27457A, ym);
        ell_fill(w, cx + (int)(ca * 12.5f), cy + (int)(sa * 12.5f), 3.8f, 1.9f, ang, 0x27457A, ym);
        ell_fill(w, cx, cy, 11.0f, 3.5f, ang, 0x4F7FC0, ym);
        ell_fill(w, cx + (int)(ca * 3.0f) - (int)(sa * 1.0f), cy + (int)(sa * 3.0f) + 1, 7.5f, 1.7f, ang, 0xE4EEFA, ym);
        ell_fill(w, cx + (int)(ca * 12.0f), cy + (int)(sa * 12.0f), 3.0f, 1.2f, ang, 0x4F7FC0, ym);
        ell_fill(w, cx - (int)(ca * 12.0f), cy - (int)(sa * 12.0f), 2.4f, 2.4f, ang + 0.8f, 0x3C69A8, ym);
        ell_fill(w, cx - (int)(ca * 15.0f), cy - (int)(sa * 15.0f), 1.2f, 3.8f, ang, 0x3C69A8, ym);
        ell_fill(w, cx - (int)(ca * 1.0f) + (int)(sa * 4.0f), cy - (int)(sa * 1.0f) - (int)(ca * 4.0f), 2.0f, 1.2f, ang - 0.6f, 0x3C69A8, ym);   /* dorsal fin */
        PX(w, cx + (int)(ca * 7.0f), cy + (int)(sa * 7.0f) - 1, 0x101018);
        return;
    }
    if (g->type == G_LEAPER) {
        static const float LJ[6] = { 1.25f, 1.9f, 1.5f, 1.1f, 1.7f, 1.2f }, LT[6] = { 2.5f, 3.0f, 3.1f, 2.2f, 3.4f, 2.4f }, LH[6] = { 22.0f, 9.0f, 28.0f, 13.0f, 26.0f, 19.0f };
        int sp = (int)(g->h % 6u);
        float cyc = fmodf(g->t + g->a, LT[sp]);
        if (cyc >= LJ[sp]) return;                                                           /* under the surface between leaps */
        float ph = 3.14159f * cyc / LJ[sp];
        int ntr = sp == 3 ? 3 : 1;
        for (int fi = 0; fi < ntr; fi++) {
            float ph2 = ph - (float)fi * 0.16f;
            if (ph2 <= 0.0f) continue;
            float hgt = LH[sp] * sinf(ph2) * (1.0f - 0.12f * (float)fi);
            float vys = -LH[sp] * cosf(ph2) * 3.14159f / LJ[sp];
            int cx = sx - g->dir * fi * 8, cy = w->gy + 4 - (int)hgt - fi * 0;
            if (cy >= w->gy + 2) continue;
            if (!water_at(w, g->x - 12.0) || !water_at(w, g->x + 12.0)) continue;            /* no hopping over the shore */
            float ang = atan2f(vys * 0.22f, g->vx * 0.9f), ca = cosf(ang), sa = sinf(ang);
            int ym = w->gy + 1;
            int ex = cx + (int)(ca * 5.0f), ey = cy + (int)(sa * 5.0f);
            switch (sp) {
                case 0: {   /* salmon */
                    ell_fill(w, cx, cy, 6.0f, 2.4f, ang, 0xD8604A, ym); ell_fill(w, cx + (int)(sa * 0.5f), cy + 1, 4.5f, 1.1f, ang, 0xF8B8A0, ym);
                    ell_fill(w, cx - (int)(ca * 7.0f), cy - (int)(sa * 7.0f), 1.6f, 3.0f, ang, 0xB84A3A, ym);
                    PX(w, ex, ey - 1, 0x101018); } break;
                case 1: {   /* flying fish: long, thin, with big pale wings */
                    ell_fill(w, cx, cy, 4.6f, 1.6f, ang, 0x5A8CC8, ym);
                    ell_fill(w, cx + (int)(sa * 0.2f), cy + 1, 3.2f, 0.7f, ang, 0xD8E8F8, ym);
                    ell_fill(w, cx - (int)(sa * 3.0f), cy - 2 - (int)(ca * 0.0f), 4.5f, 1.1f, ang - 0.55f, 0xCFEAFF, ym);
                    ell_fill(w, cx - (int)(ca * 6.0f), cy - (int)(sa * 6.0f), 1.2f, 2.4f, ang, 0x4A78B0, ym);
                    PX(w, ex, ey - 1, 0x101018); } break;
                case 2: {   /* marlin: a long bill and a tall blue sail */
                    ell_fill(w, cx, cy, 8.0f, 2.8f, ang, 0x2F5FA8, ym); ell_fill(w, cx + (int)(sa * 0.5f), cy + 1, 6.0f, 1.2f, ang, 0xC9D8EE, ym);
                    ell_fill(w, cx + (int)(ca * 11.0f), cy + (int)(sa * 11.0f), 4.5f, 0.6f, ang, 0x1D3A78, ym);
                    ell_fill(w, cx - (int)(sa * 3.0f), cy - 3, 5.0f, 1.3f, ang + 0.15f, 0x3A78D8, ym);
                    ell_fill(w, cx - (int)(ca * 10.0f), cy - (int)(sa * 10.0f), 1.6f, 4.0f, ang, 0x1D3A78, ym);
                    PX(w, cx + (int)(ca * 6.0f), cy + (int)(sa * 6.0f) - 1, 0x101018); } break;
                case 3: {   /* a leaping school of sardines */
                    ell_fill(w, cx, cy, 3.4f, 1.3f, ang, 0xC9D8EE, ym); ell_fill(w, cx, cy - 1, 2.8f, 0.7f, ang, 0x5A78A8, ym);
                    PX(w, cx - (int)(ca * 4.0f), cy - (int)(sa * 4.0f), 0x8FA3C0); PX(w, cx + (int)(ca * 2.0f), cy + (int)(sa * 2.0f) - 1, 0x101018); } break;
                case 4: {   /* manta ray: a wide diamond that flaps */
                    float fl = sinf(g->t * 9.0f);
                    float am = 0.3f * atan2f(vys * 0.22f, fabsf(g->vx) * 0.9f) * (g->dir < 0 ? -1.0f : 1.0f);   /* a gentle tilt either way */
                    ell_fill(w, cx, cy, 11.0f, 2.2f + fl * 0.8f, am, 0x3A4A6A, ym); ell_fill(w, cx, cy + 1, 7.0f, 1.2f, am, 0xE8EEF8, ym);
                    for (int tl = 1; tl <= 7; tl++) PX(w, cx - (int)(ca * (float)(6 + tl)), cy - (int)(sa * (float)(6 + tl)) + (tl & 1), 0x3A4A6A);
                    PX(w, cx + 3, cy - 1, 0x101018); } break;
                default: {  /* tuna: a silver torpedo with yellow finlets */
                    ell_fill(w, cx, cy, 6.0f, 2.8f, ang, 0x3A5A90, ym); ell_fill(w, cx + (int)(sa * 0.5f), cy + 1, 4.8f, 1.2f, ang, 0xE4ECF6, ym);
                    ell_fill(w, cx - (int)(ca * 7.0f), cy - (int)(sa * 7.0f), 1.5f, 3.2f, ang, 0xFFD23F, ym);
                    PX(w, cx - (int)(sa * 3.0f), cy - 3, 0xFFD23F); PX(w, ex, ey - 1, 0x101018); } break;
            }
        }
        return;
    }
    int dir = g->dir;
    switch (g->type) {
        case G_FISH: {
            static const Col A[5] = { 0xFF8A2A, 0x4FA6F5, 0xFFD23F, 0xFF7AA8, 0x9AE86A };
            static const Col B[5] = { 0xFFFFFF, 0xFFD23F, 0x1D1020, 0xFFFFFF, 0x4FA6F5 };
            int kind = (int)((g->h >> 13) % 8u);                       /* each school is its own kind of fish */
            int ci = (int)(g->h % 5u), n = 4 + (int)((g->h >> 5) % 4u);
            if (kind == 1 || kind == 3 || kind == 7) n = 2 + (int)((g->h >> 5) % 2u);
            for (int i = 0; i < n; i++) {
                uint32_t q = hash2(g->h, (uint32_t)i);
                int ox = (int)((rfn(q, 0) - 0.5f) * 28.0f), oy = (int)((rfn(q, 1) - 0.5f) * 16.0f + sinf(t * 1.7f + (float)i) * 1.6f);
                double mwx = g->x + (double)ox;
                if (!(w->lk_on && mwx >= w->lk_x0 + 24.0 && mwx <= w->lk_x1 - 24.0)) continue;
                int mbed = lake_depth(w, (int)floor(mwx));
                int my = y + oy;
                if (my > w->gy + mbed - 6) my = w->gy + mbed - 6;
                if (my < w->gy + 6) continue;
                if (kind == 0) draw_fish(w, sx + ox, my, dir, A[ci], B[ci], (int)(g->h >> 9) % 3, ((int)(t * 6.0f + (float)i)) & 1);
                else { Col k1, k2; fish_pal(kind, g->h, &k1, &k2); draw_fish_sp(w, sx + ox, my, dir, kind, k1, k2, ((int)(t * 6.0f + (float)i)) & 1); }
            }
        } break;
        case G_JELLY: {
            static const Col J[4] = { 0xFF6FC0, 0x6FF2FF, 0xC08CFF, 0xFFA05A };
            Col c = J[g->h & 3u];
            float p = sinf(t * 2.0f + g->a);
            int bw = 10 + (int)(p * 1.4f + 0.5f), bh = 7 - (int)(p * 1.6f + 0.5f);
            int cy = y + (int)floorf(sinf(t * 0.5f + g->a) * 8.0f);
            for (int dy = -15; dy <= 15; dy++) for (int dx = -15; dx <= 15; dx++)
                if (dx * dx + dy * dy < 225 && dx * dx + dy * dy > 60 && ((dx + dy) & 1) == 0) BLEND(w, sx + dx, cy + dy, c, 24);
            for (int dy = -bh; dy <= 0; dy++) for (int dx = -bw; dx <= bw; dx++) {
                float u = (float)dx / (float)bw, v = (float)dy / (float)bh;
                if (u * u + v * v <= 1.0f) BLEND(w, sx + dx, cy + dy, c, 225);
            }
            for (int dy = -bh + 1; dy <= -1; dy++) for (int dx = -bw / 2; dx <= bw / 2; dx++) {
                float u = (float)dx / (float)(bw / 2.0f), v = (float)dy / (float)(bh - 1);
                if (u * u + v * v <= 1.0f && (dx - dy) < 1) BLEND(w, sx + dx, cy + dy, 0xFFFFFF, 90);
            }
            for (int dx = -bw; dx <= bw; dx++) { BLEND(w, sx + dx, cy + 1, lerpc(c, 0xFFFFFF, 0.35f), 240); }
            for (int i = 0; i < 6; i++) {
                int bx = sx - bw + 1 + (i * (2 * bw - 2)) / 5, len = 9 + (int)((g->h >> (3 + i)) & 7u);
                for (int j = 0; j < len; j++) {
                    int ox = (int)floorf(sinf(t * 2.4f + (float)i * 0.9f - (float)j * 0.45f) * (1.0f + (float)j * 0.18f) + 0.5f);
                    BLEND(w, bx + ox, cy + 2 + j, c, 205 - j * 7);
                }
            }
        } break;
        case G_TURTLE: {
            const Sp *sp = (((int)(t * 2.5f)) & 1) ? &TURTLE_A : &TURTLE_B;
            int bob = (int)floorf(sinf(t * 1.1f + g->a) * 2.0f + 0.5f);
            blit_outlined(w, sp, sx - 9, y + bob, dir < 0, 0, 70);
        } break;
        case G_CRAB: {
            int moving = fabsf(g->vx) > 1.0f;
            const Sp *sp = (moving && (((int)(t * 4.0f)) & 1)) ? &CRAB_B : &CRAB_A;
            blit_outlined(w, sp, sx - 6, y - 7, 0, 0, 70);
        } break;
        case G_OCTO: {
            static const Col O[3] = { 0xE0508A, 0xA77BF0, 0xFF8A4A };
            Col c = O[g->h % 3u];
            int bob = (int)floorf(sinf(t * 2.6f) * 2.0f + 0.5f);
            int cy = y + bob;
            ell_fill(w, sx, cy, 6.0f, 5.0f, 0, c, BIGY);
            ell_fill(w, sx - 1, cy - 1, 3.0f, 2.2f, 0, lerpc(c, 0xFFFFFF, 0.3f), BIGY);
            R(w, sx - 4, cy, 3, 3, 0xFFFFFF); R(w, sx + 1, cy, 3, 3, 0xFFFFFF);
            R(w, sx - 3 + (dir > 0 ? 1 : 0), cy + 1, 1, 2, 0x1D1020); R(w, sx + 2 + (dir > 0 ? 1 : 0), cy + 1, 1, 2, 0x1D1020);
            for (int i = 0; i < 8; i++) {
                int bx = sx - 6 + i * 12 / 7;
                for (int j = 0; j < 9; j++) {
                    int ox = (int)floorf(sinf(t * 3.0f + (float)i * 0.8f - (float)j * 0.55f) * (0.8f + (float)j * 0.3f) + 0.5f) - dir * (j / 3);
                    PX(w, bx + ox, cy + 4 + j, j > 6 ? mulc(c, 0.8f) : c);
                    if (j % 3 == 1) PX(w, bx + ox, cy + 4 + j, lerpc(c, 0xFFFFFF, 0.35f));
                }
            }
        } break;
        case G_WHALE: {
            int cy = y + (int)floorf(sinf(t * 0.5f + g->a) * 3.0f + 0.5f);
            float wag = sinf(t * 1.3f) * 0.5f;
            Col body = 0x5878A8, belly = 0xC9D8EE;
            int cx = sx;
            ell_fill(w, cx, cy, 26.0f, 10.0f, 0, body, BIGY);
            ell_fill(w, cx - dir * 28, cy - 1, 9.0f, 4.0f, -dir * wag * 0.4f, body, BIGY);
            ell_fill(w, cx - dir * 38, cy - 1 + (int)(wag * 8.0f), 4.0f, 9.0f, wag * dir * 0.6f, mulc(body, 0.85f), BIGY);
            ell_fill(w, cx, cy + 6, 22.0f, 4.0f, 0, belly, BIGY);
            for (int i = 0; i < 6; i++) R(w, cx + dir * (6 + i * 2) - 1, cy + 4, 1, 5, mulc(belly, 0.82f));
            ell_fill(w, cx + dir * 4, cy + 7, 7.0f, 2.2f, dir * 0.5f, mulc(body, 0.9f), BIGY);
            R(w, cx + dir * 17 - 1, cy, 3, 3, 0xFFFFFF); PX(w, cx + dir * 17 + (dir > 0 ? 1 : 0), cy + 1, 0x101018);
            R(w, cx - 12, cy - 8, 8, 1, mulc(body, 1.2f));
        } break;
        default: break;
    }
}

static void draw_cave_guests(AWWorld *w) {
    int camI = (int)floor(w->cam);
    for (int i = 0; i < MAXGUEST; i++) {
        Guest *g = &w->guests[i];
        if (g->type && is_cave_guest(g->type)) draw_guest_deep(w, g, camI);
    }
}
