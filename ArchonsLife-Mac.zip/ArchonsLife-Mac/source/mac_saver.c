/*
 * Archon's Life - macOS screen saver front-end (.saver)
 *
 * This is plain C. It builds a ScreenSaverView subclass at load time using the
 * Objective-C runtime (looked up with dlsym), so it needs no Apple headers or
 * frameworks to compile or link - just libSystem. That lets the same file be
 * cross-compiled from Linux (zig) or built on a Mac with a bare `clang`.
 *
 * The saver bundle's NSPrincipalClass is "ArchonsLifeView". When macOS loads
 * the bundle, the constructor below registers that class. The view:
 *   - steps the shared world engine on every animateOneFrame
 *   - draws the low-res framebuffer scaled up with nearest-neighbour filtering
 *     (integer scale in *device* pixels, so Retina stays crisp)
 */
#include <dlfcn.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "aw_engine.h"
#include "aw_weather.h"

#ifndef RTLD_DEFAULT
#define RTLD_DEFAULT ((void *)-2)
#endif

typedef void *id;
typedef void *SEL;
typedef void *Class;
typedef void *Ivar;
typedef void *CGContextRef;
typedef void *CGImageRef;
typedef void *CGColorSpaceRef;
typedef void *CGDataProviderRef;
typedef struct { double x, y; } PT;
typedef struct { double w, h; } SZ;
typedef struct { PT o; SZ s; } RC;
typedef struct { id receiver; Class super_class; } SuperRec;

/* ---------------- dynamically resolved runtime / CoreGraphics ---------------- */
static id    (*p_getClass)(const char *);
static SEL   (*p_sel)(const char *);
static Class (*p_allocPair)(Class, const char *, size_t);
static void  (*p_register)(Class);
static unsigned char (*p_addMethod)(Class, SEL, void *, const char *);
static unsigned char (*p_addIvar)(Class, const char *, size_t, uint8_t, const char *);
static Ivar  (*p_getIvar)(Class, const char *);
static ptrdiff_t (*p_ivarOffset)(Ivar);
static void *p_msgSend, *p_msgSendSuper;

static CGColorSpaceRef (*cg_cs_create)(void);
static void (*cg_cs_release)(CGColorSpaceRef);
static CGDataProviderRef (*cg_prov_create)(void *, const void *, size_t, void *);
static void (*cg_prov_release)(CGDataProviderRef);
static CGImageRef (*cg_img_create)(size_t, size_t, size_t, size_t, size_t, CGColorSpaceRef, uint32_t,
                                   CGDataProviderRef, const double *, unsigned char, int);
static void (*cg_img_release)(CGImageRef);
static void (*cg_draw)(CGContextRef, RC, CGImageRef);
static void (*cg_interp)(CGContextRef, int);
static void (*cg_save)(CGContextRef);
static void (*cg_restore)(CGContextRef);
static void (*cg_setfill)(CGContextRef, double, double, double, double);
static void (*cg_fillrect)(CGContextRef, RC);
static SZ   (*cg_conv_size)(CGContextRef, SZ);

/* ---------------- tiny typed messaging wrappers ---------------- */
#ifdef AW_MOCK
extern id    mock_send_id(id, SEL);
extern void  mock_send_void_double(id, SEL, double);
extern void  mock_send_void_bool(id, SEL, unsigned char);
extern id    mock_super_init(SuperRec *, SEL, RC, unsigned char);
extern void  mock_super_void(SuperRec *, SEL);
extern void  mock_super_size(SuperRec *, SEL, SZ);
#define SEND_ID(o, s)               mock_send_id((o), (s))
#define SEND_VOID_DOUBLE(o, s, d)   mock_send_void_double((o), (s), (d))
#define SEND_VOID_BOOL(o, s, b)     mock_send_void_bool((o), (s), (b))
#define SUPER_INIT(r, s, f, p)      mock_super_init((r), (s), (f), (p))
#define SUPER_VOID(r, s)            mock_super_void((r), (s))
#define SUPER_SIZE(r, s, z)         mock_super_size((r), (s), (z))
#else
#define SEND_ID(o, s)               ((id (*)(id, SEL))p_msgSend)((o), (s))
#define SEND_VOID_DOUBLE(o, s, d)   ((void (*)(id, SEL, double))p_msgSend)((o), (s), (d))
#define SEND_VOID_BOOL(o, s, b)     ((void (*)(id, SEL, unsigned char))p_msgSend)((o), (s), (b))
#define SUPER_INIT(r, s, f, p)      ((id (*)(SuperRec *, SEL, RC, unsigned char))p_msgSendSuper)((r), (s), (f), (p))
#define SUPER_VOID(r, s)            ((void (*)(SuperRec *, SEL))p_msgSendSuper)((r), (s))
#define SUPER_SIZE(r, s, z)         ((void (*)(SuperRec *, SEL, SZ))p_msgSendSuper)((r), (s), (z))
#endif

/* ---------------- per-view state ---------------- */
typedef struct {
    AWWorld *world;
    double fw, fh;          /* view size in points */
    int vw, vh;             /* current virtual size */
    double last;            /* last step time (seconds) */
    int preview;
    int weather_started;
    double wx_last;         /* last time weather/prefs were pushed to the world */
    CGColorSpaceRef cs;
} St;

static Class     g_super, g_cls;
static ptrdiff_t g_off = -1;
static SEL       s_setNeedsDisplay, s_setAnimInterval, s_currentContext, s_CGContext;
static id        c_NSGraphicsContext;

static St *state_of(id self) {
    if (g_off < 0 || !self) return NULL;
    return *(St **)((char *)self + g_off);
}
static void set_state(id self, St *s) { *(St **)((char *)self + g_off) = s; }

static double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

/* ---------------- system preferences (CoreFoundation, resolved at run time) ---------------- */
typedef void *CFRef;
static CFRef (*cf_str_create)(void *, const char *, uint32_t);
static CFRef (*cf_pref_copy)(CFRef, CFRef, CFRef, CFRef);
static CFRef (*cf_pref_copy_app)(CFRef, CFRef);
static unsigned char (*cf_str_get)(CFRef, char *, long, uint32_t);
static unsigned long (*cf_typeid)(CFRef);
static unsigned long (*cf_str_typeid)(void);
static unsigned long (*cf_bool_typeid)(void);
static unsigned char (*cf_bool_val)(CFRef);
static void (*cf_release)(CFRef);
static CFRef k_any_app, k_cur_user, k_any_host;

static int g_clock24 = -1;       /* -1 = unknown (fall back to the country code) */
static int g_fahr = -1;
static int g_weather_on = 1;
static char g_locale_cc[3];      /* country from the system locale, "" if unknown */

static int cf_load(void) {
    dlopen("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation", RTLD_LAZY);
    void *p;
    *(void **)&cf_str_create = dlsym(RTLD_DEFAULT, "CFStringCreateWithCString");
    *(void **)&cf_pref_copy = dlsym(RTLD_DEFAULT, "CFPreferencesCopyValue");
    *(void **)&cf_pref_copy_app = dlsym(RTLD_DEFAULT, "CFPreferencesCopyAppValue");
    *(void **)&cf_str_get = dlsym(RTLD_DEFAULT, "CFStringGetCString");
    *(void **)&cf_typeid = dlsym(RTLD_DEFAULT, "CFGetTypeID");
    *(void **)&cf_str_typeid = dlsym(RTLD_DEFAULT, "CFStringGetTypeID");
    *(void **)&cf_bool_typeid = dlsym(RTLD_DEFAULT, "CFBooleanGetTypeID");
    *(void **)&cf_bool_val = dlsym(RTLD_DEFAULT, "CFBooleanGetValue");
    *(void **)&cf_release = dlsym(RTLD_DEFAULT, "CFRelease");
    p = dlsym(RTLD_DEFAULT, "kCFPreferencesAnyApplication"); k_any_app = p ? *(CFRef *)p : NULL;
    p = dlsym(RTLD_DEFAULT, "kCFPreferencesCurrentUser");    k_cur_user = p ? *(CFRef *)p : NULL;
    p = dlsym(RTLD_DEFAULT, "kCFPreferencesAnyHost");        k_any_host = p ? *(CFRef *)p : NULL;
    return cf_str_create && cf_pref_copy && cf_pref_copy_app && cf_str_get && cf_typeid && cf_str_typeid &&
           cf_bool_typeid && cf_bool_val && cf_release && k_any_app && k_cur_user && k_any_host;
}

/* Reads a preference as a boolean (-1 if missing / wrong type) or string (returns 1 and fills out). */
static CFRef cf_get(const char *key, const char *app_domain /* NULL = global domain */) {
    CFRef k = cf_str_create(NULL, key, 0x08000100u);
    if (!k) return NULL;
    CFRef v;
    if (app_domain) {
        CFRef d = cf_str_create(NULL, app_domain, 0x08000100u);
        v = d ? cf_pref_copy_app(k, d) : NULL;
        if (d) cf_release(d);
    } else {
        v = cf_pref_copy(k, k_any_app, k_cur_user, k_any_host);
    }
    cf_release(k);
    return v;
}
static int cf_bool(const char *key, const char *dom) {
    CFRef v = cf_get(key, dom);
    int r = -1;
    if (v) { if (cf_typeid(v) == cf_bool_typeid()) r = cf_bool_val(v) ? 1 : 0; cf_release(v); }
    return r;
}
static int cf_string(const char *key, const char *dom, char *out, long cap) {
    CFRef v = cf_get(key, dom);
    int r = 0;
    if (v) { if (cf_typeid(v) == cf_str_typeid() && cf_str_get(v, out, cap, 0x08000100u)) r = 1; cf_release(v); }
    return r;
}

#define AW_DOMAIN "com.archonslife.screensaver"
/* Optional overrides (Terminal):  defaults write com.archonslife.screensaver Weather -bool NO
 *                                  defaults write com.archonslife.screensaver Units -string C     (F, C)
 *                                  defaults write com.archonslife.screensaver Clock -string 24    (12, 24)  */
static void detect_prefs(void) {
    char buf[96];
    g_locale_cc[0] = 0;
    if (!cf_load()) return;

    if (cf_string("AppleLocale", NULL, buf, (long)sizeof buf)) {
        const char *u = strchr(buf, '_');
        if (u && u[1] >= 'A' && u[1] <= 'Z' && u[2] >= 'A' && u[2] <= 'Z') { g_locale_cc[0] = u[1]; g_locale_cc[1] = u[2]; g_locale_cc[2] = 0; }
    }
    int f24 = cf_bool("AppleICUForce24HourTime", NULL);
    if (f24 >= 0) g_clock24 = f24;
    else if (g_locale_cc[0]) g_clock24 = aw_country_uses_12h(g_locale_cc) ? 0 : 1;

    if (cf_string("AppleTemperatureUnit", NULL, buf, (long)sizeof buf)) g_fahr = (buf[0] == 'F' || buf[0] == 'f') ? 1 : 0;
    else if (g_locale_cc[0]) g_fahr = aw_country_uses_fahrenheit(g_locale_cc) ? 1 : 0;

    int w = cf_bool("Weather", AW_DOMAIN);
    if (w >= 0) g_weather_on = w;
    if (cf_string("Units", AW_DOMAIN, buf, (long)sizeof buf)) { if (buf[0] == 'F' || buf[0] == 'f') g_fahr = 1; else if (buf[0] == 'C' || buf[0] == 'c') g_fahr = 0; }
    if (cf_string("Clock", AW_DOMAIN, buf, (long)sizeof buf)) { if (buf[0] == '2') g_clock24 = 1; else if (buf[0] == '1') g_clock24 = 0; }
}

/* Twice a second: hand the newest reading and the display preferences to the world. */
static void push_world_state(St *s, double now) {
    if (!s->world || now - s->wx_last < 0.5) return;
    s->wx_last = now;
    AWWeather w;
    int ok = (g_weather_on && !s->preview) ? aw_weather_get(&w) : 0;
    int fahr = g_fahr, c24 = g_clock24;
    if (fahr < 0) fahr = ok && w.country[0] ? aw_country_uses_fahrenheit(w.country) : 1;
    if (c24 < 0) c24 = 0;
    aw_set_prefs(s->world, c24, fahr);
    aw_set_weather(s->world, ok, ok ? w.temp_c : 0.0f, ok ? w.wmo_code : 0, ok ? w.is_day : 1);
}

/* ---------------- method implementations ---------------- */
static id imp_init(id self, SEL cmd, RC frame, unsigned char isPreview) {
    SuperRec sup = { self, g_super };
    id r = SUPER_INIT(&sup, cmd, frame, isPreview);
    if (!r) return r;
    St *s = (St *)calloc(1, sizeof(St));
    if (!s) return r;
    s->fw = frame.s.w; s->fh = frame.s.h;
    s->preview = isPreview;
    s->last = now_sec();
    set_state(r, s);
    if (!isPreview && g_weather_on) { aw_weather_start(); s->weather_started = 1; }
    SEND_VOID_DOUBLE(r, s_setAnimInterval, 1.0 / 30.0);
    return r;
}

static void imp_dealloc(id self, SEL cmd) {
    St *s = state_of(self);
    if (s) {
        if (s->weather_started) aw_weather_stop();
        if (s->world) aw_destroy(s->world);
        if (s->cs && cg_cs_release) cg_cs_release(s->cs);
        free(s);
        set_state(self, NULL);
    }
    SuperRec sup = { self, g_super };
    SUPER_VOID(&sup, cmd);
}

static void imp_setFrameSize(id self, SEL cmd, SZ sz) {
    SuperRec sup = { self, g_super };
    SUPER_SIZE(&sup, cmd, sz);
    St *s = state_of(self);
    if (s) { s->fw = sz.w; s->fh = sz.h; }
}

static void imp_animate(id self, SEL cmd) {
    (void)cmd;
    St *s = state_of(self);
    if (!s) return;
    double t = now_sec();
    double dt = t - s->last;
    s->last = t;
    push_world_state(s, t);
    if (s->world) aw_step(s->world, dt);
    SEND_VOID_BOOL(self, s_setNeedsDisplay, 1);
}

static void imp_draw(id self, SEL cmd, RC dirty) {
    (void)cmd; (void)dirty;
    St *s = state_of(self);
    if (!s || s->fw < 1.0 || s->fh < 1.0) return;
    id nsctx = c_NSGraphicsContext ? SEND_ID(c_NSGraphicsContext, s_currentContext) : NULL;
    if (!nsctx) return;
    CGContextRef ctx = SEND_ID(nsctx, s_CGContext);
    if (!ctx) return;

    /* device pixels per point (2.0 on Retina) */
    SZ one = { 1.0, 1.0 };
    SZ dev = cg_conv_size(ctx, one);
    double backing = dev.w < 0 ? -dev.w : dev.w;
    if (backing < 1.0) backing = 1.0;

    int px_w = (int)(s->fw * backing + 0.5), px_h = (int)(s->fh * backing + 0.5);
    if (px_w < 1 || px_h < 1) return;
    int scale = aw_pick_scale(px_w, px_h);
    int vw = (px_w + scale - 1) / scale, vh = (px_h + scale - 1) / scale;

    if (!s->world) {
        uint32_t seed = (uint32_t)(now_sec() * 1000.0) ^ (uint32_t)((uintptr_t)self >> 4);
        s->world = aw_create(vw, vh, seed);
        if (!s->world) return;
        s->last = now_sec();
    } else if (vw != s->vw || vh != s->vh) {
        aw_resize(s->world, vw, vh);
    }
    s->vw = aw_width(s->world); s->vh = aw_height(s->world);
    aw_render(s->world);

    if (!s->cs) s->cs = cg_cs_create();
    size_t bytes = (size_t)s->vw * (size_t)s->vh * 4u;
    CGDataProviderRef prov = cg_prov_create(NULL, aw_pixels(s->world), bytes, NULL);
    /* 0x00RRGGBB little-endian words: kCGBitmapByteOrder32Little (2<<12) | kCGImageAlphaNoneSkipFirst (6) */
    CGImageRef img = cg_img_create((size_t)s->vw, (size_t)s->vh, 8, 32, (size_t)s->vw * 4u, s->cs,
                                   (2u << 12) | 6u, prov, NULL, 0, 0);
    if (img) {
        cg_save(ctx);
        cg_setfill(ctx, 0.0, 0.0, 0.0, 1.0);
        RC all = { { 0.0, 0.0 }, { s->fw, s->fh } };
        cg_fillrect(ctx, all);
        cg_interp(ctx, 1);                       /* kCGInterpolationNone */
        double dw = (double)s->vw * (double)scale / backing;
        double dh = (double)s->vh * (double)scale / backing;
        RC dest = { { 0.0, s->fh - dh }, { dw, dh } };   /* top-left aligned, crop right/bottom */
        cg_draw(ctx, dest, img);
        cg_restore(ctx);
        cg_img_release(img);
    }
    if (prov) cg_prov_release(prov);
}

static unsigned char imp_hasConfigureSheet(id self, SEL cmd) { (void)self; (void)cmd; return 0; }
static id imp_configureSheet(id self, SEL cmd) { (void)self; (void)cmd; return NULL; }

/* ---------------- registration ---------------- */
#define LOAD(var, name) do { *(void **)&(var) = dlsym(RTLD_DEFAULT, (name)); if (!(var)) return 0; } while (0)

static int aw_register_class(void) {
    detect_prefs();
    dlopen("/System/Library/Frameworks/ScreenSaver.framework/ScreenSaver", RTLD_LAZY);
    dlopen("/System/Library/Frameworks/AppKit.framework/AppKit", RTLD_LAZY);
    dlopen("/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics", RTLD_LAZY);

    LOAD(p_getClass, "objc_getClass");
    LOAD(p_sel, "sel_registerName");
    LOAD(p_allocPair, "objc_allocateClassPair");
    LOAD(p_register, "objc_registerClassPair");
    LOAD(p_addMethod, "class_addMethod");
    LOAD(p_addIvar, "class_addIvar");
    LOAD(p_getIvar, "class_getInstanceVariable");
    LOAD(p_ivarOffset, "ivar_getOffset");
    LOAD(p_msgSend, "objc_msgSend");
    LOAD(p_msgSendSuper, "objc_msgSendSuper");

    LOAD(cg_cs_create, "CGColorSpaceCreateDeviceRGB");
    LOAD(cg_cs_release, "CGColorSpaceRelease");
    LOAD(cg_prov_create, "CGDataProviderCreateWithData");
    LOAD(cg_prov_release, "CGDataProviderRelease");
    LOAD(cg_img_create, "CGImageCreate");
    LOAD(cg_img_release, "CGImageRelease");
    LOAD(cg_draw, "CGContextDrawImage");
    LOAD(cg_interp, "CGContextSetInterpolationQuality");
    LOAD(cg_save, "CGContextSaveGState");
    LOAD(cg_restore, "CGContextRestoreGState");
    LOAD(cg_setfill, "CGContextSetRGBFillColor");
    LOAD(cg_fillrect, "CGContextFillRect");
    LOAD(cg_conv_size, "CGContextConvertSizeToDeviceSpace");

    g_super = p_getClass("ScreenSaverView");
    if (!g_super) return 0;
    if (p_getClass("ArchonsLifeView")) return 1;      /* already registered */
    g_cls = p_allocPair(g_super, "ArchonsLifeView", 0);
    if (!g_cls) return 0;

    p_addIvar(g_cls, "aw_state", sizeof(void *), (uint8_t)(sizeof(void *) == 8 ? 3 : 2), "^v");

    p_addMethod(g_cls, p_sel("initWithFrame:isPreview:"), (void *)imp_init, "@@:{CGRect={CGPoint=dd}{CGSize=dd}}B");
    p_addMethod(g_cls, p_sel("dealloc"), (void *)imp_dealloc, "v@:");
    p_addMethod(g_cls, p_sel("setFrameSize:"), (void *)imp_setFrameSize, "v@:{CGSize=dd}");
    p_addMethod(g_cls, p_sel("animateOneFrame"), (void *)imp_animate, "v@:");
    p_addMethod(g_cls, p_sel("drawRect:"), (void *)imp_draw, "v@:{CGRect={CGPoint=dd}{CGSize=dd}}");
    p_addMethod(g_cls, p_sel("hasConfigureSheet"), (void *)imp_hasConfigureSheet, "B@:");
    p_addMethod(g_cls, p_sel("configureSheet"), (void *)imp_configureSheet, "@@:");
    p_register(g_cls);

    Ivar iv = p_getIvar(g_cls, "aw_state");
    if (!iv) return 0;
    g_off = p_ivarOffset(iv);

    s_setNeedsDisplay = p_sel("setNeedsDisplay:");
    s_setAnimInterval = p_sel("setAnimationTimeInterval:");
    s_currentContext = p_sel("currentContext");
    s_CGContext = p_sel("CGContext");
    c_NSGraphicsContext = p_getClass("NSGraphicsContext");
    return 1;
}

#ifdef AW_MOCK
int aw_mock_register(void) { return aw_register_class(); }
void *aw_mock_imps(int which) {
    switch (which) {
        case 0: return (void *)imp_init;
        case 1: return (void *)imp_animate;
        case 2: return (void *)imp_draw;
        case 3: return (void *)imp_setFrameSize;
        case 4: return (void *)imp_dealloc;
    }
    return NULL;
}
ptrdiff_t aw_mock_offset(void) { return g_off; }
#else
__attribute__((constructor)) static void aw_on_load(void) { aw_register_class(); }
#endif
