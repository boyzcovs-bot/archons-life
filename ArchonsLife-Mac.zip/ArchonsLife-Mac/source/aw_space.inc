/* aw_space.inc - things that pass by in space: a fleet of original little spaceships and the floating alien jellyfish.
 * Every ship is built from simple shapes on a tiny character canvas, then outlined and drawn (so it can face either way). */

typedef struct { char c[22][38]; } Cv;
static void cv_clear(Cv *v) { memset(v->c, '.', sizeof v->c); }
static void cv_px(Cv *v, int x, int y, char ch) { if ((unsigned)x < 38u && (unsigned)y < 22u) v->c[y][x] = ch; }
static void cv_rect(Cv *v, int x, int y, int w, int h, char ch) { for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) cv_px(v, x + i, y + j, ch); }
static void cv_ell(Cv *v, float cx, float cy, float rx, float ry, char ch) {
    for (int y = 0; y < 22; y++) for (int x = 0; x < 38; x++) {
        float dx = ((float)x - cx) / rx, dy = ((float)y - cy) / ry;
        if (dx * dx + dy * dy <= 1.0f) v->c[y][x] = ch;
    }
}
static void cv_tri(Cv *v, float x0, float y0, float x1, float y1, float x2, float y2, char ch) {
    float d = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2);
    if (fabsf(d) < 0.001f) return;
    for (int y = 0; y < 22; y++) for (int x = 0; x < 38; x++) {
        float px = (float)x + 0.5f, py = (float)y + 0.5f;
        float a = ((y1 - y2) * (px - x2) + (x2 - x1) * (py - y2)) / d;
        float b = ((y2 - y0) * (px - x2) + (x0 - x2) * (py - y2)) / d;
        if (a >= 0.0f && b >= 0.0f && 1.0f - a - b >= 0.0f) v->c[y][x] = ch;
    }
}
static void cv_line(Cv *v, int x0, int y0, int x1, int y1, char ch) {
    int n = imax(abs(x1 - x0), abs(y1 - y0));
    for (int i = 0; i <= n; i++) cv_px(v, x0 + (n ? (x1 - x0) * i / n : 0), y0 + (n ? (y1 - y0) * i / n : 0), ch);
}
static void cv_draw(AWWorld *w, const Cv *v, int cw, int ch, int x0, int y0, int flip) {
    for (int y = -1; y <= ch; y++) for (int x = -1; x <= cw; x++) {          /* a dark outline around the whole shape */
        int on = (unsigned)x < (unsigned)cw && (unsigned)y < (unsigned)ch && v->c[y][x] != '.';
        if (on) continue;
        int nb = 0;
        if (x > 0 && y >= 0 && y < ch && x - 1 < cw && v->c[y][x - 1] != '.') nb = 1;
        if (x + 1 < cw && x + 1 >= 0 && y >= 0 && y < ch && v->c[y][x + 1] != '.') nb = 1;
        if (y > 0 && x >= 0 && x < cw && y - 1 < ch && v->c[y - 1][x] != '.') nb = 1;
        if (y + 1 < ch && y + 1 >= 0 && x >= 0 && x < cw && v->c[y + 1][x] != '.') nb = 1;
        if (nb) BLEND(w, x0 + (flip ? cw - 1 - x : x), y0 + y, 0x14102A, 205);
    }
    for (int y = 0; y < ch; y++) for (int x = 0; x < cw; x++) {
        char c = v->c[y][x];
        if (c != '.') PX(w, x0 + (flip ? cw - 1 - x : x), y0 + y, sp_col(c, 0));
    }
}

/* the fleet: shuttle, dart scout, freighter, rubber duck, ladybug, crystal cruiser, whale, probe, asteroid miner */
#define NSHIP 9
static int ship_build(Cv *v, int kind, float t, int *ex, int *ey, int *fl, int *fk) {
    int cw = 30, blink = ((int)(t * 2.5f)) & 1;
    cv_clear(v);
    *fk = 0; *fl = 5; *ex = 0; *ey = 8;
    switch (kind) {
        case 0:   /* shuttle: white orbiter, black nose, delta wing */
            cw = 31;
            cv_tri(v, 2, 0, 10, 6, 2, 6, 'W'); cv_rect(v, 3, 3, 3, 1, 'R');
            cv_rect(v, 3, 6, 22, 5, 'W'); cv_ell(v, 25, 8, 6, 2.7f, 'W'); cv_ell(v, 29, 8, 2.4f, 2.0f, 'k');
            cv_rect(v, 3, 10, 22, 1, 'k'); cv_rect(v, 21, 6, 5, 1, 'c');
            cv_tri(v, 9, 11, 23, 11, 3, 14, 'G'); cv_tri(v, 9, 11, 17, 11, 6, 13, 'S');
            cv_rect(v, 0, 7, 3, 3, 'Z'); *ex = 0; *ey = 8; *fl = 6; break;
        case 1:   /* dart scout: sleek swept arrowhead */
            cv_tri(v, 17, 6, 3, 0, 9, 6, 'R'); cv_tri(v, 17, 10, 3, 16, 9, 10, 'R');
            cv_ell(v, 15, 8, 13, 3.2f, 'W'); cv_ell(v, 25, 8, 4.5f, 2.2f, 'R');
            cv_rect(v, 7, 8, 11, 1, 'R'); cv_ell(v, 18, 6, 4, 2, 'c'); cv_px(v, 17, 5, 'W'); cv_px(v, 18, 5, 's');
            cv_rect(v, 0, 6, 4, 5, 'Z'); cv_rect(v, 1, 7, 2, 3, 'A'); *ey = 8; *fl = 6; *fk = 1; break;
        case 2:   /* freighter: a spine of colourful cargo boxes with a bridge at the front */
            cw = 36;
            cv_rect(v, 5, 9, 27, 3, 'S'); cv_rect(v, 5, 9, 27, 1, 'G');
            cv_rect(v, 7, 2, 8, 7, 'R'); cv_rect(v, 7, 8, 8, 1, 'r'); cv_rect(v, 11, 2, 1, 6, 'r');
            cv_rect(v, 16, 2, 8, 7, 'B'); cv_rect(v, 16, 8, 8, 1, 'N'); cv_rect(v, 20, 2, 1, 6, 'N');
            cv_rect(v, 25, 4, 6, 5, 'y'); cv_rect(v, 25, 8, 6, 1, 'q'); cv_rect(v, 28, 4, 1, 4, 'q');
            cv_rect(v, 31, 5, 5, 7, 'G'); cv_rect(v, 32, 6, 4, 2, 'c'); cv_rect(v, 31, 11, 5, 1, 'A'); cv_px(v, 35, 5, '.');
            cv_rect(v, 0, 7, 6, 6, 'Z'); cv_rect(v, 1, 8, 2, 4, 'A'); cv_rect(v, 10, 12, 6, 2, 'A'); cv_rect(v, 21, 12, 6, 2, 'A');
            cv_px(v, 33, 9, blink ? 'R' : 'r'); cv_px(v, 12, 14, blink ? 'y' : 'q');
            *ey = 10; *fl = 7; break;
        case 3:   /* rubber duck with a bubble helmet */
            cw = 27;
            cv_ell(v, 11, 12, 10, 5, 'y'); cv_ell(v, 19, 6, 4.5f, 4.5f, 'y');
            cv_rect(v, 22, 5, 5, 2, 'o'); cv_rect(v, 23, 7, 4, 1, 'f'); cv_rect(v, 20, 4, 1, 2, 'k');
            cv_ell(v, 10, 13, 5, 3, 'q'); cv_tri(v, 3, 8, 0, 5, 6, 10, 'y');
            cv_ell(v, 9, 7, 4, 3.4f, 'l'); cv_px(v, 7, 5, 'W'); cv_px(v, 8, 5, 'W');
            cv_ell(v, 9, 8, 1.7f, 1.7f, 'O'); cv_px(v, 8, 8, 'K'); cv_px(v, 10, 8, 'K');
            cv_rect(v, 0, 13, 3, 3, 'Z'); *ex = 0; *ey = 14; *fl = 4; *fk = 2; break;
        case 4:   /* ladybug pod */
            cw = 26;
            cv_ell(v, 11, 8, 10, 6.5f, 'R');
            for (int y = 11; y < 22; y++) for (int x = 0; x < 38; x++) v->c[y][x] = '.';
            cv_rect(v, 1, 10, 21, 1, 'k'); cv_rect(v, 11, 2, 1, 8, 'k');
            cv_rect(v, 5, 5, 3, 3, 'k'); cv_rect(v, 14, 4, 3, 3, 'k'); cv_rect(v, 16, 8, 2, 2, 'k'); cv_rect(v, 7, 8, 2, 2, 'k');
            cv_ell(v, 22, 8, 3.4f, 3, 'k'); cv_px(v, 23, 6, 'W'); cv_px(v, 22, 4, 'k'); cv_px(v, 23, 3, 'k'); cv_px(v, 21, 3, 'k'); cv_px(v, 24, 4, 'k');
            cv_ell(v, 9, 1, 5, 1.2f, 'l'); cv_px(v, 6, 11, 'k'); cv_px(v, 13, 11, 'k'); cv_px(v, 19, 11, 'k');
            cv_rect(v, 0, 7, 2, 3, 'Z'); *ey = 8; *fl = 3; break;
        case 5:   /* crystal cruiser: a glowing gem */
            cw = 26;
            cv_tri(v, 13, 0, 2, 6, 24, 6, 's'); cv_rect(v, 2, 6, 23, 3, 'c'); cv_tri(v, 2, 9, 24, 9, 13, 15, 'U');
            cv_tri(v, 13, 1, 8, 6, 13, 6, 'W'); cv_rect(v, 4, 7, 18, 1, 'l'); cv_line(v, 13, 9, 13, 14, 's');
            cv_tri(v, 2, 6, 0, 3, 5, 6, 'v'); cv_tri(v, 2, 9, 0, 12, 5, 9, 'v');
            cv_ell(v, 13, 7, 2.2f, 1.6f, 'W'); *ex = 1; *ey = 7; *fl = 5; *fk = 3; break;
        case 6:   /* whale ship with portholes */
            cw = 32;
            cv_ell(v, 16, 8, 14, 6, 'B'); cv_ell(v, 18, 11, 11, 3, 'b');
            cv_tri(v, 5, 8, 0, 1, 8, 6, 'B'); cv_tri(v, 5, 8, 0, 15, 8, 10, 'B');
            cv_ell(v, 11, 6, 1.7f, 1.7f, 'l'); cv_ell(v, 16, 5, 1.7f, 1.7f, 'l'); cv_px(v, 11, 6, 'W'); cv_px(v, 16, 5, 'W');
            cv_rect(v, 26, 6, 2, 2, 'W'); cv_px(v, 27, 7, 'k'); cv_line(v, 29, 10, 23, 11, 'n');
            cv_px(v, 22, 3, 's'); cv_px(v, 23, 2, 's'); *ex = 3; *ey = 8; *fl = 5; *fk = 4; break;
        case 7:   /* probe: solar wings and a dish */
            cv_rect(v, 11, 6, 8, 8, 'S'); cv_rect(v, 11, 6, 8, 2, 'G'); cv_rect(v, 12, 12, 6, 1, 'A');
            cv_rect(v, 0, 7, 10, 6, 'N'); cv_rect(v, 20, 7, 10, 6, 'N');
            for (int x = 2; x < 10; x += 3) { cv_rect(v, x, 7, 1, 6, 'B'); cv_rect(v, 28 - x + 1, 7, 1, 6, 'B'); }
            cv_rect(v, 0, 10, 10, 1, 'B'); cv_rect(v, 20, 10, 10, 1, 'B');
            cv_rect(v, 10, 9, 1, 2, 'A'); cv_rect(v, 19, 9, 1, 2, 'A');
            cv_ell(v, 15, 3, 4.5f, 2, 'W'); cv_ell(v, 15, 4, 4, 1.2f, 'G'); cv_rect(v, 15, 5, 1, 2, 'A'); cv_px(v, 15, 0, 'A');
            cv_px(v, 15, 9, blink ? 'R' : 'r'); *fl = 0; break;
        default:  /* asteroid miner: chunky, with a drill nose and a grabber arm */
            cw = 36;
            cv_rect(v, 8, 3, 18, 9, 'y'); cv_rect(v, 8, 10, 18, 2, 'q'); cv_rect(v, 8, 3, 18, 1, 't');
            cv_rect(v, 20, 4, 6, 4, 'c'); cv_px(v, 21, 5, 'W');
            cv_tri(v, 26, 4, 26, 12, 35, 8, 'A'); cv_rect(v, 29, 6, 1, 5, 'S'); cv_rect(v, 31, 7, 1, 3, 'S');
            cv_rect(v, 7, 12, 20, 2, 'Z'); cv_px(v, 10, 13, 'A'); cv_px(v, 16, 13, 'A'); cv_px(v, 22, 13, 'A');
            cv_line(v, 8, 5, 3, 1, 'S'); cv_line(v, 3, 1, 0, 3, 'S'); cv_px(v, 0, 4, 'S');
            cv_rect(v, 5, 5, 3, 6, 'Z'); cv_px(v, 14, 2, blink ? 'R' : 'r'); cv_rect(v, 11, 6, 1, 3, 'k'); cv_rect(v, 17, 6, 1, 3, 'k');
            *ex = 4; *ey = 8; *fl = 5; break;
    }
    return cw;
}
static void ship_flame(AWWorld *w, int x, int y, int away, int len, int kind, float t) {   /* away = +1 flame goes right, -1 left */
    static const Col FA[4][4] = { { 0xFFFFFF, 0xFFE45E, 0xFFA030, 0xFF5A2A }, { 0xFFFFFF, 0x9FE8FF, 0x3FB6D8, 0x2F5FC8 },
                                  { 0xFFFFFF, 0xFFF59A, 0xFFB050, 0xFF8FB8 }, { 0xFFFFFF, 0xFFD2F4, 0xFF7AD9, 0xB58CFF } };
    const Col *c = FA[kind & 3];
    float fl = 0.72f + 0.28f * sinf(t * 31.0f + (float)len);
    int n = (int)((float)len * fl + 0.5f);
    for (int i = 0; i < n; i++) {
        int hh = i < n / 3 ? 1 : 0;
        Col col = i == 0 ? c[0] : (i < n / 3 + 1 ? c[1] : (i < n * 2 / 3 + 1 ? c[2] : c[3]));
        for (int k = -hh; k <= hh; k++) PX(w, x + away * (i + 1), y + k, col);
    }
}
static void draw_ship(AWWorld *w, int sx, int y, int dir, uint32_t h, float t) {
    Cv v;
    int kind = (int)(h % (uint32_t)NSHIP), ex, ey, fl, fk;
    int cw = ship_build(&v, kind, t, &ex, &ey, &fl, &fk);
    int flip = dir < 0;
    int x0 = sx - cw / 2, y0 = y - 8;
    if (fl > 0) {
        int fx = x0 + (flip ? cw - 1 - ex : ex) + (flip ? 1 : -1);
        ship_flame(w, fx, y0 + ey, flip ? 1 : -1, fl, fk, t);
        if (kind == 2) ship_flame(w, fx, y0 + ey + 2, flip ? 1 : -1, fl - 2, fk, t + 0.4f);
    }
    cv_draw(w, &v, cw, 22, x0, y0, flip);
    if (kind == 5) {                                                           /* the crystal glints */
        int ph = (int)(t * 5.0f) % 6;
        int gx = x0 + (flip ? cw - 1 - (6 + ph * 3) : 6 + ph * 3), gy = y0 + 3 + (ph & 1) * 4;
        PX(w, gx, gy, 0xFFFFFF); PX(w, gx - 1, gy, 0xCFF8FF); PX(w, gx + 1, gy, 0xCFF8FF); PX(w, gx, gy - 1, 0xCFF8FF); PX(w, gx, gy + 1, 0xCFF8FF);
    }
}

/* floating alien jellyfish: glowing pulsing bells with trailing tentacles, drifting in small groups */
static void draw_space_jelly(AWWorld *w, int sx, int y, uint32_t h, float t) {
    static const Col BODY[5] = { 0xFF7AD9, 0x7DF9FF, 0xB4F08E, 0xB58CFF, 0xFFC860 };
    static const Col RIM[5]  = { 0xFFD0F4, 0xD8FFFF, 0xE8FFC8, 0xE4D4FF, 0xFFF0B0 };
    int n = 1 + (int)((h >> 7) % 3u);
    static const int OX[3] = { 0, 15, -13 }, OY[3] = { 0, -10, 9 };
    static const float SC[3] = { 1.0f, 0.74f, 0.58f };
    for (int j = 0; j < n; j++) {
        int ci = (int)((h + (uint32_t)j * 2u) % 5u);
        Col bc = BODY[ci], rc = RIM[ci];
        float ph = t * 2.1f + (float)j * 1.7f + (float)(h & 15u);
        float pulse = 0.5f + 0.5f * sinf(ph);
        float sc = SC[j];
        int rx = (int)((7.0f + 1.6f * pulse) * sc + 0.5f), ry = (int)((5.0f - 1.0f * pulse) * sc + 0.5f);
        int bob = (int)floorf(sinf(t * 0.9f + (float)j * 2.0f) * 4.0f - pulse * 2.0f + 0.5f);
        int cx = sx + OX[j], cy = y + OY[j] + bob;
        /* glow */
        for (int dy = -rx - 7; dy <= rx + 9; dy++) for (int dx = -rx - 7; dx <= rx + 7; dx++) {
            int d2 = dx * dx + dy * dy, R2 = (rx + 7) * (rx + 7);
            if (d2 < R2 && d2 > rx * rx && ((dx + dy) & 1) == 0) BLEND(w, cx + dx, cy + dy, bc, 22);
        }
        /* tentacles: wavy strands that fade as they trail */
        int nt = 5 + (j == 0 ? 2 : 0);
        for (int i = 0; i < nt; i++) {
            float fx = ((float)i - (float)(nt - 1) * 0.5f) * (2.0f * sc + 0.4f);
            int len = (int)((9.0f + (float)((h >> (i * 2)) & 3u) * 3.0f + pulse * 3.0f) * sc);
            for (int k = 1; k <= len; k++) {
                int tx = cx + (int)floorf(fx + sinf(t * 2.6f + (float)i * 1.3f + (float)k * 0.45f) * (0.8f + (float)k * 0.14f) + 0.5f);
                int ty = cy + ry - 1 + k;
                BLEND(w, tx, ty, (k & 1) ? bc : rc, 215 - k * 210 / (len + 2));
            }
        }
        /* the bell: a translucent dome with a bright rim and glowing alien markings */
        for (int dy = -ry; dy <= 1; dy++) for (int dx = -rx; dx <= rx; dx++) {
            float u = (float)dx / (float)rx, v2 = (float)dy / (float)ry;
            if (u * u + v2 * v2 > 1.0f) continue;
            int rim = (u * u + v2 * v2 > 0.66f);
            if (dy == 1 && (dx & 1)) continue;                                 /* scalloped lower edge */
            BLEND(w, cx + dx, cy + dy, rim ? rc : bc, rim ? 225 : 175);
        }
        if (sc > 0.6f) {
            PX(w, cx - rx / 3, cy - ry / 2, 0xFFFFFF); PX(w, cx - rx / 3 + 1, cy - ry / 2, rc);                  /* shine */
            Col dot = lerpc(bc, 0xFFFFFF, 0.65f);
            PX(w, cx + 1, cy - ry + 2, dot); PX(w, cx - 2, cy - 1, dot); PX(w, cx + 3, cy - 2, dot);          /* markings */
            if (sc > 0.9f) { PX(w, cx - 2, cy - ry / 2 + 1, 0x1D1020); PX(w, cx + 2, cy - ry / 2 + 1, 0x1D1020); }  /* two little eyes */
        }
        /* a pair of antennae with glowing tips */
        if (j == 0) {
            int ax = (int)floorf(sinf(ph * 0.7f) * 1.0f + 0.5f);
            PX(w, cx - 3, cy - ry - 1, bc); PX(w, cx - 4 + ax, cy - ry - 2, rc); PX(w, cx - 4 + ax, cy - ry - 3, 0xFFFFFF);
            PX(w, cx + 3, cy - ry - 1, bc); PX(w, cx + 4 + ax, cy - ry - 2, rc); PX(w, cx + 4 + ax, cy - ry - 3, 0xFFFFFF);
        }
    }
}

/* ------------------------------------------------------------------ */
/* more of space: far-off planets, drifting asteroid fields, comets and meteor streaks (rocket trips only) */
/* ------------------------------------------------------------------ */
static void crescent_ball(AWWorld *w, int cx, int cy, int r, Col lit, Col rim) {
    for (int dy = -r; dy <= r; dy++)
        for (int dx = -r; dx <= r; dx++) {
            if (dx * dx + dy * dy > r * r + r / 2) continue;
            int ex = dx - r * 5 / 10, ey = dy - r * 4 / 10;
            if (ex * ex + ey * ey <= (r * 95 / 100) * (r * 95 / 100)) { if (((dx + dy) & 1) == 0) PX(w, cx + dx, cy + dy, 0x161B3C); continue; }
            PX(w, cx + dx, cy + dy, (dx * dx + dy * dy > (r - 2) * (r - 2)) ? rim : lit);
        }
}
static void far_planets(AWWorld *w) {
    if (w->oy < 30) return;
    const double par = 0.06;
    const int S = 380;
    int camL = (int)floor(w->cam * par);
    int k0 = floordiv(camL - 80, S), k1 = floordiv(camL + w->vw + 80, S);
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ 0x7A11U, (uint32_t)k);
        if (rfn(h, 9) > 0.74f) continue;
        int kind = (int)(rfn(h, 0) * 8.0f) % 8;
        int cx = k * S + 30 + (int)(rfn(h, 1) * (float)(S - 60)) - camL;
        float A = (float)w->gy + (float)w->vh * (0.20f + 1.05f * rfn(h, 2));
        int cy = (int)((float)w->gy - A);
        int r = 7 + (int)(rfn(h, 3) * 9.0f);
        switch (kind) {
            case 0:                                                                                     /* lava world: dark rock, glowing cracks */
                shaded_ball(w, cx, cy, r, 0x9A5A48, 0x5A2A22, 0x1E0C0A, 0x5A2A22, 0);
                for (int i = 0; i < 5; i++) {
                    int px0 = cx + (int)((rfn(h, 10 + i) - 0.5f) * r * 1.5f), py0 = cy + (int)((rfn(h, 20 + i) - 0.5f) * r * 1.5f);
                    if ((px0 - cx) * (px0 - cx) + (py0 - cy) * (py0 - cy) > (r - 2) * (r - 2)) continue;
                    int len = 2 + (int)(rfn(h, 30 + i) * 4.0f), sg = rfn(h, 40 + i) < 0.5f ? 1 : -1;
                    for (int j = 0; j < len; j++) { PX(w, px0 + j, py0 + (j / 2) * sg, 0xFF7A22); if (j & 1) PX(w, px0 + j, py0 + (j / 2) * sg - 1, 0xFFC040); }
                } break;
            case 1:                                                                                     /* purple gas giant with a storm eye */
                shaded_ball(w, cx, cy, r + 3, 0xE6C8FF, 0x9A6AD8, 0x3A1E6A, 0xB48AE8, 3);
                for (int dy = -2; dy <= 2; dy++) for (int dx = -3; dx <= 3; dx++) if (dx * dx * 2 + dy * dy * 4 <= 16) PX(w, cx - r / 3 + dx, cy + r / 4 + dy, (dx * dx * 2 + dy * dy * 4 <= 5) ? 0xFFB0D0 : 0xFF7AA8);
                break;
            case 2:                                                                                     /* jungle world with two little moons */
                shaded_ball(w, cx, cy, r, 0xCFFFD8, 0x3FA070, 0x14502F, 0x58C088, 0);
                for (int i = 0; i < 3; i++) disc(w, cx + (int)((rfn(h, 10 + i) - 0.5f) * r), cy + (int)((rfn(h, 20 + i) - 0.5f) * r), 1 + (int)(rfn(h, 30 + i) * 2.0f), 0xF4FFF4);
                shaded_ball(w, cx + r + 9, cy - r / 2 - 3, 2, 0xE8E8F0, 0xA8A8B8, 0x585868, 0xA8A8B8, 0);
                shaded_ball(w, cx - r - 7, cy + r / 2 + 2, 1, 0xF0D8B8, 0xC09870, 0x6A5030, 0xC09870, 0); break;
            case 3:                                                                                     /* candy world with a teal ring */
                draw_ring(w, cx, cy, r, 0, 0x8FE8F0);
                shaded_ball(w, cx, cy, r, 0xFFE0F0, 0xFF8FC8, 0x7A2F5A, 0xFFB8DA, 2);
                draw_ring(w, cx, cy, r, 1, 0x8FE8F0); break;
            case 4:                                                                                     /* golden crescent */
                crescent_ball(w, cx, cy, r + 2, 0xFFD870, 0xFFF4C0); break;
            case 5:                                                                                     /* a pair of worlds */
                shaded_ball(w, cx, cy, r, 0xCFF0FF, 0x5FA8E8, 0x1A3A78, 0x5FA8E8, 0);
                shaded_ball(w, cx + r * 2 + 1, cy - r / 2 - 4, imax(3, r / 2), 0xFFE0B0, 0xF08A3A, 0x7A3010, 0xF08A3A, 0); break;
            case 6:                                                                                     /* banded teal giant with a wide ring */
                draw_ring(w, cx, cy, r + 2, 0, 0xCFF4E8);
                shaded_ball(w, cx, cy, r + 2, 0xE0FFF4, 0x3FC4A8, 0x105046, 0x5FE0C8, 3);
                draw_ring(w, cx, cy, r + 2, 1, 0xCFF4E8); break;
            default:                                                                                    /* dusty world with ice caps and craters */
                shaded_ball(w, cx, cy, r, 0xE8C898, 0xA8845A, 0x4A3220, 0xA8845A, 0);
                for (int dx = -r / 2; dx <= r / 2; dx++) PX(w, cx + dx, cy - r + 1 + (dx * dx > r * r / 8 ? 1 : 0), 0xF4F8FF);
                for (int i = 0; i < 3; i++) disc(w, cx + (int)((rfn(h, 10 + i) - 0.5f) * r), cy + (int)((rfn(h, 20 + i) - 0.5f) * r * 0.8f + 1.0f), 1, 0x6A5030);
                break;
        }
    }
}

/* a little tumbling rock: lit on the upper left */
static void rock_px(AWWorld *w, int cx, int cy, int r, uint32_t h) {
    static const Col BASE[4] = { 0x8A7A6A, 0x7A7C88, 0x9A8466, 0x6E6A78 };
    Col b = BASE[h & 3u];
    disc(w, cx, cy, r, b);
    PX(w, cx - r / 2, cy - r / 2, mulc(b, 1.45f));
    if (r >= 2) { PX(w, cx - r / 2 + 1, cy - r / 2, mulc(b, 1.25f)); PX(w, cx + r / 2, cy + r / 2, mulc(b, 0.6f)); PX(w, cx + r / 2 - 1, cy + r / 2, mulc(b, 0.7f)); }
    if (r >= 3) { PX(w, cx + 1, cy - 1, mulc(b, 0.65f)); PX(w, cx - 1, cy + 1, mulc(b, 0.75f)); }
}
static void asteroid_fields(AWWorld *w) {
    if (w->oy < 30) return;
    const double par = 0.30;
    const int S = 330;
    int camL = (int)floor(w->cam * par);
    int k0 = floordiv(camL - 70, S), k1 = floordiv(camL + w->vw + 70, S);
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ 0xA57E01DU, (uint32_t)k);
        if (rfn(h, 9) > 0.60f) continue;
        int cx = k * S + 40 + (int)(rfn(h, 1) * (float)(S - 80)) - camL;
        float A = (float)w->gy + (float)w->vh * (0.22f + 1.0f * rfn(h, 2));
        int cy = (int)((float)w->gy - A);
        int n = 5 + (int)(rfn(h, 3) * 5.0f);
        for (int i = 0; i < n; i++) {
            uint32_t hi = hash2(h, (uint32_t)(100 + i));
            int ox = (int)((rfn(hi, 0) - 0.5f) * 84.0f), oy2 = (int)((rfn(hi, 1) - 0.5f) * 30.0f);
            int r = 1 + (int)(rfn(hi, 2) * rfn(hi, 3) * 3.4f);
            int bob = (int)floorf(sinf((float)w->t * (0.35f + 0.3f * rfn(hi, 4)) + rfn(hi, 5) * 6.28f) * 1.6f + 0.5f);
            rock_px(w, cx + ox, cy + oy2 + bob, r, hi >> 8);
        }
    }
}

/* comets and meteors: screen-space streaks, only up in space */
static void comets_meteors(AWWorld *w) {
    float sp = clampf((w->dark - 0.45f) * 4.0f, 0.0f, 1.0f);
    if (sp <= 0.0f) return;
    /* comet: a bright icy head with a long fading tail, drifting slowly across the sky */
    {
        const double PERIOD = 17.0, DUR = 6.0;
        long slot = (long)floor(w->t / PERIOD);
        uint32_t h = hash2(w->seed ^ 0xC03E7U, (uint32_t)slot);
        double lt = (w->t - slot * PERIOD) - 1.0 - rfn(h, 0) * 4.0;
        if (rfn(h, 7) < 0.8f && lt > 0.0 && lt < DUR) {
            float u = (float)(lt / DUR);
            float fade = fminf(1.0f, fminf(u * 6.0f, (1.0f - u) * 6.0f)) * sp;
            float hx = (float)w->vw * (1.06f - 1.18f * u), hy = (float)w->vh * (0.10f + 0.34f * rfn(h, 1)) + u * (float)w->vh * (0.22f + 0.15f * rfn(h, 2));
            float ang = atan2f(0.22f + 0.15f * rfn(h, 2), -1.18f);
            float tdx = -cosf(ang), tdy = -sinf(ang);                       /* the tail points away from where it is going */
            for (int i = 1; i < 64; i++) {
                float f = 1.0f - (float)i / 64.0f;
                int a = (int)(255.0f * f * sqrtf(f) * fade);
                float wob = sinf((float)i * 0.21f + rfn(h, 3) * 6.0f) * 0.9f;
                int x = (int)(hx + tdx * (float)i), y = (int)(hy + tdy * (float)i + wob) - w->oy;
                int wd = i < 10 ? 1 : (i < 30 ? 2 : 3);
                for (int k = -wd; k <= wd; k++) if (k == 0 || abs(k) == 1 || ((i + k) & 1) == 0) BLEND(w, x, y + k, i < 14 ? 0xE8FAFF : 0x8FC8FF, k == 0 ? a : (abs(k) == 1 ? a * 6 / 10 : a * 3 / 10));
                if (i > 6 && ((i + (int)w->t * 3) & 3) == 0) BLEND(w, x - 1, y + wd + 2 + i / 14, 0xFFE9A8, a / 3);            /* the dusty yellow tail curves off below */
            }
            int hx2 = (int)hx, hy2 = (int)hy - w->oy;
            for (int dy = -5; dy <= 5; dy++) for (int dx = -5; dx <= 5; dx++) { int d2 = dx * dx + dy * dy; if (d2 <= 25 && d2 > 5 && ((dx + dy) & 1) == 0) BLEND(w, hx2 + dx, hy2 + dy, 0xCFF0FF, (int)((d2 < 12 ? 110.0f : 60.0f) * fade)); }
            for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) BLEND(w, hx2 + dx, hy2 + dy, (dx == 0 && dy == 0) ? 0xFFFFFF : 0xE8F8FF, (int)(255.0f * fade));
        }
    }
    /* meteors: quick fiery streaks, a couple of lanes so there is usually one somewhere */
    for (int lane = 0; lane < 3; lane++) {
        const double PERIOD = 3.1 + 1.3 * (double)lane;
        long slot = (long)floor(w->t / PERIOD);
        uint32_t h = hash2(w->seed ^ (0x3E7E0U + (uint32_t)lane * 977U), (uint32_t)slot);
        double lt = (w->t - slot * PERIOD) - rfn(h, 0) * (PERIOD - 0.9);
        if (rfn(h, 8) > 0.82f || lt < 0.0 || lt > 0.62) continue;
        float u = (float)(lt / 0.62);
        float dxv = -(float)w->vw * (0.22f + 0.18f * rfn(h, 3)), dyv = (float)w->vh * (0.12f + 0.16f * rfn(h, 4));
        float sx = (float)w->vw * (0.30f + 0.75f * rfn(h, 1)) + u * dxv, sy = (float)w->vh * (0.04f + 0.55f * rfn(h, 2)) + u * dyv;
        float L = sqrtf(dxv * dxv + dyv * dyv), ux = -dxv / L, uy = -dyv / L;
        int tl = 14 + (int)(rfn(h, 5) * 12.0f);
        float fade = fminf(1.0f, fminf(u * 8.0f, (1.0f - u) * 4.0f)) * sp;
        static const Col FIRE[4] = { 0xFFFFFF, 0xFFE070, 0xFF9A30, 0xFF4A1C };
        for (int i = 1; i < tl; i++) {
            float f = 1.0f - (float)i / (float)tl;
            int a = (int)(255.0f * f * fade);
            int x = (int)(sx + ux * (float)i), y = (int)(sy + uy * (float)i) - w->oy;
            BLEND(w, x, y, FIRE[imin(3, i * 4 / tl)], a);
            if (i < tl / 2 && ((i + lane) & 1) == 0) BLEND(w, x, y + 1, FIRE[imin(3, 1 + i * 4 / tl)], a / 2);
            if (i > tl / 3 && ((i * 7 + (int)slot) & 5) == 0) BLEND(w, x + (int)(rfn(hash2(h, (uint32_t)i), 0) * 3.0f) - 1, y + 2, 0xFF7A28, a / 3);   /* sparks */
        }
        int hx = (int)sx, hy = (int)sy - w->oy;
        BLEND(w, hx, hy, 0xFFFFFF, (int)(255.0f * fade)); BLEND(w, hx + 1, hy, 0xFFF0C0, (int)(220.0f * fade));
        BLEND(w, hx, hy + 1, 0xFFC890, (int)(220.0f * fade)); BLEND(w, hx + 1, hy + 1, 0xE0A070, (int)(180.0f * fade));
    }
}
