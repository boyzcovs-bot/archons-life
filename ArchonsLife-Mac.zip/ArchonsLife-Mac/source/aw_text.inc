/*
 * Archon's Life - pixel fonts and the info panels (time / date / temperature)
 * that scroll past on signposts, blimps, balloon banners and space satellites.
 * Included by aw_engine.c after the world struct is defined.
 */

/* the easter-egg days (aw_holiday.inc) */
enum { H_NONE, H_XMAS_EVE, H_XMAS, H_VALENTINE, H_THANKS, H_CNY, H_VETS, H_NEWYEAR, H_HALLOWEEN, H_NYE, H_EASTER, H_PRESIDENTS, H_N };
static void hol_decorate_sign(AWWorld *w, int x, int y, int pw, int ph);

/* ---- 3x5 font: letters, digits, a few symbols (rows top->bottom, bit2 = left) ---- */
static const unsigned char F35_L[26][5] = {
    {2,5,7,5,5},{6,5,6,5,6},{3,4,4,4,3},{6,5,5,5,6},{7,4,6,4,7},{7,4,6,4,4},{3,4,5,5,3},{5,5,7,5,5},
    {7,2,2,2,7},{1,1,1,5,2},{5,5,6,5,5},{4,4,4,4,7},{5,7,7,5,5},{6,5,5,5,5},{2,5,5,5,2},{6,5,6,4,4},
    {2,5,5,6,3},{6,5,6,5,5},{3,4,2,1,6},{7,2,2,2,2},{5,5,5,5,7},{5,5,5,5,2},{5,5,7,7,5},{5,5,2,5,5},
    {5,5,2,2,2},{7,1,2,4,7},
};
static const unsigned char F35_D[10][5] = {
    {7,5,5,5,7},{2,6,2,2,7},{7,1,7,4,7},{7,1,7,1,7},{5,5,7,1,1},{7,4,7,1,7},{7,4,7,5,7},{7,1,1,1,1},{7,5,7,5,7},{7,5,7,1,7},
};
static const unsigned char *glyph35(char c) {
    if (c >= 'A' && c <= 'Z') return F35_L[c - 'A'];
    if (c >= '0' && c <= '9') return F35_D[c - '0'];
    return NULL;
}
static int text35_w(const char *s, int S) { int n = (int)strlen(s); return n ? n * 4 * S - S : 0; }
static void text35(AWWorld *w, int x, int y, const char *s, int S, Col col) {
    for (; *s; s++, x += 4 * S) {
        const unsigned char *g = glyph35(*s);
        if (!g) continue;
        for (int r = 0; r < 5; r++)
            for (int c = 0; c < 3; c++)
                if (g[r] & (4 >> c)) R(w, x + c * S, y + r * S, S, S, col);
    }
}

/* ---- 5x7 font for the big numbers (rows top->bottom, bit4 = left) ---- */
static const unsigned char F57[13][7] = {
    {0x0E,0x11,0x13,0x15,0x19,0x11,0x0E},   /* 0 */
    {0x04,0x0C,0x04,0x04,0x04,0x04,0x0E},   /* 1 */
    {0x0E,0x11,0x01,0x02,0x04,0x08,0x1F},   /* 2 */
    {0x1F,0x02,0x04,0x02,0x01,0x11,0x0E},   /* 3 */
    {0x02,0x06,0x0A,0x12,0x1F,0x02,0x02},   /* 4 */
    {0x1F,0x10,0x1E,0x01,0x01,0x11,0x0E},   /* 5 */
    {0x06,0x08,0x10,0x1E,0x11,0x11,0x0E},   /* 6 */
    {0x1F,0x01,0x02,0x04,0x08,0x08,0x08},   /* 7 */
    {0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E},   /* 8 */
    {0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C},   /* 9 */
    {0x1F,0x10,0x10,0x1E,0x10,0x10,0x10},   /* F */
    {0x0E,0x11,0x10,0x10,0x10,0x11,0x0E},   /* C */
    {0x00,0x00,0x00,0x0E,0x00,0x00,0x00},   /* - */
};
static void draw57(AWWorld *w, int x, int y, char c, int U, Col col) {
    int gi = -1;
    if (c >= '0' && c <= '9') gi = c - '0';
    else if (c == 'F') gi = 10; else if (c == 'C') gi = 11; else if (c == '-') gi = 12;
    if (gi < 0) return;
    for (int r = 0; r < 7; r++)
        for (int cc = 0; cc < 5; cc++)
            if (F57[gi][r] & (16 >> cc)) R(w, x + cc * U, y + r * U, U, U, col);
}

/* Every display gets its own LED colours (main digits, accent for colon / AM-PM / date number, third tone for the month).
 * Neighbouring signs always differ, so each new display you pass looks different. */
#define NINK 24
static const Col INKS[NINK][3] = {
    { 0xFFF3C2, 0xFFD23F, 0x7FE0FF },   /* warm cream + amber (the original) */
    { 0x8CFFB8, 0x2FE88A, 0xD6FFE8 },   /* green LED */
    { 0x86EBFF, 0x2FB6F5, 0xE4FAFF },   /* cyan */
    { 0xFFA3DA, 0xFF4FA3, 0xFFDCF0 },   /* hot pink */
    { 0xFF9A78, 0xFF4A2A, 0xFFD2B8 },   /* red-orange */
    { 0xDDFF74, 0x9AE82A, 0xF6FFCC },   /* lime */
    { 0xD0B4FF, 0x9A6CFF, 0xEBE0FF },   /* violet */
    { 0xFFFFFF, 0x9FD8FF, 0xD6E6F5 },   /* ice white */
    { 0xFFD94F, 0xFF9A1F, 0xFFF0A8 },   /* gold */
    { 0x6CFFE6, 0x1FD8B8, 0xCCFFF6 },   /* teal */
    { 0xFFB35A, 0xFF7A00, 0xFFE2B8 },   /* pure orange */
    { 0xFFB8E6, 0xFF6EC7, 0xFFE8F6 },   /* bubblegum pink */
    { 0xFF8CF0, 0xE020D0, 0xFFD0FA },   /* magenta */
    { 0xFF9C94, 0xFF5C5C, 0xFFD8D4 },   /* coral */
    { 0xFFF27A, 0xFFD400, 0xFFFAC8 },   /* sunshine yellow */
    { 0x9CD2FF, 0x3C9CFF, 0xDCEEFF },   /* sky blue */
    { 0xB4FFD8, 0x4CE6A0, 0xE6FFF2 },   /* mint */
    { 0x7AA8FF, 0x2F5CFF, 0xCCDCFF },   /* electric blue */
    { 0xE0C8FF, 0xB68CFF, 0xF4EAFF },   /* lavender */
    { 0xFF8E9E, 0xFF2D55, 0xFFD0D8 },   /* rose red */
    { 0xFFC9A8, 0xFF9468, 0xFFE8DA },   /* peach */
    { 0x8CFFF4, 0x00D4E0, 0xD0FFFB },   /* aqua */
    { 0xC8FF4A, 0x7ACC00, 0xEBFFB0 },   /* chartreuse */
    { 0xFFA07A, 0xFF4D8D, 0xFFE0C8 },   /* sunset */
};
static int ink_pick(uint32_t seed, int k) {
    static const int ST[4] = { 5, 7, 11, 13 };                  /* strides coprime to NINK, so every colour gets its turn */
    int a = ST[hash2(seed, 0x1AC0u) % 4u];
    int off = (int)(hash2(seed, 0x1AC1u) % (uint32_t)NINK);
    int j = (int)(hash2(seed ^ 0x1AC2u, (uint32_t)k) % 3u);     /* jitter keeps neighbouring signs different */
    int v = (a * k + off + j) % NINK; if (v < 0) v += NINK;
    return v;
}

static int date_fmt_pick(uint32_t seed, int k) {
    uint32_t q = hash2(seed ^ 0xDA7EU, (uint32_t)k) % 100u;
    return q < 28u ? 0 : (q < 46u ? 1 : (q < 68u ? 2 : (q < 86u ? 3 : 4)));
}
static const char *const WDAY_FULL[7] = { "SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY" };
static const char *const MONTH_FULL[12] = { "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER" };
static const char *const WDAY[7] = { "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT" };
static const char *const MONTH[12] = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };

/* ---- weather icons, 9x7 ---- */
SPDEF(IC_SUN,
    "....o....",
    ".o..o..o.",
    "..yyyyy..",
    "ooyyyyyoo",
    "..yyyyy..",
    ".o..o..o.",
    "....o....");
SPDEF(IC_MOON,
    "...WWWW..",
    "..WWW....",
    ".WWW.....",
    ".WWW.....",
    ".WWW.....",
    "..WWW....",
    "...WWWW..");
SPDEF(IC_CLOUD,
    "...WWW...",
    ".WWWWWWW.",
    "WWWWWWWWW",
    "WWWWWWWWW",
    ".GGGGGGG.",
    ".........",
    ".........");
SPDEF(IC_PARTLY,
    ".o.y.....",
    "..yyy.WW.",
    ".yyyWWWWW",
    "..yWWWWWW",
    "...WWWWWW",
    "....GGGG.",
    ".........");
SPDEF(IC_RAIN,
    "...WWW...",
    ".WWWWWWW.",
    "WWWWWWWWW",
    "WWWWWWWWW",
    ".GGGGGGG.",
    ".c..c..c.",
    "c..c..c..");
SPDEF(IC_SNOW,
    "...WWW...",
    ".WWWWWWW.",
    "WWWWWWWWW",
    "WWWWWWWWW",
    ".GGGGGGG.",
    ".s..s..s.",
    "..s..s..s");
SPDEF(IC_STORM,
    "...SSS...",
    ".SSSSSSS.",
    "SSSSSSSSS",
    "SSSSSSSSS",
    ".ZZZZZZZ.",
    "...yy....",
    "....y....");
SPDEF(IC_FOG,
    ".GGGGGGG.",
    "WWWWWWWWW",
    ".........",
    "GGGGGGGG.",
    ".........",
    ".GGGGGGGG",
    ".........");

static void blit_scaled(AWWorld *w, const Sp *s, int x, int y, int U) {
    for (int r = 0; r < s->h; r++) {
        int len = (int)strlen(s->r[r]);
        for (int c = 0; c < len; c++) {
            char ch = s->r[r][c];
            if (ch == '.' || ch == ' ') continue;
            R(w, x + c * U, y + r * U, U, U, sp_col(ch, 0));
        }
    }
}
static const Sp *weather_icon(int code, int is_day) {
    if (code == 0) return is_day ? &IC_SUN : &IC_MOON;
    if (code == 1 || code == 2) return is_day ? &IC_PARTLY : &IC_MOON;
    if (code == 3) return &IC_CLOUD;
    if (code == 45 || code == 48) return &IC_FOG;
    if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return &IC_RAIN;
    if ((code >= 71 && code <= 77) || code == 85 || code == 86) return &IC_SNOW;
    if (code >= 95) return &IC_STORM;
    return &IC_CLOUD;
}

/* ---- panel content: returns content width; draws when draw != 0 ---- */
enum { INFO_TIME, INFO_DATE, INFO_TEMP };

static int panel_U(const AWWorld *w) {
    int U = (w->vh + 32) / 64;
    return U < 1 ? 1 : (U > 3 ? 3 : U);
}

static int info_content(AWWorld *w, int info, int U, int x, int y, int draw, int *chh) {
    int cw = 0, ch = 7 * U;
    int S2 = (U >= 3) ? 2 : 1;
    const Col *ink = INKS[((unsigned)w->ink) % (unsigned)NINK];
    if (info == INFO_TIME) {
        int h = w->tm_hour, pm = h >= 12;
        if (!w->clock24) { h %= 12; if (h == 0) h = 12; }
        char hs[4], ms[4];
        snprintf(hs, sizeof hs, w->clock24 ? "%02d" : "%d", h);
        snprintf(ms, sizeof ms, "%02d", w->tm_min);
        int cx = x;
        for (const char *p = hs; *p; p++) { if (draw) draw57(w, cx, y, *p, U, ink[0]); cx += 6 * U; }
        if (draw && (w->tm_sec & 1) == 0) { R(w, cx - U + U, y + 2 * U, U, U, ink[1]); R(w, cx - U + U, y + 4 * U, U, U, ink[1]); }
        cx += 3 * U - U;
        for (const char *p = ms; *p; p++) { if (draw) draw57(w, cx, y, *p, U, ink[0]); cx += 6 * U; }
        cx -= U;
        if (!w->clock24) {
            cx += 2 * U;
            const char *ap = pm ? "PM" : "AM";
            if (draw) text35(w, cx, y + 7 * U - 5 * S2, ap, S2, ink[1]);
            cx += text35_w(ap, S2);
        }
        cw = cx - x;
    } else if (info == INFO_DATE) {
        char ds[4]; snprintf(ds, sizeof ds, "%d", w->tm_mday);
        int cx = x;
        for (const char *p = ds; *p; p++) { if (draw) draw57(w, cx, y, *p, U, ink[1]); cx += 6 * U; }
        cx -= U; cx += 2 * U;
        int S3 = (7 * U - 1) / 10; if (S3 < 1) S3 = 1;
        int lh = 5 * S3, gap = 7 * U - 2 * lh; if (gap < 1) { gap = 1; ch = 2 * lh + 1; }
        int fm = w->dfmt_force ? w->dfmt_force - 1 : w->dfmt;
        if (w->tm_year < 2000 && (fm == 1 || fm == 3 || fm == 4)) fm = 0;
        char l2b[24];
        const char *wd = WDAY[w->tm_wday % 7], *mo = MONTH[w->tm_mon % 12], *l1, *l2;
        switch (fm) {
            case 1: { snprintf(l2b, sizeof l2b, "%d", w->tm_year); l1 = mo; l2 = l2b; } break;
            case 2: l1 = WDAY_FULL[w->tm_wday % 7]; l2 = MONTH_FULL[w->tm_mon % 12]; break;
            case 3: { snprintf(l2b, sizeof l2b, "%d", w->tm_year); l1 = MONTH_FULL[w->tm_mon % 12]; l2 = l2b; } break;
            case 4: { snprintf(l2b, sizeof l2b, "%s %d", mo, w->tm_year); l1 = WDAY_FULL[w->tm_wday % 7]; l2 = l2b; } break;
            default: l1 = wd; l2 = mo; break;
        }
        if (draw) { text35(w, cx, y, l1, S3, ink[0]); text35(w, cx, y + lh + gap, l2, S3, ink[2]); }
        { int a1 = text35_w(l1, S3), a2 = text35_w(l2, S3); cx += a1 > a2 ? a1 : a2; }
        cw = cx - x;
    } else {
        const Sp *ic = weather_icon(w->w_code, w->w_isday);
        int cx = x;
        if (draw) blit_scaled(w, ic, cx, y, U);
        cx += 9 * U + 2 * U;
        float tc = w->w_temp_c;
        int tv = (int)floorf((w->fahrenheit ? tc * 9.0f / 5.0f + 32.0f : tc) + 0.5f);
        Col col = ink[0];
        char ts[8]; snprintf(ts, sizeof ts, "%d", tv);
        for (const char *p = ts; *p; p++) { if (draw) draw57(w, cx, y, *p, U, col); cx += 6 * U; }
        if (draw) {   /* degree ring */
            R(w, cx, y, 3 * U, U, col); R(w, cx, y + 2 * U, 3 * U, U, col);
            R(w, cx, y + U, U, U, col); R(w, cx + 2 * U, y + U, U, U, col);
        }
        cx += 3 * U + U;
        if (draw) draw57(w, cx, y, w->fahrenheit ? 'F' : 'C', U, col);
        cx += 5 * U;
        cw = cx - x;
    }
    if (chh) *chh = ch;
    return cw;
}

static void panel_dims(AWWorld *w, int info, int U, int *pw, int *ph) {
    int ch; int cw = info_content(w, info, U, 0, 0, 0, &ch);
    int pad = 2 * U + 1;
    *pw = cw + 2 * pad; *ph = ch + 2 * pad;
}

/* the lit screen itself */
static void panel_face(AWWorld *w, int x, int y, int info, int U) {
    int pw, ph; panel_dims(w, info, U, &pw, &ph);
    int pad = 2 * U + 1;
    R(w, x, y, pw, ph, 0x0A0F1E);
    R(w, x + 1, y + 1, pw - 2, ph - 2, 0x4A5C8C);
    R(w, x + 2, y + 2, pw - 4, ph - 4, 0x141C33);
    R(w, x + 2, y + ph - 4, pw - 4, 2, 0x10162A);
    /* faint scanline dither */
    for (int yy = y + 3; yy < y + ph - 3; yy += 2)
        for (int xx = x + 3 + ((yy >> 1) & 1); xx < x + pw - 3; xx += 2) BLEND(w, xx, yy, 0x2B3A66, 70);
    info_content(w, info, U, x + pad, y + pad, 1, NULL);
}

/* ---------------------------- carriers ---------------------------- */
static void carrier_signpost(AWWorld *w, int xc, int camI, int info, int U) {
    int pw, ph; panel_dims(w, info, U, &pw, &ph);
    int wx = xc + camI;
    int base = w->gy - ground_h(w, wx);
    int bottom = base - 20;
    int x = xc - pw / 2, y = bottom - ph;
    /* posts */
    R(w, x + pw / 5, bottom, 3, 20, 0x6B3E1F); R(w, x + pw / 5, bottom, 1, 20, 0x8A5A2B);
    R(w, x + pw - pw / 5 - 3, bottom, 3, 20, 0x6B3E1F); R(w, x + pw - pw / 5 - 3, bottom, 1, 20, 0x8A5A2B);
    /* wooden frame */
    R(w, x - 2, y - 2, pw + 4, ph + 4, 0x7A4A24);
    R(w, x - 2, y - 2, pw + 4, 1, 0xB27A43);
    R(w, x - 2, y + ph + 1, pw + 4, 1, 0x4F2F18);
    panel_face(w, x, y, info, U);
    hol_decorate_sign(w, x, y, pw, ph);
}

static void carrier_blimp(AWWorld *w, int xc, int camI, uint32_t k, int info, int U) {
    (void)camI;
    int pw, ph; panel_dims(w, info, U, &pw, &ph);
    float t = (float)w->t;
    /* the hull is an ellipse; size it so the screen's corners sit well inside it (>= ~8 px of margin all round) */
    int a = (int)((float)pw * 0.5f * 1.30f) + 10, b = (int)((float)ph * 0.5f * 1.55f) + 8;
    int yc = (int)(w->gy * 0.22f + (float)b + sinf(t * 0.7f + (float)k) * 2.5f);
    xc += (int)(sinf(t * 0.11f + (float)k * 1.7f) * 12.0f);
    /* envelope */
    for (int dy = -b - 1; dy <= b + 1; dy++) {
        float fy = (float)dy / (float)(b + 1);
        if (fy > 1.0f || fy < -1.0f) continue;
        int hw = (int)((float)(a + 1) * sqrtf(1.0f - fy * fy));
        R(w, xc - hw, yc + dy, hw * 2 + 1, 1, 0x7A869E);
    }
    for (int dy = -b; dy <= b; dy++) {
        float fy = (float)dy / (float)b;
        int hw = (int)((float)a * sqrtf(1.0f - fy * fy));
        Col c = fy < -0.55f ? 0xFFFFFF : (fy > 0.45f ? 0xB9C4D8 : 0xE4EAF4);
        R(w, xc - hw, yc + dy, hw * 2 + 1, 1, c);
    }
    /* tail fins (left) and gondola */
    R(w, xc - a - 1, yc - b / 2 - 3, 5, 9, 0xC0392B); R(w, xc - a - 4, yc - b / 2 - 6, 4, 6, 0xC0392B);
    R(w, xc - a - 1, yc + b / 2 - 4, 5, 9, 0xA52E22); R(w, xc - a - 4, yc + b / 2 + 2, 4, 6, 0xA52E22);
    R(w, xc - 8, yc + b + 1, 18, 6, 0x6B7A99); R(w, xc - 8, yc + b + 1, 18, 1, 0xA9B6D0);
    for (int i = 0; i < 4; i++) R(w, xc - 6 + i * 4, yc + b + 3, 2, 2, 0x9FE8FF);
    R(w, xc - 5, yc + b - 1, 1, 3, 0x7A869E); R(w, xc + 5, yc + b - 1, 1, 3, 0x7A869E);
    /* propeller */
    int ph_ = ((int)(t * 14.0f)) & 1;
    R(w, xc - a - 6, yc - 3 + ph_, 1, 6 - 2 * ph_ + 1, 0x4A4A5A);
    /* the screen */
    panel_face(w, xc - pw / 2, yc - ph / 2, info, U);
}

static float bg_night(const AWWorld *w);
static void rope_line(AWWorld *w, int x0, int y0, int x1, int y1, Col c) {
    int dx = abs(x1 - x0), dy = abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx - dy;
    for (int guard = 0; guard < 160; guard++) {
        PX(w, x0, y0, c);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x0 += sx; }
        if (e2 < dx) { err += dx; y0 += sy; }
    }
}

/* ---- balloons: sixteen different kinds, each with its own shape and pattern ---- */
enum { BS_EGG, BS_ROUND, BS_TALL, BS_HEART, BS_STAR, BS_SMILEY, BS_BEAR, BS_ZIG, BS_BANDS, BS_CLUSTER,
       BS_ARCHON, BS_FOX, BS_DISCO, BS_MOON, BS_FLOWER, BS_ROCKET, BS_LANTERN, BS_PUMPKIN, BS_FLAGB, BS_GHOST, BS_JACK, BS_N };
/* what a sign's balloons are picked from (hearts are twice as likely) */
static const unsigned char BAL_PICK[] = { BS_EGG, BS_ROUND, BS_TALL, BS_HEART, BS_HEART, BS_STAR, BS_SMILEY, BS_BEAR, BS_ZIG, BS_BANDS, BS_CLUSTER,
                                          BS_ARCHON, BS_FOX, BS_DISCO, BS_MOON, BS_FLOWER, BS_ROCKET };
#define BAL_NPICK ((int)sizeof(BAL_PICK))
static const Col BAL_COL[12][2] = {
    { 0xE8442A, 0xFFF3C2 }, { 0x4FA6F5, 0xFFFFFF }, { 0xA77BF0, 0xFFD23F }, { 0x2FC4B2, 0xFFF3C2 },
    { 0xFF7AB8, 0xFFFFFF }, { 0xFFD23F, 0xE8442A }, { 0x7DDB5C, 0xFFFFFF }, { 0xFF8A2A, 0xFFF3C2 },
    { 0xE0508A, 0xFFD6E8 }, { 0x3A6FD8, 0xFFD23F }, { 0x9AE8FF, 0xFFFFFF }, { 0x7449C4, 0xFF9EC8 },
};
/* is the point (u, v) inside the shape?  u, v in -1..1 (v grows downwards); tm is the time, for the ones that move */
static int bal_in(int st, float u, float v, float tm) {
    switch (st) {
        case BS_EGG: case BS_ZIG: {
            float f = (v + 1.0f) * 0.5f, hw;
            if (f < 0.7f) { float q = 1.0f - f / 0.7f; hw = sqrtf(fmaxf(0.0f, 1.0f - q * q * 0.98f)); }
            else hw = 1.0f - (f - 0.7f) / 0.3f * 0.55f;
            return fabsf(u) <= hw;
        }
        case BS_TALL: case BS_BANDS: {
            float f = (v + 1.0f) * 0.5f, hw;
            if (f < 0.78f) { float q = 1.0f - f / 0.78f; hw = sqrtf(fmaxf(0.0f, 1.0f - q * q)); }
            else hw = 1.0f - (f - 0.78f) / 0.22f * 0.5f;
            return fabsf(u) <= hw;
        }
        case BS_HEART: {
            float x = u * 1.18f, y = -(v - 0.12f) * 1.18f;
            float a = x * x + y * y - 1.0f;
            return a * a * a - x * x * y * y * y <= 0.0f;
        }
        case BS_STAR: {
            float r = sqrtf(u * u + v * v);
            if (r < 0.001f) return 1;
            float th = atan2f(u, -v);                                   /* 0 at the top point */
            float seg = fmodf(fabsf(th) * 5.0f / 6.2831853f, 1.0f);
            float tri = fabsf(seg - 0.5f) * 2.0f;                       /* 1 at a point, 0 in a notch */
            return r <= 0.42f + 0.58f * tri;
        }
        case BS_BEAR: {
            if (u * u + (v + 0.1f) * (v + 0.1f) / 0.9f <= 0.64f) return 1;
            float ex = fabsf(u) - 0.62f, ey = v + 0.72f;
            return ex * ex + ey * ey <= 0.12f;
        }
        case BS_ARCHON: {                                               /* a round face under a little crown */
            float by = (v - 0.2f) / 0.8f;
            if (u * u + by * by <= 1.0f) return 1;
            if (v >= -0.64f && v < -0.36f && fabsf(u) < 0.66f) return 1;                     /* crown band */
            if (v >= -1.0f && v < -0.60f) {
                static const float SC[3] = { -0.46f, 0.0f, 0.46f };
                for (int i = 0; i < 3; i++) if (fabsf(u - SC[i]) <= 0.24f * (v + 1.0f) / 0.40f) return 1;   /* three points */
            }
            return 0;
        }
        case BS_FOX: {
            float e = u * u / 0.9025f + (v - 0.22f) * (v - 0.22f) / 0.5776f;
            if (e <= 1.0f) return 1;
            if (v >= -1.0f && v < -0.12f) return fabsf(fabsf(u) - 0.60f) <= 0.30f * (v + 1.0f) / 0.88f;   /* pointed ears */
            return 0;
        }
        case BS_MOON: {                                                 /* a crescent, horns to the right */
            if (u * u + v * v > 1.0f) return 0;
            float cx = u - 0.46f, cy = v + 0.16f;
            return cx * cx + cy * cy > 0.62f * 0.62f;
        }
        case BS_FLOWER: {                                               /* six round petals, slowly turning */
            float r = sqrtf(u * u + v * v);
            if (r < 0.30f) return 1;
            float th = atan2f(v, u) + tm * 0.35f;
            return r <= 0.72f + 0.28f * cosf(6.0f * th);
        }
        case BS_ROCKET: {
            float f = (v + 1.0f) * 0.5f, hw;
            if (f < 0.34f) { float q = 1.0f - f / 0.34f; hw = 0.52f * sqrtf(fmaxf(0.0f, 1.0f - q * q)); }    /* nose cone */
            else if (f < 0.90f) { hw = 0.52f; if (f > 0.62f) hw += 0.44f * (f - 0.62f) / 0.28f; }          /* body, then swept fins */
            else hw = 0.28f;                                                                                /* nozzle */
            return fabsf(u) <= hw;
        }
        case BS_LANTERN: return u * u * u * u + v * v * v * v <= 0.80f;
        case BS_PUMPKIN: case BS_JACK: {
            if (v < -0.62f) return fabsf(u) < 0.16f && v > -1.0f;
            return u * u + (v + 0.10f) * (v + 0.10f) / 0.62f <= 1.0f;
        }
        case BS_GHOST: {                                                /* a sheet with a wobbling hem */
            if (v <= 0.10f) { float q = (v - 0.10f) / 1.10f; return u * u + q * q <= 1.0f; }
            return fabsf(u) <= 0.98f && v <= 0.70f + 0.28f * fabsf(sinf(u * 5.5f + tm * 2.4f));
        }
        default: return u * u + v * v <= 1.0f;
    }
}
static Col bal_col(int st, float u, float v, int dx, int dy, int hs, Col c1, Col c2, float tm) {
    Col c = c1;
    int sweep = (dx + dy + 400 - (int)(tm * 10.0f)) % 30 < 2;                     /* a glint that slides across the foil */
    switch (st) {
        case BS_EGG:  if (((dx + 100) / 4) % 3 == 1) c = c2; break;
        case BS_ZIG:  if (((dy + abs(dx) + 100) / 4) % 2 == 1) c = c2; break;
        case BS_BANDS: if (((dy + 100) / 5) % 2 == 1) c = c2; break;
        case BS_TALL: { int ro = ((dy + 100) / 5) & 1; if ((((dx + 100 + ro * 3) % 6) < 2) && ((dy + 100) % 5 < 2)) c = c2; } break;
        case BS_STAR: if (((dx + dy + 100) & 3) == 0) c = lerpc(c, 0xFFFFFF, 0.55f); if (sweep) c = lerpc(c, 0xFFFFFF, 0.7f); break;
        case BS_HEART: if (sweep) c = lerpc(c, 0xFFFFFF, 0.45f); break;
        case BS_SMILEY: {
            if ((fabsf(u + 0.34f) < 0.13f || fabsf(u - 0.34f) < 0.13f) && v > -0.38f && v < -0.02f) c = 0x1D1020;
            float d = sqrtf(u * u + (v - 0.05f) * (v - 0.05f));
            if (v > 0.18f && d > 0.46f && d < 0.64f) c = 0x1D1020;
            if (v > 0.1f && fabsf(u) > 0.5f && fabsf(u) < 0.68f && v < 0.3f) c = 0xFF8FB8;
        } break;
        case BS_BEAR: {
            if (u * u / 0.30f + (v - 0.28f) * (v - 0.28f) / 0.16f <= 1.0f) c = c2;                 /* muzzle */
            float ex = fabsf(u) - 0.62f, ey = v + 0.72f;
            if (ex * ex + ey * ey <= 0.04f) c = 0xE8A8A0;                                           /* inner ears */
            if ((fabsf(u + 0.36f) < 0.1f || fabsf(u - 0.36f) < 0.1f) && fabsf(v + 0.18f) < 0.11f) c = 0x1D1020;
            if (fabsf(u) < 0.13f && fabsf(v - 0.12f) < 0.09f) c = 0x1D1020;
        } break;
        case BS_ARCHON: {                                  /* c1 drifts through the hologram colours; the crown is gold */
            float by = (v - 0.2f) / 0.8f;
            if (u * u + by * by > 1.0f) {
                c = 0xFFD23F; if (v < -0.64f) c = lerpc(c, 0xFFF3C2, 0.35f);
                if (fabsf(u) < 0.14f && v > -0.62f && v < -0.40f) c = 0xFF4FA8;                      /* gem */
                break;
            }
            if (sweep) c = lerpc(c, 0xFFFFFF, 0.5f);
            if ((fabsf(u + 0.34f) < 0.12f || fabsf(u - 0.34f) < 0.12f) && v > 0.04f && v < 0.30f) c = 0x1D1020;    /* eyes */
            float d = sqrtf(u * u + (v - 0.24f) * (v - 0.24f));
            if (v > 0.42f && d > 0.27f && d < 0.45f) c = 0x1D1020;                                                /* smile */
            if (v > 0.30f && v < 0.48f && fabsf(u) > 0.50f && fabsf(u) < 0.70f) c = lerpc(c, 0xFFFFFF, 0.55f);     /* cheeks */
        } break;
        case BS_FOX: {
            float ex = fabsf(u) - 0.60f;
            if (v < -0.30f && fabsf(ex) < 0.15f * (v + 1.0f) / 0.5f && v < -0.42f) c = 0x7A2E18;                  /* inner ears */
            if (v > 0.12f && fabsf(u) > 0.50f - (v - 0.12f) * 1.15f) c = c2;                                        /* white cheeks */
            if (v > 0.52f && fabsf(u) < 0.22f - (v - 0.52f) * 0.4f) c = c2;                                         /* chin */
            if ((fabsf(u + 0.42f) < 0.11f || fabsf(u - 0.42f) < 0.11f) && v > -0.08f && v < 0.16f) c = 0x1D1020;   /* eyes */
            if (fabsf(u) < 0.14f && v > 0.40f && v < 0.56f) c = 0x1D1020;                                          /* nose */
        } break;
        case BS_DISCO: {                                   /* a mirror ball: little tiles, a few of them flashing */
            int tx = (dx + 100) / 4, ty = (dy + 100) / 4;
            static const Col MT[5] = { 0xE8ECF8, 0xB4BCD4, 0x9CD2EE, 0xEEC4E6, 0xCFD6E8 };
            uint32_t hq = hash2((uint32_t)(tx * 31 + ty * 7 + 5), 77u);
            c = MT[hq % 5u];
            float lit = 1.08f - 0.30f * sqrtf((u + 0.35f) * (u + 0.35f) + (v + 0.35f) * (v + 0.35f));   /* a round ball, lit from the top left */
            c = mulc(c, clampf(lit, 0.62f, 1.1f));
            if ((dx + 100) % 4 == 3 || (dy + 100) % 4 == 3) c = 0x5A6280;                                  /* grout between the mirrors */
            else { uint32_t q = hash2((uint32_t)(tx * 31 + ty), (uint32_t)(tm * 5.0f)); if ((q & 15u) < 2u) c = 0xFFFFFF; else if ((q & 15u) == 2u) c = 0xFFB8EC; else if ((q & 15u) == 3u) c = 0xA8F0FF; }   /* flashes */
        } break;
        case BS_MOON: {
            if (fabsf(u + 0.62f) < 0.16f && fabsf(v + 0.02f) < 0.07f) c = 0x6A5420;                              /* a sleepy eye */
            { float ux = u + 0.72f, vy = v - 0.26f; if (ux * ux + vy * vy < 0.02f) c = 0xFF9EB8; }               /* cheek */
            { float ux = u + 0.30f, vy = v + 0.62f; if (ux * ux + vy * vy < 0.012f) c = lerpc(c1, 0xB89A30, 0.5f); }   /* a crater */
        } break;
        case BS_FLOWER: {
            float r = sqrtf(u * u + v * v);
            if (r < 0.30f) { c = c2; if (r < 0.16f) c = 0xE8902A; }
            else if (r < 0.52f) c = lerpc(c, 0xFFFFFF, 0.28f);
        } break;
        case BS_ROCKET: {
            float f = (v + 1.0f) * 0.5f;
            c = 0xF4F4FA;
            if (f < 0.30f) c = c1;                                                                  /* nose */
            if (f > 0.60f && f < 0.67f) c = c1;                                                      /* stripe */
            if (fabsf(u) > 0.56f && f > 0.60f) c = c1;                                               /* fins */
            if (f >= 0.90f) c = 0x8A90A0;                                                            /* nozzle */
            { float ww = u * u + (v + 0.08f) * (v + 0.08f) * 0.9f; if (ww < 0.040f) c = 0x4FA6F5; else if (ww < 0.085f) c = 0x8A90A0; }   /* porthole */
            if (sweep && c == 0xF4F4FA) c = 0xBFD8FF;
        } break;
        case BS_LANTERN: {
            if (v < -0.74f || v > 0.74f) c = c2;
            else if (((dx + 100) % 5) == 0) c = lerpc(c, 0xFF8A7A, 0.45f);
            if (fabsf(u) + fabsf(v) < 0.40f) c = c2;
            if (fabsf(u) + fabsf(v) < 0.20f) c = c1;
        } break;
        case BS_PUMPKIN: {
            if (v < -0.62f) { c = 0x3F7A2A; break; }
            float ru = fabsf(u);
            if (ru < 0.07f || (ru > 0.30f && ru < 0.37f) || (ru > 0.62f && ru < 0.69f)) c = mulc(c, 0.76f);
            else if (ru < 0.2f) c = lerpc(c, 0xFFB060, 0.25f);
        } break;
        case BS_FLAGB: {
            c = (((dy + 100) / 2) & 1) ? 0xFFFFFF : 0xD6283A;
            if (u < 0.05f && v < -0.05f) { c = 0x23408E; if (((dx + dy + 100) & 3) == 0) c = 0xFFFFFF; }
        } break;
        case BS_GHOST: {                                   /* c1 sheet, c2 the dark face */
            if ((fabsf(u + 0.34f) < 0.15f || fabsf(u - 0.34f) < 0.15f) && v > -0.42f && v < 0.02f) c = c2;
            if (u * u / 0.050f + (v - 0.30f) * (v - 0.30f) / 0.040f <= 1.0f) c = c2;
        } break;
        case BS_JACK: {                                    /* c1 pumpkin, c2 the candle glow showing through the carving */
            float ru = fabsf(u);
            if (v < -0.62f) { c = 0x3F7A2A; break; }
            if (ru < 0.07f || (ru > 0.62f && ru < 0.69f)) c = mulc(c, 0.76f);
            if (v > -0.40f && v < -0.02f && ru > 0.16f && ru < 0.52f && (v + 0.40f) * 1.0f > (ru - 0.16f) * 0.9f) c = c2;      /* triangle eyes */
            if (v > 0.22f && v < 0.52f && ru < 0.58f && (((int)floorf(u * 6.0f + 20.0f)) & 1) == 0) c = c2;                      /* toothy grin */
            if (v > 0.22f && v < 0.30f && ru < 0.58f) c = c2;
        } break;
        default: break;
    }
    if (u > 0.55f) c = mulc(c, 0.82f);
    else if (u < -0.62f) c = lerpc(c, 0xFFFFFF, 0.22f);
    if (st != BS_STAR && st != BS_DISCO && st != BS_FLOWER && st != BS_ROCKET && u < -0.30f && u > -0.62f && v < -0.35f && v > -0.62f)
        c = lerpc(c, 0xFFFFFF, 0.32f);                     /* glossy highlight */
    (void)hs;
    return c;
}
static void draw_balloon_v(AWWorld *w, int cx, int bottom, int st, int rad, int ht, Col c1, Col c2, float tm) {
    int rw = rad, hs = ht;
    switch (st) {
        case BS_ROUND: case BS_SMILEY: case BS_DISCO: hs = 2 * rad; break;
        case BS_HEART: rw = rad; hs = 2 * rad; break;
        case BS_STAR: rw = rad + 3; hs = 2 * rad + 2; break;
        case BS_BEAR: rw = rad + 2; hs = 2 * rad + 4; break;
        case BS_TALL: case BS_BANDS: rw = rad * 3 / 4 + 1; hs = ht + 5; break;
        case BS_ARCHON: rw = rad; hs = 2 * rad + 4; break;
        case BS_FOX: rw = rad + 3; hs = 2 * rad + 3; break;
        case BS_MOON: rw = rad + 1; hs = 2 * rad + 2; break;
        case BS_FLOWER: rw = rad + 3; hs = 2 * rad + 6; break;
        case BS_ROCKET: rw = rad * 3 / 4 + 3; hs = ht + 7; break;
        case BS_LANTERN: rw = rad; hs = 2 * rad + 4; break;
        case BS_PUMPKIN: case BS_JACK: rw = rad + 2; hs = 2 * rad + 1; break;
        case BS_GHOST: rw = rad + 1; hs = 2 * rad + 5; break;
        case BS_FLAGB: hs = 2 * rad; break;
        default: break;
    }
    Col oc = c1;                                           /* the outline is a darker c1 for the multi-coloured ones */
    int top = bottom - hs;
    for (int dy = 0; dy < hs; dy++) {
        float v = ((float)dy + 0.5f) / ((float)hs * 0.5f) - 1.0f;
        for (int dx = -rw - 1; dx <= rw + 1; dx++) {
            float u = (float)dx / (float)(rw + 0.5f);
            if (!bal_in(st, u, v, tm)) continue;
            Col c = bal_col(st, u, v, dx, dy, hs, c1, c2, tm);
            float un = (float)(dx + 1) / (float)(rw + 0.5f), up = (float)(dx - 1) / (float)(rw + 0.5f);
            float vn_ = ((float)dy + 1.5f) / ((float)hs * 0.5f) - 1.0f, vp_ = ((float)dy - 0.5f) / ((float)hs * 0.5f) - 1.0f;
            int edge = dy == 0 || !bal_in(st, un, v, tm) || !bal_in(st, up, v, tm) || !bal_in(st, u, vn_, tm) || !bal_in(st, u, vp_, tm);
            if (edge) {
                Col base = (st == BS_SMILEY || st == BS_BEAR || st == BS_FOX || st == BS_MOON || st == BS_ARCHON) ? oc : c;
                if (st == BS_ROCKET) base = 0x8A90A8;
                c = mulc(base, 0.68f);
            }
            PX(w, cx + dx, top + dy, c);
        }
    }
    R(w, cx - 1, bottom, 3, 1, mulc(c1, 0.7f)); PX(w, cx, bottom + 1, mulc(c1, 0.6f));      /* knot */
}
/* three little balloons tied together */
static void draw_balloon_cluster(AWWorld *w, int cx, int bottom, int rad, uint32_t h) {
    int r2 = rad * 55 / 100 + 1;
    static const int OX[3] = { -8, 8, 0 }, OY[3] = { 3, 5, -9 };
    for (int i = 0; i < 3; i++) {
        const Col *p = BAL_COL[(h >> (i * 4)) % 12u];
        for (int dy = 0; dy < 2 * r2; dy++) {
            for (int dx = -r2; dx <= r2; dx++) {
                float u = (float)dx / (float)r2, v = ((float)dy + 0.5f) / (float)r2 - 1.0f;
                if (u * u + v * v > 1.0f) continue;
                Col c = p[0];
                if (u > 0.5f) c = mulc(c, 0.82f);
                if (u < -0.25f && u > -0.62f && v < -0.2f && v > -0.6f) c = lerpc(c, 0xFFFFFF, 0.4f);
                if (u * u + v * v > 0.7f) c = mulc(c, 0.7f);
                PX(w, cx + OX[i] + dx, bottom - 14 + OY[i] - 2 * r2 + dy + 8, c);
            }
        }
        rope_line(w, cx + OX[i], bottom - 14 + OY[i] + 8, cx, bottom, 0x4A3A2A);
    }
    R(w, cx - 1, bottom, 3, 1, 0x7A5A8A);
}

static void carrier_balloons(AWWorld *w, int xc, int camI, uint32_t k, int info, int U) {
    (void)camI;
    int pw, ph; panel_dims(w, info, U, &pw, &ph);
    float t = (float)w->t;
    int bob = (int)floorf(sinf(t * 0.8f + (float)k) * 2.0f + 0.5f);
    int rad = 11 + U, ht = 26 + 3 * U;
    int top = (int)(w->gy * 0.10f) + bob;
    int ybot = top + ht;
    int x0 = xc - pw / 2, x1 = xc + pw / 2;
    int sl = BAL_PICK[(k >> 3) % (uint32_t)BAL_NPICK], sr = BAL_PICK[(k >> 7) % (uint32_t)BAL_NPICK];
    if (w->bal_force) { sl = w->bal_force - 1; sr = (sl + 4) % BS_N; }
    int holb = 0;
    switch (w->hol) {
        case H_VALENTINE: sl = sr = BS_HEART; holb = 1; break;
        case H_THANKS:    sl = BS_PUMPKIN; sr = (k & 1u) ? BS_FLOWER : BS_PUMPKIN; holb = 1; break;
        case H_CNY:       sl = sr = BS_LANTERN; holb = 1; break;
        case H_VETS: case H_PRESIDENTS: sl = BS_FLAGB; sr = (k & 1u) ? BS_STAR : BS_FLAGB; holb = 1; break;
        case H_EASTER:    sl = BS_EGG; sr = (k & 1u) ? BS_FLOWER : BS_EGG; holb = 1; break;
        case H_NEWYEAR:   sl = BS_DISCO; sr = BS_STAR; if (k & 1u) { sl = BS_STAR; sr = BS_DISCO; } holb = 1; break;
        case H_NYE:       sl = BS_DISCO; sr = BS_MOON; if (k & 1u) { sl = BS_MOON; sr = BS_DISCO; } holb = 1; break;
        case H_HALLOWEEN: sl = BS_GHOST; sr = BS_JACK; if (k & 1u) { sl = BS_JACK; sr = BS_GHOST; } holb = 1; break;
        default: break;
    }
    if (!holb && sr == sl) sr = BAL_PICK[((k >> 7) % (uint32_t)BAL_NPICK + 3u + ((k >> 11) & 3u)) % (uint32_t)BAL_NPICK];   /* the two never match */
    if (!holb && sr == sl) sr = (sl + 5) % BS_N;
    int cl = (int)((k >> 13) % 12u), cr = (int)((k >> 17) % 12u);
    if (cr == cl) cr = (cr + 5) % 12;
    int by = ybot + 12 + bob / 2;                     /* board top */
    int bx[2] = { x0 + 2, x1 - 2 }, sty[2] = { sl, sr }, cc[2] = { cl, cr };
    for (int i = 0; i < 2; i++) {
        int st = sty[i];
        Col c1 = BAL_COL[cc[i]][0], c2 = BAL_COL[cc[i]][1];
        if (st == BS_SMILEY) { c1 = 0xFFD23F; c2 = 0xFFF3C2; }
        else if (st == BS_BEAR) { c1 = 0xB07A3A; c2 = 0xF0D8B0; }
        else if (st == BS_HEART) { static const Col HC[3] = { 0xE8304A, 0xFF5C9A, 0xFF7AB8 }; c1 = HC[cc[i] % 3]; c2 = 0xFFFFFF; }
        else if (st == BS_STAR) { c1 = (cc[i] & 1) ? 0xFFD23F : 0xC8D0E0; c2 = 0xFFFFFF; }
        else if (st == BS_ARCHON) { c1 = hsv_col(0.045f + t * 0.06f + 0.5f * (float)i, 0.70f, 0.98f); c2 = 0xFFD23F; }   /* a hologram that never settles */
        else if (st == BS_FOX) { c1 = 0xFF8A2A; c2 = 0xFFFFFF; }
        else if (st == BS_DISCO) { c1 = 0xC8D0E0; c2 = 0xFFFFFF; }
        else if (st == BS_MOON) { c1 = 0xFFE27A; c2 = 0xFFF6C8; }
        else if (st == BS_FLOWER) { static const Col FC[5] = { 0xFF7AB8, 0xFFFFFF, 0xA77BF0, 0xFF8A2A, 0x4FA6F5 }; c1 = FC[cc[i] % 5]; c2 = 0xFFD23F; }
        else if (st == BS_ROCKET) { static const Col RC[4] = { 0xE8442A, 0x4FA6F5, 0xA77BF0, 0x2FC4B2 }; c1 = RC[cc[i] % 4]; c2 = 0xFFFFFF; }
        else if (st == BS_LANTERN) { c1 = 0xE0202C; c2 = 0xFFC21F; }
        else if (st == BS_PUMPKIN) { c1 = 0xE8742A; c2 = 0x3F7A2A; }
        else if (st == BS_FLAGB) { c1 = 0xD6283A; c2 = 0xFFFFFF; }
        else if (st == BS_GHOST) { c1 = 0xF2F4FF; c2 = 0x20203A; }
        else if (st == BS_JACK) { c1 = 0xE8742A; c2 = 0xFFD23F; }
        if (w->hol == H_VALENTINE && st == BS_HEART) { c1 = i ? 0xFF5C9A : 0xE8203F; c2 = 0xFFFFFF; }
        if (w->hol == H_THANKS && st == BS_FLOWER) { c1 = 0xFFC21F; c2 = 0x7A4A24; }
        if (w->hol == H_NEWYEAR && st == BS_STAR) { c1 = 0xFFD23F; c2 = 0xFFFFFF; }
        if ((w->hol == H_VETS || w->hol == H_PRESIDENTS) && st == BS_STAR) { c1 = 0x4F7AE8; c2 = 0xFFFFFF; }
        if (w->hol == H_EASTER && (st == BS_EGG || st == BS_FLOWER)) {                     /* pastel eggs in the sky */
            static const Col EC[4][2] = { { 0xFFB3D1, 0xFFFFFF }, { 0xB8E6FF, 0xFFFFFF }, { 0xFFF3A0, 0xFFB3D1 }, { 0xB8F0C8, 0xFFFFFF } };
            c1 = EC[(cc[i] + i) & 3][0]; c2 = EC[(cc[i] + i) & 3][1];
        }
        int jit = (int)((k >> (20 + i * 3)) & 3u) - 1;                                  /* the balloons hang at slightly different heights */
        int bot = ybot + jit - (i ? bob / 2 : 0);
        int sway = (int)floorf(sinf(t * 0.9f + (float)(k & 255u) * 0.37f + 1.9f * (float)i) * 1.6f + 0.5f);   /* and drift a little in the breeze */
        int bxs = bx[i] + sway;
        int rd = rad;
        if (st == BS_HEART) { float ph = fmodf(t * 1.15f + 0.3f * (float)i, 1.0f); if (ph < 0.10f || (ph > 0.20f && ph < 0.28f)) rd = rad + 1; }   /* the hearts beat */
        /* the string, from the board corner up to the knot */
        rope_line(w, i ? x1 - 1 : x0 + 1, by - 1, bxs, bot + 1, 0x4A3A2A);
        if (st == BS_CLUSTER) draw_balloon_cluster(w, bxs, bot, rad, k >> (5 + i * 9));
        else draw_balloon_v(w, bxs, bot, st, rd, ht, c1, c2, t);
    }
    R(w, x0, by - 1, 2, ph + 2, 0x4A3A2A); R(w, x1 - 2, by - 1, 2, ph + 2, 0x4A3A2A);
    R(w, xc - pw / 2 - 1, by - 2, pw + 2, 1, 0x4A3A2A);
    panel_face(w, xc - pw / 2, by, info, U);
    hol_decorate_sign(w, xc - pw / 2, by, pw, ph);
}

/* ---- drones ---- */
static void drone_rotor(AWWorld *w, int x, int y, int half, int ph) {
    R(w, x - 1, y + 1, 3, 2, 0x2A2E3A);                                                    /* motor */
    R(w, x, y, 1, 1, 0x8A90A0);
    for (int dx = -half; dx <= half; dx++) {                                              /* the spinning blades: a soft blur disc */
        BLEND(w, x + dx, y - 1, 0xDCE6F8, 78 - 40 * abs(dx) / (half + 1));
        if ((abs(dx) + ph) % 5 == 0) PX(w, x + dx, y - 1, 0x1D2030);
    }
    PX(w, x - half, y - 1, 0x1D2030); PX(w, x + half, y - 1, 0x1D2030);
}
static void drone_lights(AWWorld *w, int xl, int xr, int y, float night, float t) {
    int on = ((int)(t * 2.0f)) & 1;
    Col l = on ? 0xFF4040 : 0x802020, r = on ? 0x40FF70 : 0x208040;
    PX(w, xl, y, l); PX(w, xr, y, r);
    if (night > 0.3f && on) {
        int a = (int)(110.0f * night);
        for (int dy = -3; dy <= 3; dy++) for (int dx = -3; dx <= 3; dx++) if (dx * dx + dy * dy <= 8) {
            BLEND(w, xl + dx, y + dy, 0xFF4040, a / 2); BLEND(w, xr + dx, y + dy, 0x40FF70, a / 2);
        }
    }
}
/* a single quadcopter seen side-on, `bw` wide; cx is its centre, y the top of the body */
static void draw_quad(AWWorld *w, int cx, int y, int bw, Col body, int ph, float night, float t) {
    int half = bw / 2;
    R(w, cx - half, y, bw, 5, body); R(w, cx - half, y, bw, 1, lerpc(body, 0xFFFFFF, 0.35f)); R(w, cx - half, y + 4, bw, 1, mulc(body, 0.6f));
    R(w, cx - half + 2, y + 2, bw - 4, 1, 0x7FF0FF);                                         /* light strip */
    R(w, cx - 2, y + 5, 5, 3, 0x1D2030); PX(w, cx, y + 6, 0xFFE070);                         /* camera ball */
    R(w, cx - half - 6, y + 1, 7, 1, 0x4A4F5C); R(w, cx + half, y + 1, 7, 1, 0x4A4F5C);       /* arms */
    drone_rotor(w, cx - half - 5, y - 2, 5, ph);
    drone_rotor(w, cx + half + 5, y - 2, 5, ph + 2);
    R(w, cx - half - 1, y + 5, 1, 4, 0x2A2E3A); R(w, cx + half, y + 5, 1, 4, 0x2A2E3A);       /* little landing legs */
    drone_lights(w, cx - half - 6, cx + half + 6, y + 3, night, t);
}
static void carrier_drone(AWWorld *w, int xc, int camI, uint32_t k, int info, int U) {
    (void)camI;
    int pw, ph; panel_dims(w, info, U, &pw, &ph);
    float t = (float)w->t, night = bg_night(w);
    int bob = (int)floorf(sinf(t * 1.1f + (float)k) * 2.0f + 0.5f);
    xc += (int)(sinf(t * 0.13f + (float)k * 2.3f) * 9.0f);
    int by = (int)(w->gy * 0.34f) + bob;                           /* board top */
    int x0 = xc - pw / 2, x1 = xc + pw / 2;
    int ph_ = ((int)(t * 20.0f)) & 3;
    static const Col BODY[6] = { 0xE6EAF2, 0x3A4050, 0xE8442A, 0x3A9CFF, 0xFFD23F, 0x7DDB5C };
    Col body = BODY[(k >> 6) % 6u];
    if ((k >> 3) & 1u) {
        /* one wide cargo drone, four rotors, four cables */
        int yb = by - 24 + (int)floorf(sinf(t * 0.9f + 1.0f) * 1.0f + 0.5f);
        int rxs[4] = { x0 - 3, x0 + pw / 3, x1 - pw / 3, x1 + 3 };
        R(w, x0 - 5, yb + 2, pw + 10, 2, 0x4A4F5C); R(w, x0 - 5, yb + 2, pw + 10, 1, 0x7A8090);   /* the carrier bar */
        for (int i = 0; i < 4; i++) drone_rotor(w, rxs[i], yb - 2, 6, ph_ + i);
        R(w, xc - 10, yb - 1, 21, 7, body); R(w, xc - 10, yb - 1, 21, 1, lerpc(body, 0xFFFFFF, 0.4f)); R(w, xc - 10, yb + 5, 21, 1, mulc(body, 0.6f));
        R(w, xc - 7, yb + 2, 15, 1, 0x7FF0FF);
        R(w, xc - 2, yb + 6, 5, 3, 0x1D2030); PX(w, xc, yb + 7, 0xFFE070);
        drone_lights(w, x0 - 5, x1 + 5, yb + 2, night, t);
        rope_line(w, x0 - 3, yb + 4, x0 + 1, by - 1, 0x2A2E3A); rope_line(w, x1 + 3, yb + 4, x1 - 1, by - 1, 0x2A2E3A);
        rope_line(w, x0 + pw / 3, yb + 4, x0 + pw / 3, by - 1, 0x2A2E3A); rope_line(w, x1 - pw / 3, yb + 4, x1 - pw / 3, by - 1, 0x2A2E3A);
    } else {
        /* two small drones, one at each end of the sign */
        for (int i = 0; i < 2; i++) {
            int dxm = i ? x1 - 4 : x0 + 4;
            int yb = by - 22 + (int)floorf(sinf(t * 1.3f + (float)i * 2.1f + (float)k) * 2.0f + 0.5f);
            Col bc = i ? BODY[(k >> 9) % 6u] : body;
            draw_quad(w, dxm, yb, 12, bc, ph_ + i, night, t);
            rope_line(w, dxm - 2, yb + 9, i ? x1 - 1 : x0 + 1, by - 1, 0x2A2E3A);
            rope_line(w, dxm + 2, yb + 9, i ? x1 - 1 : x0 + 1, by - 1, 0x2A2E3A);
        }
    }
    R(w, x0, by - 2, pw, 2, 0x4A4F5C); R(w, x0, by - 2, pw, 1, 0x7A8090);
    R(w, x0 - 1, by - 1, 1, ph + 2, 0x2A2E3A); R(w, x1, by - 1, 1, ph + 2, 0x2A2E3A);
    panel_face(w, x0, by, info, U);
}

/* ---- a flock of birds carrying the sign ---- */
static void draw_cbird(AWWorld *w, int x, int y, int fr, uint32_t h) {
    static const Col BC[8][3] = {
        { 0x4FA6F5, 0xF4F4F8, 0x2F5FC8 }, { 0xE8442A, 0xFFB09A, 0x9A2A1A }, { 0xFFD23F, 0xFFF3A0, 0xE0A020 }, { 0xFF7AB8, 0xFFD6E8, 0xE0508A },
        { 0x6CCB52, 0xB4F08E, 0x2F8F3A }, { 0xA77BF0, 0xD2B8FF, 0x7449C4 }, { 0xF4F4F8, 0xFFFFFF, 0xB8C4D8 }, { 0xFF9A2A, 0xFFD9A8, 0xD86A10 },
    };
    const Col *c = BC[h % 8u];
    /* drawn facing left: every rect/pixel below is mirrored about the bird's centre (x + 3) */
#define BR(a, b_, wd, ht, col) R(w, x + 7 - (a) - (wd), y + (b_), (wd), (ht), (col))
#define BP(a, b_, col)         PX(w, x + 6 - (a), y + (b_), (col))
    BR(0, 2, 7, 4, c[0]); BR(1, 1, 5, 1, c[0]); BR(1, 6, 5, 1, c[1]);                                    /* body */
    BR(1, 5, 5, 1, c[1]);
    BR(5, 0, 4, 4, c[0]); BP(8, 1, 0x1D1020);                                                            /* head + eye */
    BP(9, 2, 0xFF9A2A); BP(10, 2, 0xE8782A);                                                             /* beak */
    BR(-3, 3, 3, 2, c[2]); BP(-4, 2, c[2]);                                                              /* tail */
    if (fr) { BR(1, -3, 4, 3, c[2]); BP(4, -4, c[2]); BP(2, -4, lerpc(c[2], 0xFFFFFF, 0.3f)); }
    else    { BR(1, 3, 5, 3, c[2]); BR(1, 3, 5, 1, lerpc(c[2], 0xFFFFFF, 0.3f)); }
    BP(3, 7, 0xE8782A); BP(5, 7, 0xE8782A);                                                              /* feet */
#undef BR
#undef BP
}
static void carrier_birds(AWWorld *w, int xc, int camI, uint32_t k, int info, int U) {
    (void)camI;
    int pw, ph; panel_dims(w, info, U, &pw, &ph);
    float t = (float)w->t;
    int bob = (int)floorf(sinf(t * 1.0f + (float)k) * 1.5f + 0.5f);
    xc += (int)(sinf(t * 0.12f + (float)k * 1.9f) * 8.0f);
    int by = (int)(w->gy * 0.37f) + bob;
    int x0 = xc - pw / 2, x1 = xc + pw / 2;
    int n = pw > 90 ? 5 : 4;
    R(w, x0 - 1, by - 2, pw + 2, 2, 0x6B4A2A); R(w, x0 - 1, by - 2, pw + 2, 1, 0x9A7040);                /* a light wooden rail */
    for (int i = 0; i < n; i++) {
        float mid = (float)(n - 1) * 0.5f;
        int bcx = xc - pw / 2 - 6 + (pw + 12) * i / (n - 1);                                              /* the flock fans out above the sign */
        int tx = xc + (bcx - xc) * 3 / 4;                                                                 /* ...and the strings pull in to it */
        int lift = (int)((mid - fabsf((float)i - mid)) * 3.0f);                                           /* a shallow V formation */
        int bx = bcx - 4 + (int)floorf(sinf(t * 0.7f + (float)i * 1.7f) * 2.0f + 0.5f);
        int bobi = (int)floorf(sinf(t * 2.2f + (float)i * 1.3f + (float)k) * 1.5f + 0.5f);
        int bxy = by - 21 - lift * 2 + bobi;
        uint32_t hh = hash2(k, (uint32_t)i + 77u);
        rope_line(w, bx + 4, bxy + 7, tx, by - 2, 0x8A6A44);
        rope_line(w, bx + 5, bxy + 7, tx + 1, by - 2, 0x8A6A44);
        draw_cbird(w, bx, bxy, ((int)(t * 7.0f + (float)i * 1.3f)) & 1, hh);
    }
    R(w, x0, by - 1, 1, ph + 2, 0x6B4A2A); R(w, x1 - 1, by - 1, 1, ph + 2, 0x6B4A2A);
    panel_face(w, x0, by, info, U);
}

SPDEF(SAT_DISH,
    "..SSS..",
    ".S...S.",
    "S.....S",
    "...S...",
    "...S...");

static void carrier_satellite(AWWorld *w, int xc, uint32_t k, int info, int U, float acr) {
    int pw, ph; panel_dims(w, info, U, &pw, &ph);
    float off = (rfn(k, 5) - 0.5f) * 0.45f * (float)w->vh;
    int yc = (int)((float)w->gy - (acr + off)) + (int)floorf(sinf((float)w->t * 0.6f + (float)k) * 2.0f);
    int armw = 22 + 4 * U;
    /* solar arrays */
    for (int side = 0; side < 2; side++) {
        int ax0 = side == 0 ? xc - pw / 2 - 5 - armw : xc + pw / 2 + 5;
        R(w, ax0, yc - 7, armw, 14, 0x1D3A78);
        for (int gx = 0; gx <= armw; gx += 5) R(w, ax0 + gx - (gx == armw ? 1 : 0), yc - 7, 1, 14, 0xA8D8FF);
        R(w, ax0, yc, armw, 1, 0xA8D8FF);
        R(w, ax0, yc - 7, armw, 1, 0x4FA6F5); R(w, ax0, yc + 6, armw, 1, 0x0F2150);
        R(w, side == 0 ? ax0 + armw : ax0 - 5, yc - 1, 5, 2, 0x8FA3C0);
    }
    R(w, xc - pw / 2 - 2, yc - ph / 2 - 2, pw + 4, ph + 4, 0x8FA3C0);
    R(w, xc - pw / 2 - 2, yc - ph / 2 - 2, pw + 4, 1, 0xE6EEF8);
    panel_face(w, xc - pw / 2, yc - ph / 2, info, U);
    blit(w, &SAT_DISH, xc - 3, yc - ph / 2 - 7, 0, 0);
}

#include "aw_holiday.inc"

#define PSLOT 250
#define SSLOT 380
static int lm_panel_shift(AWWorld *w, int wx, int pwm, int wxL, int wxR, int *out);   /* aw_landmark.inc */
static void draw_panels(AWWorld *w) {
    int camI = (int)floor(w->cam);
    int U = panel_U(w);
    static const int SEQ[4] = { INFO_TIME, INFO_DATE, INFO_TIME, INFO_TEMP };
    int k0 = floordiv(camI - 220, PSLOT), k1 = floordiv(camI + w->vw + 220, PSLOT);
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ 0x1AF0U, (uint32_t)k);
        int info = SEQ[(k + (int)(w->seed >> 9)) & 3];
        if (info == INFO_TEMP && !w->w_valid) info = INFO_TIME;
        float r = rfn(h, 0);
        int xc = k * PSLOT + PSLOT / 2 + (int)((rfn(h, 2) - 0.5f) * 40.0f) - camI;
        if (!w->car_force) {   /* a sign never hangs in front of a landmark: it moves along to just beside it (or waits for the next one) */
            int pwm = 0, phh;
            for (int inf = 0; inf < 3; inf++) { int pwi; panel_dims(w, inf, U, &pwi, &phh); if (pwi > pwm) pwm = pwi; }
            uint32_t hl = hash2(w->seed ^ 0x1AF0U, (uint32_t)(k - 1)), hr = hash2(w->seed ^ 0x1AF0U, (uint32_t)(k + 1));
            int wxL = (k - 1) * PSLOT + PSLOT / 2 + (int)((rfn(hl, 2) - 0.5f) * 40.0f), wxR = (k + 1) * PSLOT + PSLOT / 2 + (int)((rfn(hr, 2) - 0.5f) * 40.0f);
            int nx, sh = lm_panel_shift(w, xc + camI, pwm, wxL, wxR, &nx);
            if (sh < 0) continue;
            xc = nx - camI;
        }
        if (r < 0.30f && (ground_h(w, xc + camI) < 0 || road_m(w, xc + camI) > 0.0f || pier_near(w, (double)(xc + camI)))) r = 0.9f;      /* no roadside posts standing in a lake: floating banners instead */
        w->ink = ink_pick(w->seed ^ 0xAB10u, k); w->dfmt = date_fmt_pick(w->seed ^ 0xAB10u, k);
        if (w->car_force == 1) r = 0.05f; else if (w->car_force == 2) r = 0.36f; else if (w->car_force == 3) r = 0.55f; else if (w->car_force == 4) r = 0.76f; else if (w->car_force == 5) r = 0.93f;
        int sleigh = 0;
        if (w->hol && !w->car_force) {        /* on a holiday the signs hang from the day's own things */
            if (w->hol == H_XMAS_EVE || w->hol == H_XMAS) { if (r >= 0.30f) sleigh = 1; }
            else r = r < 0.34f ? 0.05f : 0.50f;
        } else if (w->hol && w->car_force == 6) sleigh = 1;
        if (sleigh) carrier_sleigh(w, xc, camI, h, info, U);
        else if (r < 0.30f) carrier_signpost(w, xc, camI, info, U);
        else if (r < 0.44f) carrier_blimp(w, xc, camI, h, info, U);
        else if (r < 0.68f) carrier_balloons(w, xc, camI, h, info, U);
        else if (r < 0.85f) carrier_drone(w, xc, camI, h, info, U);
        else carrier_birds(w, xc, camI, h, info, U);
    }
    if (w->oy > 20) {
        float acr = 1.45f * (float)w->vh;
        int s0 = floordiv(camI - 260, SSLOT), s1 = floordiv(camI + w->vw + 260, SSLOT);
        for (int k = s0; k <= s1; k++) {
            uint32_t h = hash2(w->seed ^ 0x5A71U, (uint32_t)k);
            int info = SEQ[(k + (int)(w->seed >> 11)) & 3];
            if (info == INFO_TEMP && !w->w_valid) info = INFO_TIME;
            int xc = k * SSLOT + SSLOT / 2 + (int)((rfn(h, 2) - 0.5f) * 60.0f) - camI;
            w->ink = ink_pick(w->seed ^ 0xAB20u, k); w->dfmt = date_fmt_pick(w->seed ^ 0xAB20u, k);
            carrier_satellite(w, xc, h, info, U, acr);
        }
    }
}
