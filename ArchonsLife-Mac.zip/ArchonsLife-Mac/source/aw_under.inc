/*
 * Archon's Life - the ground beneath his feet.
 * Caves with stalactites and stalagmites, boulders, ores, geodes, crystals,
 * fossil slabs and the big dinosaur skeletons. Included from aw_extra.inc.
 * Everything is a pure function of (seed, world-x, depth) so the scenery never pops.
 */

typedef struct { int cx, cy, hw, hh, fl; uint32_t h; int tier; } UCave;
typedef struct { int x0, x1, y0, y1, kind, dir; uint32_t h; } UPiece;
#define U_MAXC 24
#define U_MAXP 24
#define U_CW 210      /* cave cell width  */
#define U_PW 120      /* skeleton cell width */

typedef struct { Col b, hi, sh, ol; } UBone;

static void u_line(AWWorld *w, int x0, int y0, int x1, int y1, int th, Col c) {
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
    for (int guard = 0; guard < 400; guard++) {
        R(w, x0, y0, th, th, c);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}
/* a bone: dark rim, bone body, light top edge, shadow underside, knobbed ends */
static void u_bone(AWWorld *w, int x0, int y0, int x1, int y1, int th, const UBone *B, int knob) {
    u_line(w, x0 - 1, y0 - 1, x1 - 1, y1 - 1, th + 2, B->ol);
    u_line(w, x0, y0, x1, y1, th, B->b);
    if (th >= 2) { u_line(w, x0, y0, x1, y1, 1, B->hi); u_line(w, x0, y0 + th - 1, x1, y1 + th - 1, 1, B->sh); }
    if (knob) {
        R(w, x0 - 1, y0 - 1, th + 2, th + 2, B->ol); R(w, x0 - 1, y0 - 1, th + 1, th + 1, B->b); PX(w, x0 - 1, y0 - 1, B->hi);
        R(w, x1 - 1, y1 - 1, th + 2, th + 2, B->ol); R(w, x1 - 1, y1 - 1, th + 1, th + 1, B->b); PX(w, x1 - 1, y1 - 1, B->hi);
    }
}

/* sprite blitter: auto outline, optional mirror. chars: b bone, h light, s shade, k hollow, t tooth */
static Col u_sc(char ch, const UBone *B) {
    switch (ch) {
        case 'b': return B->b;
        case 'h': return B->hi;
        case 's': return B->sh;
        case 'k': return 0x1B100C;
        case 't': return 0xFFF8E0;
        case 'x': return B->ol;
        default: return 0;
    }
}
static void u_sprite(AWWorld *w, const char *const *rows, int n, int sw, int x, int y, int flip, const UBone *B) {
    for (int pass = 0; pass < 2; pass++)
        for (int r = 0; r < n; r++) {
            int len = (int)strlen(rows[r]);
            for (int c = 0; c < len && c < sw; c++) {
                char ch = rows[r][c];
                if (ch == '.' || ch == ' ') continue;
                int px = flip ? x + (sw - 1 - c) : x + c, py = y + r;
                if (pass == 0) { PX(w, px - 1, py, B->ol); PX(w, px + 1, py, B->ol); PX(w, px, py - 1, B->ol); PX(w, px, py + 1, B->ol); }
                else PX(w, px, py, u_sc(ch, B));
            }
        }
}

static const char *const SPR_REX_BIG[] = {
    "..hhhhhhhhhhhhhhhh........",
    ".hbbbbbbbbbbbbbbbbhhh.....",
    "hbbbbbbbbbbbbbbbbbbbbbhh..",
    "bbbbbkkkbbbbbbkkbbbbbbbbh.",
    "bbbbkkkkkbbbkkkkbbbbbbbbbb",
    "bbbbbkkkbbbbkkkkbbbbbbbbbb",
    "sbbbbbbbbbbbbbbbbbbbbbbbbb",
    "ssbbbbbbbbbtbtbtbtbtbtbtbs",
    ".sskkkkkkkkkkkkkkkkkkkkkk.",
    "..sbbbbbbbbbtbtbtbtbtbtbb.",
    "...sbbbbbbbbbbbbbbbbbbbs..",
    "....ssbbbbbbbbbbbbbbsss...",
    ".....sssssssssssssss......",
};
static const char *const SPR_REX_SMALL[] = {
    "..hhhhhhhhhh..",
    ".hbbbbbbbbbbhh",
    "hbbbkkbbkkbbbb",
    "bbbkkkbbkkkbbb",
    "sbbbbbbbbbbbbb",
    "ssbtbtbtbtbtbt",
    ".skkkkkkkkkkk.",
    "..sbtbtbtbtbb.",
    "...ssssssssss.",
};
static const char *const SPR_SABRE[] = {
    "...hhhhhhhhhhh.......",
    "..hbbbbbbbbbbbhh.....",
    ".hbbbkkkbbbbbbbbbh...",
    "hbbbkkkkkbbbbbbbbbbh.",
    "bbbbbkkkbbbbbbbbbbbbk",
    "sbbbbbbbbbbbbbbbbbbbb",
    "ssbbbbbbbbbbbbtbbbtbt",
    ".sskkkkkkkkkkktkkkkkk",
    "..sbbbbbbbbbbbtbbbbb.",
    "...ssssssssssstssssss",
    ".............t.......",
};

static UBone u_bone_pal(const Pal *p) {
    UBone B;
    B.b = 0xD9CBA4; B.hi = 0xF4EACB; B.sh = 0xA59672;
    B.ol = lerpc(mulc(p->dirt_dk, 0.55f), 0x0C0706, 0.35f);
    return B;
}

/* ---- the big set pieces ---- */
static void u_rex_full(AWWorld *w, int ox, int oy, int d, const UBone *B) {
#define LX(v) (ox + d * (v))
    Col dark = B->ol;
    /* far hind leg (darker) */
    UBone F = *B; F.b = mulc(B->b, 0.82f); F.hi = mulc(B->hi, 0.82f); F.sh = mulc(B->sh, 0.82f);
    u_bone(w, LX(-2), oy - 11, LX(2), oy - 5, 2, &F, 1);
    u_bone(w, LX(2), oy - 5, LX(-3), oy - 1, 2, &F, 0);
    u_bone(w, LX(-3), oy - 1, LX(4), oy - 1, 2, &F, 1);
    /* tail: vertebrae tapering to a point */
    for (int i = 0; i < 16; i++) {
        int tx = -5 - i * 2, ty = -12 + (int)(i * 0.62f) + (i > 9 ? (i - 9) / 3 : 0);
        int th = i < 5 ? 4 : (i < 11 ? 3 : (i < 14 ? 2 : 1));
        R(w, LX(tx) - 1, oy + ty - 1, th + 2, th + 2, dark);
    }
    for (int i = 0; i < 16; i++) {
        int tx = -5 - i * 2, ty = -12 + (int)(i * 0.62f) + (i > 9 ? (i - 9) / 3 : 0);
        int th = i < 5 ? 4 : (i < 11 ? 3 : (i < 14 ? 2 : 1));
        R(w, LX(tx), oy + ty, th, th, (i & 1) ? B->b : B->hi);
        if (i > 1 && i < 12) PX(w, LX(tx), oy + ty + th + 1, B->sh);
    }
    /* back and neck */
    u_bone(w, LX(-5), oy - 12, LX(9), oy - 13, 2, B, 0);
    u_bone(w, LX(9), oy - 13, LX(14), oy - 18, 2, B, 0);
    for (int i = -4; i < 14; i += 3) PX(w, LX(i), oy - 13 + (i > 9 ? -(i - 9) : 0), dark);
    /* rib cage: chords of an ellipse */
    for (int rx = 0; rx <= 12; rx += 2) {
        float u = ((float)rx - 6.0f) / 7.0f;
        float e = sqrtf(fmaxf(0.0f, 1.0f - u * u));
        int bot = oy - 12 + (int)(8.5f * e);
        R(w, LX(rx), oy - 11, 1, bot - (oy - 11), B->b);
        PX(w, LX(rx), bot, B->sh); PX(w, LX(rx), oy - 11, B->hi);
    }
    R(w, LX(0), oy - 3, 1, 1, dark);
    /* near hind leg */
    u_bone(w, LX(-5), oy - 12, LX(-1), oy - 5, 3, B, 1);
    u_bone(w, LX(-1), oy - 5, LX(-6), oy - 1, 2, B, 0);
    u_bone(w, LX(-6), oy - 1, LX(2), oy - 1, 2, B, 1);
    PX(w, LX(3), oy, B->b); PX(w, LX(3), oy + 1, B->sh);
    /* tiny arms */
    u_bone(w, LX(11), oy - 11, LX(14), oy - 7, 1, B, 0);
    PX(w, LX(15), oy - 7, B->hi); PX(w, LX(15), oy - 6, B->hi);
    /* skull */
    const int sw = 14;
    u_sprite(w, SPR_REX_SMALL, 9, sw, d > 0 ? LX(13) : LX(13) - (sw - 1), oy - 24, d < 0, B);
#undef LX
}

static void u_ribcage(AWWorld *w, int ox, int oy, int d, const UBone *B) {
#define LX(v) (ox + d * (v))
    u_bone(w, LX(-18), oy - 3, LX(20), oy - 3, 2, B, 1);       /* spine along the bottom */
    for (int i = -16; i <= 18; i += 3) PX(w, LX(i), oy - 3, B->ol);
    for (int i = 0; i < 9; i++) {                               /* ribs: a row of curved C-shapes rising from the spine */
        int rx = -15 + i * 4, hgt = 15 - abs(i - 4) * 2;
        for (int pass = 0; pass < 2; pass++)
            for (int s = 0; s < hgt; s++) {
                float k = (float)s / (float)(hgt - 1);
                int cx = rx + (int)(sinf(k * 2.7f) * 5.0f);
                if (pass == 0) R(w, LX(cx) - 1, oy - 4 - s - 1, 3, 3, B->ol);
                else {
                    PX(w, LX(cx), oy - 4 - s, s > hgt - 3 ? B->hi : B->b);
                    if (s % 3 == 1) PX(w, LX(cx) + d, oy - 4 - s, B->sh);
                }
            }
    }
    /* a skull of some small thing resting at the end */
    u_sprite(w, SPR_REX_SMALL, 9, 14, d > 0 ? LX(22) : LX(22) - 13, oy - 9, d < 0, B);
#undef LX
}

static void u_trike(AWWorld *w, int ox, int oy, int d, const UBone *B) {
#define LX(v) (ox + d * (v))
    /* big bony frill: a shield sweeping up and back from the skull, scalloped rim, two windows */
    {
        float fa = 0.95f * (float)d;
        ell_fill(w, LX(-1), oy - 14, 13.6f, 8.6f, fa, B->ol, BIGY);
        ell_fill(w, LX(-1), oy - 14, 12.6f, 7.6f, fa, B->sh, BIGY);
        ell_fill(w, LX(-1), oy - 14, 11.2f, 6.2f, fa, B->b, BIGY);
        ell_fill(w, LX(-2), oy - 15, 8.0f, 3.2f, fa, B->hi, BIGY);
        ell_fill(w, LX(-4), oy - 16, 3.6f, 2.2f, fa, 0x1B100C, BIGY);
        ell_fill(w, LX(2), oy - 12, 3.0f, 2.0f, fa, 0x1B100C, BIGY);
        for (int i = 0; i < 9; i++) {                                 /* rim bumps */
            float a = 3.6f + (float)i * 0.36f, cs = cosf(fa), sn = sinf(fa);
            float ex = cosf(a) * 13.0f, ey = sinf(a) * 8.0f;
            int bx = (int)(ex * cs - ey * sn), by = (int)(ex * sn + ey * cs);
            R(w, LX(-1 + bx) - (d < 0 ? 1 : 0), oy - 14 + by - 1, 2, 2, B->hi);
        }
    }
    /* the face under the frill */
    u_bone(w, LX(3), oy - 9, LX(19), oy - 7, 7, B, 0);
    u_bone(w, LX(17), oy - 8, LX(23), oy - 3, 4, B, 0);          /* beak */
    ell_fill(w, LX(12), oy - 9, 1.6f, 1.6f, 0, 0x1B100C, BIGY);   /* eye */
    for (int i = 0; i < 5; i++) PX(w, LX(8 + i * 2), oy - 3, 0xFFF8E0);   /* teeth */
    /* two long brow horns and a short nose horn */
    u_bone(w, LX(10), oy - 11, LX(25), oy - 25, 2, B, 0);
    PX(w, LX(26), oy - 26, B->hi);
    u_bone(w, LX(7), oy - 11, LX(19), oy - 23, 2, B, 0);
    u_bone(w, LX(20), oy - 9, LX(24), oy - 14, 2, B, 0);
#undef LX
}

static void u_femur_pile(AWWorld *w, int ox, int oy, int d, const UBone *B) {
#define LX(v) (ox + d * (v))
    u_bone(w, LX(-14), oy - 2, LX(12), oy - 12, 3, B, 1);      /* giant leg bone */
    u_bone(w, LX(-12), oy - 8, LX(10), oy - 2, 2, B, 1);       /* a second bone crossing it */
    for (int i = 0; i < 6; i++) {                              /* vertebra beads */
        int cx = 8 + i * 4, cy = oy - 1 - (i % 2);
        R(w, LX(cx) - 1, cy - 3, 5, 5, B->ol);
        R(w, LX(cx), cy - 2, 3, 3, (i & 1) ? B->b : B->hi);
        PX(w, LX(cx) + 1, cy, B->ol);
    }
    u_sprite(w, SPR_REX_SMALL, 9, 14, d > 0 ? LX(-24) : LX(-24) - 13, oy - 9, d < 0, B);
#undef LX
}

static void u_nest(AWWorld *w, int ox, int oy, uint32_t h, const Pal *p) {
    Col straw = lerpc(p->dirt_dk, 0xA48A52, 0.55f), strawd = mulc(straw, 0.7f);
    for (int dx = -16; dx <= 16; dx++) {
        int sag = (int)((float)(dx * dx) / 90.0f);
        R(w, ox + dx, oy - 4 + sag, 1, 2, ((dx + (int)(h & 7)) % 3) ? straw : strawd);
    }
    static const int ex[5] = { -11, -3, 6, 13, 1 }, ey[5] = { -3, -4, -3, -2, -11 };
    for (int i = 0; i < 5; i++) {
        int cx = ox + ex[i], cy = oy + ey[i];
        ell_fill(w, cx, cy, 4.6f, 5.8f, 0, 0x3A2A1C, BIGY);
        ell_fill(w, cx, cy, 4.0f, 5.0f, 0, 0xE9DFC0, BIGY);
        ell_fill(w, cx + 1, cy + 1, 2.6f, 3.8f, 0, 0xCDBE98, BIGY);
        R(w, cx - 2, cy - 3, 1, 2, 0xFBF5DC);
        PX(w, cx - 1, cy + 1, 0x8C7A4E); PX(w, cx + 1, cy - 1, 0x8C7A4E); PX(w, cx, cy + 2, 0x8C7A4E);
        if (i == 3) {   /* a cracked one */
            for (int k = -3; k <= 3; k++) PX(w, cx + k, cy - 4 + (k & 1), 0x1B100C);
            R(w, cx - 1, cy - 3, 3, 1, 0x1B100C);
        }
    }
}

static void u_slab(AWWorld *w, int x, int y, int sw, int sh, Col g) {
    R(w, x - sw / 2 - 1, y - sh / 2, sw + 2, sh, mulc(g, 0.5f));
    R(w, x - sw / 2, y - sh / 2 - 1, sw, sh + 2, mulc(g, 0.5f));
    R(w, x - sw / 2, y - sh / 2, sw, sh, g);
    R(w, x - sw / 2, y - sh / 2, sw, 1, mulc(g, 1.25f));
    R(w, x - sw / 2, y + sh / 2 - 1, sw, 1, mulc(g, 0.8f));
    PX(w, x - sw / 2, y - sh / 2, mulc(g, 0.5f)); PX(w, x + sw / 2 - 1, y - sh / 2, mulc(g, 0.5f));
}
static void u_fish(AWWorld *w, int x, int y, int d) {
#define LX(v) (x + d * (v))
    Col f = 0xE9DFBF, fs = 0xB8A87E;
    u_line(w, LX(-9), y, LX(5), y, 1, f);                      /* backbone */
    for (int i = -7; i <= 3; i += 2) { R(w, LX(i), y - 3 + abs(i) / 5, 1, 3, f); R(w, LX(i), y + 1, 1, 3 - abs(i) / 5, fs); }
    ell_fill(w, LX(8), y, 3.8f, 3.0f, 0, f, BIGY);              /* head */
    PX(w, LX(9), y - 1, 0x3A2A1C); R(w, LX(5), y - 1, 1, 3, fs);
    PX(w, LX(11), y + 1, fs);
    u_line(w, LX(-9), y, LX(-13), y - 3, 1, f); u_line(w, LX(-9), y, LX(-13), y + 3, 1, f);   /* tail */
    PX(w, LX(-12), y - 1, fs); PX(w, LX(-12), y + 1, fs);
#undef LX
}
static void u_trilo(AWWorld *w, int x, int y) {
    Col f = 0xE4D8B4, fs = 0xA29270, fd = 0x4A3E30;
    ell_fill(w, x, y, 7.0f, 4.4f, 0, fs, BIGY);
    ell_fill(w, x, y - 1, 6.6f, 3.6f, 0, f, BIGY);
    ell_fill(w, x - 5, y, 3.4f, 4.0f, 0, f, BIGY);              /* head shield */
    PX(w, x - 6, y - 1, 0x3A2A1C); PX(w, x - 4, y - 1, 0x3A2A1C);
    for (int i = -2; i <= 6; i += 2) { R(w, x + i, y - 3, 1, 6, fd); }
    R(w, x - 2, y, 9, 1, fs);
    for (int i = -1; i <= 7; i += 2) { PX(w, x + i, y + 4, fs); PX(w, x + i, y - 4, fs); }
}
static void u_fern(AWWorld *w, int x, int y) {
    Col f = 0xCFC09A;
    u_line(w, x - 9, y + 3, x + 9, y - 3, 1, f);
    for (int i = -7; i <= 7; i += 2) {
        int cy = y - (i * 3) / 9;
        int len = 4 - abs(i) / 3;
        if (len < 1) len = 1;
        u_line(w, x + i, cy, x + i - 1, cy - len, 1, f);
        u_line(w, x + i, cy, x + i - 1, cy + len, 1, f);
    }
}

/* the dinosaur skeletons, and the bone-yard they sit in */
static void u_piece_draw(AWWorld *w, const UPiece *pc, int camI, const Pal *p) {
    UBone B = u_bone_pal(p);
    int ox = (pc->x0 + pc->x1) / 2 - camI, oy = w->gy + pc->y1;
    int d = pc->dir;
    uint32_t h = pc->h;
    switch (pc->kind) {
        case 0: u_rex_full(w, ox, oy, d, &B); break;
        case 1: u_sprite(w, SPR_REX_BIG, 13, 26, ox - 13, oy - 14, d < 0, &B); break;
        case 2: u_ribcage(w, ox, oy, d, &B); break;
        case 3: u_trike(w, ox, oy, d, &B); break;
        case 4: u_femur_pile(w, ox, oy, d, &B); break;
        case 5: u_nest(w, ox, oy, h, p); break;
        case 6: { Col g = lerpc(0x8A8478, p->dirt, 0.3f); u_slab(w, ox, oy - 7, 30, 16, g); u_fish(w, ox, oy - 7, d); } break;
        case 7: { Col g = lerpc(0x84807A, p->dirt, 0.3f); u_slab(w, ox, oy - 7, 24, 15, g); u_trilo(w, ox, oy - 7); } break;
        case 8: { Col g = lerpc(0x8A8478, p->dirt, 0.3f); u_slab(w, ox, oy - 7, 26, 15, g); u_fern(w, ox, oy - 7); } break;
        default: u_sprite(w, SPR_SABRE, 11, 21, ox - 10, oy - 12, d < 0, &B); break;
    }
}
static void u_piece_box(int kind, int *hw, int *ht) {
    static const int HW[10] = { 36, 15, 28, 18, 28, 20, 18, 15, 16, 12 };
    static const int HT[10] = { 27, 16, 17, 27, 16, 11, 17, 16, 16, 12 };
    *hw = HW[kind % 10] + 2; *ht = HT[kind % 10] + 2;
}

/* ---- caves ---- */
static int u_cave_get(AWWorld *w, int cell, int tier, UCave *c) {
    uint32_t h = hash2(w->seed ^ 0xCA7E5U ^ ((uint32_t)tier * 0x85EBCA6BU), (uint32_t)cell);
    if (rfn(h, 0) > 0.50f) return 0;
    c->h = h; c->tier = tier;
    c->hw = 22 + (int)(rfn(h, 1) * 15.0f);
    c->hh = 11 + (int)(rfn(h, 2) * 3.0f);
    c->fl = 6 + (int)(rfn(h, 6) * 2.0f);
    c->cx = cell * U_CW + c->hw + 8 + (int)(rfn(h, 3) * (float)(U_CW - 2 * c->hw - 16));
    c->cy = tier == 0 ? 27 + (int)(rfn(h, 4) * 4.0f) : 88 + (int)(rfn(h, 4) * 24.0f);
    for (int i = -c->hw; i <= c->hw; i += 5)
        if (c->cy - c->hh < -ground_h(w, c->cx + i) + 8) return 0;
    return 1;
}
static int u_gather_caves(AWWorld *w, int x0, int x1, UCave *out, int maxn) {
    int n = 0;
    for (int tier = 0; tier < 2; tier++)
        for (int cell = floordiv(x0 - 60, U_CW); cell <= floordiv(x1 + 60, U_CW); cell++) {
            UCave c;
            if (n < maxn && u_cave_get(w, cell, tier, &c)) out[n++] = c;
        }
    return n;
}
static int u_hit_cave(const UCave *cv, int n, int wx, int dep, int mx, int my) {
    for (int i = 0; i < n; i++)
        if (abs(wx - cv[i].cx) < cv[i].hw + mx && dep > cv[i].cy - cv[i].hh - my && dep < cv[i].cy + cv[i].fl + my) return 1;
    return 0;
}
static int u_hit_piece(const UPiece *pc, int n, int wx, int dep, int mx, int my) {
    for (int i = 0; i < n; i++)
        if (wx > pc[i].x0 - mx && wx < pc[i].x1 + mx && dep > pc[i].y0 - my && dep < pc[i].y1 + my) return 1;
    return 0;
}
static int u_gather_pieces(AWWorld *w, int x0, int x1, const UCave *cv, int ncv, UPiece *out, int maxn) {
    int n = 0;
    for (int tier = 0; tier < 2; tier++)
        for (int cell = floordiv(x0 - 60, U_PW); cell <= floordiv(x1 + 60, U_PW); cell++) {
            uint32_t h = hash2(w->seed ^ 0xB0E5U ^ ((uint32_t)tier * 0x27D4EB2FU), (uint32_t)cell);
            if (rfn(h, 0) > (tier == 0 ? 0.40f : 0.50f)) continue;
            int kind = (int)(rfn(h, 1) * 10.0f) % 10;
            int hw, ht; u_piece_box(kind, &hw, &ht);
            int cx = cell * U_PW + hw + 4 + (int)(rfn(h, 2) * (float)(U_PW - 2 * hw - 8 > 0 ? U_PW - 2 * hw - 8 : 1));
            int base = tier == 0 ? 34 + (int)(rfn(h, 3) * 5.0f) : 82 + (int)(rfn(h, 3) * 40.0f);
            if (base - ht < -ground_h(w, cx) + 9) continue;
            if (base - ht < -ground_h(w, cx - hw) + 9 || base - ht < -ground_h(w, cx + hw) + 9) continue;
            if (u_hit_cave(cv, ncv, cx, base - ht / 2, hw + 3, ht / 2 + 3)) continue;
            if (n >= maxn) continue;
            UPiece *pc = &out[n++];
            pc->x0 = cx - hw; pc->x1 = cx + hw; pc->y0 = base - ht; pc->y1 = base;
            pc->kind = kind; pc->dir = rfn(h, 4) < 0.5f ? 1 : -1; pc->h = h;
        }
    return n;
}

static void u_draw_cave(AWWorld *w, const UCave *c, int camI) {
    const Pal *p = &w->cur;
    float t = (float)w->t;
    int xs = c->cx - c->hw - camI, xe = c->cx + c->hw - camI;
    if (xe < -2 || xs > w->vw + 2) return;
    Col rim = lerpc(p->dirt_dk, 0x0C0706, 0.45f);
    Col rockc = lerpc(0xA89C8C, p->dirt, 0.30f);
    int pool = rfn(c->h, 8) < 0.40f;
    int poolA = -c->hw * 6 / 10 + (int)(rfn(c->h, 9) * (float)(c->hw / 2)), poolB = poolA + c->hw * 7 / 10;
    int crystal = rfn(c->h, 10) < 0.55f;
    static const Col gem[5] = { 0x7DF9FF, 0xFF7AD9, 0xB58CFF, 0x6CFF8A, 0xFFD23F };
    Col gc = gem[(int)(rfn(c->h, 11) * 5.0f) % 5];
    /* per-column ceiling and floor */
    int ycl[200], yfl[200];
    int ncol = c->hw * 2 + 1;
    if (ncol > 200) return;
    for (int i = 0; i < ncol; i++) {
        int dx = i - c->hw, wx = c->cx + dx;
        float u = (float)dx / (float)c->hw;
        float e = sqrtf(fmaxf(0.0f, 1.0f - u * u));
        uint32_t nh = hash2(c->h ^ 0x77U, (uint32_t)(wx >> 1));
        int nz = (int)(rfn(nh, 0) * 2.99f) - 1;
        ycl[i] = c->cy - (int)floorf((float)c->hh * powf(e, 0.8f) + 0.5f) - (e > 0.3f ? nz : 0);
        yfl[i] = c->cy + (int)floorf((float)c->fl * clampf(e * 2.4f, 0.0f, 1.0f) + 0.5f);
        if (yfl[i] <= ycl[i]) yfl[i] = ycl[i];
    }
    /* hollow */
    for (int i = 0; i < ncol; i++) {
        int dx = i - c->hw, wx = c->cx + dx, x = wx - camI;
        if ((unsigned)x >= (unsigned)w->vw) continue;
        for (int dep = ycl[i]; dep <= yfl[i]; dep++) {
            int e0 = dep == ycl[i], e1 = dep == yfl[i];
            Col col;
            if (e0 || (i > 0 && dep < ycl[i - 1] && dep > ycl[i] - 0)) col = rim;
            else {
                col = lerpc(mulc(dirt_px(p, wx + 7, dep + 3), 0.40f), 0x1A1024, 0.30f);
                col = lerpc(col, 0x0C0810, 0.25f + 0.2f * (float)(dep - ycl[i]) / (float)(yfl[i] - ycl[i] + 1) * 0.0f);
                if (((wx * 5 + dep * 11) % 23) == 0) col = lerpc(col, 0x6A5A7A, 0.35f);
            }
            if (e1) col = lerpc(p->dirt_dk, 0x2A1E22, 0.35f);
            if (i == 0 || i == ncol - 1) col = rim;
            PX(w, x, w->gy + dep, col);
        }
        if (yfl[i] - ycl[i] > 1) PX(w, x, w->gy + yfl[i] - 0, lerpc(p->dirt_lt, 0x2A1E22, 0.55f));
    }
    /* pool of water on the floor */
    if (pool) {
        for (int i = 0; i < ncol; i++) {
            int dx = i - c->hw;
            if (dx < poolA || dx > poolB) continue;
            int x = c->cx + dx - camI;
            for (int k = 1; k <= 2; k++) {
                Col wc = lerpc(p->liq, 0x0A1424, k == 1 ? 0.15f : 0.45f);
                PX(w, x, w->gy + yfl[i] - k + 1, wc);
            }
            if (((c->cx + dx + (int)(t * 4.0f)) & 7) == 0) PX(w, x, w->gy + yfl[i] - 1, lerpc(p->liq_hi, 0xFFFFFF, 0.4f));
        }
    }
    /* stalactites */
    int dropx = -9999, dropy = 0;
    for (int dx = -c->hw + 6, k = 0; dx < c->hw - 5; k++) {
        uint32_t sh = hash2(c->h ^ 0x57A1U, (uint32_t)k);
        int bw = 3 + 2 * (int)(rfn(sh, 0) * 1.99f);
        int i = dx + c->hw;
        if (i < 0 || i >= ncol) { dx += 5; continue; }
        int gap = yfl[i] - ycl[i];
        int L = 3 + (int)(rfn(sh, 1) * 8.0f);
        if (L > gap - 5) L = gap - 5;
        int wx = c->cx + dx;
        if (L >= 2 && !(pool && dx >= poolA && dx <= poolB && 0)) {
            for (int r = 0; r < L; r++) {
                int hwid = (bw / 2) * (L - r) / L;
                for (int q = -hwid; q <= hwid; q++) {
                    Col col = q < 0 ? mulc(rockc, 1.18f) : (q > 0 ? mulc(rockc, 0.72f) : rockc);
                    if (hwid == 0) col = rockc;
                    PX(w, wx - camI + q, w->gy + ycl[i] + r, col);
                }
            }
            PX(w, wx - camI, w->gy + ycl[i] + L - 1, lerpc(rockc, 0xDDEEFF, 0.4f));
            if (k == 2 || (sh & 15) == 3) { dropx = wx; dropy = ycl[i] + L; }
        }
        dx += 5 + (int)(rfn(sh, 2) * 5.0f);
    }
    /* stalagmites (and the occasional column joining floor and roof) */
    int colk = (int)(rfn(c->h, 12) * 6.0f);
    for (int dx = -c->hw + 5, k = 0; dx < c->hw - 4; k++) {
        uint32_t sh = hash2(c->h ^ 0x57A2U, (uint32_t)k);
        int bw = 3 + 2 * (int)(rfn(sh, 0) * 1.99f);
        int i = dx + c->hw;
        if (i < 0 || i >= ncol) { dx += 5; continue; }
        if (pool && dx >= poolA - 1 && dx <= poolB + 1) { dx += 5; continue; }
        int gap = yfl[i] - ycl[i];
        int L = 3 + (int)(rfn(sh, 1) * 8.0f);
        int wx = c->cx + dx;
        if (k == colk && gap > 8) {                                  /* a column */
            for (int dep = ycl[i]; dep <= yfl[i]; dep++) {
                int hwid = 1 + ((dep - ycl[i]) < 3 || (yfl[i] - dep) < 3 ? 1 : 0);
                for (int q = -hwid; q <= hwid; q++) PX(w, wx - camI + q, w->gy + dep, q < 0 ? mulc(rockc, 1.2f) : (q > 0 ? mulc(rockc, 0.7f) : rockc));
            }
        } else {
            if (L > gap - 3) L = gap - 3;
            if (L >= 2) {
                for (int r = 0; r < L; r++) {
                    int hwid = (bw / 2) * (L - r) / L;
                    for (int q = -hwid; q <= hwid; q++) {
                        Col col = q < 0 ? mulc(rockc, 1.2f) : (q > 0 ? mulc(rockc, 0.7f) : rockc);
                        if (hwid == 0) col = rockc;
                        PX(w, wx - camI + q, w->gy + yfl[i] - r, col);
                    }
                }
                PX(w, wx - camI, w->gy + yfl[i] - L + 1, mulc(rockc, 1.3f));
            }
        }
        dx += 5 + (int)(rfn(sh, 2) * 6.0f);
    }
    /* a dripping tip */
    if (dropx > -9000) {
        float ph = fmodf(t * 0.9f + rfn(c->h, 13) * 5.0f, 2.2f);
        if (ph < 0.5f) {
            int dy = dropy + (int)(ph * ph * 60.0f);
            int i = dropx - c->cx + c->hw;
            if (i >= 0 && i < ncol && dy < yfl[i] - 1) PX(w, dropx - camI, w->gy + dy, 0xBFE6FF);
        }
    }
    /* glowing crystals growing from the floor */
    if (crystal) {
        int i = c->hw + (int)(rfn(c->h, 14) * (float)c->hw * 0.8f) - c->hw / 3;
        if (i < 6) i = 6;
        if (i > ncol - 8) i = ncol - 8;
        int x = c->cx - c->hw + i - camI, y = w->gy + yfl[i];
        for (int dy = -9; dy <= 4; dy++) for (int dx = -9; dx <= 9; dx++)
            if (dx * dx + dy * dy < 81 && ((dx + dy) & 1) == 0 && dx * dx + dy * dy > 10) BLEND(w, x + dx, y + dy, gc, 38);
        for (int q = 0; q < 3; q++) {
            int bx = x + (q - 1) * 3, bh = 4 + (int)(rfn(c->h, 15 + q) * 5.0f) + (q == 1 ? 2 : 0);
            R(w, bx - 1, y - bh + 1, 3, bh, gc); PX(w, bx, y - bh, lerpc(gc, 0xFFFFFF, 0.6f));
            R(w, bx - 1, y - bh + 1, 1, bh, lerpc(gc, 0xFFFFFF, 0.45f)); R(w, bx + 1, y - bh / 2, 1, bh / 2, mulc(gc, 0.7f));
        }
        if (sinf(t * 2.4f + (float)c->cx * 0.1f) > 0.7f) PX(w, x, y - 10, 0xFFFFFF);
    }
}


/* ------------------------------------------------- worms and moles ---- */
/* an earthworm: a pink segmented body wriggling through its own little burrow */
static void u_worm(AWWorld *w, int x, int y, int len, int dir, float ph, int vert, const Pal *p) {
    float t = (float)w->t;
    int creep = (int)floorf(sinf(t * 0.35f + ph) * 3.0f + 0.5f);
    x += vert ? 0 : creep * dir;
    Col burrow = mulc(p->dirt, 0.62f);
    if (vert) ell_fill(w, x, y + len / 2, 2.6f, (float)len / 2.0f + 3.0f, 0, burrow, BIGY);
    else ell_fill(w, x + dir * len / 2, y, (float)len / 2.0f + 3.5f, 3.0f, 0, burrow, BIGY);
    for (int i = len - 1; i >= 0; i--) {
        float k = (float)i / (float)len;
        float wv = sinf((float)i * 0.62f - t * 3.4f + ph) * (0.8f + 1.3f * (1.0f - k));
        int sx = vert ? x + (int)floorf(wv + 0.5f) : x + dir * i;
        int sy = vert ? y + i : y + (int)floorf(wv + 0.5f);
        Col c = (i % 3 == 2) ? 0xC8707C : 0xE89AA4;
        if (i >= len * 4 / 10 && i < len * 4 / 10 + 3) c = 0xF2C0BC;           /* the paler band behind the head */
        if (i < 2) c = 0xD27E88;
        PX(w, sx, sy, c);
        if (vert) PX(w, sx + 1, sy, mulc(c, 0.84f)); else PX(w, sx, sy + 1, mulc(c, 0.84f));
        if (i == 0) { PX(w, sx - (vert ? 0 : dir), sy - (vert ? 1 : 0), 0xC8707C); PX(w, sx, sy, 0x5A2A30); }
    }
}
/* a mole in its chamber: velvety grey, pink star nose, big shovel paws, digging, with a tunnel behind it */
static void u_mole(AWWorld *w, int x, int y, int dir, float ph, const Pal *p) {
    float t = (float)w->t;
    #define MXC(v) (x + dir * (v))
    #define MRR(v, yy, ww, hh, c) R(w, (dir > 0) ? x + (v) : x - (v) - (ww) + 1, (yy), (ww), (hh), (c))
    Col burrow = mulc(p->dirt, 0.55f);
    ell_fill(w, MXC(-15), y + 1, 14.0f, 3.0f, 0, burrow, BIGY);                    /* the tunnel it came along */
    ell_fill(w, MXC(1), y, 10.5f, 7.0f, 0, burrow, BIGY);                           /* the chamber */
    int dg = (int)floorf(sinf(t * 6.0f + ph) * 1.6f + 0.5f), bob = (int)floorf(sinf(t * 3.0f + ph) * 0.6f + 0.5f);
    Col fur = 0x4C4658, furl = 0x6C6680, furd = 0x34303E;
    PX(w, MXC(-9), y + 1, furd); PX(w, MXC(-10), y, furd); PX(w, MXC(-11), y - 1, furd);                    /* the short tail */
    ell_fill(w, MXC(-2), y + 1 + bob, 6.5f, 4.2f, 0, fur, BIGY);                    /* body */
    ell_fill(w, MXC(-3), y - 1 + bob, 4.5f, 2.2f, 0, furl, BIGY);
    ell_fill(w, MXC(5), y + bob, 3.6f, 3.2f, 0, fur, BIGY);                         /* head */
    MRR(7, y - 1 + bob, 3, 2, 0xF0A0AA);                                           /* snout */
    for (int i = -1; i <= 1; i++) PX(w, MXC(10), y - 1 + bob + i + 1, 0xFFB8C0);    /* the star nose */
    PX(w, MXC(10), y + bob, 0xE0687A);
    PX(w, MXC(6), y - 2 + bob, 0x0A0810);                                          /* a pinprick eye */
    MRR(3, y - 3 + bob, 2, 1, furd);
    MRR(5 + (dg > 0), y + 2 + dg / 2, 5, 2, 0xF2B8B0); MRR(8 + (dg > 0), y + 2 + dg / 2, 3, 1, 0xFFE0D8);   /* the paws */
    PX(w, MXC(10 + (dg > 0)), y + 3 + dg / 2, 0xFFFFFF); PX(w, MXC(10 + (dg > 0)), y + 2 + dg / 2, 0xFFFFFF); PX(w, MXC(9 + (dg > 0)), y + 4 + dg / 2, 0xFFFFFF);
    MRR(4 - (dg > 0), y + 3, 4, 2, 0xE0A098);
    for (int i = 0; i < 4; i++) {                                                   /* crumbs of earth flying off the claws */
        float f = fmodf(t * 3.0f + (float)i * 0.27f + ph, 1.0f);
        PX(w, MXC(11 + (int)(f * 5.0f)), y + 3 - (int)(f * 4.0f) + (int)(f * f * 6.0f), (i & 1) ? p->dirt_lt : mulc(p->dirt, 0.85f));
    }
    #undef MXC
    #undef MRR
}

/* is one of the ordinary underground items (rocks, ore, crystals, bones...) sitting near this spot? the critters keep clear of them */
static int u_item_near(const AWWorld *w, int wx, int dep, int mx, int my) {
    for (int ky = floordiv(dep, 30) - 1; ky <= floordiv(dep, 30) + 1; ky++) for (int kx = floordiv(wx, 40) - 1; kx <= floordiv(wx, 40) + 1; kx++) {
        uint32_t h = hash2(w->seed ^ 0xD16U ^ ((uint32_t)(ky + 64) * 0x9E3779B1U), (uint32_t)kx);
        if (rfn(h, 0) > 0.66f) continue;
        int ix = kx * 40 + 8 + (int)(rfn(h, 1) * 24.0f), iy = ky * 30 + 5 + (int)(rfn(h, 2) * 20.0f);
        if (abs(ix - wx) < mx && abs(iy - dep) < my) return 1;
    }
    return 0;
}
#ifdef AW_UNDER_DEBUG
static int u_dbg_force(void) { const char *e = getenv("AW_PIECE"); return e ? atoi(e) : -1; }
#endif

static void draw_underground(AWWorld *w) {
    int camI = (int)floor(w->cam);
    const Pal *p = &w->cur;
    int dmin = -w->oy - w->gy - 24, dmax = w->vh - w->oy - w->gy + 24;
    if (dmax < 10) return;
    float t = (float)w->t;
    UCave cv[U_MAXC]; UPiece pc[U_MAXP];
    int ncv = u_gather_caves(w, camI, camI + w->vw, cv, U_MAXC);
    int npc = u_gather_pieces(w, camI, camI + w->vw, cv, ncv, pc, U_MAXP);
#ifdef AW_UNDER_DEBUG
    if (u_dbg_force() >= 0) {
        ncv = 0; npc = 0;
        int kind = u_dbg_force();
        int hw, ht; u_piece_box(kind, &hw, &ht);
        pc[0].x0 = camI + w->vw / 2 - hw; pc[0].x1 = camI + w->vw / 2 + hw; pc[0].y1 = 36; pc[0].y0 = 36 - ht; pc[0].kind = kind; pc[0].dir = 1; pc[0].h = 99;
        npc = 1;
        if (getenv("AW_CAVE")) { cv[0].cx = camI + w->vw / 2; cv[0].cy = 28; cv[0].hw = 30; cv[0].hh = 12; cv[0].fl = 7; cv[0].h = (uint32_t)atoi(getenv("AW_CAVE")); cv[0].tier = 0; ncv = 1; npc = 0; }
    }
#endif
    for (int i = 0; i < ncv; i++) u_draw_cave(w, &cv[i], camI);

    const int SX = 40, SY = 30;
    static const Col gem[5] = { 0x7DF9FF, 0xFF7AD9, 0xB58CFF, 0x6CFF8A, 0xFFD23F };
    int kx0 = floordiv(camI - 24, SX), kx1 = floordiv(camI + w->vw + 24, SX);
    int ky0 = floordiv(imax(dmin, 8), SY), ky1 = floordiv(dmax, SY);
    for (int ky = ky0; ky <= ky1; ky++) {
        for (int kx = kx0; kx <= kx1; kx++) {
            uint32_t h = hash2(w->seed ^ 0xD16U ^ ((uint32_t)(ky + 64) * 0x9E3779B1U), (uint32_t)kx);
            if (rfn(h, 0) > 0.66f) continue;
            int wx = kx * SX + 8 + (int)(rfn(h, 1) * (float)(SX - 16));
            int dep = ky * SY + 5 + (int)(rfn(h, 2) * (float)(SY - 10));
            if (dep < -ground_h(w, wx) + 11) continue;
            if (u_hit_cave(cv, ncv, wx, dep, 14, 8) || u_hit_piece(pc, npc, wx, dep, 14, 9)) continue;
#ifdef AW_UNDER_DEBUG
            if (u_dbg_force() >= 0) continue;
#endif
            int x = wx - camI, y = w->gy + dep;
            float kk = rfn(h, 3), deep = clampf((float)dep / 110.0f, 0.0f, 1.0f);
            Col g = mulc(lerpc((rfn(h, 12) < 0.35f ? 0xA89A86 : 0x9A9AA8), p->dirt, 0.28f), 1.0f - deep * 0.25f);
            int sw = 10 + (int)(rfn(h, 4) * 12.0f), sh = 6 + (int)(rfn(h, 5) * 7.0f);
            if (kk < 0.20f || (kk < 0.57f && kk >= 0.50f && dep <= 30)) {    /* boulder with a crack */
                ell_fill(w, x, y + 1, (float)sw / 2.0f + 0.5f, (float)sh / 2.0f + 0.5f, 0, mulc(g, 0.55f), BIGY);
                ell_fill(w, x, y, (float)sw / 2.0f, (float)sh / 2.0f, 0, g, BIGY);
                R(w, x - sw / 3, y - sh / 2 + 1, imax(2, sw / 3), 1, mulc(g, 1.35f));
                R(w, x - sw / 4, y + sh / 2 - 1, imax(3, sw / 2), 1, mulc(g, 0.78f));
                if (rfn(h, 6) < 0.6f) { PX(w, x + 1, y - sh / 2 + 1, mulc(g, 0.5f)); PX(w, x + 2, y - 1, mulc(g, 0.5f)); PX(w, x + 2, y, mulc(g, 0.5f)); PX(w, x + 3, y + 1, mulc(g, 0.5f)); }
            } else if (kk < 0.30f) {                                      /* rock cluster */
                for (int i = 0; i < 3; i++) {
                    int ox = (i - 1) * (sw / 2 + 1), oyy = (i == 1 ? -2 : 1), rr = 3 + (int)(rfn(h, 7 + i) * 3.0f);
                    Col gg = mulc(g, 0.85f + 0.15f * (float)i);
                    ell_fill(w, x + ox, y + oyy + 1, (float)rr + 0.5f, (float)rr * 0.7f + 0.5f, 0, mulc(gg, 0.55f), BIGY);
                    ell_fill(w, x + ox, y + oyy, (float)rr, (float)rr * 0.7f, 0, gg, BIGY);
                    R(w, x + ox - rr / 2, y + oyy - rr / 2, imax(1, rr / 2), 1, mulc(gg, 1.35f));
                }
            } else if (kk < 0.38f) {                                      /* layered slab */
                int bw = 14 + (int)(rfn(h, 7) * 10.0f), bh = 7 + (int)(rfn(h, 8) * 4.0f);
                R(w, x - bw / 2 - 1, y - bh / 2 + 1, bw + 2, bh - 2, mulc(g, 0.5f));
                R(w, x - bw / 2, y - bh / 2, bw, bh, g);
                for (int r = 1; r < bh; r += 2) R(w, x - bw / 2, y - bh / 2 + r, bw, 1, mulc(g, (r & 2) ? 0.82f : 1.12f));
                R(w, x - bw / 2, y - bh / 2, bw, 1, mulc(g, 1.3f));
                PX(w, x - bw / 2, y - bh / 2, mulc(g, 0.5f)); PX(w, x + bw / 2 - 1, y - bh / 2, mulc(g, 0.5f));
            } else if (kk < 0.44f) {                                      /* coal */
                for (int i = 0; i < 4; i++) {
                    int ox = (int)(rfn(h, 7 + i) * (float)sw) - sw / 2, oyy = (int)(rfn(h, 11 + i) * 5.0f) - 2, rr = 2 + (i & 1);
                    ell_fill(w, x + ox, y + oyy, (float)rr, (float)rr * 0.8f, 0, 0x23232B, BIGY);
                    PX(w, x + ox - 1, y + oyy - 1, 0x5C6070);
                }
            } else if (kk < 0.50f) {                                      /* iron-red ore with flecks */
                ell_fill(w, x, y + 1, (float)sw / 2.0f, (float)sh / 2.0f, 0, mulc(g, 0.6f), BIGY);
                ell_fill(w, x, y, (float)sw / 2.0f, (float)sh / 2.0f, 0, g, BIGY);
                for (int i = 0; i < 6; i++) { uint32_t q = hash2(h, (uint32_t)(40 + i)); PX(w, x - sw / 3 + (int)(rfn(q, 0) * (float)(sw * 2 / 3)), y - sh / 4 + (int)(rfn(q, 1) * (float)(sh / 2 + 1)), (i & 1) ? 0xC4552A : 0x8E3A20); }
            } else if (kk < 0.57f) {                                      /* gold ore */
                ell_fill(w, x, y + 1, (float)sw / 2.0f, (float)sh / 2.0f, 0, mulc(g, 0.6f), BIGY);
                ell_fill(w, x, y, (float)sw / 2.0f, (float)sh / 2.0f, 0, g, BIGY);
                for (int i = 0; i < 5; i++) { uint32_t q = hash2(h, (uint32_t)(40 + i)); PX(w, x - sw / 3 + (int)(rfn(q, 0) * (float)(sw * 2 / 3)), y - sh / 4 + (int)(rfn(q, 1) * (float)(sh / 2 + 1)), 0xFFD23F); }
                if (sinf(t * 2.2f + (float)wx) > 0.85f) PX(w, x, y - 1, 0xFFFFFF);
            } else if (kk < 0.64f) {                                      /* geode */
                Col c = gem[(int)(rfn(h, 6) * 5.0f) % 5];
                if (dep < 24) c = 0xB58CFF;
                int r = 6 + (int)(rfn(h, 7) * 2.0f);
                ell_fill(w, x, y + 1, (float)r + 1.0f, (float)r * 0.85f + 1.0f, 0, mulc(g, 0.5f), BIGY);
                ell_fill(w, x, y, (float)r, (float)r * 0.85f, 0, g, BIGY);
                ell_fill(w, x, y, (float)r - 2.0f, (float)r * 0.85f - 2.0f, 0, mulc(c, 0.55f), BIGY);
                ell_fill(w, x, y + 1, (float)r - 3.0f, (float)r * 0.85f - 3.0f, 0, c, BIGY);
                for (int i = 0; i < 6; i++) { float a = (float)i * 1.047f + rfn(h, 8) * 6.0f; PX(w, x + (int)(cosf(a) * (float)(r - 3)), y + (int)(sinf(a) * (float)(r - 3) * 0.85f), lerpc(c, 0xFFFFFF, 0.55f)); }
                if (sinf(t * 2.0f + (float)wx * 0.2f) > 0.75f) PX(w, x, y - 1, 0xFFFFFF);
            } else if (kk < 0.78f && dep > 18) {                           /* small fossil slab */
                int pick = (int)(rfn(h, 6) * 3.0f);
                Col gs = lerpc(0x8A8478, p->dirt, 0.3f);
                if (pick == 0) { u_slab(w, x, y, 28, 14, gs); u_fish(w, x, y, rfn(h, 7) < 0.5f ? 1 : -1); }
                else if (pick == 1) { u_slab(w, x, y, 22, 14, gs); u_trilo(w, x, y); }
                else { u_slab(w, x, y, 24, 14, gs); u_fern(w, x, y); }
            } else if (kk < 0.92f) {                                       /* crystals */
                Col c = gem[(int)(rfn(h, 6) * 5.0f) % 5];
                for (int dy = -9; dy <= 9; dy++) for (int dx = -9; dx <= 9; dx++)
                    if (dx * dx + dy * dy < 81 && ((dx + dy) & 1) == 0 && dx * dx + dy * dy > 14) BLEND(w, x + dx, y + dy, c, 30);
                int nn = 3 + (int)(rfn(h, 9) * 3.0f);
                for (int i = 0; i < nn; i++) {
                    int bx = x + (i - nn / 2) * 3, bh = 4 + (int)(rfn(h, 7 + (i % 3)) * 7.0f) + (i == nn / 2 ? 3 : 0) - (i == 0 || i == nn - 1 ? 2 : 0);
                    if (bh < 3) bh = 3;
                    R(w, bx - 1, y - bh, 3, bh, c); R(w, bx, y - bh - 1, 1, 1, lerpc(c, 0xFFFFFF, 0.6f)); R(w, bx - 1, y - bh, 1, bh, lerpc(c, 0xFFFFFF, 0.45f));
                    R(w, bx + 1, y - bh / 2, 1, bh / 2, mulc(c, 0.7f));
                }
                R(w, x - nn * 3 / 2 - 1, y, nn * 3 + 2, 2, mulc(g, 0.8f));
                if (sinf(t * 2.6f + (float)wx * 0.3f) > 0.72f) { PX(w, x, y - 12, 0xFFFFFF); PX(w, x - 1, y - 12, lerpc(c, 0xFFFFFF, 0.5f)); PX(w, x + 1, y - 12, lerpc(c, 0xFFFFFF, 0.5f)); }
            } else if (kk > 0.968f && dep > 12) {                              /* the dog bone (kept from the first version) */
                R(w, x - 6, y, 12, 2, 0xEFE6D2); R(w, x - 8, y - 1, 3, 4, 0xEFE6D2); R(w, x + 5, y - 1, 3, 4, 0xEFE6D2); R(w, x - 6, y + 1, 12, 1, 0xCFC4A8);
                PX(w, x - 8, y + 2, 0xCFC4A8); PX(w, x + 7, y + 2, 0xCFC4A8); PX(w, x - 7, y - 1, 0xFFFFFF);
            } else {                                                       /* pebbles */
                R(w, x - 4, y, 3, 2, mulc(g, 0.9f)); R(w, x + 1, y + 1, 2, 1, mulc(g, 1.1f)); PX(w, x + 3, y, mulc(g, 0.8f));
                R(w, x - 1, y + 2, 2, 1, mulc(g, 0.75f)); PX(w, x - 4, y, mulc(g, 1.2f));
            }
        }
    }
    /* worms and moles, now and then (their own grid, so nothing above moves) */
    {
        const int WX = 70, WY = 28;
        int cx0 = floordiv(camI - 20, WX), cx1 = floordiv(camI + w->vw + 20, WX);
        int cy0 = floordiv(imax(dmin, 8), WY), cy1 = floordiv(dmax, WY);
        for (int cy = cy0; cy <= cy1; cy++) for (int cx = cx0; cx <= cx1; cx++) {
            uint32_t h = hash2(w->seed ^ 0x3017C0U ^ ((uint32_t)(cy + 64) * 0x9E3779B1U), (uint32_t)cx);
            if (rfn(h, 0) > 0.20f) continue;
            int wx = cx * WX + 16 + (int)(rfn(h, 1) * (float)(WX - 32));
            int dep = cy * WY + 6 + (int)(rfn(h, 2) * (float)(WY - 12));
            if (dep < -ground_h(w, wx) + 10) continue;
            if (u_hit_cave(cv, ncv, wx, dep, 20, 9) || u_hit_piece(pc, npc, wx, dep, 20, 10) || u_item_near(w, wx, dep, 22, 9)) continue;
#ifdef AW_UNDER_DEBUG
            if (u_dbg_force() >= 0) continue;
#endif
            int dir = rfn(h, 3) < 0.5f ? 1 : -1;
            float ph = rfn(h, 4) * 6.28f;
            int x = wx - camI, y = w->gy + dep;
            if (rfn(h, 5) < 0.58f) u_worm(w, x, y, 11 + (int)(rfn(h, 6) * 9.0f), dir, ph, rfn(h, 7) < 0.30f, p);
            else u_mole(w, x, y, dir, ph, p);
        }
    }
    for (int i = 0; i < npc; i++) u_piece_draw(w, &pc[i], camI, p);
    /* tree roots dangling under the grass */
    if (-w->oy - w->gy < 60) {
        const int RS = 34;
        int r0 = floordiv(camI - 6, RS), r1 = floordiv(camI + w->vw + 6, RS);
        for (int k = r0; k <= r1; k++) {
            uint32_t h = hash2(w->seed ^ 0x2007U, (uint32_t)k);
            if (rfn(h, 0) > 0.42f) continue;
            int wx = k * RS + (int)(rfn(h, 1) * (float)RS);
            int gh = ground_h(w, wx);
            if (gh < 0) continue;
            int len = 12 + (int)(rfn(h, 2) * 26.0f), y0 = w->gy - gh + 5, x = wx - camI;
            Col rc = lerpc(p->trunk, p->dirt_lt, 0.35f);
            for (int i = 0; i < len; i++) {
                int sx = (int)floorf(sinf((float)i * 0.33f + rfn(h, 3) * 6.0f) * 2.0f + 0.5f);
                PX(w, x + sx, y0 + i, i > len - 4 ? mulc(rc, 0.8f) : rc);
                if (i % 8 == 5) { int dir = (i & 8) ? 1 : -1; R(w, x + sx + dir, y0 + i, 3 * dir > 0 ? 3 : -3 + 1, 1, rc); }
            }
        }
    }
}
