/*
 * Archon's Life v4 - backdrop variety.
 * The three parallax layers behind the ground are no longer always mountains: the world walks through regions of
 * mountains, rolling hills, forest, city, suburb, farmland and desert mesas. Neighbouring regions blend: ridge heights
 * morph into each other and the buildings / trees / barns thin out toward the region edge.
 * Everything is a pure function of (seed, x, time) so the simulation stays deterministic. Included by aw_engine.c.
 */

enum { BG_MOUNTAIN, BG_HILLS, BG_FOREST, BG_CITY, BG_SUBURB, BG_FARM, BG_MESA, BG_N };
#define BG_SEG 1500.0          /* world px per backdrop region */

/* ridge height factor (of the layer's mountain height) for each style */
static const float BG_HF[BG_N] = { 1.00f, 1.00f, 0.52f, 0.30f, 0.36f, 0.50f, 0.82f };

static int bg_style_seg(const AWWorld *w, int seg) {
    if (w->bg_force) return w->bg_force - 1;
    static const int PERM[BG_N] = { 0, 3, 2, 4, 1, 6, 5 };
    int a = 3 + (int)(hash2(w->seed, 0xB601u) % 2u);                  /* stride 3 or 4 (+jitter 0..1): never the same style twice in a row */
    int off = (int)(hash2(w->seed, 0xB602u) % (uint32_t)BG_N);
    int j = (int)(hash2(w->seed ^ 0xB603u, (uint32_t)seg) % 2u);
    int v = (a * seg + off + j) % BG_N; if (v < 0) v += BG_N;
    return PERM[v];
}

static float bg_night(const AWWorld *w) {
    Col c = w->cur.sky_mid;
    float lum = (float)((c >> 16) & 255) * 0.30f + (float)((c >> 8) & 255) * 0.59f + (float)(c & 255) * 0.11f;
    float n = clampf((150.0f - lum) / 90.0f, 0.0f, 1.0f);
    return n > w->dark ? n : w->dark;
}

/* style mix at layer-x X: own region (weight wc) and the neighbour it is blending with */
static void bg_mix(const AWWorld *w, int X, int segL, int *sc, int *sn, float *wc) {
    int seg = floordiv(X, segL);
    int rel = X - seg * segL;
    float e = (float)imin(rel, segL - 1 - rel);
    float t = smooth(clampf(e / ((float)segL * 0.14f), 0.0f, 1.0f));
    *wc = 0.5f + 0.5f * t;
    *sc = bg_style_seg(w, seg);
    *sn = bg_style_seg(w, rel < segL / 2 ? seg - 1 : seg + 1);
}
/* how strongly ornaments of the region around X may show (0 at the region edge .. 1 inside) */
static float bg_presence(int X, int X0, int segL) {
    float e = (float)imin(X - X0, X0 + segL - 1 - X);
    return smooth(clampf(e / ((float)segL * 0.16f), 0.0f, 1.0f));
}

static int bg_style_height(const AWWorld *w, int X, int layer, int hmin, int hmax, int style) {
    if (style == BG_MOUNTAIN) return ridge_h(w, X, layer, hmin, hmax, w->cur.peaky);
    uint32_t s = w->seed + 1000u * (uint32_t)layer + 0x5100u;
    float lo = (float)hmin * BG_HF[style], hi = (float)hmax * BG_HF[style];
    float v;
    if (style == BG_MESA) {
        float n = vn(s + 31u, (float)X / (46.0f + 16.0f * (float)layer));
        int lvl = (int)(n * 3.99f);
        v = (float)lvl / 3.0f;
        v = v * 0.80f + 0.20f * vn(s + 5u, (float)X / 30.0f);
    } else if (style == BG_CITY || style == BG_SUBURB) {
        v = 0.8f * vn(s, (float)X / (120.0f + 40.0f * (float)layer)) + 0.2f * vn(s + 9u, (float)X / 41.0f);
    } else {
        v = 0.68f * vn(s, (float)X / (84.0f + 30.0f * (float)layer)) + 0.32f * vn(s + 9u, (float)X / (31.0f + 10.0f * (float)layer));
    }
    return ((int)(lo + (hi - lo) * v)) & ~1;
}
static int bg_height(const AWWorld *w, int X, int layer, int hmin, int hmax, int segL) {
    int sc, sn; float wc;
    bg_mix(w, X, segL, &sc, &sn, &wc);
    float a = (float)bg_style_height(w, X, layer, hmin, hmax, sc);
    if (sn == sc) return ((int)a) & ~1;
    float b = (float)bg_style_height(w, X, layer, hmin, hmax, sn);
    return ((int)(a * wc + b * (1.0f - wc))) & ~1;
}

/* ---- little helpers ---- */
static Col bg_haze(const AWWorld *w, Col c, Col layer_col, float k, float night) {
    /* pull a fixed-colour object toward its layer's colour (distance haze) and darken it at night */
    (void)w;
    return lerpc(mulc(c, 1.0f - 0.62f * night), layer_col, k);
}
static Col bg_green(const AWWorld *w, Col layer_col, float k) {
    float n = bg_night(w);
    return lerpc(layer_col, mulc(0x3E9A52, 1.0f - 0.70f * n), k);
}
static void bg_window(AWWorld *w, int x, int y, int ww, int hh, int lit, Col unlit, Col litc) {
    R(w, x, y, ww, hh, lit ? litc : unlit);
}

/* ---- CITY: towers of varied width/height with antennas, stepped tops, water tanks and lit windows ---- */
static void bg_city(AWWorld *w, int layer, int X0, int segL, int camL, int hmin, int hmax, Col col, float night) {
    static const int CELL[3] = { 8, 11, 14 };
    int C = CELL[layer];
    float sc = (float)w->vh / 180.0f;
    float bl[3] = { 14.0f, 20.0f, 16.0f }, bh[3] = { 40.0f, 60.0f, 38.0f };
    int k0 = floordiv(imax(X0, camL - 30), C), k1 = floordiv(imin(X0 + segL, camL + w->vw + 30), C);
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ (0xC170u + (uint32_t)layer * 131u), (uint32_t)k);
        int X = k * C;
        if (rfn(h, 0) > bg_presence(X + C / 2, X0, segL) * 0.92f) continue;
        int bw = C - 1 - (int)(rfn(h, 1) * 2.0f);
        float r2 = rfn(h, 2);
        float height = (bl[layer] + (bh[layer] - bl[layer]) * r2 * r2) * sc;
        if (rfn(h, 8) < 0.13f) height *= 1.45f;
        int base = w->gy - bg_height(w, X + bw / 2, layer, hmin, hmax, segL);
        int bot = base + 6;
        int ytop = base - (int)height;
        int sx = X - camL;
        Col bc = lerpc(col, mulc(0x8D9BBA, 1.0f - 0.62f * night), layer == 0 ? 0.40f : 0.58f);
        bc = mulc(bc, 0.93f + 0.14f * rfn(h, 4));
        if (layer == 0) bc = lerpc(bc, w->cur.sky_bot, 0.10f);
        int kind = (int)(rfn(h, 3) * 6.0f);
        int bodyTop = ytop;
        int sw = bw;
        if (kind == 2) {                                   /* stepped top: slim upper block */
            int uh = 4 + (int)(rfn(h, 5) * 6.0f * sc);
            R(w, sx + 2, ytop - uh, bw - 4, uh + 1, bc);
        } else if (kind == 1) {                            /* antenna */
            int ah = 5 + (int)(rfn(h, 5) * 9.0f * sc);
            R(w, sx + bw / 2, ytop - ah, 1, ah + 1, bc);
            if (night > 0.3f && ((int)(w->t * 1.4 + (double)k) & 1)) PX(w, sx + bw / 2, ytop - ah - 1, 0xFF5A4A);
        } else if (kind == 3 && layer > 0) {               /* rooftop water tank on legs */
            R(w, sx + 1, ytop - 4, 3, 3, mulc(bc, 0.9f)); R(w, sx + 1, ytop - 1, 1, 2, bc); R(w, sx + 3, ytop - 1, 1, 2, bc);
        } else if (kind == 4) {                            /* slanted roof */
            for (int i = 0; i < bw; i++) R(w, sx + i, ytop - (i * 5 / bw), 1, 1 + (i * 5 / bw), bc);
        }
        R(w, sx, bodyTop, sw, bot - bodyTop, bc);
        R(w, sx, bodyTop, 1, bot - bodyTop, lerpc(bc, 0xFFFFFF, 0.07f));
        R(w, sx + sw - 1, bodyTop, 1, bot - bodyTop, mulc(bc, 0.88f));
        /* windows: lit at night, faint glass by day */
        float litp = night > 0.05f ? (0.06f + 0.86f * night) * (0.4f + 0.9f * rfn(h, 6)) : 0.0f;
        if (layer == 0 && night < 0.2f) continue;
        Col unlit = night > 0.25f ? mulc(bc, 0.82f) : lerpc(bc, w->cur.sky_mid, 0.20f);
        int wstep = layer == 0 ? 2 : 3, wsz = layer == 0 ? 1 : 2;
        for (int yy = ytop + 3; yy < base - 2; yy += wstep) {
            for (int xx = 1; xx + wsz <= sw - 1; xx += wstep) {
                uint32_t q = hash2(h, (uint32_t)(yy * 31 + xx));
                int lit = rfn(q, 0) < litp;
                static const Col LC[3] = { 0xFFE9A0, 0xFFD36A, 0xFFF6D6 };
                Col lc = LC[q % 3u];
                if (!lit && layer == 0) continue;
                bg_window(w, sx + xx, yy, wsz, wsz, lit, unlit, lc);
            }
        }
    }
}

/* ---- FOREST: dense pines and round trees ---- */
static void bg_forest(AWWorld *w, int layer, int X0, int segL, int camL, int hmin, int hmax, Col col, float night) {
    static const int CELL[3] = { 5, 7, 9 };
    int C = CELL[layer];
    float sc = (float)w->vh / 180.0f;
    float tl[3] = { 9.0f, 13.0f, 17.0f }, th[3] = { 16.0f, 24.0f, 32.0f };
    int k0 = floordiv(imax(X0, camL - 30), C), k1 = floordiv(imin(X0 + segL, camL + w->vw + 30), C);
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ (0xF0E5u + (uint32_t)layer * 71u), (uint32_t)k);
        int X = k * C + (int)(rfn(h, 1) * (float)C);
        if (rfn(h, 0) > bg_presence(X, X0, segL) * 0.97f) continue;
        int base = w->gy - bg_height(w, X, layer, hmin, hmax, segL);
        float ht = (tl[layer] + (th[layer] - tl[layer]) * rfn(h, 2)) * sc;
        int sx = X - camL;
        float k_g = layer == 0 ? 0.42f : (layer == 1 ? 0.55f : 0.62f);
        Col tc = bg_green(w, col, k_g);
        tc = mulc(tc, 0.90f + 0.20f * rfn(h, 4));
        if (rfn(h, 5) < 0.18f && night < 0.5f) tc = lerpc(tc, 0xE08A3A, 0.35f);   /* the odd autumn-coloured tree */
        Col hl = lerpc(tc, 0xFFFFFF, 0.14f), sh = mulc(tc, 0.84f);
        int hgt = (int)ht;
        int ybase = base + 3;
        if (rfn(h, 3) < 0.62f) {                            /* pine: stacked tiers */
            int pw = (int)(ht * 0.46f) + 2;
            int span = imax(2, hgt / 3);
            for (int i = 0; i < hgt; i++) {
                int tier = imin(2, (i * 3) / imax(1, hgt));
                int rowi = i - tier * hgt / 3;
                int maxw = imax(2, pw * (tier + 2) / 4);
                int wdt = imin(maxw, 1 + (rowi * maxw) / span);
                int y = base - hgt + i + 2;
                R(w, sx - wdt / 2, y, wdt, 1, tc);
                if (wdt > 2) { R(w, sx - wdt / 2, y, 1, 1, hl); R(w, sx - wdt / 2 + wdt - 1, y, 1, 1, sh); }
            }
            R(w, sx, ybase - 2, 1, 4, mulc(tc, 0.6f));
        } else {                                            /* broadleaf: a lumpy ball on a trunk */
            int rr = imax(2, (int)(ht * 0.34f));
            int cy = base - hgt + rr + 2;
            for (int dy = -rr; dy <= rr; dy++)
                for (int dx = -rr; dx <= rr; dx++) {
                    if (dx * dx + dy * dy > rr * rr + rr / 2) continue;
                    PX(w, sx + dx, cy + dy, (dx + dy < -rr / 2) ? hl : (dx > rr / 3 ? sh : tc));
                }
            R(w, sx, cy + rr - 1, 1, ybase - (cy + rr - 1), mulc(tc, 0.6f));
        }
    }
}

/* ---- HILLS: lone round trees and little copses along the crests ---- */
static void bg_hills(AWWorld *w, int layer, int X0, int segL, int camL, int hmin, int hmax, Col col, float night) {
    if (layer == 0) return;
    int C = layer == 1 ? 30 : 22;
    int k0 = floordiv(imax(X0, camL - 30), C), k1 = floordiv(imin(X0 + segL, camL + w->vw + 30), C);
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ (0x1111u + (uint32_t)layer * 17u), (uint32_t)k);
        int X = k * C + (int)(rfn(h, 1) * (float)C);
        if (rfn(h, 0) > 0.55f * bg_presence(X, X0, segL)) continue;
        int base = w->gy - bg_height(w, X, layer, hmin, hmax, segL);
        int sx = X - camL, rr = (layer == 1 ? 3 : 4) + (int)(rfn(h, 2) * 2.0f);
        Col tc = mulc(bg_green(w, col, 0.70f), 0.88f + 0.2f * rfn(h, 3));
        int cy = base - rr - 1;
        for (int dy = -rr; dy <= rr; dy++) for (int dx = -rr; dx <= rr; dx++)
            if (dx * dx + dy * dy <= rr * rr + rr / 2) PX(w, sx + dx, cy + dy, (dx + dy < -rr / 2) ? lerpc(tc, 0xFFFFFF, 0.16f) : (dx > rr / 3 ? mulc(tc, 0.82f) : tc));
        R(w, sx, cy + rr - 1, 1, base - (cy + rr - 1) + 3, mulc(tc, 0.55f));
        if (rfn(h, 4) < 0.5f) {                               /* a second tree beside it */
            int r2 = rr - 1; int cx2 = sx + rr + 1; int cy2 = base - r2 - 1 + 1;
            for (int dy = -r2; dy <= r2; dy++) for (int dx = -r2; dx <= r2; dx++)
                if (dx * dx + dy * dy <= r2 * r2 + r2 / 2) PX(w, cx2 + dx, cy2 + dy, (dx + dy < -r2 / 2) ? lerpc(tc, 0xFFFFFF, 0.1f) : tc);
        }
    }
}

/* ---- SUBURB: pitched-roof houses, picket-fence glimpses and round trees ---- */
static void bg_house(AWWorld *w, int sx, int base, int bw, int wh, int rh, uint32_t h, int layer, Col col, float night) {
    static const Col WALL[6] = { 0xF2E6C8, 0xBFD9EC, 0xF4D78A, 0xFFFFFF, 0xF0B39A, 0xC8E0B8 };
    static const Col ROOF[6] = { 0xA0472E, 0x6B4A3A, 0x4A5A78, 0xB8452E, 0x3F6A66, 0x7A3A4A };
    float k = layer == 0 ? 0.42f : (layer == 1 ? 0.30f : 0.20f);
    Col wall = bg_haze(w, WALL[h % 6u], col, k, night);
    Col roof = bg_haze(w, ROOF[(h >> 3) % 6u], col, k, night);
    int y0 = base - wh;                                    /* top of the wall */
    R(w, sx, y0, bw, wh + 6, wall);
    R(w, sx + bw - 2, y0, 2, wh + 6, mulc(wall, 0.86f));
    /* roof: triangle with a small overhang */
    for (int i = 0; i < rh; i++) {
        int hw = ((bw / 2 + 2) * (rh - i)) / rh;
        R(w, sx + bw / 2 - hw, y0 - 1 - i, 2 * hw + 1, 1, i == 0 ? mulc(roof, 0.8f) : roof);
    }
    if (rfn(h, 9) < 0.6f && layer > 0) R(w, sx + bw * 2 / 3, y0 - rh - 2, 2, 3 + rh / 3, mulc(roof, 0.75f));   /* chimney */
    if (layer == 0) return;
    int ws = layer == 1 ? 2 : 3;
    Col glass = night > 0.3f ? 0xFFD36A : lerpc(0x9CC6E8, col, 0.3f);
    if (night > 0.3f && rfn(h, 10) < 0.25f) glass = mulc(wall, 0.7f);
    R(w, sx + 2, y0 + 2, ws, ws, glass);
    R(w, sx + bw - 2 - ws - (layer == 2 ? 1 : 0), y0 + 2, ws, ws, glass);
    R(w, sx + bw / 2 - 1, base - (layer == 1 ? 4 : 5), 2, layer == 1 ? 4 : 5, mulc(roof, 0.9f));            /* door */
}
static void bg_suburb(AWWorld *w, int layer, int X0, int segL, int camL, int hmin, int hmax, Col col, float night) {
    static const int CELL[3] = { 20, 32, 44 };
    int C = CELL[layer];
    float sc = (float)w->vh / 180.0f;
    int k0 = floordiv(imax(X0, camL - 40), C), k1 = floordiv(imin(X0 + segL, camL + w->vw + 40), C);
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ (0x5B0Bu + (uint32_t)layer * 53u), (uint32_t)k);
        int X = k * C + (int)(rfn(h, 1) * (float)(C / 4));
        float pres = bg_presence(X, X0, segL);
        int sx = X - camL;
        if (rfn(h, 0) < 0.80f * pres) {
            static const int BWL[3] = { 8, 14, 20 }, BWH[3] = { 11, 20, 28 };
            int bw = BWL[layer] + (int)(rfn(h, 2) * (float)(BWH[layer] - BWL[layer]));
            int wh = (int)((layer == 0 ? 5.0f : (layer == 1 ? 8.0f : 11.0f)) * sc) + (int)(rfn(h, 3) * 3.0f);
            int rh = imax(3, bw * 2 / 5);
            int base = w->gy - bg_height(w, X + bw / 2, layer, hmin, hmax, segL);
            bg_house(w, sx, base, bw, wh, rh, hash2(h, 7u), layer, col, night);
        }
        /* a round tree in the gap */
        if (rfn(h, 4) < 0.62f * pres) {
            int tx = X + C / 2 + 4 + (int)(rfn(h, 5) * 6.0f);
            int base = w->gy - bg_height(w, tx, layer, hmin, hmax, segL);
            int rr = (layer == 0 ? 3 : (layer == 1 ? 4 : 6)) + (int)(rfn(h, 6) * 2.0f);
            Col tc = bg_green(w, col, layer == 0 ? 0.42f : 0.55f);
            int cy = base - rr - 2, txs = tx - camL;
            for (int dy = -rr; dy <= rr; dy++) for (int dx = -rr; dx <= rr; dx++)
                if (dx * dx + dy * dy <= rr * rr + rr / 2) PX(w, txs + dx, cy + dy, (dx + dy < -rr / 2) ? lerpc(tc, 0xFFFFFF, 0.14f) : (dx > rr / 3 ? mulc(tc, 0.84f) : tc));
            R(w, txs, cy + rr - 1, 1, base - (cy + rr - 1) + 3, mulc(tc, 0.55f));
        }
    }
}

/* ---- FARM: barns, silos, a turning windmill, haystacks ---- */
static void bg_farm(AWWorld *w, int layer, int X0, int segL, int camL, int hmin, int hmax, Col col, float night) {
    static const int CELL[3] = { 56, 72, 64 };
    int C = CELL[layer];
    float sc = (float)w->vh / 180.0f;
    float k = layer == 0 ? 0.40f : (layer == 1 ? 0.28f : 0.16f);
    int k0 = floordiv(imax(X0, camL - 50), C), k1 = floordiv(imin(X0 + segL, camL + w->vw + 50), C);
    for (int q = k0; q <= k1; q++) {
        uint32_t h = hash2(w->seed ^ (0xFA2Au + (uint32_t)layer * 41u), (uint32_t)q);
        int X = q * C + 8 + (int)(rfn(h, 1) * (float)(C - 30));
        float pres = bg_presence(X, X0, segL);
        if (rfn(h, 0) > 0.85f * pres) continue;
        int sx = X - camL;
        int base = w->gy - bg_height(w, X, layer, hmin, hmax, segL);
        int kind = (int)(rfn(h, 2) * 4.0f);
        float m = layer == 0 ? 0.55f : (layer == 1 ? 0.8f : 1.0f);
        if (kind == 0 || kind == 3) {                       /* barn with a silo */
            int bw = (int)(22.0f * m) & ~1, bh = (int)(12.0f * m * sc);
            Col red = bg_haze(w, 0xB8452E, col, k, night), trim = bg_haze(w, 0xF4EBDD, col, k, night), dark = bg_haze(w, 0x5A3A34, col, k, night);
            R(w, sx, base - bh, bw, bh + 6, red);
            R(w, sx + bw - 2, base - bh, 2, bh + 6, mulc(red, 0.84f));
            for (int i = 0; i < 6; i++) {                       /* gambrel roof */
                int inset = i < 3 ? i * 2 : 6 + (i - 2);
                if (inset * 2 >= bw) break;
                R(w, sx - 1 + inset, base - bh - 1 - i, bw + 2 - 2 * inset, 1, i == 0 ? mulc(dark, 0.9f) : dark);
            }
            if (layer > 0) {
                int dw = bw / 3, dh = bh * 3 / 4;
                R(w, sx + bw / 2 - dw / 2, base - dh, dw, dh, trim);
                R(w, sx + bw / 2 - dw / 2 + 1, base - dh + 1, dw - 2, dh - 1, red);
                for (int i = 1; i < dh - 1; i++) { PX(w, sx + bw / 2 - dw / 2 + 1 + (i * (dw - 3)) / (dh - 2), base - dh + i, trim); PX(w, sx + bw / 2 + dw / 2 - 2 - (i * (dw - 3)) / (dh - 2), base - dh + i, trim); }
            }
            int sh = (int)(24.0f * m * sc), sw = layer == 0 ? 4 : 6;                    /* silo */
            Col sc1 = bg_haze(w, 0xB9C2CC, col, k, night);
            R(w, sx + bw + 2, base - sh, sw, sh + 6, sc1);
            R(w, sx + bw + 2 + sw - 2, base - sh, 2, sh + 6, mulc(sc1, 0.82f));
            for (int i = 0; i < sw / 2 + 1; i++) R(w, sx + bw + 2 + i, base - sh - (sw / 2 - i) , sw - 2 * i, 1, mulc(sc1, 0.9f));
        } else if (kind == 1) {                             /* windmill */
            int th = (int)(26.0f * m * sc);
            Col tw = bg_haze(w, 0xE8E0D0, col, k, night);
            for (int i = 0; i < th; i++) { int hw = 1 + (th - i) / (th / 3 + 1); R(w, sx - hw / 2 - 1, base - i, hw + 2, 1, tw); }
            double a0 = w->t * 0.9 + (double)q;
            Col bl = bg_haze(w, 0xF6F0E4, col, k * 0.6f, night);
            int bl_len = (int)(11.0f * m);
            for (int b = 0; b < 4; b++) {
                double a = a0 + b * 1.5707963;
                for (int i = 2; i <= bl_len; i++) {
                    int px = sx + (int)floor(cos(a) * (double)i + 0.5), py = base - th + (int)floor(sin(a) * (double)i + 0.5);
                    PX(w, px, py, bl);
                    if (i > bl_len / 2) PX(w, px + (sin(a) > 0.3 ? 1 : 0), py + (cos(a) > 0.3 ? 0 : 1), bl);
                }
            }
            R(w, sx - 1, base - th - 1, 3, 3, mulc(tw, 0.8f));
        } else {                                            /* farmhouse + haystacks */
            int bw = (int)(16.0f * m) & ~1;
            bg_house(w, sx, base, bw, (int)(8.0f * m * sc), imax(3, bw * 2 / 5), hash2(h, 3u), layer, col, night);
            if (layer > 0) for (int s = 0; s < 3; s++) {
                int hx = sx + bw + 5 + s * 9, hr = 4;
                Col hay = bg_haze(w, 0xE0B850, col, k, night);
                for (int dy = 0; dy < hr; dy++) R(w, hx - hr + dy / 2 + (dy < 1 ? 1 : 0), base + 2 - dy, 2 * hr - dy - (dy < 1 ? 2 : 0), 1, dy == 0 ? mulc(hay, 0.85f) : hay);
            }
        }
    }
}

/* ---- one parallax layer: ornaments first, then the hill silhouette in front of their feet ---- */
static void draw_bg_layer(AWWorld *w, double par, int layer, int hmin, int hmax, Col col, int caps) {
    int camL = (int)floor(w->cam * par);
    int segL = imax(60, (int)(BG_SEG * par));
    float night = bg_night(w);
    int s0 = floordiv(camL - 70, segL), s1 = floordiv(camL + w->vw + 70, segL);
    for (int seg = s0; seg <= s1; seg++) {
        int st = bg_style_seg(w, seg), X0 = seg * segL;
        switch (st) {
            case BG_HILLS:  bg_hills(w, layer, X0, segL, camL, hmin, hmax, col, night); break;
            case BG_CITY:   bg_city(w, layer, X0, segL, camL, hmin, hmax, col, night); break;
            case BG_FOREST: bg_forest(w, layer, X0, segL, camL, hmin, hmax, col, night); break;
            case BG_SUBURB: bg_suburb(w, layer, X0, segL, camL, hmin, hmax, col, night); break;
            case BG_FARM:   bg_farm(w, layer, X0, segL, camL, hmin, hmax, col, night); break;
            default: break;
        }
    }
    float thr = (float)hmin + (float)(hmax - hmin) * 0.55f;
    for (int x = 0; x < w->vw; x++) {
        int X = camL + x;
        int sc, sn; float wc;
        bg_mix(w, X, segL, &sc, &sn, &wc);
        int hh = bg_height(w, X, layer, hmin, hmax, segL);
        int top = w->gy - hh;
        /* region tint: a layer's silhouette gets greener over hills / forest / farm land, redder over mesas */
        Col cc = col;
        for (int i = 0; i < 2; i++) {
            int s = i == 0 ? sc : sn; float wt = i == 0 ? wc : 1.0f - wc;
            if (s == BG_HILLS || s == BG_FOREST || s == BG_FARM || s == BG_SUBURB) cc = lerpc(cc, bg_green(w, col, 1.0f), (s == BG_FOREST ? 0.42f : (s == BG_SUBURB ? 0.22f : (s == BG_HILLS ? 0.50f : 0.34f))) * wt * (layer == 0 ? 0.75f : 1.0f));
            else if (s == BG_MESA) cc = lerpc(cc, mulc(0xC8683A, 1.0f - 0.65f * night), (layer == 0 ? 0.50f : 0.62f) * wt);
        }
        float mt = (sc == BG_MOUNTAIN ? wc : 0.0f) + (sn == BG_MOUNTAIN ? 1.0f - wc : 0.0f);
        int capn = (caps && w->cur.cap > 0.5f && mt > 0.5f && (float)hh > thr) ? 2 + (int)(((float)hh - thr) / 5.0f) : 0;
        float field = (sc == BG_HILLS || sc == BG_FARM) ? wc : 0.0f;
        field += (sn == BG_HILLS || sn == BG_FARM) ? 1.0f - wc : 0.0f;
        float mesa = (sc == BG_MESA ? wc : 0.0f) + (sn == BG_MESA ? 1.0f - wc : 0.0f);
        Col patch = cc;
        if (field > 0.5f && layer > 0) {
            static const Col PCH[4] = { 0xD8C060, 0x6FB050, 0x9A7A4A, 0xA8D060 };
            uint32_t ph = hash2(w->seed ^ 0xF1E1u, (uint32_t)(floordiv(X, 34) + layer * 91));
            patch = lerpc(cc, mulc(PCH[ph & 3u], 1.0f - 0.6f * night), 0.30f);
        }
        for (int y = imax(top, -w->oy); y < w->gy && y + w->oy < w->vh; y++) {
            int d = y - top;
            Col c = cc;
            if (d < capn) c = w->cur.cap_c;
            else if (field > 0.5f && layer > 0) c = d < 22 ? ((d / 2) & 1 ? patch : lerpc(patch, 0xFFFFFF, 0.06f)) : cc;
            else if (mesa > 0.5f && layer > 0) c = (d % 7 < 2) ? lerpc(cc, 0x8A3A22, 0.22f) : (d < 2 ? lerpc(cc, 0xFFE0B0, 0.2f) : cc);
            w->px[(y + w->oy) * w->vw + x] = c;
        }
    }
}
