/*
 * Archon's Life - shared pixel-world engine. See aw_engine.h.
 *
 * The world is a pure function of world-x (plus a per-instance seed), so nothing needs to be
 * stored for terrain, scenery, clouds or info signs: every frame we just redraw whatever is on
 * screen. Time-based things (biome palettes, drifting clouds, the clock) are functions of
 * Archon's distance travelled and the running clock.
 *
 * Archon wanders through the world and, every so often, changes how he travels: he sprouts
 * wings, drives a flying car, rides a rocket into space, floats in a hot-air balloon, flies on
 * a magic carpet or straps on a jetpack. Surprise guests (a fox, a slime, a robot, a rival
 * Archon, elemental wisps, a ghost, a wizard, a dragon, a UFO...) drop in at random. Signs,
 * blimps and balloon banners carry the live time, date and temperature past as he goes.
 *
 * Art style follows the Archon's Life login screen: chunky pixels, bright grass over
 * checkered-speck dirt, stepped flat-bottomed clouds, the crowned orange Archon.
 */
#include "aw_engine.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef uint32_t Col;

#define TARGET_ROWS 192
#define SEG_LEN     1800.0   /* world px per biome */
#define NPAL        9
#define MAXFX       192
#define MAXGUEST    3
#define TRN         2048     /* tunnel-trail columns remembered (the digger's cavity) */
#define SEA_LEN     3200.0   /* world px per season */


/* ------------------------------------------------------------------ */
/* small helpers                                                       */
/* ------------------------------------------------------------------ */
static inline uint32_t hash32(uint32_t x) {
    x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16;
    return x;
}
static inline uint32_t hash2(uint32_t a, uint32_t b) {
    return hash32(a * 0x9E3779B1U ^ hash32(b + 0x7F4A7C15U));
}
/* n-th independent random float in [0,1) derived from hash h */
static inline float rfn(uint32_t h, int n) {
    return (float)(hash32(h * 0x9E3779B1U + (uint32_t)n * 0x85EBCA6BU + 0x1234567U) & 0xFFFFFF) / 16777216.0f;
}
static inline int floordiv(int a, int b) {
    int q = a / b;
    if ((a % b != 0) && ((a < 0) != (b < 0))) q--;
    return q;
}
static inline int imin(int a, int b) { return a < b ? a : b; }
static inline int imax(int a, int b) { return a > b ? a : b; }
static inline float smooth(float t) { return t * t * (3.0f - 2.0f * t); }

static inline Col rgb(int r, int g, int b) {
    r = r < 0 ? 0 : (r > 255 ? 255 : r);
    g = g < 0 ? 0 : (g > 255 ? 255 : g);
    b = b < 0 ? 0 : (b > 255 ? 255 : b);
    return (Col)((r << 16) | (g << 8) | b);
}
static Col lerpc(Col a, Col b, float t) {
    int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
    int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
    return rgb(ar + (int)((br - ar) * t + 0.5f), ag + (int)((bg - ag) * t + 0.5f), ab + (int)((bb - ab) * t + 0.5f));
}
static Col mulc(Col a, float f) {
    return rgb((int)(((a >> 16) & 255) * f), (int)(((a >> 8) & 255) * f), (int)((a & 255) * f));
}
static inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }

/* ------------------------------------------------------------------ */
/* palettes ("biomes")                                                 */
/* ------------------------------------------------------------------ */
enum { DK_ROUND, DK_PINE, DK_CACTUS, DK_DEAD, DK_CRYSTAL, DK_HUT, DK_MUSH, DK_ROCK, DK_BUSH, DK_SPIKES };
enum { FL_FLOWERS, FL_MUSH, FL_PEBBLES };
enum { PT_NONE, PT_LEAVES, PT_PETALS, PT_EMBERS, PT_SNOW, PT_FIREFLY, PT_SAND, PT_SPARKLE };

typedef struct {
    Col   sky_top, sky_mid, sky_bot;
    Col   cel_col;  int cel_kind;  float cel_y;   /* kind 0 sun, 1 moon; y = fraction of ground line */
    float stars;
    Col   cloud, cloud_sh;
    Col   far_c, mid_c, near_c, cap_c;  float peaky, cap;
    Col   grass_pale, grass_main, grass_dark, tick_dark, tick_light;
    Col   dirt, dirt_dk, dirt_lt;
    Col   fol1, fol2, trunk, acc1, acc2;
    Col   liq, liq_hi;
    int   decor[2];  int flora;  int ptype;
} Pal;

static const Pal PALS[NPAL] = {
    /* 0 MEADOW - the blue-sky icon look */
    { .sky_top = 0x62B8F5, .sky_mid = 0x8FD0FA, .sky_bot = 0xC4ECFF,
      .cel_col = 0xFFE45E, .cel_kind = 0, .cel_y = 0.22f, .stars = 0.0f,
      .cloud = 0xFFFFFF, .cloud_sh = 0xD4EAF7,
      .far_c = 0x9DC9D8, .mid_c = 0x7DBF8E, .near_c = 0x4FA867, .cap_c = 0xFFFFFF, .peaky = 0.35f, .cap = 0.0f,
      .grass_pale = 0xB4F08E, .grass_main = 0x7DDB5C, .grass_dark = 0x4FB04A, .tick_dark = 0x4FB04A, .tick_light = 0x95E873,
      .dirt = 0x8C5A2F, .dirt_dk = 0x744623, .dirt_lt = 0xB27A43,
      .fol1 = 0x3FA34D, .fol2 = 0x2E7D3A, .trunk = 0x7A4A24, .acc1 = 0xFF6FA3, .acc2 = 0xFFD23F,
      .liq = 0x3FA7F0, .liq_hi = 0xA8E4FF,
      .decor = { DK_ROUND, DK_BUSH }, .flora = FL_FLOWERS, .ptype = PT_PETALS },
    /* 1 DESERT */
    { .sky_top = 0x56B5F0, .sky_mid = 0xA9DCEF, .sky_bot = 0xFFEFC0,
      .cel_col = 0xFFF2A0, .cel_kind = 0, .cel_y = 0.18f, .stars = 0.0f,
      .cloud = 0xFFF8E6, .cloud_sh = 0xF0DDB8,
      .far_c = 0xE8C58A, .mid_c = 0xD9A863, .near_c = 0xC48A45, .cap_c = 0xFFFFFF, .peaky = 0.0f, .cap = 0.0f,
      .grass_pale = 0xFBE9A8, .grass_main = 0xF0CF7A, .grass_dark = 0xD3A94F, .tick_dark = 0xD3A94F, .tick_light = 0xFFF3C2,
      .dirt = 0xC48F4A, .dirt_dk = 0xA8742F, .dirt_lt = 0xDDAA66,
      .fol1 = 0x3F9B4F, .fol2 = 0x2E7A3E, .trunk = 0x8A5A2B, .acc1 = 0xFF6F91, .acc2 = 0xFFD23F,
      .liq = 0x2FB6D8, .liq_hi = 0x9CF0F8,
      .decor = { DK_CACTUS, DK_ROCK }, .flora = FL_PEBBLES, .ptype = PT_SAND },
    /* 2 AUTUMN */
    { .sky_top = 0xF6B36B, .sky_mid = 0xFFD08A, .sky_bot = 0xFFEBC2,
      .cel_col = 0xFFF0B0, .cel_kind = 0, .cel_y = 0.34f, .stars = 0.0f,
      .cloud = 0xFFF0DC, .cloud_sh = 0xF1C9A0,
      .far_c = 0xD9A878, .mid_c = 0xC97D3F, .near_c = 0xA85A2A, .cap_c = 0xFFFFFF, .peaky = 0.2f, .cap = 0.0f,
      .grass_pale = 0xF2E48E, .grass_main = 0xD9B445, .grass_dark = 0xB8862B, .tick_dark = 0xB8862B, .tick_light = 0xF6EAA8,
      .dirt = 0x7A4A28, .dirt_dk = 0x5F3820, .dirt_lt = 0xA06A3C,
      .fol1 = 0xE8642A, .fol2 = 0xC9401E, .trunk = 0x6B3E1F, .acc1 = 0xFFB020, .acc2 = 0xE8442A,
      .liq = 0x3B8FD0, .liq_hi = 0x9ACBF0,
      .decor = { DK_ROUND, DK_ROUND }, .flora = FL_FLOWERS, .ptype = PT_LEAVES },
    /* 3 DUSK */
    { .sky_top = 0x2A2063, .sky_mid = 0xB03E7F, .sky_bot = 0xFF9C5A,
      .cel_col = 0xFFD38A, .cel_kind = 0, .cel_y = 0.66f, .stars = 0.2f,
      .cloud = 0xFF8F7A, .cloud_sh = 0xB5457A,
      .far_c = 0x7A3C86, .mid_c = 0x542A6E, .near_c = 0x3A1F52, .cap_c = 0xFFFFFF, .peaky = 0.5f, .cap = 0.0f,
      .grass_pale = 0x9FD67A, .grass_main = 0x5FB84F, .grass_dark = 0x3A8A3E, .tick_dark = 0x3A8A3E, .tick_light = 0x7FD068,
      .dirt = 0x6B4426, .dirt_dk = 0x54331C, .dirt_lt = 0x8A5A32,
      .fol1 = 0x2F7D4A, .fol2 = 0x1F5C3A, .trunk = 0x4A2E1C, .acc1 = 0xFFD23F, .acc2 = 0xFF6A3A,
      .liq = 0x3A5FC8, .liq_hi = 0x8FB0F0,
      .decor = { DK_HUT, DK_ROUND }, .flora = FL_FLOWERS, .ptype = PT_FIREFLY },
    /* 4 EMBER - the dark-red login-screen theme */
    { .sky_top = 0x1A0606, .sky_mid = 0x4A1010, .sky_bot = 0xA02A14,
      .cel_col = 0xFF5A2A, .cel_kind = 0, .cel_y = 0.60f, .stars = 0.3f,
      .cloud = 0x371F1F, .cloud_sh = 0x2A1414,
      .far_c = 0x5A1612, .mid_c = 0x3A0E0E, .near_c = 0x240808, .cap_c = 0xFFFFFF, .peaky = 1.0f, .cap = 0.0f,
      .grass_pale = 0xB4F08E, .grass_main = 0x7DDB5C, .grass_dark = 0x4FB04A, .tick_dark = 0x4FB04A, .tick_light = 0x95E873,
      .dirt = 0x8C5A2F, .dirt_dk = 0x744623, .dirt_lt = 0xB27A43,
      .fol1 = 0x2B1010, .fol2 = 0x3A1818, .trunk = 0x1E0C0C, .acc1 = 0xFF6A1F, .acc2 = 0xFFC24A,
      .liq = 0xFF5A1F, .liq_hi = 0xFFC24A,
      .decor = { DK_DEAD, DK_SPIKES }, .flora = FL_PEBBLES, .ptype = PT_EMBERS },
    /* 5 NIGHT */
    { .sky_top = 0x050818, .sky_mid = 0x0E1840, .sky_bot = 0x24366E,
      .cel_col = 0xF4F1D0, .cel_kind = 1, .cel_y = 0.24f, .stars = 1.0f,
      .cloud = 0x2A3A78, .cloud_sh = 0x1C2858,
      .far_c = 0x1C2A5E, .mid_c = 0x131E48, .near_c = 0x0C1432, .cap_c = 0xFFFFFF, .peaky = 0.6f, .cap = 0.0f,
      .grass_pale = 0x8FD8A6, .grass_main = 0x4FAF72, .grass_dark = 0x2F8654, .tick_dark = 0x2F8654, .tick_light = 0xA8F0C0,
      .dirt = 0x4A3322, .dirt_dk = 0x392718, .dirt_lt = 0x664830,
      .fol1 = 0x1D6B52, .fol2 = 0x134A3B, .trunk = 0x2B1B12, .acc1 = 0x7DF9FF, .acc2 = 0xB58CFF,
      .liq = 0x1E4FB0, .liq_hi = 0x6FA0FF,
      .decor = { DK_PINE, DK_MUSH }, .flora = FL_MUSH, .ptype = PT_FIREFLY },
    /* 6 VIOLET TWILIGHT */
    { .sky_top = 0x1A0F3C, .sky_mid = 0x6A3AA0, .sky_bot = 0xF27AB6,
      .cel_col = 0xFFE6F6, .cel_kind = 1, .cel_y = 0.30f, .stars = 0.8f,
      .cloud = 0xA56FD8, .cloud_sh = 0x7A47B0,
      .far_c = 0x5A2F8E, .mid_c = 0x43226E, .near_c = 0x2E1752, .cap_c = 0xFFFFFF, .peaky = 0.8f, .cap = 0.0f,
      .grass_pale = 0xA8F5D0, .grass_main = 0x55D9A8, .grass_dark = 0x2FA882, .tick_dark = 0x2FA882, .tick_light = 0xC8FFE6,
      .dirt = 0x4B2F5E, .dirt_dk = 0x3A234A, .dirt_lt = 0x6E4887,
      .fol1 = 0x7A4BD0, .fol2 = 0x5A32A8, .trunk = 0x2E1A44, .acc1 = 0xFF7AD9, .acc2 = 0x7DF9FF,
      .liq = 0x8A3AE0, .liq_hi = 0xE0A8FF,
      .decor = { DK_CRYSTAL, DK_MUSH }, .flora = FL_MUSH, .ptype = PT_SPARKLE },
    /* 7 FROST */
    { .sky_top = 0x8FCFF2, .sky_mid = 0xC4E8FA, .sky_bot = 0xF2FBFF,
      .cel_col = 0xFFFBE0, .cel_kind = 0, .cel_y = 0.26f, .stars = 0.0f,
      .cloud = 0xFFFFFF, .cloud_sh = 0xD0E6F2,
      .far_c = 0xCFE2F0, .mid_c = 0xA8C8E0, .near_c = 0x88AECF, .cap_c = 0xFFFFFF, .peaky = 1.0f, .cap = 1.0f,
      .grass_pale = 0xFFFFFF, .grass_main = 0xE6F3FB, .grass_dark = 0xBFD9EA, .tick_dark = 0xBFD9EA, .tick_light = 0xFFFFFF,
      .dirt = 0x6D5A4A, .dirt_dk = 0x574637, .dirt_lt = 0x8B7561,
      .fol1 = 0x2F6B5A, .fol2 = 0x1F4E44, .trunk = 0x4A3526, .acc1 = 0xBFEFFF, .acc2 = 0xFFFFFF,
      .liq = 0x2F78C8, .liq_hi = 0xA8DCFF,
      .decor = { DK_PINE, DK_CRYSTAL }, .flora = FL_PEBBLES, .ptype = PT_SNOW },
    /* 8 DAWN */
    { .sky_top = 0x3E5CB0, .sky_mid = 0xF29AC0, .sky_bot = 0xFFE2A6,
      .cel_col = 0xFFF3B0, .cel_kind = 0, .cel_y = 0.62f, .stars = 0.2f,
      .cloud = 0xFFC4D8, .cloud_sh = 0xE08FB0,
      .far_c = 0xB58AC8, .mid_c = 0x8C6BB0, .near_c = 0x5D4A8C, .cap_c = 0xFFFFFF, .peaky = 0.4f, .cap = 0.0f,
      .grass_pale = 0xB4F08E, .grass_main = 0x7DDB5C, .grass_dark = 0x4FB04A, .tick_dark = 0x4FB04A, .tick_light = 0x95E873,
      .dirt = 0x8C5A2F, .dirt_dk = 0x744623, .dirt_lt = 0xB27A43,
      .fol1 = 0x4FB05A, .fol2 = 0x3A8A48, .trunk = 0x7A4A24, .acc1 = 0xFF8FB8, .acc2 = 0xFFE066,
      .liq = 0x4FA8E8, .liq_hi = 0xBFE8FF,
      .decor = { DK_ROUND, DK_BUSH }, .flora = FL_FLOWERS, .ptype = PT_PETALS },
};

/* The tour order. Adjacent entries are chosen to crossfade nicely. */
static const int PAL_ORDER[NPAL] = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

#define LERP_COL(f) o->f = lerpc(a->f, b->f, t)
#define LERP_F(f)   o->f = lerpf(a->f, b->f, t)
static void pal_lerp(const Pal *a, const Pal *b, float t, Pal *o) {
    *o = (t < 0.5f) ? *a : *b; /* enums/ints switch at the midpoint */
    LERP_COL(sky_top); LERP_COL(sky_mid); LERP_COL(sky_bot);
    LERP_COL(cel_col); LERP_F(cel_y); LERP_F(stars);
    LERP_COL(cloud); LERP_COL(cloud_sh);
    LERP_COL(far_c); LERP_COL(mid_c); LERP_COL(near_c); LERP_COL(cap_c); LERP_F(peaky); LERP_F(cap);
    LERP_COL(grass_pale); LERP_COL(grass_main); LERP_COL(grass_dark); LERP_COL(tick_dark); LERP_COL(tick_light);
    LERP_COL(dirt); LERP_COL(dirt_dk); LERP_COL(dirt_lt);
    LERP_COL(fol1); LERP_COL(fol2); LERP_COL(trunk); LERP_COL(acc1); LERP_COL(acc2);
    LERP_COL(liq); LERP_COL(liq_hi);
}

/* ------------------------------------------------------------------ */
/* world state                                                         */
/* ------------------------------------------------------------------ */
typedef struct { double x; float y, vx, vy, life, max; int kind; Col col; } Spark;
enum { SK_SPARKLE, SK_DUST, SK_SMOKE, SK_FLAME, SK_HEART, SK_STAR, SK_GLITTER, SK_DROP, SK_BUBBLE, SK_FOAM, SK_CHUNK };

enum { M_WALK, M_WINGS, M_CAR, M_ROCKET, M_BALLOON, M_CARPET, M_JETPACK, M_DIG, M_SUB, M_BOAT, M_ROAD, M_DIVE, M_COUNT };
enum { SE_SPRING, SE_SUMMER, SE_AUTUMN, SE_WINTER };
enum { PH_IN, PH_ACT, PH_OUT };
enum { G_NONE, G_FOX, G_SLIME, G_ROBOT, G_BLUE, G_WISP_F, G_WISP_W, G_WISP_E, G_WISP_A,
       G_GHOST, G_BIRDS, G_WIZARD, G_DRAGON, G_UFO,
       G_HEDGE, G_WORM, G_MOLE, G_BEETLE,                       /* underground friends */
       G_FISH, G_JELLY, G_TURTLE, G_CRAB, G_OCTO, G_WHALE,      /* underwater friends */
       G_DOLPHIN,                                               /* jumps beside the sailboat */
       G_CORGI, G_DALM, G_HUSKY,                                /* more cute dogs (ground friends) */
       G_CAT, G_TERRIER,                                        /* cats, and the little white terrier with his sign */
       G_PERSON,                                                /* someone out for a stroll */
       G_LEAPER,                                                /* fish that leap out of the water beside the boat */
       G_COUNT };

typedef struct { int type, state, dir; double x; float y, vx, vy, t, life, a, b, c; uint32_t h; } Guest;

struct AWWorld {
    int vw, vh, gy, oy;
    uint32_t *px;
    uint32_t seed, rng;
    double t, biome_off;

    /* Archon */
    double ax; float ay, alt, valt, surf_s, spd;
    int mode, last_mode, last_mode2, phase, stage, idle, touched;
    float phase_t, stage_t, act_len, walk_len, idle_t, next_idle, anim_t, blink_t, next_blink, grounded_t;
    float pitch, vup, wob, oy_f, smoke_t;
    double cam; int cam_off;

    Pal cur; int pa, pb; float pt;
    float cel_y; int cel_kind; Col cel_col;
    float dark;

    /* lakes (made just ahead of Archon when he sails or dives), the digger's tunnel, seasons */
    int lk_on; double lk_x0, lk_x1; float lk_depth; uint32_t lk_seed;
    int lk_dive;             /* 0 = an ordinary lake, 1 = a shallow snorkelling reef, 2 = a deep scuba dive */
    int dive_kind, dive_force;   /* 0 snorkel, 1 scuba (and the debug override: 0 none, 1 snorkel, 2 scuba) */
    int tr_x[TRN]; short tr_y[TRN], tr_r[TRN];
    uint32_t dkey;           /* stable per-tree key for seasonal decoration */
    float dig_slope;
    float sea_k[4]; int sea_a, sea_b; float sea_t;
    double sea_off; int sea_k0, sea_f0, sea_ck, sea_cf;
    float dig_head;          /* digger heading: -1 diving, 0 level, +1 climbing */

    Spark fx[MAXFX];
    Guest guests[MAXGUEST];
    float next_guest;

    /* clock / weather */
    int ink;                 /* LED colour set of the display being drawn */
    int car_force, bal_force;   /* test hooks: which carrier holds every sign (1 + kind), which balloon style (1 + style) */
    int boat, last_boat, boat_force;   /* which boat he is sailing (aw_boats.inc); boat_force is a test hook */
    int lk_pl;               /* length of the piers at the two ends of the lake (0 = no piers) */
    int veh_force;           /* test hook: aw_debug_veh(k) makes the next road trip use vehicle k */
    int veh, last_veh;       /* road trips: which vehicle, and which one he drove last time */
    int jp_on; double jp_x0, jp_x1; float jp_amp, jp_lam, jp_ph; uint32_t jp_seed;   /* the jeep's rolling hills (a dirt trail over big hills) */
    int rd_on, rd_h; double rd_x0, rd_x1;   /* the level road laid ahead of him (rd_h = its height above the ground line) */
    int bg_force;            /* test hook: >= 0 pins the backdrop style (set via aw_debug_bg; stored +1 so calloc means "free") */
    int clock24, fahrenheit, w_valid, w_code, w_isday; float w_temp_c;
    int tm_hour, tm_min, tm_sec, tm_wday, tm_mon, tm_mday, tm_override; double tm_poll;
    int tm_year;             /* 4-digit year of the local date */
    int hol, hol_force;      /* today's holiday theme (H_*), and the test hook (stored +1 so calloc means automatic) */
    int lm_force;            /* test hook: pins a landmark beside the path (stored +1) */
    int dfmt, dfmt_force;    /* how the date display is written (see info_content); the test hook is stored +1 */
};

static inline uint32_t rng_u32(AWWorld *w) {
    uint32_t x = w->rng; x ^= x << 13; x ^= x >> 17; x ^= x << 5; w->rng = x; return x;
}
static inline float rng_f(AWWorld *w) { return (float)(rng_u32(w) >> 8) * (1.0f / 16777216.0f); }
static inline float rng_r(AWWorld *w, float a, float b) { return a + (b - a) * rng_f(w); }
static inline float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static float approach(float cur, float tgt, float rate, float dt) {
    float k = rate * dt; if (k > 1.0f) k = 1.0f; return cur + (tgt - cur) * k;
}

/* ------------------------------------------------------------------ */
/* drawing primitives (y is world-y; oy is the camera's vertical shift) */
/* ------------------------------------------------------------------ */
static inline void PX(AWWorld *w, int x, int y, Col c) {
    y += w->oy;
    if ((unsigned)x < (unsigned)w->vw && (unsigned)y < (unsigned)w->vh) w->px[y * w->vw + x] = c;
}
static void BLEND(AWWorld *w, int x, int y, Col c, int a256) {
    y += w->oy;
    if ((unsigned)x >= (unsigned)w->vw || (unsigned)y >= (unsigned)w->vh) return;
    Col d = w->px[y * w->vw + x];
    int r = (int)((d >> 16) & 255) + ((((int)((c >> 16) & 255) - (int)((d >> 16) & 255)) * a256) >> 8);
    int g = (int)((d >> 8) & 255) + ((((int)((c >> 8) & 255) - (int)((d >> 8) & 255)) * a256) >> 8);
    int b = (int)(d & 255) + ((((int)(c & 255) - (int)(d & 255)) * a256) >> 8);
    w->px[y * w->vw + x] = rgb(r, g, b);
}
static void R(AWWorld *w, int x, int y, int ww, int hh, Col c) {
    y += w->oy;
    int x0 = imax(x, 0), y0 = imax(y, 0), x1 = imin(x + ww, w->vw), y1 = imin(y + hh, w->vh);
    for (int yy = y0; yy < y1; yy++) {
        uint32_t *row = w->px + yy * w->vw;
        for (int xx = x0; xx < x1; xx++) row[xx] = c;
    }
}
static void disc(AWWorld *w, int cx, int cy, int r, Col c) {
    for (int dy = -r; dy <= r; dy++)
        for (int dx = -r; dx <= r; dx++)
            if (dx * dx + dy * dy <= r * r + r / 2) PX(w, cx + dx, cy + dy, c);
}

/* smooth 1-D value noise */
static float vn(uint32_t seed, float x) {
    int xi = (int)floorf(x);
    float f = x - (float)xi;
    float a = rfn(hash2(seed, (uint32_t)xi), 0), b = rfn(hash2(seed, (uint32_t)(xi + 1)), 0);
    return a + (b - a) * smooth(f);
}

/* gentle rolling ground: flat stretches and low hills, 0..12 px above the ground line */
static int ground_raw(const AWWorld *w, int x) {
    float v = 0.65f * vn(w->seed ^ 0x6E0DU, (float)x / 210.0f) + 0.35f * vn(w->seed ^ 0x77U, (float)x / 71.0f);
    int h = (int)((v - 0.32f) * 26.0f);
    return h < 0 ? 0 : (h > 12 ? 12 : h);
}

/* A lake is made just ahead of Archon whenever he is about to sail or dive. Its bed is carved below the ground
 * line; the water level is the ground line itself, so water appears wherever the ground sinks below it. */
static int lake_depth(const AWWorld *w, int x) {
    if (!w->lk_on) return 0;
    float fx = (float)x;
    if (fx <= (float)w->lk_x0 || fx >= (float)w->lk_x1) return 0;
    float e = fminf(fx - (float)w->lk_x0, (float)w->lk_x1 - fx) / 78.0f;
    e = e > 1.0f ? 1.0f : e;
    e = e * e * (3.0f - 2.0f * e);
    float prof = w->lk_depth * (0.70f + 0.30f * vn(w->lk_seed, fx / 83.0f)) + (vn(w->lk_seed + 3u, fx / 9.0f) - 0.5f) * 4.0f;
    int d = (int)(e * prof);
    return d < 0 ? 0 : d;
}
static float lake_flat(const AWWorld *w, int x) {   /* 0 on dry land .. 1 inside the lake: hills are levelled */
    if (!w->lk_on) return 0.0f;
    float fx = (float)x;
    if (fx <= (float)w->lk_x0) return 0.0f;
    if (fx >= (float)w->lk_x1) return 0.0f;
    float m = fminf(fx - (float)w->lk_x0, (float)w->lk_x1 - fx) / 40.0f;
    return m > 1.0f ? 1.0f : m;
}
#define PIER_H 3
/* the piers: a deck PIER_H px above the water at each end of a lake made for one of the bigger boats */
static int pier_deck(const AWWorld *w, double x) {
    if (!w->lk_on || w->lk_pl <= 0) return 0;
    if (x >= w->lk_x0 - 12.0 && x <= w->lk_x0 + (double)w->lk_pl) return PIER_H;
    if (x >= w->lk_x1 - (double)w->lk_pl && x <= w->lk_x1 + 12.0) return PIER_H;
    return 0;
}
static int pier_near(const AWWorld *w, double x) { return pier_deck(w, x) || pier_deck(w, x - 7.0) || pier_deck(w, x + 7.0); }
#define ROAD_RAMP 48.0f
/* 0 off the road .. 1 on the flat road; the hills ease into it over ROAD_RAMP px at both ends */
static float road_m(const AWWorld *w, int x) {
    if (!w->rd_on) return 0.0f;
    float fx = (float)x;
    if (fx <= (float)w->rd_x0 || fx >= (float)w->rd_x1) return 0.0f;
    float m = fminf(fx - (float)w->rd_x0, (float)w->rd_x1 - fx) / ROAD_RAMP;
    return m >= 1.0f ? 1.0f : smooth(m);
}
/* the jeep trail: the ground rolls up and down in big hills, easing in and out over ROAD_RAMP px at both ends */
static float jeep_m(const AWWorld *w, int x) {
    if (!w->jp_on) return 0.0f;
    float fx = (float)x;
    if (fx <= (float)w->jp_x0 || fx >= (float)w->jp_x1) return 0.0f;
    float m = fminf(fx - (float)w->jp_x0, (float)w->jp_x1 - fx) / ROAD_RAMP;
    return m >= 1.0f ? 1.0f : smooth(m);
}
static float jeep_hill(const AWWorld *w, int x) {
    float fx = (float)x;
    return 2.0f + 0.5f * w->jp_amp * (1.0f + sinf(fx * 6.28318f / w->jp_lam + w->jp_ph)) + 1.5f * vn(w->jp_seed ^ 0x51U, fx / 43.0f);
}
static int ground_h(const AWWorld *w, int x) {
    int h = ground_raw(w, x);
    if (w->lk_on && w->lk_pl > 0) {     /* a lake with piers has level shores, so boats and docks sit neatly */
        float fx = (float)x, sdist = fx < (float)w->lk_x0 ? (float)w->lk_x0 - fx : (fx > (float)w->lk_x1 ? fx - (float)w->lk_x1 : 0.0f);
        float f = sdist / 34.0f; if (f > 1.0f) f = 1.0f;
        h = (int)((float)h * f);
    }
    if (w->lk_on) {
        float m = lake_flat(w, x);
        if (m > 0.0f) h = (int)((float)h * (1.0f - m)) - lake_depth(w, x);
    }
    if (w->rd_on) {
        float m = road_m(w, x);
        if (m > 0.0f) h = (int)floorf((float)h * (1.0f - m) + (float)w->rd_h * m + 0.5f);
    }
    if (w->jp_on) {
        float m = jeep_m(w, x);
        if (m > 0.0f) h = (int)floorf((float)h * (1.0f - m) + jeep_hill(w, x) * m + 0.5f);
    }
    return h;
}

#include "aw_art.inc"
#include "aw_art2.inc"
#include "aw_text.inc"

static void season_dots(AWWorld *w, int x, int y, int wd, int tier);   /* aw_extra.inc */


/* ------------------------------------------------------------------ */
/* sky (altitude aware), stars, space bodies, sun / moon               */
/* ------------------------------------------------------------------ */
static const int BAYER[4][4] = { {0,8,2,10}, {12,4,14,6}, {3,11,1,9}, {15,7,13,5} };
#define SPACE_COL 0x04061AU
#define ACR(w) (1.45f * (float)(w)->vh)    /* rocket cruise altitude */

static float space_d(const AWWorld *w, float A) {
    float d = (A - (float)w->gy) / (0.8f * (float)w->vh);
    d = d < 0.0f ? 0.0f : (d > 1.0f ? 1.0f : d);
    return smooth(d);
}
static Col sky_at_alt(const AWWorld *w, float A) {
    const Pal *p = &w->cur;
    float gy = (float)w->gy;
    if (A <= gy) {
        float f = 1.0f - A / gy; if (f < 0.0f) f = 0.0f;
        return f < 0.5f ? lerpc(p->sky_top, p->sky_mid, f * 2.0f) : lerpc(p->sky_mid, p->sky_bot, (f - 0.5f) * 2.0f);
    }
    return lerpc(p->sky_top, SPACE_COL, space_d(w, A));
}

static void draw_sky(AWWorld *w) {
    int gy = w->gy, oy = w->oy;
    int bh = (gy + 13) / 14; if (bh < 4) bh = 4;
    int ymax = imin(w->vh, gy + oy);
    for (int y = 0; y < ymax; y++) {
        int wy = y - oy;
        int b = floordiv(wy, bh), r = wy - b * bh;
        Col c0 = sky_at_alt(w, (float)gy - (float)(b * bh + bh / 2)), c1 = c0;
        float f = 0.0f;
        if (r >= bh - 4) { c1 = sky_at_alt(w, (float)gy - (float)((b + 1) * bh + bh / 2)); f = ((float)(r - (bh - 4)) + 0.5f) / 4.0f; }
        uint32_t *row = w->px + y * w->vw;
        if (c0 == c1) { for (int x = 0; x < w->vw; x++) row[x] = c0; }
        else for (int x = 0; x < w->vw; x++) row[x] = ((float)BAYER[y & 3][x & 3] / 16.0f < f) ? c1 : c0;
    }
}

static void draw_stars(AWWorld *w) {
    int camI = (int)floor(w->cam * 0.02);
    int ytop = -w->oy, ybot = imin(w->vh - w->oy, w->gy * 7 / 10);
    int r0 = floordiv(ytop, 11), r1 = floordiv(ybot, 11);
    for (int cr = r0; cr <= r1; cr++) {
        for (int cx = -1; cx * 11 < w->vw + 11; cx++) {
            int X = cx + floordiv(camI, 11);
            uint32_t h = hash2(w->seed ^ 0x57A2U, hash2((uint32_t)X, (uint32_t)(cr + 4000)));
            int yw = cr * 11 + (int)(rfn(h, 2) * 10.0f);
            if (yw > w->gy * 7 / 10) continue;
            float vis = fmaxf(w->cur.stars, space_d(w, (float)(w->gy - yw)));
            if (vis < 0.02f || rfn(h, 0) > 0.30f * vis) continue;
            int x = cx * 11 - (camI % 11) + (int)(rfn(h, 1) * 10.0f);
            float tw = sinf((float)w->t * (1.0f + rfn(h, 3) * 2.0f) + rfn(h, 4) * 6.28f);
            Col c = rfn(h, 5) < 0.25f ? 0xFFE9A8 : 0xFFFFFF;
            if (tw > -0.5f) {
                PX(w, x, yw, c);
                if (rfn(h, 6) < 0.18f && tw > 0.5f) { Col m = mulc(c, 0.6f); PX(w, x - 1, yw, m); PX(w, x + 1, yw, m); PX(w, x, yw - 1, m); PX(w, x, yw + 1, m); }
            } else if (rfn(h, 7) < 0.5f) {
                PX(w, x, yw, mulc(c, 0.5f));
            }
        }
    }
    /* shooting star (night / space) */
    float vis = fmaxf(w->cur.stars, w->dark);
    if (vis > 0.6f) {
        const double PERIOD = 9.0;
        long slot = (long)floor(w->t / PERIOD);
        uint32_t h = hash2(w->seed ^ 0x5007U, (uint32_t)slot);
        double lt = (w->t - slot * PERIOD) - 2.0 - rfn(h, 0) * 4.0;
        if (lt > 0.0 && lt < 0.7) {
            float u = (float)(lt / 0.7);
            float sx = w->vw * (0.35f + 0.6f * rfn(h, 1)) - u * w->vw * 0.28f;
            float sy = w->gy * (0.08f + 0.25f * rfn(h, 2)) + u * w->gy * 0.20f - (float)w->oy;
            for (int i = 0; i < 9; i++) {
                int a = (int)(255 * (1.0f - i / 9.0f) * (1.0f - u * 0.4f));
                BLEND(w, (int)(sx + i * 1.6f), (int)(sy - i * 0.7f), 0xFFFFFF, a);
            }
        }
    }
}

/* planets and moons high above the clouds (only ever on screen while the rocket is up there) */
static void shaded_ball(AWWorld *w, int cx, int cy, int r, Col lit, Col mid, Col shade, Col band2, int bandh) {
    for (int dy = -r; dy <= r; dy++)
        for (int dx = -r; dx <= r; dx++) {
            if (dx * dx + dy * dy > r * r + r / 2) continue;
            float nx = (float)dx / (float)r, ny = (float)dy / (float)r;
            float light = -(nx * 0.62f + ny * 0.48f);
            Col c = mid;
            if (bandh > 0 && (((dy + r * 4) / bandh) & 1)) c = band2;
            if (light > 0.38f) c = lerpc(c, lit, 0.55f);
            else if (light < -0.30f) c = ((dx + dy) & 1) ? shade : mulc(c, 0.7f);
            else if (light < -0.12f && ((dx + dy) & 1)) c = mulc(c, 0.82f);
            PX(w, cx + dx, cy + dy, c);
        }
}
static void draw_ring(AWWorld *w, int cx, int cy, int r, int front, Col col) {
    int rx = r * 17 / 10, ry = r * 5 / 12;
    for (int dx = -rx; dx <= rx; dx++) {
        float s = sqrtf(1.0f - (float)(dx * dx) / (float)(rx * rx));
        int y = (int)(ry * s + 0.5f);
        if (front) { PX(w, cx + dx, cy + y, col); PX(w, cx + dx, cy + y + 1, mulc(col, 0.8f)); }
        else {
            int yy = -y;
            if (dx * dx + yy * yy > r * r) { PX(w, cx + dx, cy + yy, col); PX(w, cx + dx, cy + yy - 1, mulc(col, 0.8f)); }
        }
    }
}
static void draw_space_bodies(AWWorld *w) {
    if (w->oy < 30) return;
    const double par = 0.12;
    const int S = 520;
    int camL = (int)floor(w->cam * par);
    int k0 = floordiv(camL - 90, S), k1 = floordiv(camL + w->vw + 90, S);
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ 0x5B0DU, (uint32_t)k);
        int kind = (int)(rfn(h, 0) * 6.0f) % 6;
        int cx = k * S + (int)(rfn(h, 1) * (float)(S - 120)) + 40 - camL;
        float A = (float)w->gy + (float)w->vh * (0.28f + 1.0f * rfn(h, 2));
        int cy = (int)((float)w->gy - A);
        int r = 9 + (int)(rfn(h, 3) * 16.0f);
        switch (kind) {
            case 0: shaded_ball(w, cx, cy, r + 6, 0xFFE0A0, 0xE89A4A, 0x7A3A18, 0xC46E30, 3 + (int)(rfn(h, 4) * 3)); break;   /* gas giant */
            case 1: draw_ring(w, cx, cy, r + 3, 0, 0xE8D49A);
                    shaded_ball(w, cx, cy, r + 3, 0xFFF3C8, 0xD9B96A, 0x6B5424, 0xC8A456, 4);
                    draw_ring(w, cx, cy, r + 3, 1, 0xE8D49A); break;                                                        /* ringed */
            case 2: shaded_ball(w, cx, cy, r, 0xFF9A7A, 0xC4472A, 0x5A1C12, 0xC4472A, 0);
                    disc(w, cx - r / 4, cy - r + 2, imax(1, r / 5), 0xFFFFFF); break;                                       /* red planet */
            case 3: shaded_ball(w, cx, cy, r + 2, 0xA8E4FF, 0x3F8FE0, 0x14306A, 0x3F8FE0, 0);
                    for (int i = 0; i < 4; i++) {
                        int bx = cx + (int)((rfn(h, 10 + i) - 0.5f) * r * 1.2f), by = cy + (int)((rfn(h, 20 + i) - 0.5f) * r * 1.2f);
                        if ((bx - cx) * (bx - cx) + (by - cy) * (by - cy) < (r - 2) * (r - 2)) disc(w, bx, by, 2 + (int)(rfn(h, 30 + i) * 3), 0x4FB84A);
                    } break;                                                                                                 /* blue marble */
            case 4: shaded_ball(w, cx, cy, r, 0xF4F4F8, 0xB4B4C0, 0x585868, 0xB4B4C0, 0);
                    for (int i = 0; i < 4; i++) disc(w, cx + (int)((rfn(h, 40 + i) - 0.5f) * r), cy + (int)((rfn(h, 50 + i) - 0.5f) * r), 1 + (int)(rfn(h, 60 + i) * 2), 0x8A8A98);
                    break;                                                                                                   /* moon */
            default: shaded_ball(w, cx, cy, r - 2, 0xE0FFFF, 0x6AD0E0, 0x1F5A78, 0x8FE8F0, 5); break;                       /* ice world */
        }
    }
}

static void draw_celestial(AWWorld *w) {
    if (w->dark > 0.97f) return;
    int cx = (int)(w->vw * 0.72f);
    int cy = (int)(w->cel_y * w->gy);
    int r = imax(5, w->vh / 22);
    Col c = w->cel_col;
    int hr = r * 2 + 2;
    for (int dy = -hr; dy <= hr; dy++)
        for (int dx = -hr; dx <= hr; dx++) {
            int d2 = dx * dx + dy * dy;
            if (d2 > hr * hr || d2 <= r * r) continue;
            if ((((cx + dx) + (cy + dy)) & 1) == 0 && d2 < (hr * hr * 7) / 10) BLEND(w, cx + dx, cy + dy, c, 46);
            else if ((((cx + dx) & 1) == 0) && (((cy + dy) & 1) == 0)) BLEND(w, cx + dx, cy + dy, c, 26);
        }
    disc(w, cx, cy, r, c);
    if (w->cel_kind == 1) {
        Col cr = mulc(c, 0.86f);
        disc(w, cx - r / 3, cy - r / 3, imax(1, r / 4), cr);
        disc(w, cx + r / 3, cy + r / 4, imax(1, r / 5), cr);
        disc(w, cx - r / 4, cy + r / 2, imax(1, r / 6), cr);
    } else {
        disc(w, cx, cy, r - 2, lerpc(c, 0xFFFFFF, 0.35f));
    }
}


/* ------------------------------------------------------------------ */
/* clouds (stepped, flat-bottomed - like the login screen)             */
/* ------------------------------------------------------------------ */
static void cloud_shape(AWWorld *w, int x, int y, int cw, uint32_t h) {
    const Pal *p = &w->cur;
    int w2 = cw * 62 / 100, w3 = cw * 34 / 100;
    int o2 = (int)(rfn(h, 10) * (float)(cw - w2));
    int o3 = o2 + (int)(rfn(h, 11) * (float)(w2 - w3));
    R(w, x, y, cw, 4, p->cloud);
    R(w, x + o2, y - 2, w2, 2, p->cloud);
    R(w, x + o3, y - 4, w3, 2, p->cloud);
    R(w, x, y + 3, cw, 1, p->cloud_sh);
}
static void draw_clouds(AWWorld *w, int layer, double par, double drift, int S, float y0, float y1, int wmin, int wmax) {
    double off = w->cam * par + w->t * drift;
    int offi = (int)floor(off);
    int k0 = floordiv(offi - wmax, S), k1 = floordiv(offi + w->vw, S);
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ (0xC10DU + (uint32_t)layer * 977U), (uint32_t)k);
        if (rfn(h, 0) > 0.72f) continue;
        int cw = wmin + (int)(rfn(h, 1) * (float)(wmax - wmin));
        int cx = k * S + (int)(rfn(h, 2) * (float)S) - offi;
        int cy = (int)((y0 + (y1 - y0) * rfn(h, 3)) * w->gy);
        cy = (cy / 2) * 2;
        cloud_shape(w, cx, cy, cw, h);
    }
}

static int ridge_h(const AWWorld *w, int X, int layer, int hmin, int hmax, float peaky) {
    uint32_t s = w->seed + 1000u * (uint32_t)layer;
    float hill = 0.55f * vn(s, (float)X / (60.0f + 20.0f * layer)) + 0.30f * vn(s + 7, (float)X / 23.0f) + 0.15f * vn(s + 13, (float)X / 9.0f);
    float hh = (float)hmin + (float)(hmax - hmin) * hill;
    if (peaky > 0.01f) {
        const int S = 56 + 10 * layer;
        int k0 = floordiv(X, S);
        float best = 0.0f;
        for (int k = k0 - 1; k <= k0 + 1; k++) {
            uint32_t h = hash2(s + 99, (uint32_t)k);
            float px = (float)(k * S) + rfn(h, 0) * (float)S;
            float ph = (float)hmin + (float)(hmax - hmin) * (0.35f + 0.65f * rfn(h, 1));
            float v = ph - fabsf((float)X - px) * 0.85f;
            if (v > best) best = v;
        }
        float lo = (float)hmin * 0.35f;
        if (best < lo) best = lo;
        hh = hh * (1.0f - peaky) + best * peaky;
    }
    return ((int)hh) & ~1;
}

/* ------------------------------------------------------------------ */
/* ridges                                                              */
/* ------------------------------------------------------------------ */
static void draw_ridge(AWWorld *w, double par, int layer, int hmin, int hmax, Col col, int caps) {
    int camL = (int)floor(w->cam * par);
    float thr = (float)hmin + (float)(hmax - hmin) * 0.55f;
    for (int x = 0; x < w->vw; x++) {
        int hh = ridge_h(w, camL + x, layer, hmin, hmax, w->cur.peaky);
        int top = w->gy - hh;
        int capn = (caps && w->cur.cap > 0.5f && (float)hh > thr) ? 2 + (int)(((float)hh - thr) / 5.0f) : 0;
        for (int y = imax(top, -w->oy); y < w->gy && y + w->oy < w->vh; y++)
            w->px[(y + w->oy) * w->vw + x] = (y - top < capn) ? w->cur.cap_c : col;
    }
}


#include "aw_bg.inc"

/* ------------------------------------------------------------------ */
/* biome lookup                                                        */
/* ------------------------------------------------------------------ */
static void biome_at(const AWWorld *w, double x, int *a, int *b, float *t) {
    double u = (x + w->biome_off) / SEG_LEN;
    double fi = floor(u), f = u - fi;
    long i = (long)fi;
    int ia = (int)(((i % NPAL) + NPAL) % NPAL);
    float tt = 0.0f;
    if (f > 0.65) { double s = (f - 0.65) / 0.35; tt = (float)(s * s * (3.0 - 2.0 * s)); }
    *a = PAL_ORDER[ia]; *b = PAL_ORDER[(ia + 1) % NPAL]; *t = tt;
}

/* ------------------------------------------------------------------ */
/* scenery sprites (procedural rect art)                               */
/* ------------------------------------------------------------------ */
static void d_round_tree(AWWorld *w, int x, int base, int var) {
    const Pal *p = &w->cur;
    static const int W0[7] = { 10, 14, 16, 16, 14, 10, 6 };
    static const int W1[7] = { 12, 16, 18, 18, 16, 12, 8 };
    static const int W2[7] = { 8, 12, 12, 10, 6, 0, 0 };
    const int *ww = var == 1 ? W1 : (var == 2 ? W2 : W0);
    int rows = var == 2 ? 5 : 7;
    int th = 7 + var;
    R(w, x - 1, base - th, 3, th, p->trunk);
    int y = base - th + 1;
    for (int i = 0; i < rows; i++) {
        y -= 2;
        int wd = ww[i];
        R(w, x - wd / 2, y, wd, 2, p->fol1);
        if (i <= 1) R(w, x - wd / 2, y, wd, 2, p->fol2);
        else R(w, x + wd / 2 - 3, y, 3, 2, p->fol2);
        season_dots(w, x, y, wd, i);
    }
}
static void d_pine(AWWorld *w, int x, int base, int var) {
    const Pal *p = &w->cur;
    int n = 4 + var, w0 = 14 + 2 * var;
    R(w, x - 1, base - 4, 3, 4, p->trunk);
    int y = base - 4;
    for (int i = 0; i < n; i++) {
        int tw = imax(2, (w0 * (n - i) / n) & ~1);
        R(w, x - tw / 2, y - 3, tw, 3, p->fol1);
        R(w, x + tw / 2 - imax(1, tw / 3), y - 3, imax(1, tw / 3), 3, p->fol2);
        if (p->cap > 0.5f) R(w, x - tw / 2, y - 3, tw, 1, p->cap_c);
        y -= 3;
    }
}
static void d_cactus(AWWorld *w, int x, int base, int var) {
    const Pal *p = &w->cur;
    int hgt = 14 + var * 3;
    R(w, x - 2, base - hgt, 4, hgt, p->fol1);
    R(w, x, base - hgt, 2, hgt, p->fol2);
    int y1 = base - hgt / 2;
    R(w, x - 6, y1, 4, 2, p->fol1); R(w, x - 6, y1 - 5, 2, 7, p->fol1);
    if (var != 1) { int y2 = base - hgt / 2 - 3; R(w, x + 2, y2, 4, 2, p->fol1); R(w, x + 4, y2 - 4, 2, 6, p->fol2); }
    R(w, x - 1, base - hgt - 1, 2, 1, p->acc1);
}
static void d_dead(AWWorld *w, int x, int base, int var) {
    const Pal *p = &w->cur;
    int h = 16 + var * 4;
    R(w, x - 1, base - h, 3, h, p->trunk);
    R(w, x - 5, base - h / 2 - 2, 5, 1, p->trunk); R(w, x - 5, base - h / 2 - 5, 1, 4, p->trunk);
    R(w, x + 2, base - h + 6, 5, 1, p->trunk);     R(w, x + 6, base - h + 3, 1, 4, p->trunk);
    PX(w, x - 5, base - h / 2 - 6, p->acc1); PX(w, x + 6, base - h + 2, p->acc1);
}
static void d_crystal(AWWorld *w, int x, int base, int var) {
    const Pal *p = &w->cur;
    static const int DX[3] = { -6, 0, 6 };
    for (int i = 0; i < 3; i++) {
        int hh = (i == 1 ? 16 : 9 + i) + var * 2, wd = i == 1 ? 6 : 4;
        int bx = x + DX[i] - wd / 2;
        int body = hh * 2 / 3;
        R(w, bx, base - body, wd, body, p->acc1);
        R(w, bx + 1, base - hh, wd - 2, hh - body, p->acc1);
        R(w, bx, base - body, 1, body, lerpc(p->acc1, 0xFFFFFF, 0.5f));
        PX(w, bx + wd / 2, base - hh - 1, p->acc2);
        BLEND(w, bx + wd / 2, base - hh - 2, p->acc2, 120);
    }
}
static void d_hut(AWWorld *w, int x, int base, int var) {
    const Pal *p = &w->cur;
    Col wall = lerpc(0xC9A06A, p->near_c, 0.25f), dark = 0x3A2418;
    (void)var;
    R(w, x - 7, base - 9, 14, 9, wall);
    R(w, x - 7, base - 2, 14, 2, mulc(wall, 0.8f));
    for (int i = 0; i < 6; i++) R(w, x - 9 + i, base - 9 - i - 1, 18 - 2 * i, 1, p->acc2);
    R(w, x + 3, base - 17, 3, 5, mulc(wall, 0.8f));
    R(w, x - 5, base - 6, 3, 6, dark);
    R(w, x + 1, base - 7, 4, 3, p->acc1);
    for (int dy = -2; dy <= 4; dy++) for (int dx = -3; dx <= 7; dx++) if ((dx + dy) % 2 == 0) BLEND(w, x + dx, base - 6 + dy, p->acc1, 28);
}
static void d_mush(AWWorld *w, int x, int base, int var) {
    const Pal *p = &w->cur;
    int s = var == 1 ? 1 : 0;
    R(w, x - 1, base - 5 - s * 2, 3, 5 + s * 2, 0xEFE6D2);
    R(w, x - 4 - s, base - 9 - s * 2, 8 + s * 2, 2, p->acc1);
    R(w, x - 5 - s, base - 7 - s * 2, 10 + s * 2, 2, p->acc1);
    PX(w, x - 2, base - 8 - s * 2, 0xFFFFFF); PX(w, x + 2, base - 7 - s * 2, 0xFFFFFF);
    for (int dy = -7; dy <= 3; dy++) for (int dx = -9; dx <= 9; dx++)
        if (dx * dx + dy * dy < 70 && ((dx + dy) & 1) == 0) BLEND(w, x + dx, base - 6 + dy, p->acc1, 30);
}
static void d_rock(AWWorld *w, int x, int base, int var) {
    const Pal *p = &w->cur;
    Col g = lerpc(0x8A8A96, p->near_c, 0.35f);
    R(w, x - 5 - var, base - 3, 10 + var * 2, 3, g);
    R(w, x - 3, base - 5 - var, 6, 2 + var, g);
    R(w, x - 3, base - 5 - var, 3, 1, mulc(g, 1.25f));
    R(w, x + 1, base - 3, 4, 3, mulc(g, 0.82f));
}
static void d_bush(AWWorld *w, int x, int base, int var) {
    const Pal *p = &w->cur;
    int s = var;
    R(w, x - 4 - s, base - 4, 8 + s * 2, 4, p->fol1);
    R(w, x - 3 - s, base - 6, 6 + s * 2, 2, p->fol1);
    R(w, x + 1, base - 3, 4 + s, 3, p->fol2);
    PX(w, x - 2, base - 4, p->acc1); PX(w, x + 2, base - 5, p->acc1); PX(w, x, base - 2, p->acc2);
}
static void d_spikes(AWWorld *w, int x, int base, int var) {
    const Pal *p = &w->cur;
    static const int DX[3] = { -5, 0, 5 };
    Col obs = lerpc(0x2A0F10, p->near_c, 0.3f);
    for (int i = 0; i < 3; i++) {
        int hh = (i == 1 ? 18 : 10 + i * 2) + var * 2;
        for (int r = 0; r < hh; r++) {
            int wd = imax(1, (4 * (hh - r)) / hh + 1);
            R(w, x + DX[i] - wd / 2, base - r - 1, wd, 1, obs);
        }
        PX(w, x + DX[i], base - hh, p->acc1);
        PX(w, x + DX[i], base - hh + 1, p->acc2);
    }
}

static void draw_decor_layer(AWWorld *w) {
    const double par = 0.7;
    const int S = 30;
    int camL = (int)floor(w->cam * par);
    int k0 = floordiv(camL - 24, S), k1 = floordiv(camL + w->vw + 24, S);
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ 0xDEC0U, (uint32_t)k);
        if (rfn(h, 0) > 0.48f) continue;
        int X = k * S + (int)(rfn(h, 1) * (float)S);
        int sx = X - camL;
        double equiv = ((double)X - 0.5 * w->vw) / par + (double)w->cam_off;
        int a, b; float t;
        biome_at(w, equiv, &a, &b, &t);
        const Pal *pp = &PALS[t >= 0.5f ? b : a];
        int kind = pp->decor[rfn(h, 2) < 0.6f ? 0 : 1];
        int var = (int)(rfn(h, 3) * 3.0f);
        int base = w->gy;
        w->dkey = hash2(h, 77u);
        switch (kind) {
            case DK_ROUND:   d_round_tree(w, sx, base, var); break;
            case DK_PINE:    d_pine(w, sx, base, var); break;
            case DK_CACTUS:  d_cactus(w, sx, base, var); break;
            case DK_DEAD:    d_dead(w, sx, base, var); break;
            case DK_CRYSTAL: d_crystal(w, sx, base, var); break;
            case DK_HUT:     d_hut(w, sx, base, var); break;
            case DK_MUSH:    d_mush(w, sx, base, var & 1); break;
            case DK_ROCK:    d_rock(w, sx, base, var & 1); break;
            case DK_BUSH:    d_bush(w, sx, base, var & 1); break;
            case DK_SPIKES:  d_spikes(w, sx, base, var & 1); break;
            default: break;
        }
    }
}

/* ------------------------------------------------------------------ */
/* ground                                                              */
/* ------------------------------------------------------------------ */
static Col dirt_px(const Pal *p, int wx, int yy) {
    int ty = ((yy % 9) + 9) % 9;
    int shift = ((floordiv(yy, 9)) & 1) ? 8 : 0;
    int tx = (wx + shift) & 15;
    Col c = p->dirt;
    if (ty == 1 && (tx == 5 || tx == 6)) c = p->dirt_dk;
    else if ((ty == 2 || ty == 3) && (tx == 10 || tx == 11)) c = p->dirt_lt;
    else if ((ty == 4 || ty == 5) && (tx >= 1 && tx <= 3)) c = p->dirt_lt;
    else if ((ty == 6 || ty == 7) && (tx == 14 || tx == 15)) c = p->dirt_dk;
    return c;
}

/* rock layers deepen below the topsoil (only kicks in below the old visible strip) */
static Col strata(Col c, int depth) {
    if (depth > 34) c = mulc(c, 0.88f);
    if (depth > 46) c = mulc(c, 0.9f);
    if (depth > 56) {
        float f = clampf((float)(depth - 56) / 80.0f, 0.0f, 1.0f) * 0.65f;
        int band = floordiv(depth, 17);
        Col rock = lerpc(0x6B5B52, 0x5A5A68, (float)((band * 7) & 3) / 3.0f);
        c = lerpc(c, rock, f);
        if (depth % 17 == 0) c = mulc(c, 0.86f);
    }
    if (depth > 70) c = mulc(c, 1.0f - clampf((float)(depth - 70) / 220.0f, 0.0f, 0.34f));
    return c;
}

static void draw_ground(AWWorld *w) {
    const Pal *p = &w->cur;
    int camI = (int)floor(w->cam);
    for (int x = 0; x < w->vw; x++) {
        int wx = camI + x;
        int top = w->gy - ground_h(w, wx);
        int m16 = wx & 15;
        int under = top > w->gy + 1;     /* lake bed: sand instead of grass */
        for (int y = imax(top, -w->oy); y + w->oy < w->vh; y++) {
            int dy = y - top;
            Col c;
            if (under && dy <= 4) {
                c = dy == 0 ? 0xEBDDA6 : (dy <= 3 ? 0xDCC88C : 0xC4AE74);
                if (dy >= 1 && dy <= 3 && (((wx * 7 + dy * 3) % 11) == 0)) c = 0xF2E8BC;
            } else if (dy == 0) c = p->grass_pale;
            else if (dy <= 3) {
                c = p->grass_main;
                if (m16 == 3 && dy >= 2) c = p->tick_dark;
                if (m16 == 11 && dy <= 2) c = p->tick_light;
            } else if (dy == 4) c = p->grass_dark;
            else {
                int depth = y - w->gy;
                c = strata(dirt_px(p, wx, depth), depth);
            }
            w->px[(y + w->oy) * w->vw + x] = c;
        }
    }
}

static void draw_flora(AWWorld *w) {
    const Pal *p = &w->cur;
    int camI = (int)floor(w->cam);
    const int S = 14;
    int k0 = floordiv(camI - 8, S), k1 = floordiv(camI + w->vw + 8, S);
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ 0xF10AU, (uint32_t)k);
        if (rfn(h, 0) > 0.30f) continue;
        int wx = k * S + 2 + (int)(rfn(h, 1) * (float)(S - 4));
        int hh = ground_h(w, wx);
        if (hh < 0 || ground_h(w, wx - 2) != hh || ground_h(w, wx + 2) != hh) continue;
        if (road_m(w, wx - 3) > 0.0f || road_m(w, wx + 3) > 0.0f || pier_near(w, (double)wx)) continue;   /* nothing grows on the tarmac or the pier */
        int x = wx - camI, base = w->gy - hh;
        int c = (int)(rfn(h, 2) * 4.0f);
        switch (p->flora) {
            case FL_FLOWERS: {
                Col fc[4] = { p->acc1, p->acc2, 0xFFFFFF, 0xFF8FB8 };
                R(w, x, base - 3, 1, 3, p->grass_dark);
                R(w, x - 1, base - 5, 3, 2, fc[c]);
                PX(w, x, base - 4, 0xFFE066);
            } break;
            case FL_MUSH: {
                R(w, x, base - 2, 1, 2, 0xEFE6D2);
                R(w, x - 1, base - 4, 3, 2, c & 1 ? p->acc1 : p->acc2);
                BLEND(w, x, base - 3, p->acc1, 60);
            } break;
            default: {
                Col g = lerpc(0x9A9AA8, p->near_c, 0.3f);
                R(w, x - 1, base - 2, 3, 2, g);
                if (c & 1) R(w, x + 2, base - 1, 2, 1, mulc(g, 0.85f));
                PX(w, x - 1, base - 2, mulc(g, 1.2f));
            } break;
        }
    }
}


/* ------------------------------------------------------------------ */
/* particles                                                           */
/* ------------------------------------------------------------------ */
static void spawn_spark(AWWorld *w, double x, float y, float vx, float vy, float life, int kind, Col col) {
    for (int i = 0; i < MAXFX; i++) if (w->fx[i].life <= 0.0f) {
        w->fx[i].x = x; w->fx[i].y = y; w->fx[i].vx = vx; w->fx[i].vy = vy;
        w->fx[i].life = life; w->fx[i].max = life; w->fx[i].kind = kind; w->fx[i].col = col;
        return;
    }
}
static void poof(AWWorld *w, double x, float y) {
    for (int i = 0; i < 12; i++) {
        float a = rng_f(w) * 6.2832f, s = 14.0f + rng_f(w) * 30.0f;
        spawn_spark(w, x, y - 6.0f, cosf(a) * s, sinf(a) * s - 6.0f, 0.5f + rng_f(w) * 0.4f, SK_SMOKE, 0xFFFFFF);
    }
    static const Col cols[3] = { 0xFFD23F, 0xFFFFFF, 0xFF9EB5 };
    for (int i = 0; i < 10; i++) {
        float a = rng_f(w) * 6.2832f, s = 20.0f + rng_f(w) * 44.0f;
        spawn_spark(w, x, y - 6.0f, cosf(a) * s, sinf(a) * s - 18.0f, 0.5f + rng_f(w) * 0.5f, SK_STAR, cols[(int)(rng_f(w) * 3.0f) % 3]);
    }
}
static void dust(AWWorld *w, double x, float y, int n) {
    Col c = lerpc(w->cur.dirt_lt, 0xFFFFFF, 0.35f);
    for (int i = 0; i < n; i++) {
        float dir = (i & 1) ? 1.0f : -1.0f;
        spawn_spark(w, x + dir * 3.0f, y - 1.0f, dir * (8.0f + rng_f(w) * 16.0f), -(4.0f + rng_f(w) * 10.0f), 0.35f + rng_f(w) * 0.25f, SK_DUST, c);
    }
}
static void hearts(AWWorld *w, double x, float y, int n) {
    for (int i = 0; i < n; i++)
        spawn_spark(w, x + (rng_f(w) - 0.5f) * 14.0f, y - 8.0f - rng_f(w) * 6.0f, (rng_f(w) - 0.5f) * 10.0f, -12.0f - rng_f(w) * 10.0f, 1.0f + rng_f(w) * 0.6f, SK_HEART, 0xFF8FB8);
}
static float fx_grav(int kind) {
    switch (kind) {
        case SK_SPARKLE: return 90.0f; case SK_DUST: return 10.0f; case SK_SMOKE: return -14.0f; case SK_FLAME: return -25.0f;
        case SK_HEART: return -6.0f; case SK_STAR: return 40.0f; case SK_GLITTER: return 18.0f; case SK_DROP: return 140.0f;
        case SK_BUBBLE: return -20.0f; case SK_FOAM: return 70.0f; case SK_CHUNK: return 120.0f;
        default: return 0.0f;
    }
}
static void draw_fx(AWWorld *w) {
    int camI = (int)floor(w->cam);
    for (int i = 0; i < MAXFX; i++) {
        Spark *s = &w->fx[i];
        if (s->life <= 0.0f) continue;
        int x = (int)floor(s->x) - camI, y = (int)floorf(s->y);
        float f = s->life / s->max;
        switch (s->kind) {
            case SK_SPARKLE:
            case SK_STAR:
                if (f > 0.25f || ((int)(f * 40)) & 1) {
                    PX(w, x, y, s->col);
                    Col m = mulc(s->col, 0.7f);
                    PX(w, x - 1, y, m); PX(w, x + 1, y, m); PX(w, x, y - 1, m); PX(w, x, y + 1, m);
                }
                break;
            case SK_DUST: { int sz = f > 0.5f ? 2 : 1; R(w, x, y, sz, sz, s->col); } break;
            case SK_SMOKE: {
                int r = 1 + (int)((1.0f - f) * 3.0f);
                for (int dy = -r; dy <= r; dy++) for (int dx = -r; dx <= r; dx++)
                    if (dx * dx + dy * dy <= r * r + 1) BLEND(w, x + dx, y + dy, s->col, (int)(150.0f * f));
            } break;
            case SK_FLAME: {
                Col c = f > 0.6f ? 0xFFE45E : (f > 0.3f ? 0xFFA030 : 0xFF5A2A);
                int sz = f > 0.4f ? 2 : 1; R(w, x, y, sz, sz, c);
            } break;
            case SK_HEART: if (f > 0.25f || ((int)(f * 30)) & 1) blit(w, &HEART, x - 2, y - 2, 0, 0); break;
            case SK_GLITTER: PX(w, x, y, s->col); if (f > 0.4f) BLEND(w, x, y + 1, s->col, 110); break;
            case SK_DROP: R(w, x, y, 1, 2, s->col); break;
            case SK_BUBBLE: PX(w, x, y, 0xCFF3FF); PX(w, x + 1, y + 1, 0x8FD0F0); if (f > 0.4f) PX(w, x + 1, y, 0xFFFFFF); break;
            case SK_FOAM: R(w, x, y, 2, 1, s->col); if (f > 0.5f) PX(w, x, y - 1, s->col); break;
            case SK_CHUNK: R(w, x, y, 2, 1, s->col); PX(w, x, y + 1, mulc(s->col, 0.7f)); break;
            default: break;
        }
    }
}
static void step_fx(AWWorld *w, float dt) {
    for (int i = 0; i < MAXFX; i++) {
        Spark *s = &w->fx[i];
        if (s->life <= 0.0f) continue;
        s->life -= dt;
        s->x += s->vx * dt; s->y += s->vy * dt;
        s->vy += fx_grav(s->kind) * dt;
        if (s->kind == SK_HEART) s->vx += sinf((float)w->t * 5.0f + (float)i) * 20.0f * dt;
        if (s->kind == SK_BUBBLE) { s->vx = sinf((float)w->t * 4.0f + (float)i) * 5.0f; if (s->y < (float)w->gy) s->life = 0.0f; }
        if (s->kind == SK_FOAM && s->vy > 0.0f && s->y > (float)w->gy + 1.0f) s->life = 0.0f;
    }
}

/* ambient biome particles (screen-space) */
static inline float wrapf(float v, float m) { v = fmodf(v, m); return v < 0 ? v + m : v; }

static void draw_ambient(AWWorld *w, int kind, float weight) {
    if (kind == PT_NONE || weight < 0.02f) return;
    int N = imax(24, imin(170, 70 * w->vw / 384));
    int n = (int)(N * weight);
    float vw = (float)w->vw, gy = (float)w->gy, t = (float)w->t;
    float cam = (float)w->cam;
    for (int i = 0; i < n; i++) {
        uint32_t h = hash2(w->seed ^ (0xA0B0U + (uint32_t)kind * 31U), (uint32_t)i);
        float depth = 0.35f + 0.65f * rfn(h, 0);
        float x0 = rfn(h, 1) * vw, y0 = rfn(h, 2) * gy;
        float sw = rfn(h, 3);
        switch (kind) {
            case PT_SNOW: {
                float x = wrapf(x0 + sinf(t * 0.7f + (float)i) * 5.0f - cam * depth * 0.6f - t * 3.0f, vw);
                float y = wrapf(y0 + t * (12.0f + 14.0f * depth), gy);
                int s = depth > 0.75f ? 2 : 1;
                R(w, (int)x, (int)y, s, s, 0xFFFFFF);
            } break;
            case PT_LEAVES: {
                float x = wrapf(x0 + sinf(t * 1.1f + (float)i * 2.0f) * 9.0f - cam * depth * 0.6f - t * 6.0f, vw);
                float y = wrapf(y0 + t * (9.0f + 7.0f * depth), gy);
                Col c = sw < 0.34f ? w->cur.fol1 : (sw < 0.67f ? w->cur.acc1 : w->cur.acc2);
                R(w, (int)x, (int)y, 2, 1, c); PX(w, (int)x + 1, (int)y + 1, mulc(c, 0.7f));
            } break;
            case PT_PETALS: {
                float x = wrapf(x0 + sinf(t * 0.9f + (float)i) * 8.0f - cam * depth * 0.6f + t * 4.0f, vw);
                float y = wrapf(y0 + t * (6.0f + 6.0f * depth), gy);
                Col c = sw < 0.5f ? 0xFFFFFF : w->cur.acc1;
                R(w, (int)x, (int)y, 2, 1, c);
            } break;
            case PT_EMBERS: {
                float life = wrapf(t * (9.0f + 14.0f * depth) + y0, gy);
                float y = gy - life;
                float x = wrapf(x0 + sinf(t * 1.5f + (float)i * 1.3f) * 6.0f - cam * depth * 0.6f, vw);
                float f = life / gy;
                Col c = f < 0.45f ? w->cur.acc2 : (f < 0.75f ? w->cur.acc1 : mulc(w->cur.acc1, 0.55f));
                if (sinf(t * 9.0f + (float)i * 4.0f) > -0.6f) { PX(w, (int)x, (int)y, c); if (depth > 0.8f && f < 0.6f) PX(w, (int)x, (int)y - 1, mulc(c, 0.6f)); }
            } break;
            case PT_FIREFLY: {
                float x = wrapf(x0 + sinf(t * 0.5f + (float)i * 1.7f) * 14.0f - cam * depth * 0.7f, vw);
                float y = gy * (0.35f + 0.6f * rfn(h, 4)) + sinf(t * 0.9f + (float)i) * 6.0f;
                float b = sinf(t * 1.7f + (float)i * 3.1f);
                if (b > -0.1f) {
                    int a = (int)(255 * (0.55f + 0.45f * b));
                    Col c = 0xFFF59A;
                    BLEND(w, (int)x, (int)y, c, a);
                    BLEND(w, (int)x - 1, (int)y, c, a / 4); BLEND(w, (int)x + 1, (int)y, c, a / 4);
                    BLEND(w, (int)x, (int)y - 1, c, a / 4); BLEND(w, (int)x, (int)y + 1, c, a / 4);
                }
            } break;
            case PT_SAND: {
                float x = wrapf(x0 - t * (46.0f + 36.0f * depth) - cam * depth * 0.9f, vw);
                float y = gy * (0.5f + 0.5f * rfn(h, 4)) + sinf(t * 2.0f + (float)i) * 1.5f;
                for (int k = 0; k < 3; k++) BLEND(w, (int)x + k, (int)y, 0xF0D89A, 150 - k * 40);
            } break;
            case PT_SPARKLE: {
                float x = wrapf(x0 - cam * depth * 0.5f, vw);
                float y = y0 * 0.9f;
                float b = sinf(t * 1.9f + (float)i * 5.0f);
                if (b > 0.35f) {
                    Col c = sw < 0.33f ? 0xFFFFFF : (sw < 0.66f ? w->cur.acc1 : w->cur.acc2);
                    PX(w, (int)x, (int)y, c);
                    if (b > 0.7f) { BLEND(w, (int)x - 1, (int)y, c, 140); BLEND(w, (int)x + 1, (int)y, c, 140); BLEND(w, (int)x, (int)y - 1, c, 140); BLEND(w, (int)x, (int)y + 1, c, 140); }
                }
            } break;
            default: break;
        }
    }
}


#include "aw_extra.inc"
#include "aw_friends.inc"
#include "aw_people.inc"

static void update_palette(AWWorld *w) {
    int a, b; float t;
    biome_at(w, w->ax, &a, &b, &t);
    w->pa = a; w->pb = b; w->pt = t;
    pal_lerp(&PALS[a], &PALS[b], t, &w->cur);
    update_season(w);
    season_grade(w);
    hol_grade(w);
    const Pal *A = &PALS[a], *B = &PALS[b];
    if (A->cel_kind == B->cel_kind) {
        w->cel_kind = A->cel_kind; w->cel_y = lerpf(A->cel_y, B->cel_y, t); w->cel_col = lerpc(A->cel_col, B->cel_col, t);
    } else if (t < 0.5f) {
        w->cel_kind = A->cel_kind; w->cel_y = lerpf(A->cel_y, 1.2f, t * 2.0f); w->cel_col = A->cel_col;
    } else {
        w->cel_kind = B->cel_kind; w->cel_y = lerpf(1.2f, B->cel_y, (t - 0.5f) * 2.0f); w->cel_col = B->cel_col;
    }
    hol_cel(w);
}



/* ------------------------------------------------------------------ */
/* drawing Archon and his rides                                        */
/* ------------------------------------------------------------------ */
typedef struct { float vcruise, vland, alt_lo, alt_hi, tin, climb, wander, act_lo, act_hi, vgnd, tout; } FlyP;
static const FlyP FLYP[M_COUNT] = {
    /* WALK    */ { 0 },
    /* WINGS   */ { 56.0f, 28.0f, 24.0f, 58.0f, 1.5f, 1.4f, 0.9f, 16.0f, 26.0f,  0.0f, 1.0f },
    /* CAR     */ { 64.0f, 32.0f, 28.0f, 54.0f, 4.5f, 1.3f, 0.6f, 15.0f, 22.0f, 46.0f, 2.2f },
    /* ROCKET  */ { 0 },
    /* BALLOON */ { 18.0f, 12.0f, 34.0f, 62.0f, 3.0f, 0.55f, 0.35f, 17.0f, 25.0f, 0.0f, 1.5f },
    /* CARPET  */ { 52.0f, 30.0f, 22.0f, 56.0f, 1.4f, 1.2f, 0.8f, 16.0f, 26.0f, 0.0f, 1.0f },
    /* JETPACK */ { 74.0f, 36.0f, 26.0f, 60.0f, 1.4f, 2.0f, 1.6f, 13.0f, 20.0f, 0.0f, 0.9f },
    /* DIG, SUB, BOAT, ROAD, DIVE have their own state machines */ { 0 }, { 0 }, { 0 }, { 0 }, { 0 },
};

static void draw_h_wings(AWWorld *w, int sx, int sy, int blink) {
    float t = (float)w->t;
    float wf = 1.0f;
    if (w->phase == PH_IN) wf = clampf(w->phase_t / FLYP[M_WINGS].tin, 0.0f, 1.0f);
    else if (w->phase == PH_OUT && w->touched) wf = 1.0f - clampf(w->grounded_t / 0.9f, 0.0f, 1.0f);
    int air = w->alt > 2.0f;
    int bob = air ? (int)floorf(sinf(t * 4.0f) * 1.0f + 0.5f) : 0;
    int fr = ((int)(t * (air ? 6.0f : 3.0f))) & 3;
    const Sp *wing = fr == 0 ? &WING_UP : (fr == 2 ? &WING_DN : &WING_MID);
    int attach = fr == 0 ? 8 : (fr == 2 ? 5 : 7);
    int top = sy - 12 + bob;
    int wy = top + 6 - attach;
    int nc = (int)ceilf(wf * 11.0f);
    if (nc > 0) {
        blit_cols(w, wing, sx - 6 - 9, wy, 0, 11 - nc, 11);
        blit_cols(w, wing, sx + 4, wy, 1, 11 - nc, 11);
    }
    draw_arch(w, sx - 6, top, air ? 3 : 0, blink, 0, 0);
}

static void draw_wheel(AWWorld *w, int x, int y, int spin) {
    R(w, x + 1, y, 4, 1, 0x1D1020); R(w, x, y + 1, 6, 4, 0x1D1020); R(w, x + 1, y + 5, 4, 1, 0x1D1020);
    R(w, x + 2, y + 2, 2, 2, 0xA9A9B8);
    static const int sp[4][2] = { {2, 1}, {4, 2}, {3, 4}, {1, 3} };
    PX(w, x + sp[spin & 3][0], y + sp[spin & 3][1], 0xFFFFFF);
}
static void draw_h_car(AWWorld *w, int sx, int sy, int blink) {
    float t = (float)w->t;
    int air = w->alt > 2.0f;
    int cw = sp_w(&CAR_BODY);
    int carL = sx - cw / 2;
    int bob = air ? (int)floorf(sinf(t * 3.1f) + 0.5f) : 0;
    int top = sy - 11 + bob;
    draw_arch(w, carL + 8, top - 5, 4, blink, 0, 0);
    blit(w, &CAR_BODY, carL, top, 0, 0);
    int wx1 = carL + 4, wx2 = carL + 19;
    if (!air) {
        int spin = (int)(w->anim_t * 12.0f);
        draw_wheel(w, wx1, top + 5, spin); draw_wheel(w, wx2, top + 5, spin);
    } else {
        int ff = ((int)(t * 20.0f)) & 1;
        int xs[2] = { wx1, wx2 };
        for (int i = 0; i < 2; i++) {
            R(w, xs[i], top + 8, 7, 2, 0x8FA3C0); R(w, xs[i] + 1, top + 10, 5, 1, 0x4A5C8C);
            R(w, xs[i] + 2, top + 11, 3, 2 + ff, 0xFFE45E); R(w, xs[i] + 3, top + 11, 1, 3 + ff, 0xFFA030);
        }
    }
}

static void draw_h_balloon(AWWorld *w, int sx, int sy, int blink) {
    float t = (float)w->t;
    int air = w->alt > 2.0f;
    int sway = air ? (int)floorf(sinf(t * 0.9f) * 1.0f + 0.5f) : 0;
    int rad = 15, ht = 34;
    int basketTop = sy - 7;
    int envBottom = basketTop - 10;
    int envTop = envBottom - ht;
    int cx = sx + sway;
    Col sets[4][2] = { { 0xE8442A, 0xFFF3C2 }, { 0x4FA6F5, 0xFFFFFF }, { 0xA77BF0, 0xFFD23F }, { 0x2FC4B2, 0xFFF3C2 } };
    int s = (int)(w->seed & 3);
    draw_balloon_env(w, cx, envTop, rad, ht, sets[s][0], sets[s][1]);
    for (int i = 0; i < 10; i++) { PX(w, cx - 6 - i / 5, envBottom + i, 0x4A3A2A); PX(w, cx + 6 + i / 5, envBottom + i, 0x4A3A2A); }
    if (air || w->phase == PH_IN) {   /* burner flame */
        int ff = ((int)(t * 12.0f)) & 1;
        R(w, cx - 1, envBottom + 1, 3, 3 + ff, 0xFFA030); R(w, cx, envBottom + 1, 1, 2 + ff, 0xFFE45E);
    }
    draw_arch(w, sx - 6 + sway, basketTop - 8, 4, blink, 0, 0);
    R(w, sx - 7 + sway, basketTop, 14, 7, 0x8A5A2B);
    for (int i = 0; i < 7; i += 2) R(w, sx - 7 + sway, basketTop + i, 14, 1, 0xC48A45);
    R(w, sx - 8 + sway, basketTop - 1, 16, 2, 0xB27A43);
}

static void draw_h_carpet(AWWorld *w, int sx, int sy, int blink) {
    float t = (float)w->t;
    int cw = 30, x0 = sx - cw / 2, ybase = sy - 4;
    draw_arch(w, sx - 6, ybase - 10, 4, blink, 0, 0);
    int fly = w->alt > 2.0f;
    for (int c = 0; c < cw; c++) {
        float edge = fabsf((float)(c - cw / 2)) / (float)(cw / 2);
        int dy = fly ? (int)floorf(sinf(t * 4.5f + (float)c * 0.42f) * (0.5f + 1.5f * edge) + 0.5f) : 0;
        int y = ybase + dy;
        Col body = (c % 6 < 3) ? 0xA77BF0 : 0x7449C4;
        R(w, x0 + c, y, 1, 1, 0xFFD23F);
        R(w, x0 + c, y + 1, 1, 2, body);
        if (c % 6 == 2) PX(w, x0 + c, y + 1, 0xE0508A);
        R(w, x0 + c, y + 3, 1, 1, 0xFFD23F);
        if (c == 0 || c == cw - 1) R(w, x0 + c + (c == 0 ? -1 : 1), y + 1, 1, 3, 0xFFD23F);
    }
}

static void draw_h_jetpack(AWWorld *w, int sx, int sy, int blink) {
    float t = (float)w->t;
    int air = w->alt > 2.0f;
    int top = sy - 12 + (air ? (int)floorf(sinf(t * 7.0f) + 0.5f) : 0);
    blit(w, &JET_PACK, sx - 6 - 4, top + 3, 0, 0);
    draw_arch(w, sx - 6, top, air ? 3 : 0, blink, 0, 0);
    if (air || w->phase == PH_IN) {
        int ff = ((int)(t * 24.0f)) % 3;
        int fx = sx - 6 - 4;
        R(w, fx + 1, top + 10, 3, 3 + ff, 0xFFE45E); R(w, fx + 2, top + 10, 1, 5 + ff, 0xFFA030);
        PX(w, fx + 2, top + 14 + ff, 0xFF5A2A);
    }
}

static void draw_h_rocket(AWWorld *w, int sx, int sy) {
    float t = (float)w->t;
    int steps = (int)floorf(w->pitch / 45.0f + 0.5f);
    int cw = 16, ch = 38;
    int cx = sx, cy = sy - 10;
    if (w->stage == 0 && w->stage_t > 1.3f) cx += (sinf(t * 70.0f) > 0.0f) ? 1 : 0;
    blit_rot(w, &ROCKET_BODY, 0, 0, cw, ch, 8.0f, 19.0f, cx, cy, steps);
    const Sp *fl = NULL;
    int ff = ((int)(t * 18.0f)) % 3;
    if (w->stage == 0) { if (w->stage_t > 1.3f) fl = &ROCKET_FL0; }
    else if (w->stage >= 1 && w->stage <= 5) fl = ff == 0 ? &ROCKET_FL1 : (ff == 1 ? &ROCKET_FL2 : &ROCKET_FL1);
    if (fl) blit_rot(w, fl, 0, 30, cw, ch, 8.0f, 19.0f, cx, cy, steps);
    /* Archon peeking out of the porthole - always upright */
    static const float COS[8] = { 1.0f, 0.70710678f, 0.0f, -0.70710678f, -1.0f, -0.70710678f, 0.0f, 0.70710678f };
    static const float SIN[8] = { 0.0f, 0.70710678f, 1.0f, 0.70710678f, 0.0f, -0.70710678f, -1.0f, -0.70710678f };
    float vx = 0.0f, vy = -5.5f;
    int px = cx + (int)floorf(vx * COS[steps & 7] - vy * SIN[steps & 7] + 0.5f);
    int py = cy + (int)floorf(vx * SIN[steps & 7] + vy * COS[steps & 7] + 0.5f);
    holo_face(w, px - 4, py - 2);
}

#include "aw_road.inc"
#include "aw_boats.inc"

static void draw_hero(AWWorld *w) {
    int camI = (int)floor(w->cam);
    int sx = (int)floor(w->ax) - camI;
    int sy = (int)floorf(w->ay);
    int blink = w->blink_t > 0.0f;
    switch (w->mode) {
        case M_WALK: {
            int legs = 0;
            if (w->spd > 4.0f) legs = 1 + (((int)(w->anim_t * 5.0f)) & 1);
            draw_arch(w, sx - 6, sy - 12, legs, blink, 0, 0);
        } break;
        case M_WINGS:   draw_h_wings(w, sx, sy, blink); break;
        case M_CAR:     draw_h_car(w, sx, sy, blink); break;
        case M_ROCKET:  draw_h_rocket(w, sx, sy); break;
        case M_BALLOON: draw_h_balloon(w, sx, sy, blink); break;
        case M_CARPET:  draw_h_carpet(w, sx, sy, blink); break;
        case M_JETPACK: draw_h_jetpack(w, sx, sy, blink); break;
        case M_DIG:     draw_h_dig(w, sx, sy); break;
        case M_ROAD:
            if (w->stage == 0) {   /* hurrying to the road */
                int legs = 1 + (((int)(w->anim_t * 5.0f)) & 1);
                draw_arch(w, sx - 6, sy - 12, legs, blink, 0, 0);
            } else draw_h_road(w, sx, sy, blink);
            break;
        case M_DIVE:
            if (w->stage == 0) {   /* hurrying down to the water */
                int legs = 1 + (((int)(w->anim_t * 5.0f)) & 1);
                draw_arch(w, sx - 6, sy - 12, legs, blink, 0, 0);
            } else draw_h_dive(w, sx, sy, blink);
            break;
        case M_SUB:
        case M_BOAT:
            if (w->stage == 0) {   /* hurrying down to the water */
                int legs = 1 + (((int)(w->anim_t * 5.0f)) & 1);
                draw_arch(w, sx - 6, sy - 12, legs, blink, 0, 0);
            } else if (w->mode == M_SUB) draw_h_sub(w, sx, sy - (int)(clampf((w->alt + 8.0f) / 8.0f, 0.0f, 1.0f) * 3.0f + 0.5f), blink);
            else if (w->boat == B_SAIL) draw_h_boat(w, sx, sy, blink);
            else draw_h_vessel(w, sx, sy, blink);
            break;
        default: break;
    }
}

/* ------------------------------------------------------------------ */
/* simulation: how Archon travels                                      */
/* ------------------------------------------------------------------ */
static void end_mode(AWWorld *w) {
    if (w->mode == M_WINGS) {
        for (int i = 0; i < 6; i++) spawn_spark(w, w->ax + (rng_f(w) - 0.5f) * 14.0f, w->ay - 8.0f, (rng_f(w) - 0.5f) * 30.0f, -10.0f - rng_f(w) * 16.0f, 0.6f, SK_STAR, 0xFFFFFF);
    } else poof(w, w->ax, w->ay);
    w->last_mode2 = w->last_mode; w->last_mode = w->mode;
    w->mode = M_WALK; w->phase = PH_IN; w->alt = 0.0f; w->valt = 0.0f; w->pitch = 0.0f; w->stage = 0;
    w->dig_head = 0.0f; w->dig_slope = 0.0f;
    w->walk_len = fmaxf(rng_r(w, 11.0f, 22.0f), (0.3f * (float)w->vw + 90.0f) / 22.0f);   /* walk far enough that an old lake has left the screen */
    w->next_idle = rng_r(w, 5.0f, 12.0f); w->idle = 0;
}
static void start_lake(AWWorld *w, int m) {
    float spd = m == M_SUB ? 26.0f : (m == M_DIVE ? 22.0f : 32.0f);
    float need = (m == M_SUB || m == M_DIVE) ? spd * w->act_len + 300.0f : spd * w->act_len + 200.0f;
    float vh = (float)w->vh;
    int pier = 0;
    if (m == M_BOAT) {   /* pick the boat; the new ones come with piers */
        static const float BW[B_N] = { 1.0f, 1.0f, 1.0f, 1.0f, 0.8f, 0.9f };
        float tot = 0.0f, wt[B_N];
        for (int i = 0; i < B_N; i++) { wt[i] = i == w->last_boat ? 0.0f : BW[i]; tot += wt[i]; }
        float r = rng_f(w) * tot; int b = B_SAIL;
        for (int i = 0; i < B_N; i++) { if (r < wt[i]) { b = i; break; } r -= wt[i]; }
        if (w->boat_force) { b = w->boat_force - 1; w->boat_force = 0; }
        w->boat = b; w->last_boat = b;
        const BoatP *bp = &BOATP[b];
        pier = bp->pier;
        if (b != B_SAIL) {
            w->act_len = rng_r(w, bp->dlo, bp->dhi);
            spd = bp->speed;
            need = spd * w->act_len + (float)bp->len + 2.0f * (float)bp->pier + 150.0f;
        }
    }
    w->lk_pl = pier;
    w->lk_on = 1;
    w->lk_x0 = w->ax + 0.7 * (double)w->vw + (pier ? 36.0 : 28.0);
    w->lk_x1 = w->lk_x0 + (double)need;
    if (w->rd_on && w->rd_x0 < w->lk_x1 && w->rd_x1 > w->lk_x0) w->rd_on = 0;     /* the newest ride's scenery wins if an unfinished trip laid something in the same place */
    if (w->jp_on && w->jp_x0 < w->lk_x1 && w->jp_x1 > w->lk_x0) w->jp_on = 0;
    w->lk_depth = m == M_SUB ? fmaxf(vh * rng_r(w, 0.56f, 0.63f), 108.0f) : fmaxf(vh * rng_r(w, 0.38f, 0.50f), 64.0f);
    w->lk_dive = 0;
    if (m == M_DIVE) {   /* a snorkeller needs a reef he can see from the surface; a scuba diver wants the deep */
        w->dive_kind = rng_f(w) < 0.36f ? 0 : 1;
        if (w->dive_force) { w->dive_kind = w->dive_force - 1; w->dive_force = 0; }
        w->lk_dive = w->dive_kind ? 2 : 1;
        w->lk_depth = w->dive_kind ? fmaxf(vh * rng_r(w, 0.68f, 0.74f), 124.0f) : fmaxf(vh * rng_r(w, 0.21f, 0.23f), 38.0f);
    }
    w->lk_seed = rng_u32(w);
}
/* a level road is laid just beyond the right edge of the screen; he picks a vehicle and hurries to it */
static void start_road(AWWorld *w) {
    static const float VW[V_N] = { 1.0f, 1.0f, 1.2f, 1.2f, 1.0f, 0.8f, 1.0f, 0.8f, 1.1f, 1.1f, 4.0f };
    float tot = 0.0f, wt[V_N];
    for (int i = 0; i < V_N; i++) { wt[i] = i == w->last_veh ? 0.0f : VW[i]; tot += wt[i]; }
    float r = rng_f(w) * tot; int v = V_SEDAN;
    for (int i = 0; i < V_N; i++) { if (r < wt[i]) { v = i; break; } r -= wt[i]; }
    if (w->veh_force) { v = w->veh_force - 1; w->veh_force = 0; }
    w->veh = v; w->last_veh = v;
    float need = VEHP[v].speed * w->act_len + 3.0f * ROAD_RAMP + 190.0f + (float)VEHP[v].len;
    w->rd_on = 1;
    w->rd_x0 = w->ax + 0.7 * (double)w->vw + 28.0;
    w->rd_x1 = w->rd_x0 + (double)need;
    if (w->lk_on && w->lk_x0 < w->rd_x1 && w->lk_x1 > w->rd_x0) w->lk_on = 0;     /* ...and so does a road laid over an unfinished lake */
    w->rd_h = 2 + (int)(rng_f(w) * 5.0f);
    w->jp_on = 0;
    if (v == V_JEEP) {   /* the 4x4 takes a dirt trail over gentle rolling hills and small rocks instead of a level road */
        w->rd_on = 0;
        w->jp_on = 1; w->jp_x0 = w->rd_x0; w->jp_x1 = w->rd_x1;
        w->jp_amp = rng_r(w, 7.0f, 10.0f); w->jp_lam = rng_r(w, 190.0f, 250.0f); w->jp_ph = rng_r(w, 0.0f, 6.28f); w->jp_seed = rng_u32(w);
    }
}
static void start_mode(AWWorld *w, int m) {
    w->mode = m; w->phase = PH_IN; w->phase_t = 0.0f; w->stage = 0; w->stage_t = 0.0f; w->touched = 0; w->grounded_t = 0.0f;
    w->alt = 0.0f; w->valt = 0.0f; w->pitch = 0.0f; w->idle = 0; w->wob = rng_f(w) * 6.28f;
    w->dig_head = 0.0f; w->dig_slope = 0.0f;
    w->act_len = rng_r(w, FLYP[m].act_lo, FLYP[m].act_hi);
    if (m == M_ROCKET) w->act_len = rng_r(w, 10.0f, 15.0f);
    if (m == M_DIG) w->act_len = rng_r(w, 9.0f, 13.0f);
    if (m == M_SUB) w->act_len = rng_r(w, 10.0f, 14.0f);
    if (m == M_BOAT) w->act_len = rng_r(w, 11.0f, 15.0f);
    if (m == M_DIVE) w->act_len = rng_r(w, 12.0f, 17.0f);
    if (m == M_ROAD) { w->act_len = rng_r(w, 10.0f, 14.0f); start_road(w); }
    if (m == M_SUB || m == M_BOAT || m == M_DIVE) start_lake(w, m);
    else if (m != M_ROAD) poof(w, w->ax, w->ay);
}
static int pick_mode(AWWorld *w) {
    static const float W[M_COUNT] = { 0.0f, 20.0f, 17.0f, 14.0f, 14.0f, 17.0f, 16.0f, 15.0f, 15.0f, 19.0f, 30.0f, 22.0f };
    float wt[M_COUNT], tot = 0.0f;
    for (int i = 1; i < M_COUNT; i++) { wt[i] = (i == w->last_mode || i == w->last_mode2) ? 0.0f : W[i]; tot += wt[i]; }
    float r = rng_f(w) * tot;
    for (int i = 1; i < M_COUNT; i++) { if (r < wt[i]) return i; r -= wt[i]; }
    return M_WINGS;
}

static void step_fly(AWWorld *w, float dt) {
    const FlyP *p = &FLYP[w->mode];
    w->phase_t += dt;
    if (w->phase == PH_IN) {
        w->alt = 0.0f; w->valt = 0.0f;
        float tgt = (w->mode == M_CAR && w->phase_t > 0.7f) ? p->vgnd : 0.0f;
        w->spd = approach(w->spd, tgt, 2.5f, dt);
        if (w->phase_t >= p->tin) { w->phase = PH_ACT; w->phase_t = 0.0f; }
        return;
    }
    float om = p->climb * 1.6f;
    if (w->phase == PH_ACT) {
        w->spd = approach(w->spd, p->vcruise, 1.2f, dt);
        w->wob += p->wander * dt;
        float goal = p->alt_lo + (p->alt_hi - p->alt_lo) * (0.5f + 0.5f * sinf(w->wob));
        w->valt += ((goal - w->alt) * om * om - 2.0f * om * w->valt) * dt;
        w->alt += w->valt * dt;
        if (w->alt < 0.0f) { w->alt = 0.0f; w->valt = 0.0f; }
        if (w->phase_t >= w->act_len) { w->phase = PH_OUT; w->phase_t = 0.0f; w->touched = 0; w->grounded_t = 0.0f; }
        return;
    }
    /* PH_OUT */
    if (!w->touched) {
        w->spd = approach(w->spd, p->vland, 1.5f, dt);
        w->valt += ((-9.0f - w->alt) * om * om - 2.0f * om * w->valt) * dt;
        w->alt += w->valt * dt;
        if (w->alt <= 0.0f) {
            w->alt = 0.0f; w->valt = 0.0f; w->touched = 1; w->grounded_t = 0.0f;
            dust(w, w->ax, w->ay, 6);
        }
    } else {
        w->grounded_t += dt;
        float tgt = 0.0f;
        if (w->mode == M_WINGS) tgt = 30.0f;
        else if (w->mode == M_CAR) tgt = w->grounded_t < 1.2f ? 18.0f : 0.0f;
        w->spd = approach(w->spd, tgt, 3.0f, dt);
        if (w->grounded_t >= p->tout) end_mode(w);
    }
}

static void step_rocket(AWWorld *w, float dt) {
    const float acr = ACR(w);
    w->stage_t += dt;
    w->smoke_t -= dt;
    float nozzle_y = w->ay + 0.0f;
    switch (w->stage) {
        case 0:   /* on the pad: countdown */
            w->alt = 0.0f; w->spd = approach(w->spd, 0.0f, 6.0f, dt);
            if (w->stage_t > 1.3f && w->smoke_t <= 0.0f) {
                w->smoke_t = 0.07f;
                spawn_spark(w, w->ax + (rng_f(w) - 0.5f) * 8.0f, nozzle_y - 2.0f, (rng_f(w) - 0.5f) * 50.0f, -4.0f - rng_f(w) * 8.0f, 0.7f, SK_SMOKE, 0xE8E8F0);
            }
            if (w->stage_t >= 2.8f) { w->stage = 1; w->stage_t = 0.0f; w->vup = 12.0f; }
            break;
        case 1:   /* lift-off */
            w->vup = fminf(w->vup + (34.0f + w->alt * 0.2f) * dt, 110.0f);
            w->alt += w->vup * dt;
            w->spd = approach(w->spd, 14.0f, 1.0f, dt);
            if (w->smoke_t <= 0.0f) {
                w->smoke_t = 0.05f;
                spawn_spark(w, w->ax + (rng_f(w) - 0.5f) * 6.0f, w->ay + 14.0f, (rng_f(w) - 0.5f) * 14.0f, 6.0f + rng_f(w) * 10.0f, 0.8f, SK_SMOKE, 0xFFFFFF);
            }
            if (w->alt >= acr) { w->alt = acr; w->stage = 2; w->stage_t = 0.0f; w->wob = 0.0f; }
            break;
        case 2:   /* nose over */
            w->pitch = clampf(w->stage_t / 1.4f, 0.0f, 1.0f) * 90.0f;
            w->spd = approach(w->spd, 108.0f, 1.3f, dt);
            w->alt = acr;
            if (w->stage_t >= 1.4f) { w->stage = 3; w->stage_t = 0.0f; }
            break;
        case 3:   /* cruise through space */
            w->pitch = 90.0f; w->wob += dt * 0.9f;
            w->spd = approach(w->spd, 108.0f, 1.3f, dt);
            w->alt = acr + 8.0f * clampf(w->stage_t, 0.0f, 1.0f) * sinf(w->wob);
            if (w->smoke_t <= 0.0f) {
                w->smoke_t = 0.06f;
                spawn_spark(w, w->ax - 14.0f, w->ay - 10.0f + (rng_f(w) - 0.5f) * 3.0f, -20.0f, 0.0f, 0.6f, SK_GLITTER, 0xFFE45E);
            }
            if (w->stage_t >= w->act_len) { w->stage = 4; w->stage_t = 0.0f; }
            break;
        case 4:   /* nose back up */
            w->pitch = (1.0f - clampf(w->stage_t / 1.4f, 0.0f, 1.0f)) * 90.0f;
            w->spd = approach(w->spd, 12.0f, 1.6f, dt);
            w->alt = acr + 8.0f * (1.0f - clampf(w->stage_t / 1.4f, 0.0f, 1.0f)) * sinf(w->wob);
            if (w->stage_t >= 1.4f) { w->stage = 5; w->stage_t = 0.0f; w->alt = acr; }
            break;
        case 5: { /* retro descent */
            float v = fminf(11.0f + sqrtf(2.0f * 55.0f * fmaxf(w->alt, 0.0f)), 125.0f);
            w->alt -= v * dt;
            w->spd = approach(w->spd, 10.0f, 1.0f, dt);
            if (w->smoke_t <= 0.0f && w->alt < 90.0f) {
                w->smoke_t = 0.05f;
                spawn_spark(w, w->ax + (rng_f(w) - 0.5f) * 6.0f, w->ay + 14.0f, (rng_f(w) - 0.5f) * 20.0f, 4.0f, 0.5f, SK_SMOKE, 0xFFFFFF);
            }
            if (w->alt <= 0.0f) { w->alt = 0.0f; w->stage = 6; w->stage_t = 0.0f; dust(w, w->ax, w->ay, 8); }
        } break;
        default:  /* landed */
            w->alt = 0.0f; w->spd = approach(w->spd, 0.0f, 5.0f, dt);
            if (w->stage_t > 1.5f) end_mode(w);
            break;
    }
}

/* ---- the digger, the submarine and the sailboat ---- */
static void dirt_spray(AWWorld *w, double x, float y, int n, float up) {
    for (int i = 0; i < n; i++) {
        Col c = (i & 1) ? w->cur.dirt : w->cur.dirt_lt;
        spawn_spark(w, x + (rng_f(w) - 0.5f) * 8.0f, y, (rng_f(w) - 0.5f) * 44.0f, -up * (0.4f + rng_f(w)), 0.5f + rng_f(w) * 0.4f, SK_CHUNK, c);
    }
}
static void bubbles(AWWorld *w, double x, float y, int n) {
    for (int i = 0; i < n; i++)
        spawn_spark(w, x + (rng_f(w) - 0.5f) * 5.0f, y + (rng_f(w) - 0.5f) * 4.0f, 0.0f, -14.0f - rng_f(w) * 12.0f, 1.2f + rng_f(w) * 1.6f, SK_BUBBLE, 0xCFF3FF);
}
static void splash(AWWorld *w, double x, int n) {
    for (int i = 0; i < n; i++)
        spawn_spark(w, x + (rng_f(w) - 0.5f) * 12.0f, (float)w->gy, (rng_f(w) - 0.5f) * 40.0f, -18.0f - rng_f(w) * 26.0f, 0.5f + rng_f(w) * 0.3f, SK_FOAM, 0xFFFFFF);
}

static void step_dig(AWWorld *w, float dt) {
    w->stage_t += dt; w->smoke_t -= dt;
    float vh = (float)w->vh;
    float dmid = fmaxf(0.34f * vh, 50.0f);
    switch (w->stage) {
        case 0:   /* rolls along the ground with the drill spinning */
            w->alt = 0.0f; w->dig_head = 0.0f; w->dig_slope = 0.0f;
            w->spd = approach(w->spd, 20.0f, 2.5f, dt);
            if (w->smoke_t <= 0.0f && w->stage_t > 0.5f) { w->smoke_t = 0.1f; dirt_spray(w, w->ax + 20.0, w->ay - 4.0f, 1, 20.0f); }
            if (w->stage_t >= 1.5f) { w->stage = 1; w->stage_t = 0.0f; }
            break;
        case 1:   /* dives at 45 degrees */
            w->dig_head = -1.0f; w->dig_slope = 1.0f;
            w->spd = approach(w->spd, 22.0f, 3.0f, dt);
            w->alt -= 22.0f * dt;
            if (w->alt > -16.0f && w->smoke_t <= 0.0f) { w->smoke_t = 0.05f; dirt_spray(w, w->ax + 18.0, w->surf_s - 2.0f, 2, 42.0f); }
            if (-w->alt >= dmid) { w->alt = -dmid; w->stage = 2; w->stage_t = 0.0f; w->wob = 0.0f; w->next_guest = fminf(w->next_guest, 1.0f); }
            break;
        case 2: { /* tunnels along underground */
            w->dig_head = 0.0f;
            w->wob += dt * 0.55f;
            float goal = dmid + 0.05f * vh * sinf(w->wob);
            float prev = w->alt;
            w->alt = approach(w->alt, -goal, 1.8f, dt);
            w->spd = approach(w->spd, 26.0f, 2.0f, dt);
            w->dig_slope = dt > 0.0f ? clampf(-(w->alt - prev) / dt / fmaxf(w->spd, 8.0f), -0.6f, 0.6f) : 0.0f;
            if (w->smoke_t <= 0.0f) { w->smoke_t = 0.06f; spawn_spark(w, w->ax + 20.0, w->ay - 8.0f + (rng_f(w) - 0.5f) * 6.0f, -22.0f - rng_f(w) * 22.0f, (rng_f(w) - 0.5f) * 30.0f, 0.5f, SK_CHUNK, rng_f(w) < 0.5f ? w->cur.dirt_lt : w->cur.dirt); }
            if (w->stage_t >= w->act_len) { w->stage = 3; w->stage_t = 0.0f; }
        } break;
        case 3:   /* climbs back up */
            w->dig_head = 1.0f; w->dig_slope = -1.0f;
            w->spd = approach(w->spd, 22.0f, 3.0f, dt);
            w->alt += 22.0f * dt;
            if (w->alt >= -1.0f) { w->alt = 0.0f; w->stage = 4; w->stage_t = 0.0f; w->dig_head = 0.0f; w->dig_slope = 0.0f; dirt_spray(w, w->ax + 14.0, w->surf_s, 14, 70.0f); dust(w, w->ax, w->surf_s, 8); }
            break;
        default:  /* pops out */
            w->alt = 0.0f; w->dig_head = 0.0f; w->dig_slope = 0.0f;
            w->spd = approach(w->spd, 0.0f, 4.0f, dt);
            if (w->stage_t > 1.1f) end_mode(w);
            break;
    }
}

static void step_sub(AWWorld *w, float dt) {
    w->stage_t += dt; w->phase_t += dt; w->smoke_t -= dt;
    float vh = (float)w->vh;
    if (w->phase_t > 90.0f) { end_mode(w); return; }
    switch (w->stage) {
        case 0:   /* hurry to the shore */
            w->alt = 0.0f; w->spd = approach(w->spd, 44.0f, 3.0f, dt);
            if (w->ax >= w->lk_x0 + 8.0) { poof(w, w->ax, (float)w->gy); splash(w, w->ax, 10); w->stage = 1; w->stage_t = 0.0f; }
            break;
        case 1:   /* bobs on the surface */
            w->alt = 0.0f; w->spd = approach(w->spd, 18.0f, 2.5f, dt);
            if (w->stage_t >= 1.6f) { w->stage = 2; w->stage_t = 0.0f; }
            break;
        case 2: { /* dives */
            float goal = fmaxf(0.25f * vh, 44.0f);
            w->spd = approach(w->spd, 24.0f, 1.5f, dt);
            float rate = 14.0f * clampf((goal + w->alt) / 10.0f + 0.15f, 0.15f, 1.0f);
            w->alt -= rate * dt;
            if (w->smoke_t <= 0.0f) { w->smoke_t = 0.1f; bubbles(w, w->ax - 22.0, w->ay - 2.0f, 1); }
            if (w->alt <= -goal + 0.5f) { w->stage = 3; w->stage_t = 0.0f; w->next_guest = fminf(w->next_guest, 1.0f); }
        } break;
        case 3: { /* cruises under the water */
            w->wob += dt * 0.6f;
            float dlo = fmaxf(0.21f * vh, 38.0f), dhi = fmaxf(0.285f * vh, 52.0f);
            int ix = (int)floor(w->ax);
            float bed = (float)imin(lake_depth(w, ix - 20), imin(lake_depth(w, ix), lake_depth(w, ix + 24)));
            float goal = dlo + (dhi - dlo) * (0.5f + 0.5f * sinf(w->wob));
            goal = fminf(goal, bed - 18.0f);
            if (goal < 6.0f) goal = 6.0f;
            w->alt = approach(w->alt, -goal, 1.4f, dt);
            w->spd = approach(w->spd, 26.0f, 1.5f, dt);
            if (w->smoke_t <= 0.0f) { w->smoke_t = 0.16f; bubbles(w, w->ax - 22.0, w->ay - 2.0f, 1); if (rng_f(w) < 0.3f) bubbles(w, w->ax + 2.0, w->ay - 16.0f, 1); }
            if (w->stage_t >= w->act_len) { w->stage = 4; w->stage_t = 0.0f; }
        } break;
        case 4:   /* comes back up */
            w->alt = fminf(0.0f, approach(w->alt, 0.0f, 1.1f, dt) + 4.0f * dt);
            w->spd = approach(w->spd, 24.0f, 1.5f, dt);
            if (w->smoke_t <= 0.0f) { w->smoke_t = 0.12f; bubbles(w, w->ax - 22.0, w->ay - 2.0f, 1); }
            if (w->alt > -1.5f) { w->alt = 0.0f; w->stage = 5; w->stage_t = 0.0f; splash(w, w->ax, 8); }
            break;
        default:  /* glides to the far shore on the surface */
            w->alt = 0.0f; w->spd = approach(w->spd, 22.0f, 1.5f, dt);
            if (w->smoke_t <= 0.0f) { w->smoke_t = 0.07f; spawn_spark(w, w->ax - 22.0, (float)w->gy, -8.0f - rng_f(w) * 6.0f, -6.0f, 0.5f, SK_FOAM, 0xFFFFFF); }
            if (w->ax >= w->lk_x1 - 14.0) { poof(w, w->ax, (float)w->gy); end_mode(w); }
            break;
    }
}

/* the dive: swims out in a mask, then snorkels along the surface (peering at the reef) or goes deep with a tank */
static void step_dive(AWWorld *w, float dt) {
    w->stage_t += dt; w->phase_t += dt; w->smoke_t -= dt;
    float vh = (float)w->vh;
    int scuba = w->dive_kind;
    if (w->phase_t > 110.0f) { end_mode(w); return; }
    int ix = (int)floor(w->ax);
    float bed = (float)imin(lake_depth(w, ix - 20), imin(lake_depth(w, ix), lake_depth(w, ix + 24)));
    switch (w->stage) {
        case 0:   /* hurry to the shore */
            w->alt = 0.0f; w->spd = approach(w->spd, 44.0f, 3.0f, dt);
            if (w->ax >= w->lk_x0 + 8.0) { poof(w, w->ax, (float)w->gy); splash(w, w->ax, 12); w->stage = 1; w->stage_t = 0.0f; }
            break;
        case 1:   /* bobs at the surface, settling his mask */
            w->alt = 0.0f; w->spd = approach(w->spd, 16.0f, 2.5f, dt);
            if (w->stage_t >= 1.7f) { w->stage = scuba ? 2 : 3; w->stage_t = 0.0f; w->wob = rng_f(w) * 6.28f; }
            break;
        case 2: { /* scuba: sinks down to the deep */
            float goal = fmaxf(0.36f * vh, 62.0f);
            w->spd = approach(w->spd, 22.0f, 1.5f, dt);
            float rate = 12.0f * clampf((goal + w->alt) / 12.0f + 0.15f, 0.15f, 1.0f);
            w->alt -= rate * dt;
            if (w->smoke_t <= 0.0f) { w->smoke_t = 0.34f; bubbles(w, w->ax + 1.0, w->ay - 14.0f, 2); }
            if (w->alt <= -goal + 0.5f) { w->stage = 3; w->stage_t = 0.0f; w->next_guest = fminf(w->next_guest, 1.0f); }
        } break;
        case 3: { /* cruising: deep with a tank, or along the surface with a snorkel */
            w->wob += dt * 0.5f;
            if (scuba) {
                float dlo = fmaxf(0.36f * vh, 62.0f), dhi = fmaxf(0.47f * vh, 80.0f);
                float goal = dlo + (dhi - dlo) * (0.5f + 0.5f * sinf(w->wob));
                goal = fminf(goal, bed - 20.0f);
                if (goal < 8.0f) goal = 8.0f;
                w->alt = approach(w->alt, -goal, 1.2f, dt);
                w->spd = approach(w->spd, 23.0f, 1.5f, dt);
                if (w->smoke_t <= 0.0f) { w->smoke_t = 0.9f; bubbles(w, w->ax + 1.0, w->ay - 14.0f, 3); }
            } else {   /* a little duck now and then to look at the fish */
                float cyc = fmodf(w->stage_t, 6.5f);
                float tgt = (cyc > 3.6f && cyc < 5.4f) ? -4.5f : 0.0f;
                w->alt = approach(w->alt, tgt, 7.0f, dt);
                w->spd = approach(w->spd, 19.0f, 1.5f, dt);
                if (w->alt < -2.0f && w->smoke_t <= 0.0f) { w->smoke_t = 0.25f; bubbles(w, w->ax + 1.0, w->ay - 6.0f, 1); }
                if (w->alt > -0.5f && w->smoke_t <= 0.0f) { w->smoke_t = 0.12f; spawn_spark(w, w->ax - 8.0, (float)w->gy, -8.0f - rng_f(w) * 6.0f, -5.0f, 0.5f, SK_FOAM, 0xFFFFFF); }
            }
            if (w->stage_t >= w->act_len) { w->stage = scuba ? 4 : 5; w->stage_t = 0.0f; }
        } break;
        case 4:   /* scuba: kicks back up to the light */
            w->alt = fminf(0.0f, approach(w->alt, 0.0f, 1.1f, dt) + 4.0f * dt);
            w->spd = approach(w->spd, 22.0f, 1.5f, dt);
            if (w->smoke_t <= 0.0f) { w->smoke_t = 0.2f; bubbles(w, w->ax + 1.0, w->ay - 14.0f, 2); }
            if (w->alt > -1.5f) { w->alt = 0.0f; w->stage = 5; w->stage_t = 0.0f; splash(w, w->ax, 8); }
            break;
        default:  /* paddles on to the far shore */
            w->alt = 0.0f; w->spd = approach(w->spd, 20.0f, 1.5f, dt);
            if (w->smoke_t <= 0.0f) { w->smoke_t = 0.08f; spawn_spark(w, w->ax - 8.0, (float)w->gy, -8.0f - rng_f(w) * 6.0f, -6.0f, 0.5f, SK_FOAM, 0xFFFFFF); }
            if (w->ax >= w->lk_x1 - 14.0) { poof(w, w->ax, (float)w->gy); end_mode(w); }
            break;
    }
}

/* the new boats: board at the near pier, sail across, tie up alongside the far pier and step off onto it */
static void step_vessel(AWWorld *w, float dt) {
    const BoatP *bp = &BOATP[w->boat];
    double dock_x = w->lk_x0 + (double)bp->len * 0.5 + 4.0;          /* where he boards: the whole hull is over water */
    double stop_x = w->lk_x1 - (double)bp->len * 0.5 - 6.0;          /* where he ties up */
    switch (w->stage) {
        case 0:
            w->alt = 0.0f; w->spd = approach(w->spd, 44.0f, 3.0f, dt);
            if (w->ax >= dock_x) { poof(w, w->ax, (float)(w->gy - PIER_H)); splash(w, w->ax, 10); w->stage = 1; w->stage_t = 0.0f; w->spd = fminf(w->spd, 24.0f); }
            break;
        case 1:   /* casts off */
            w->alt = 0.0f; w->spd = approach(w->spd, bp->speed * 0.4f, 2.0f, dt);
            if (w->stage_t >= 1.2f) { w->stage = 2; w->stage_t = 0.0f; w->next_guest = fminf(w->next_guest, 2.0f); }
            break;
        case 2:   /* under way */
            w->alt = 0.0f; w->spd = approach(w->spd, bp->speed, bp->accel, dt);
            if (w->stage_t >= w->act_len || w->ax >= stop_x - (double)bp->speed * 2.4) { w->stage = 3; w->stage_t = 0.0f; }
            break;
        case 3: { /* slows for the far pier */
            double rem = stop_x - w->ax;
            float tgt = fminf(bp->speed, 3.0f + (float)rem * 0.8f);
            w->alt = 0.0f; w->spd = approach(w->spd, tgt, 4.0f, dt);
            if (rem <= 0.6) { w->stage = 4; w->stage_t = 0.0f; w->spd = 0.0f; }
        } break;
        default:  /* alongside; he steps off */
            w->alt = 0.0f; w->spd = 0.0f;
            if (w->stage_t > 0.9f) { poof(w, w->ax, (float)(w->gy - PIER_H)); splash(w, w->ax, 8); end_mode(w); }
            break;
    }
    if (w->stage < 1 || w->smoke_t > 0.0f) return;
    float sp = w->spd, bow = (float)bp->len * 0.5f - 2.0f, stern = -(float)bp->len * 0.5f + 3.0f;
    float gyf = (float)w->gy;
    switch (w->boat) {
        case B_TUG:
            w->smoke_t = 0.22f;
            spawn_spark(w, w->ax + stern + 12.0, gyf - 22.0f, -3.0f - sp * 0.1f, -14.0f, 0.9f, SK_SMOKE, 0x3A3A46);
            spawn_spark(w, w->ax + stern, gyf + 1.0f, -5.0f - sp * 0.2f, -3.0f - rng_f(w) * 4.0f, 0.5f, SK_FOAM, 0xFFFFFF);
            if (sp > 8.0f) spawn_spark(w, w->ax + bow, gyf, sp * 0.1f, -9.0f - rng_f(w) * 7.0f, 0.4f, SK_FOAM, 0xFFFFFF);
            break;
        case B_JET:
            w->smoke_t = 0.035f;
            if (sp > 12.0f) {
                spawn_spark(w, w->ax + stern, gyf, -sp * 0.35f - rng_f(w) * 10.0f, -28.0f - rng_f(w) * 34.0f, 0.55f, SK_FOAM, 0xFFFFFF);      /* the rooster tail */
                spawn_spark(w, w->ax + stern + 2.0f, gyf, -sp * 0.2f, -16.0f - rng_f(w) * 22.0f, 0.5f, SK_FOAM, 0xDDF3FF);
                spawn_spark(w, w->ax + bow, gyf, sp * 0.1f, -10.0f - rng_f(w) * 12.0f, 0.35f, SK_FOAM, 0xFFFFFF);
            }
            break;
        case B_SPEED:
            w->smoke_t = 0.05f;
            if (sp > 10.0f) {
                spawn_spark(w, w->ax + stern, gyf, -sp * 0.3f - rng_f(w) * 8.0f, -10.0f - rng_f(w) * 18.0f, 0.5f, SK_FOAM, 0xFFFFFF);
                spawn_spark(w, w->ax + bow - 6.0f, gyf, sp * 0.12f, -8.0f - rng_f(w) * 14.0f, 0.4f, SK_FOAM, 0xFFFFFF);
            }
            break;
        case B_FLOAT:
            w->smoke_t = 0.5f;
            spawn_spark(w, w->ax + (rng_f(w) < 0.5f ? -12.0f : 12.0f), gyf + 1.0f, (rng_f(w) - 0.5f) * 6.0f, -4.0f - rng_f(w) * 4.0f, 0.4f, SK_FOAM, 0xFFFFFF);
            break;
        default:  /* cruise ship */
            w->smoke_t = 0.3f;
            spawn_spark(w, w->ax - 2.0f, gyf - 31.0f, -3.0f - sp * 0.1f, -10.0f, 1.2f, SK_SMOKE, 0xD0D0DA);
            if (sp > 5.0f) {
                spawn_spark(w, w->ax + stern, gyf + 1.0f, -6.0f - sp * 0.2f, -3.0f - rng_f(w) * 5.0f, 0.55f, SK_FOAM, 0xFFFFFF);
                spawn_spark(w, w->ax + bow, gyf, sp * 0.1f, -8.0f - rng_f(w) * 8.0f, 0.4f, SK_FOAM, 0xFFFFFF);
            }
            break;
    }
}

static void step_boat(AWWorld *w, float dt) {
    w->stage_t += dt; w->phase_t += dt; w->smoke_t -= dt;
    if (w->phase_t > 90.0f) { end_mode(w); return; }
    if (w->boat != B_SAIL) { step_vessel(w, dt); return; }
    switch (w->stage) {
        case 0:
            w->alt = 0.0f; w->spd = approach(w->spd, 44.0f, 3.0f, dt);
            if (w->ax >= w->lk_x0 + 6.0) { poof(w, w->ax, (float)w->gy); splash(w, w->ax, 10); w->stage = 1; w->stage_t = 0.0f; }
            break;
        case 1:   /* launch; the sail goes up */
            w->alt = 0.0f; w->spd = approach(w->spd, 16.0f, 2.0f, dt);
            if (w->stage_t >= 1.3f) { w->stage = 2; w->stage_t = 0.0f; w->next_guest = fminf(w->next_guest, 2.0f); }
            break;
        case 2:   /* sails */
            w->alt = 0.0f; w->spd = approach(w->spd, 32.0f, 1.2f, dt);
            if (w->stage_t >= w->act_len || w->ax >= w->lk_x1 - 64.0) { w->stage = 3; w->stage_t = 0.0f; }
            break;
        default:  /* slows for the far shore */
            w->alt = 0.0f; w->spd = approach(w->spd, 18.0f, 1.5f, dt);
            if (w->ax >= w->lk_x1 - 14.0) { poof(w, w->ax, (float)w->gy); end_mode(w); }
            break;
    }
    if (w->mode == M_BOAT && w->stage >= 1 && w->smoke_t <= 0.0f) {
        w->smoke_t = 0.06f;
        float sp = w->spd;
        spawn_spark(w, w->ax - 17.0, (float)w->gy + 1.0f, -6.0f - sp * 0.15f, -3.0f - rng_f(w) * 4.0f, 0.55f, SK_FOAM, 0xFFFFFF);
        if (sp > 14.0f) spawn_spark(w, w->ax + 18.0, (float)w->gy, sp * 0.12f, -10.0f - rng_f(w) * 10.0f, 0.4f, SK_FOAM, 0xFFFFFF);
    }
}

static void step_road(AWWorld *w, float dt) {
    const VehP *v = &VEHP[w->veh];
    w->stage_t += dt; w->phase_t += dt;
    w->alt = 0.0f;
    if (w->phase_t > 90.0f) { end_mode(w); return; }
    double flat0 = w->rd_x0 + (double)ROAD_RAMP, flat1 = w->rd_x1 - (double)ROAD_RAMP;
    switch (w->stage) {
        case 0:   /* hurry to the road */
            w->spd = approach(w->spd, 54.0f, 3.0f, dt);
            if (w->ax >= flat0 + 4.0) { poof(w, w->ax, w->ay); w->stage = 1; w->stage_t = 0.0f; w->spd = fminf(w->spd, 16.0f); }
            break;
        case 1:   /* hops in and pulls away */
            w->spd = approach(w->spd, v->speed, 1.3f, dt);
            if (w->stage_t >= 1.5f) { w->stage = 2; w->stage_t = 0.0f; }
            break;
        case 2:   /* drives */
            w->spd = approach(w->spd, v->speed, 1.0f, dt);
            if (w->stage_t >= w->act_len || w->ax >= flat1 - (double)v->len - 50.0) { w->stage = 3; w->stage_t = 0.0f; }
            break;
        case 3:   /* brakes to a stop */
            w->spd = approach(w->spd, 0.0f, 2.4f, dt);
            if (w->spd < 1.5f) { w->spd = 0.0f; w->stage = 4; w->stage_t = 0.0f; }
            break;
        default:  /* parks, hops out */
            w->spd = 0.0f;
            if (w->stage_t > 0.9f) { poof(w, w->ax, w->ay); end_mode(w); }
            break;
    }
}

/* trails / exhaust that depend on the current ride */
static void step_ride_fx(AWWorld *w, float dt) {
    if (w->mode == M_ROCKET) return;
    w->smoke_t -= dt;
    int air = w->alt > 2.0f;
    if (w->mode == M_CARPET && air && w->smoke_t <= 0.0f) {
        w->smoke_t = 0.06f;
        static const Col cols[3] = { 0xFFD23F, 0xFF9EB5, 0xFFFFFF };
        spawn_spark(w, w->ax - 15.0f, w->ay - 2.0f + (rng_f(w) - 0.5f) * 3.0f, -10.0f - rng_f(w) * 8.0f, (rng_f(w) - 0.3f) * 8.0f, 0.8f, SK_GLITTER, cols[(int)(rng_f(w) * 3.0f) % 3]);
    }
    if (w->mode == M_JETPACK && (air || w->phase == PH_IN) && w->smoke_t <= 0.0f) {
        w->smoke_t = 0.045f;
        spawn_spark(w, w->ax - 8.0f, w->ay - 2.0f, -6.0f + rng_f(w) * 4.0f, 14.0f + rng_f(w) * 8.0f, 0.6f, SK_SMOKE, 0xD8D8E4);
    }
    if (w->mode == M_CAR && air && w->smoke_t <= 0.0f) {
        w->smoke_t = 0.05f;
        spawn_spark(w, w->ax - 10.0f, w->ay - 1.0f, (rng_f(w) - 0.5f) * 10.0f, 18.0f + rng_f(w) * 8.0f, 0.4f, SK_FLAME, 0xFFA030);
        spawn_spark(w, w->ax + 5.0f, w->ay - 1.0f, (rng_f(w) - 0.5f) * 10.0f, 18.0f + rng_f(w) * 8.0f, 0.4f, SK_FLAME, 0xFFA030);
    }
    if (w->mode == M_CAR && !air && w->spd > 20.0f && w->smoke_t <= 0.0f) {
        w->smoke_t = 0.12f;
        spawn_spark(w, w->ax - 15.0f, w->ay - 3.0f, -10.0f, -4.0f, 0.5f, SK_SMOKE, 0xC8C8D4);
    }
    if (w->mode == M_ROAD && w->stage >= 1 && w->stage <= 3 && w->spd > 6.0f && w->smoke_t <= 0.0f) {
        const VehP *v = &VEHP[w->veh];
        double xb = w->ax - (double)v->len * 0.5;
        switch (w->veh) {
            case V_MOTO:   w->smoke_t = 0.11f; spawn_spark(w, xb - 1.0, w->ay - 3.0f, -9.0f, -3.0f, 0.5f, SK_SMOKE, 0xC8C8D4); break;
            case V_SEDAN:  w->smoke_t = 0.16f; spawn_spark(w, xb - 1.0, w->ay - 3.0f, -9.0f, -3.0f, 0.5f, SK_SMOKE, 0xC8C8D4); break;
            case V_PICKUP: w->smoke_t = 0.15f; spawn_spark(w, xb - 1.0, w->ay - 3.0f, -10.0f, -3.0f, 0.55f, SK_SMOKE, 0xB8B8C4);
                           if (w->spd > 30.0f) spawn_spark(w, xb + 8.0, w->ay - 1.0f, -14.0f, -5.0f, 0.4f, SK_DUST, 0xD8C8A8); break;
            case V_BUS:    w->smoke_t = 0.14f; spawn_spark(w, xb - 1.0, w->ay - 4.0f, -10.0f, -2.0f, 0.6f, SK_SMOKE, 0xA8A8B4); break;
            case V_SEMI:   w->smoke_t = 0.10f; spawn_spark(w, xb + 60.0, w->ay - 28.0f, -4.0f, -16.0f, 0.9f, SK_SMOKE, 0x4A4A56);
                           spawn_spark(w, xb + 62.0, w->ay - 27.0f, -3.0f, -14.0f, 0.8f, SK_SMOKE, 0x5A5A66); break;
            case V_FORK:   w->smoke_t = 0.2f; spawn_spark(w, xb + 4.0, w->ay - 12.0f, -4.0f, -7.0f, 0.5f, SK_SMOKE, 0xC8C8D4); break;
            case V_SKATE:  w->smoke_t = 0.09f; if (w->spd > 14.0f) spawn_spark(w, xb + 4.0, w->ay - 1.0f, -10.0f, -4.0f, 0.35f, SK_DUST, 0xD8D8E0); break;
            case V_JEEP:   w->smoke_t = 0.06f; spawn_spark(w, xb + 7.0, w->ay - 1.0f, -16.0f - rng_f(w) * 8.0f, -6.0f - rng_f(w) * 8.0f, 0.55f, SK_DUST, 0xC9AA78);
                           if (w->spd > 12.0f) spawn_spark(w, xb + 7.0, w->ay - 1.0f, -10.0f, -14.0f - rng_f(w) * 8.0f, 0.4f, SK_DUST, 0xB89868); break;
            case V_SEGWAY: w->smoke_t = 0.14f; if (w->spd > 14.0f) spawn_spark(w, xb + 6.0, w->ay - 1.0f, -8.0f, -3.0f, 0.35f, SK_DUST, 0xD8D8E0); break;
            case V_EV:     w->smoke_t = 0.12f; if (w->spd > 30.0f) spawn_spark(w, xb - 1.0, w->ay - 4.0f, -12.0f, 0.0f, 0.4f, SK_GLITTER, 0x7FF0FF); break;
            default: w->smoke_t = 0.2f; break;
        }
    }
    if (w->mode == M_WINGS && air && w->smoke_t <= 0.0f) {
        w->smoke_t = 0.18f;
        spawn_spark(w, w->ax + (rng_f(w) - 0.5f) * 26.0f, w->ay - 8.0f, -6.0f, 6.0f, 0.7f, SK_STAR, 0xFFFFFF);
    }
    if (w->mode == M_BALLOON && air && w->smoke_t <= 0.0f) { w->smoke_t = 0.5f; }
}

static void step_archon(AWWorld *w, float dt) {
    if (w->mode == M_WALK) {
        if (w->idle) {
            w->idle_t -= dt;
            if (w->idle_t <= 0.0f) { w->idle = 0; w->next_idle = rng_r(w, 9.0f, 18.0f); }
        } else {
            w->next_idle -= dt;
            if (w->next_idle <= 0.0f && w->walk_len > 6.0f) { w->idle = 1; w->idle_t = rng_r(w, 2.0f, 3.8f); }
        }
        w->spd = approach(w->spd, w->idle ? 0.0f : 30.0f, 4.0f, dt);
        if (w->idle && w->spd < 0.4f) w->spd = 0.0f;
        w->walk_len -= dt;
        if (w->walk_len <= 0.0f && !w->idle) start_mode(w, pick_mode(w));
    } else if (w->mode == M_ROCKET) step_rocket(w, dt);
    else if (w->mode == M_DIG) step_dig(w, dt);
    else if (w->mode == M_SUB) step_sub(w, dt);
    else if (w->mode == M_DIVE) step_dive(w, dt);
    else if (w->mode == M_BOAT) step_boat(w, dt);
    else if (w->mode == M_ROAD) step_road(w, dt);
    else step_fly(w, dt);

    step_ride_fx(w, dt);
    w->anim_t += dt * (w->spd / 30.0f);
    w->ax += (double)w->spd * dt;
    float surf = (float)(w->gy - ground_h(w, (int)floor(w->ax)));
    { int dk = pier_deck(w, w->ax); if (dk && surf > (float)(w->gy - dk)) surf = (float)(w->gy - dk); }   /* walking out along a pier */
    if ((w->mode == M_SUB || w->mode == M_BOAT || w->mode == M_DIVE) && w->stage >= 1) surf = (float)w->gy;   /* the water level */
    if (w->mode == M_WALK || w->mode == M_ROAD) w->surf_s = surf; else w->surf_s = approach(w->surf_s, surf, 9.0f, dt);
    w->ay = w->surf_s - w->alt;
    if (w->mode == M_DIG && w->alt < -1.0f) dig_record(w, w->ay - 8.0f);

    w->next_blink -= dt;
    if (w->next_blink <= 0.0f) { w->blink_t = 0.16f; w->next_blink = rng_r(w, 2.0f, 5.5f); }
    if (w->blink_t > 0.0f) w->blink_t -= dt;
}


/* ------------------------------------------------------------------ */
/* surprise guests                                                     */
/* ------------------------------------------------------------------ */
static void blit_alpha(AWWorld *w, const Sp *s, int x, int y, int flip, int a256) {
    int sw = sp_w(s);
    for (int r = 0; r < s->h; r++) {
        int len = (int)strlen(s->r[r]);
        for (int c = 0; c < len; c++) {
            char ch = s->r[r][c];
            if (ch == '.' || ch == ' ') continue;
            BLEND(w, flip ? x + (sw - 1 - c) : x + c, y + r, sp_col(ch, 0), a256);
        }
    }
}

static int is_ground_guest(int t) { return (t >= G_FOX && t <= G_BLUE) || (t >= G_CORGI && t <= G_TERRIER); }
static int is_wisp(int t) { return t >= G_WISP_F && t <= G_WISP_A; }
static Col wisp_col(int t) { return t == G_WISP_F ? 0xFFA030 : (t == G_WISP_W ? 0x4FA6F5 : (t == G_WISP_E ? 0x6CCB52 : 0xE6F6FF)); }

static int guest_count(const AWWorld *w) { int n = 0; for (int i = 0; i < MAXGUEST; i++) if (w->guests[i].type) n++; return n; }

static void spawn_guest(AWWorld *w, int type) {
    Guest *g = NULL;
    for (int i = 0; i < MAXGUEST; i++) if (!w->guests[i].type) { g = &w->guests[i]; break; }
    if (!g) return;
    memset(g, 0, sizeof *g);
    g->type = type; g->h = rng_u32(w);
    if (is_deep_guest(type)) { spawn_guest_deep(w, g, type); return; }
    int camI = (int)floor(w->cam);
    float skyy = (float)(w->gy) * rng_r(w, 0.14f, 0.52f) - (float)w->oy;
    if (w->oy > 40) skyy = (float)w->vh * rng_r(w, 0.12f, 0.75f) - (float)w->oy;
    g->dir = rng_f(w) < 0.5f ? 1 : -1;
    if (is_ground_guest(type)) {
        g->x = (double)camI - 30.0; g->dir = 1; g->life = rng_r(w, 20.0f, 34.0f); g->a = rng_r(w, 1.5f, 4.0f);
    } else if (type == G_PERSON) {
        g->x = (double)(camI + w->vw) + 24.0; g->b = rng_r(w, 9.0f, 15.0f); g->life = 90.0f;     /* strolls in from the right, at their own pace */
        if (ground_h(w, (int)floor(g->x)) < 0) g->type = G_NONE;
    } else if (is_wisp(type)) {
        g->a = (float)w->vw * 0.6f; g->b = -60.0f; g->life = rng_r(w, 16.0f, 28.0f);
        g->c = rng_f(w) < 0.5f ? -1.0f : 1.0f;
    } else {
        g->x = g->dir > 0 ? (double)camI - 60.0 : (double)(camI + w->vw) + 60.0;
        g->y = skyy;
        float sp = 20.0f;
        switch (type) {
            case G_GHOST:  sp = rng_r(w, 14.0f, 22.0f); break;
            case G_BIRDS:  sp = rng_r(w, 36.0f, 50.0f); g->x += g->dir > 0 ? -20.0 : 20.0; break;
            case G_WIZARD: sp = rng_r(w, 55.0f, 72.0f); break;
            case G_DRAGON: sp = rng_r(w, 24.0f, 32.0f); break;
            case G_UFO:    sp = rng_r(w, 26.0f, 42.0f); break;
            default: break;
        }
        g->vx = sp * (float)g->dir;
        g->life = 60.0f;
    }
}

static int pick_guest(AWWorld *w) {
    float r = rng_f(w);
    if (w->mode == M_DIG) {          /* friends who live underground */
        if (w->stage != 2 || w->act_len - w->stage_t < 3.0f) return G_NONE;
        return G_HEDGE + (int)(rng_f(w) * 4.0f) % 4;
    }
    if (w->mode == M_SUB) {          /* friends who live underwater */
        if (w->stage < 2 || w->stage > 3) return G_NONE;
        if (r < 0.30f) return G_FISH;
        if (r < 0.56f) return G_JELLY;
        if (r < 0.68f) return G_TURTLE;
        if (r < 0.78f) return G_CRAB;
        if (r < 0.90f) return G_OCTO;
        return G_WHALE;
    }
    if (w->mode == M_DIVE) {         /* friends of the reef and of the deep */
        if (w->stage < 2 || w->stage > 3) return G_NONE;
        if (!w->dive_kind) return r < 0.50f ? G_FISH : (r < 0.76f ? G_TURTLE : (r < 0.90f ? G_CRAB : G_OCTO));
        if (r < 0.28f) return G_FISH;
        if (r < 0.46f) return G_JELLY;
        if (r < 0.60f) return G_TURTLE;
        if (r < 0.70f) return G_CRAB;
        if (r < 0.84f) return G_OCTO;
        return G_WHALE;
    }
    if (w->mode == M_BOAT) {
        if (w->stage != 2) return G_NONE;
        return r < 0.30f ? G_DOLPHIN : (r < 0.76f ? G_LEAPER : G_BIRDS);
    }
    if (w->mode == M_ROCKET) {
        if (w->stage == 3 && w->stage_t > 2.0f && w->act_len - w->stage_t > 5.0f) return G_UFO;
        return G_NONE;
    }
    if (w->mode == M_WALK && w->walk_len > 9.0f && !w->idle) {
        if (r < 0.56f) {   /* a friend to walk with: plenty of cats and puppies, and now and then the little white terrier */
            static const float PW[9] = { 1.0f, 0.8f, 0.8f, 1.0f, 1.4f, 1.4f, 1.4f, 3.0f, 1.2f };
            static const int PT[9] = { G_FOX, G_SLIME, G_ROBOT, G_BLUE, G_CORGI, G_DALM, G_HUSKY, G_CAT, G_TERRIER };
            float tot = 0.0f; for (int i = 0; i < 9; i++) tot += PW[i];
            float q = rng_f(w) * tot;
            for (int i = 0; i < 9; i++) { if (q < PW[i]) return PT[i]; q -= PW[i]; }
            return G_CAT;
        }
        if (r < 0.64f) return G_PERSON;
        if (r < 0.78f) return G_WISP_F + (int)(rng_f(w) * 4.0f) % 4;
    } else if (r < 0.32f) return G_WISP_F + (int)(rng_f(w) * 4.0f) % 4;
    return G_GHOST + (int)(rng_f(w) * 5.0f) % 5;
}

static void step_guests(AWWorld *w, float dt) {
    int camI = (int)floor(w->cam);
    w->next_guest -= dt;
    if (w->next_guest <= 0.0f) {
        if (guest_count(w) < 2) {
            int t = pick_guest(w);
            if (t != G_NONE) { spawn_guest(w, t); w->next_guest = (w->mode == M_DIG || w->mode == M_SUB || w->mode == M_BOAT || w->mode == M_DIVE) ? rng_r(w, 3.0f, 5.5f) : rng_r(w, 11.0f, 24.0f); }
            else w->next_guest = 2.5f;
        } else w->next_guest = 3.0f;
    }
    for (int i = 0; i < MAXGUEST; i++) {
        Guest *g = &w->guests[i];
        if (!g->type) continue;
        if (is_deep_guest(g->type)) { step_guest_deep(w, g, dt); continue; }
        g->t += dt;
        int sx = (int)floor(g->x) - camI;
        if (is_ground_guest(g->type)) {
            double rel = g->x - w->ax;
            double off = -19.0 - (double)(g->h & 3) - 13.0 * (double)(i & 3);   /* each follower keeps to its own spot */
            if (g->state == 0) {
                g->vx = w->spd + clampf((float)(off - rel) * 1.6f, -20.0f, 42.0f);
                if (fabs(off - rel) < 3.0 && w->mode == M_WALK) { g->state = 1; hearts(w, g->x, w->ay - 4.0f, 4); }
                if (g->t > 14.0f) g->state = 3;
            } else if (g->state == 1) {
                g->vx = w->spd + (float)((off + sin(g->t * 0.7) * 5.0 - rel) * 2.0);
                g->life -= dt;
                if (w->mode != M_WALK) g->state = 2;
                else if (g->life <= 0.0f) g->state = 3;
            } else if (g->state == 2) {
                g->vx = 0.0f;
            } else g->vx = w->spd + 52.0f;
            g->x += g->vx * dt;
            g->a -= dt;
            if (g->a <= 0.0f && g->state == 1) { g->b = 0.45f; g->a = rng_r(w, 2.0f, 6.0f); }
            if (g->b > 0.0f) g->b -= dt;
            if (g->state >= 2 && (sx < -50 || sx > w->vw + 60)) g->type = G_NONE;
        } else if (g->type == G_PERSON) {
            g->vx = (float)g->dir * g->b;
            g->x += (double)g->vx * dt;
            if (ground_h(w, (int)floor(g->x)) < 0 || (w->lk_on && g->x > w->lk_x0 - 8.0 && g->x < w->lk_x1 + 8.0)) g->type = G_NONE;   /* never wades into a lake */
            if (g->t > 6.0f && (sx < -40 || sx > w->vw + 40)) g->type = G_NONE;
            if (g->t > g->life) g->type = G_NONE;
        } else if (is_wisp(g->type)) {
            float tx = g->c * (26.0f + 6.0f * sinf(g->t * 0.8f)), ty = -22.0f + 5.0f * sinf(g->t * 1.3f);
            if (g->state == 0) {
                g->a += (tx - g->a) * 1.5f * dt; g->b += (ty - g->b) * 1.5f * dt;
                if (fabsf(g->a - tx) < 5.0f) { g->state = 1; hearts(w, w->ax + g->a, w->ay + g->b, 3); }
            } else if (g->state == 1) {
                g->a += (tx - g->a) * 3.0f * dt; g->b += (ty - g->b) * 3.0f * dt;
                g->life -= dt;
                if (g->life <= 0.0f) g->state = 2;
            } else {
                g->a += 40.0f * dt + (g->a - tx) * 0.2f * dt; g->b -= 28.0f * dt;
                if (g->a > (float)w->vw || g->b < -(float)w->vh * 1.5f) g->type = G_NONE;
            }
            g->x = w->ax + g->a; g->y = w->ay - 8.0f + g->b;
            /* elemental trail */
            g->vy -= dt;
            if (g->vy <= 0.0f && g->state < 2) {
                g->vy = 0.09f;
                Col c = wisp_col(g->type);
                int sxw = (int)floor(g->x) - camI;
                (void)sxw;
                if (g->type == G_WISP_F) spawn_spark(w, g->x + (rng_f(w) - 0.5f) * 4.0f, g->y + 4.0f, (rng_f(w) - 0.5f) * 6.0f, -10.0f, 0.5f, SK_FLAME, c);
                else if (g->type == G_WISP_W) spawn_spark(w, g->x + (rng_f(w) - 0.5f) * 4.0f, g->y + 5.0f, 0.0f, 10.0f, 0.7f, SK_DROP, 0xA8D8FF);
                else if (g->type == G_WISP_E) spawn_spark(w, g->x + (rng_f(w) - 0.5f) * 6.0f, g->y + 4.0f, (rng_f(w) - 0.5f) * 8.0f, 8.0f, 0.8f, SK_GLITTER, 0xB4F08E);
                else spawn_spark(w, g->x - 3.0f + (rng_f(w) - 0.5f) * 8.0f, g->y + 2.0f, -8.0f, 0.0f, 0.7f, SK_GLITTER, 0xFFFFFF);
            }
        } else {
            g->x += (double)(w->spd + g->vx) * dt;
            float wy = g->y;
            switch (g->type) {
                case G_GHOST:  wy += sinf(g->t * 1.6f) * 7.0f; break;
                case G_WIZARD: wy += sinf(g->t * 1.2f) * 12.0f - g->t * 1.5f * 0; break;
                case G_DRAGON: wy += sinf(g->t * 0.9f) * 9.0f; break;
                case G_UFO:    wy += sinf(g->t * 1.1f) * 8.0f + sinf(g->t * 2.9f) * 2.0f; break;
                default: break;
            }
            g->vy = wy;   /* drawn height */
            if (g->type == G_WIZARD && sx > -10 && sx < w->vw + 10) {
                g->b -= dt;
                if (g->b <= 0.0f) {
                    g->b = 0.05f;
                    static const Col cols[3] = { 0xFFD23F, 0xD2B8FF, 0xFFFFFF };
                    spawn_spark(w, g->x - (double)g->dir * 10.0, wy + 10.0f, -g->dir * 6.0f, 6.0f + rng_f(w) * 6.0f, 0.8f, SK_GLITTER, cols[(int)(rng_f(w) * 3.0f) % 3]);
                }
            }
            if (g->type == G_DRAGON && sx > w->vw * 35 / 100 && sx < w->vw * 62 / 100) {
                g->b -= dt;
                if (g->b <= 0.0f) {
                    g->b = 0.03f;
                    spawn_spark(w, g->x + (double)(g->dir > 0 ? 33 : -1), wy + 7.0f, g->dir * (40.0f + rng_f(w) * 20.0f), (rng_f(w) - 0.5f) * 14.0f, 0.55f, SK_FLAME, 0xFFA030);
                }
            }
            if (g->t > 45.0f || (g->dir > 0 && sx > w->vw + 80) || (g->dir < 0 && sx < -80 - 40)) g->type = G_NONE;
        }
    }
}

static void draw_bird(AWWorld *w, int x, int y, int fr, int dir) {
    static const char *const A[3] = { "X...X", ".X.X.", "..X.." };
    static const char *const B[3] = { "..X..", ".X.X.", "X...X" };
    const char *const *s = fr ? B : A;
    (void)dir;
    /* pick light or dark ink from whatever sky is behind the flock */
    int sy = y + 1 + w->oy, sxp = x + 2;
    int lum = 128;
    if ((unsigned)sxp < (unsigned)w->vw && (unsigned)sy < (unsigned)w->vh) {
        Col d = w->px[sy * w->vw + sxp];
        lum = (int)(((d >> 16) & 255) * 3 + ((d >> 8) & 255) * 6 + (d & 255)) / 10;
    }
    Col ink = lum < 110 ? 0xE6E2F4 : 0x2A2040;
    for (int r = 0; r < 3; r++) for (int c = 0; c < 5; c++) if (s[r][c] == 'X') PX(w, x + c, y + r, ink);
}

static void draw_guests(AWWorld *w) {
    int camI = (int)floor(w->cam);
    for (int i = 0; i < MAXGUEST; i++) {
        Guest *g = &w->guests[i];
        if (!g->type) continue;
        if (is_deep_guest(g->type)) { if (!is_cave_guest(g->type)) draw_guest_deep(w, g, camI); continue; }
        int sx = (int)floor(g->x) - camI;
        float t = g->t;
        if (is_ground_guest(g->type)) {
            int wxp = (int)floor(g->x);
            int base = w->gy - ground_h(w, wxp);
            int hop = g->b > 0.0f ? (int)(5.0f * sinf(3.14159f * (1.0f - g->b / 0.45f)) + 0.5f) : 0;
            int moving = fabsf(g->vx) > 5.0f;
            int fr = moving ? (((int)(t * 7.0f)) & 1) : 0;
            const Sp *sp = NULL; int tint = 0;
            switch (g->type) {
                case G_FOX:   sp = fr ? &FOX_B : &FOX_A; break;
                case G_SLIME: sp = (moving && ((int)(t * 4.0f) & 1)) ? &SLIME_B : &SLIME_A; break;
                case G_ROBOT: sp = fr ? &ROBOT_B : &ROBOT_A; break;
                case G_CORGI: sp = fr ? &CORGI_B : &CORGI_A; break;
                case G_DALM:  sp = fr ? &DALM_B : &DALM_A; break;
                case G_HUSKY: sp = fr ? &HUSKY_B : &HUSKY_A; break;
                case G_CAT:   sp = fr ? &CAT_B : &CAT_A; tint = 2 + (int)(g->h % 5u); break;
                case G_TERRIER: sp = fr ? &TERR_B : &TERR_A; break;
                default: break;
            }
            if (g->type == G_BLUE) {
                int legs = moving ? 1 + (((int)(t * 5.0f)) & 1) : 0;
                draw_arch(w, sx - 6, base - 12 - hop, legs, ((int)(t * 0.9f) % 4) == 0 && fmodf(t, 1.1f) < 0.15f, 1, 0);
            } else if (sp) {
                int sw = sp_w(sp);
                blit_outlined(w, sp, sx - sw / 2, base - sp->h - hop, 0, tint, 70);
                if (g->type == G_TERRIER) draw_sammy_sign(w, sx, base - sp->h - hop, t);
            }
        } else if (g->type == G_PERSON) {
            int gh = ground_h(w, (int)floor(g->x));
            if (gh < 0) continue;
            paint_person(w, sx, w->gy - gh, g->h, g->dir, t, 1);
        } else if (is_wisp(g->type)) {
            int x = sx, y = (int)floorf(g->y);
            Col c = wisp_col(g->type);
            for (int dy = -8; dy <= 8; dy++) for (int dx = -8; dx <= 8; dx++) {
                int d2 = dx * dx + dy * dy;
                if (d2 < 64 && d2 > 16 && ((dx + dy) & 1) == 0) BLEND(w, x + dx, y + 6 + dy, c, 34);
            }
            const Sp *sp = g->type == G_WISP_F ? &WISP_F : (g->type == G_WISP_W ? &WISP_W : (g->type == G_WISP_E ? &WISP_E : &WISP_A));
            int bob = (int)floorf(sinf(t * 3.0f) * 1.0f + 0.5f);
            blit_outlined(w, sp, x - 4, y + bob, 0, 0, 60);
        } else {
            int y = (int)floorf(g->vy);
            int flip = g->dir < 0;
            switch (g->type) {
                case G_GHOST: blit_alpha(w, &GHOST, sx - 5, y, flip, 205); break;
                case G_BIRDS:
                    for (int b = 0; b < 6; b++) {
                        int row = (b + 1) / 2, side = (b & 1) ? 1 : -1;
                        int bx = sx - g->dir * row * 7, by = y + side * row * 4 + (int)floorf(sinf(t * 2.0f + (float)b) + 0.5f);
                        draw_bird(w, bx, by, ((int)(t * 7.0f + (float)b)) & 1, g->dir);
                    }
                    break;
                case G_WIZARD: blit_outlined(w, &WIZARD, sx - 12, y, flip, 0, 70); break;
                case G_DRAGON: blit_outlined(w, (((int)(t * 4.0f)) & 1) ? &DRAGON_DN : &DRAGON_UP, sx - 16, y - ((((int)(t * 4.0f)) & 1) ? 0 : 0), flip, 0, 70); break;
                case G_UFO: {
                    float ph = fmodf(t, 7.0f);
                    if (ph > 2.5f && ph < 4.6f && w->oy < 10) {
                        int top = y + 8, bot = w->gy - 2;
                        for (int yy = top; yy < bot; yy++) {
                            float f = (float)(yy - top) / (float)imax(1, bot - top);
                            int hw = 4 + (int)(f * 12.0f);
                            for (int xx = -hw; xx <= hw; xx++) if (((xx + yy) & 1) == 0) BLEND(w, sx + xx, yy, 0xFFF59A, 54);
                        }
                    }
                    blit_outlined(w, &UFO, sx - 11, y, 0, 0, 80);
                    int blinkc = ((int)(t * 5.0f)) % 3;
                    PX(w, sx - 8 + blinkc * 8, y + 4, 0xFFE45E);
                } break;
                default: break;
            }
        }
    }
}


/* ------------------------------------------------------------------ */
/* frame                                                               */
/* ------------------------------------------------------------------ */
#ifdef _WIN32
/* The C runtime's localtime() can ignore the Windows time-zone setting, so ask Windows directly. */
typedef struct { unsigned short y, mo, dow, d, h, mi, s, ms; } AW_SYSTIME;
__declspec(dllimport) void __stdcall GetLocalTime(AW_SYSTIME *);
#endif

static void poll_time(AWWorld *w) {
    if (w->tm_override) return;
#ifdef _WIN32
    {
        AW_SYSTIME st;
        GetLocalTime(&st);
        w->tm_hour = st.h; w->tm_min = st.mi; w->tm_sec = st.s;
        w->tm_wday = st.dow; w->tm_mon = st.mo - 1; w->tm_mday = st.d; w->tm_year = st.y;
        return;
    }
#else
    time_t tt = time(NULL);
    struct tm *tm = localtime(&tt);
    if (!tm) return;
    w->tm_hour = tm->tm_hour; w->tm_min = tm->tm_min; w->tm_sec = tm->tm_sec;
    w->tm_wday = tm->tm_wday; w->tm_mon = tm->tm_mon; w->tm_mday = tm->tm_mday; w->tm_year = tm->tm_year + 1900;
#endif
}

void aw_step(AWWorld *w, double dt) {
    if (dt > 0.1) dt = 0.1;
    if (dt < 0.0) dt = 0.0;
    float fdt = (float)dt;
    w->t += dt;
    w->tm_poll -= dt;
    if (w->tm_poll <= 0.0) { poll_time(w); w->tm_poll = 0.25; }
    w->hol = w->hol_force ? w->hol_force - 1 : hol_detect(w);
    step_archon(w, fdt);
    step_guests(w, fdt);
    w->cam = floor(w->ax) - (double)w->cam_off;
    {   /* camera: follows Archon up (rocket) and down (digger, submarine); going down it lags a little */
        float vh = (float)w->vh, d = w->ay - (float)w->gy - 4.0f;
        float target = d > 0.0f ? -(d + fminf(d, 0.22f * vh)) : clampf(0.46f * vh - w->ay, 0.0f, 100000.0f);
        if (target < 0.0f || w->oy_f < 0.0f) {
            w->oy_f += (target - w->oy_f) * fminf(1.0f, 1.5f * fdt);
            if (target >= 0.0f && w->oy_f > -0.5f) w->oy_f = target;
        } else w->oy_f = target;
        w->oy = (int)floorf(w->oy_f);
    }
    w->dark = space_d(w, (float)w->gy - ((float)w->vh * 0.5f - w->oy_f));
    update_palette(w);
    step_fx(w, fdt);
}

void aw_render(AWWorld *w) {
    float sc = (float)w->vh / 180.0f;
    draw_sky(w);
    draw_stars(w);
    draw_space_bodies(w);
    draw_celestial(w);
    if (w->dark < 0.92f) {
        draw_clouds(w, 0, 0.03, 1.2, 150, 0.06f, 0.26f, 18, 36);
        draw_clouds(w, 1, 0.06, 2.0, 190, 0.20f, 0.42f, 28, 54);
    }
    if (w->hol && w->dark < 0.9f) hol_sky(w);
    draw_bg_layer(w, 0.10, 0, (int)(26 * sc), (int)(72 * sc), w->cur.far_c, 1);
    if (w->dark < 0.92f) draw_clouds(w, 2, 0.14, 3.0, 230, 0.38f, 0.58f, 34, 70);
    draw_bg_layer(w, 0.26, 1, (int)(16 * sc), (int)(46 * sc), w->cur.mid_c, 0);
    draw_bg_layer(w, 0.46, 2, (int)(8 * sc), (int)(26 * sc), w->cur.near_c, 0);
    if ((w->hol == H_NEWYEAR || w->hol == H_NYE) && w->dark < 0.9f) hol_ball_tower(w);
    draw_landmarks(w, 0);
    draw_decor_layer(w);
    draw_water(w);
    draw_ground(w);
    draw_road(w);
    draw_trail(w);
    draw_piers(w);
    draw_underground(w);
    draw_seabed(w);
    draw_dive_scene(w);
    draw_tunnels(w);
    draw_dig_light(w);
    draw_flora(w);
    draw_crops(w);
    draw_season_flora(w);
    draw_holiday_ground(w);
    draw_landmarks(w, 1);
    draw_panels(w);
    draw_cave_guests(w);     /* little cave pockets sit behind the underground signs */
    draw_deep_panels(w);
    draw_guests(w);
    draw_hero(w);
    draw_fx(w);
    draw_water_front(w);
    if (w->hol && w->dark < 0.9f) hol_front(w);
    /* biome and seasonal weather particles are screen-space; they fade out as the sky goes dark or we go underground */
    int soy = w->oy; w->oy = 0;
    float vis = (1.0f - w->dark) * (1.0f - clampf(-w->oy_f / (0.30f * (float)w->vh), 0.0f, 1.0f));
    if (vis > 0.02f) {
        float wa = (1.0f - w->pt) * vis, wb = w->pt * vis;
        int ka = PALS[w->pa].ptype, kb = PALS[w->pb].ptype;
        if (ka == kb) draw_ambient(w, ka, vis);
        else { draw_ambient(w, ka, wa); draw_ambient(w, kb, wb); }
        static const int SEAP[4] = { PT_PETALS, PT_NONE, PT_LEAVES, PT_SNOW };
        for (int sidx = 0; sidx < 4; sidx++)
            if (SEAP[sidx] != PT_NONE && w->sea_k[sidx] > 0.05f) draw_ambient(w, SEAP[sidx], vis * w->sea_k[sidx] * 0.85f);
    }
    w->oy = soy;
}

/* ------------------------------------------------------------------ */
/* lifecycle                                                           */
/* ------------------------------------------------------------------ */
int aw_pick_scale(int pixel_w, int pixel_h) {
    (void)pixel_w;
    int s = (int)floor((double)pixel_h / (double)TARGET_ROWS + 0.5);
    return s < 1 ? 1 : s;
}

static void layout(AWWorld *w) {
    w->gy = (int)(w->vh * 0.76f);
    w->cam_off = (int)(w->vw * 0.30f);
}

AWWorld *aw_create(int vw, int vh, uint32_t seed) {
    AWWorld *w = (AWWorld *)calloc(1, sizeof(AWWorld));
    if (!w) return NULL;
    if (vw < 64) vw = 64;
    if (vh < 64) vh = 64;
    w->vw = vw; w->vh = vh;
    w->px = (uint32_t *)calloc((size_t)vw * (size_t)vh, sizeof(uint32_t));
    if (!w->px) { free(w); return NULL; }
    w->seed = hash32(seed ^ 0xC0FFEEU) | 1u;
    w->rng = hash32(seed * 2654435761u + 77u) | 1u;
    layout(w);
    w->biome_off = rfn(w->seed, 1) * SEG_LEN * NPAL;
    w->ax = 40000.0 + (double)(hash32(w->seed + 5) % 400000u);
    w->mode = M_WALK; w->last_mode = -1; w->last_mode2 = -1; w->last_boat = -1; w->last_veh = -1;
    w->walk_len = rng_r(w, 7.0f, 11.0f);
    w->next_idle = rng_r(w, 5.0f, 10.0f);
    w->next_blink = 2.0f; w->spd = 30.0f;
    w->surf_s = (float)(w->gy - ground_h(w, (int)floor(w->ax)));
    w->ay = w->surf_s;
    w->next_guest = rng_r(w, 5.0f, 9.0f);
    w->clock24 = 0; w->fahrenheit = 1;
    w->cam = floor(w->ax) - (double)w->cam_off;
    for (int i = 0; i < TRN; i++) w->tr_x[i] = -0x7FFFFFFF;
    w->sea_off = (double)rfn(w->seed, 9) * SEA_LEN * 16.0;
    w->sea_k0 = (int)floor((w->ax + w->sea_off) / SEA_LEN);
    w->sea_f0 = (int)(hash2(w->seed, 0x5EA5U) & 3U);
    w->sea_ck = w->sea_k0; w->sea_cf = w->sea_f0;
    poll_time(w);
    update_palette(w);
    return w;
}

void aw_destroy(AWWorld *w) {
    if (!w) return;
    free(w->px);
    free(w);
}

void aw_resize(AWWorld *w, int vw, int vh) {
    if (vw < 64) vw = 64;
    if (vh < 64) vh = 64;
    if (vw == w->vw && vh == w->vh) return;
    uint32_t *np = (uint32_t *)calloc((size_t)vw * (size_t)vh, sizeof(uint32_t));
    if (!np) return;
    free(w->px);
    w->px = np; w->vw = vw; w->vh = vh;
    layout(w);
    w->surf_s = (float)(w->gy - ground_h(w, (int)floor(w->ax)));
    w->ay = w->surf_s - w->alt;
    w->cam = floor(w->ax) - (double)w->cam_off;
    memset(w->guests, 0, sizeof w->guests);
}

const uint32_t *aw_pixels(const AWWorld *w) { return w->px; }
int aw_width(const AWWorld *w)  { return w->vw; }
int aw_height(const AWWorld *w) { return w->vh; }

void aw_set_prefs(AWWorld *w, int clock24, int fahrenheit) {
    if (!w) return;
    w->clock24 = clock24 != 0; w->fahrenheit = fahrenheit != 0;
}
void aw_set_weather(AWWorld *w, int valid, float temp_c, int wmo_code, int is_day) {
    if (!w) return;
    w->w_valid = valid != 0; w->w_temp_c = temp_c; w->w_code = wmo_code; w->w_isday = is_day != 0;
}

/* ---- test hooks ---- */
void aw_debug_warp(AWWorld *w, double seconds) {
    while (seconds > 0.0) { aw_step(w, 1.0 / 30.0); seconds -= 1.0 / 30.0; }
}
void aw_debug_set_time(AWWorld *w, int hour, int min, int sec, int wday, int mon, int mday) {
    w->tm_override = 1;
    w->tm_hour = hour; w->tm_min = min; w->tm_sec = sec; w->tm_wday = wday; w->tm_mon = mon; w->tm_mday = mday;
}
void aw_debug_landmark(AWWorld *w, int k) { w->lm_force = k < 0 ? 0 : k + 1; }
void aw_debug_set_year(AWWorld *w, int year) { w->tm_year = year; }
void aw_debug_holiday(AWWorld *w, int h) { w->hol_force = h < 0 ? 0 : h + 1; }
void aw_debug_datefmt(AWWorld *w, int f) { w->dfmt_force = f < 0 ? 0 : f + 1; }
int aw_debug_holiday_now(const AWWorld *w) { return w->hol; }
void aw_debug_force_mode(AWWorld *w, int mode) {
    if (mode < 0 || mode >= M_COUNT) return;
    if (mode == M_WALK) { w->mode = M_WALK; w->alt = 0.0f; w->pitch = 0.0f; w->walk_len = 5.0f; return; }
    start_mode(w, mode);
}
void aw_debug_force_guest(AWWorld *w, int type) { if (type > G_NONE && type < G_COUNT) spawn_guest(w, type); }
void aw_debug_season(AWWorld *w, int s) {
    s &= 3;
    double k = floor((w->ax + w->sea_off) / SEA_LEN);
    w->sea_off = (k + 0.30) * SEA_LEN - w->ax;
    w->sea_k0 = (int)k; w->sea_f0 = s; w->sea_ck = (int)k; w->sea_cf = s;
    update_palette(w);
}
int  aw_debug_season_now(const AWWorld *w) { return w->sea_a; }
int  aw_debug_lake(const AWWorld *w) { return w->lk_on; }
int  aw_debug_mode(const AWWorld *w)  { return w->mode; }
int  aw_debug_stage(const AWWorld *w) { return w->stage; }
int  aw_debug_guests(const AWWorld *w) { return guest_count(w); }
float aw_debug_alt(const AWWorld *w) { return w->alt; }
int   aw_debug_ground(const AWWorld *w) { return ground_h(w, (int)floor(w->ax)); }   /* the ground under Archon: negative = he is over water */
float aw_debug_holo(const AWWorld *w) { return holo_presence(w); }
void  aw_debug_veh(AWWorld *w, int kind) { w->veh_force = (kind >= 0 && kind < V_N) ? kind + 1 : 0; }
int   aw_debug_veh_now(const AWWorld *w) { return w->veh; }
void  aw_debug_carrier(AWWorld *w, int kind, int style) { w->car_force = kind >= 0 ? kind + 1 : 0; w->bal_force = style >= 0 ? style + 1 : 0; }
void  aw_debug_dive(AWWorld *w, int kind) { w->dive_force = (kind == 0 || kind == 1) ? kind + 1 : 0; }
int   aw_debug_dive_now(const AWWorld *w) { return w->dive_kind; }
void  aw_debug_boat(AWWorld *w, int kind) { w->boat_force = (kind >= 0 && kind < B_N) ? kind + 1 : 0; }
int   aw_debug_boat_now(const AWWorld *w) { return w->boat; }
void  aw_debug_bg(AWWorld *w, int style) { w->bg_force = style >= 0 && style < BG_N ? style + 1 : 0; }
