/*
 * Archon's Life - more rides: a different rocket for every trip to space (shapes and colours), and the helicopter.
 * Included by aw_engine.c after aw_art.inc (needs sp_col, blit_rot, holo_face, draw_arch, PX, BLEND, R and the world state).
 */

/* ------------------------------------------------------------------ */
/* palettes: used for the rockets' hulls and for the helicopters      */
/* ------------------------------------------------------------------ */
typedef struct { Col R, r, L, D, W, G, N, n, J, j, fo, fy, ff; } CraftPal;
#define NRKPAL 10
static const CraftPal RKPAL[NRKPAL] = {
    /* 0 red and white (the original rocket) */ { 0xE8442A, 0xB02A1A, 0xFF9A6A, 0xD44A22, 0xFFFFFF, 0xC9D8EE, 0x2F5FA8, 0x1D3A78, 0xFFD23F, 0xE0A02A, 0xFFA030, 0xFFE45E, 0xFF5A2A },
    /* 1 blue         */ { 0x4FA6F5, 0x2F5FC8, 0x9AC4FF, 0x2F7FD8, 0xFFFFFF, 0xC9D8EE, 0x1D3A78, 0x0F2050, 0xFFD23F, 0xE0A02A, 0xFFA030, 0xFFE45E, 0xFF5A2A },
    /* 2 green, cream */ { 0x6CCB52, 0x3F9B3A, 0xB4F08E, 0x4FA05A, 0xFFF3C2, 0xE0CFA0, 0x2E8B6A, 0x1F5A40, 0xFF9EB5, 0xE0508A, 0xFFA030, 0xFFE45E, 0xFF5A2A },
    /* 3 purple, gold */ { 0xA77BF0, 0x7449C4, 0xD2B8FF, 0x8A5AD8, 0xF0E6FF, 0xCDBDF0, 0x5A32A8, 0x3A2078, 0xFFD23F, 0xE0A02A, 0xFF7AD9, 0xFFE0F6, 0xB58CFF },
    /* 4 bee: yellow, black */ { 0xFFD23F, 0xE0A02A, 0xFFF59A, 0xF0B820, 0x3A3A4A, 0x22222E, 0x8FA3C0, 0x4A5C8C, 0xE8442A, 0xB02A1A, 0xFFA030, 0xFFE45E, 0xFF5A2A },
    /* 5 teal, pink   */ { 0x2FC4B2, 0x1B8F85, 0x9FF0E4, 0x22A89A, 0xFFFFFF, 0xCFF4EE, 0xE0508A, 0xA02A66, 0xFF8FB8, 0xE0508A, 0xFFA030, 0xFFE45E, 0xFF5A2A },
    /* 6 silver, orange, blue flame */ { 0xC9D8EE, 0x8FA3C0, 0xFFFFFF, 0xA9B8D0, 0xE8EEF8, 0x9AAAC0, 0xFF7A22, 0xC4501A, 0xFF7A22, 0xC4501A, 0x7FD8FF, 0xFFFFFF, 0x3FB6D8 },
    /* 7 pink, white  */ { 0xFF8FB8, 0xE0508A, 0xFFD0E4, 0xF06AA0, 0xFFFFFF, 0xF0DDE8, 0xA77BF0, 0x7449C4, 0xFFD23F, 0xE0A02A, 0xFFA030, 0xFFE45E, 0xFF5A2A },
    /* 8 stealth, neon */ { 0x3A3A52, 0x22222E, 0x6A6A8A, 0x2E2E44, 0x6A6A88, 0x4A4A66, 0x7FF0FF, 0x3FB6D8, 0x7FF0FF, 0x3FB6D8, 0x3FB6D8, 0xCFFFFF, 0x2F5FC8 },
    /* 9 orange, white */ { 0xFF9A3E, 0xC86A1E, 0xFFC890, 0xE07A28, 0xFFFFFF, 0xE8DCC8, 0x2F5FA8, 0x1D3A78, 0x4FA6F5, 0x2F5FC8, 0xFFA030, 0xFFE45E, 0xFF5A2A },
};
static Col craft_col(char c, const CraftPal *p) {
    switch (c) {
        case 'R': return p->R; case 'r': return p->r; case 'L': return p->L; case 'D': return p->D;
        case 'W': return p->W; case 'G': return p->G; case 'N': return p->N; case 'n': return p->n;
        case 'J': return p->J; case 'j': return p->j;
        case 'o': return p->fo; case 'y': return p->fy; case 'f': return p->ff;
        default: return sp_col(c, 0);
    }
}
/* the same turn-in-45-degree-steps blit as blit_rot, with a palette */
static void blit_rot_pal(AWWorld *w, const Sp *s, int ox, int oy, int cw, int ch, float px, float py, int cx, int cy, int steps, const CraftPal *pal) {
    static const float COS[8] = { 1.0f, 0.70710678f, 0.0f, -0.70710678f, -1.0f, -0.70710678f, 0.0f, 0.70710678f };
    static const float SIN[8] = { 0.0f, 0.70710678f, 1.0f, 0.70710678f, 0.0f, -0.70710678f, -1.0f, -0.70710678f };
    steps &= 7;
    float c = COS[steps], sn = SIN[steps];
    int R_ = (int)ceilf(sqrtf((float)(cw * cw + ch * ch))) / 2 + 2;
    for (int dy = -R_; dy <= R_; dy++) {
        for (int dx = -R_; dx <= R_; dx++) {
            float fx = (float)dx + 0.5f, fy = (float)dy + 0.5f;
            float u = px + fx * c + fy * sn;
            float v = py - fx * sn + fy * c;
            int iu = (int)floorf(u) - ox, iv = (int)floorf(v) - oy;
            if (iv < 0 || iv >= s->h || iu < 0) continue;
            if (iu >= (int)strlen(s->r[iv])) continue;
            char chh = s->r[iv][iu];
            if (chh == '.' || chh == ' ') continue;
            PX(w, cx + dx, cy + dy, craft_col(chh, pal));
        }
    }
}

/* ------------------------------------------------------------------ */
/* rocket shapes (nose up, 16 x 30; the window is in the same place on every one, so Archon always peeks out of it) */
/* ------------------------------------------------------------------ */
SPDEF(RK_DART,
    ".......RD.......",
    ".......RD.......",
    "......LRRD......",
    "......LRRD......",
    ".....RLRRDD.....",
    ".....RLRRDD.....",
    "....RRLRRDRD....",
    "....RRRRRRRD....",
    "...RRRRRRRRRD...",
    "...JJJJJJJJJj...",
    "..WWNNNNNNNNWG..",
    "..WNNssssssNNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNNssssssNNG..",
    "..WWNNNNNNNNWG..",
    "..WWWWWWWWWWWG..",
    "...WWWWWWWWWG...",
    "...WWWWWWWWWG...",
    "....WWWWWWWG....",
    "...rWWWWWWWWr...",
    "..rrWWWWWWWWrr..",
    ".rrrWWWWWWWWrrr.",
    "rrrrWWWWWWWWrrrr",
    "rrrrWWWWWWWWrrrr",
    "rrrrWWWWWWWWrrrr",
    "r...WZZZZZZW...r",
    "....rZZZZZZr....");
SPDEF(RK_PODS,
    "......RRRD......",
    ".....RRRRRD.....",
    ".....RLRRDD.....",
    "....RRLRRDRD....",
    "....RRLRRDRD....",
    "...RRRLRRDRRD...",
    "...RRRRRRRRRD...",
    "...RRRRRRRRRD...",
    "..RRRRRRRRRRRD..",
    "..JJJJJJJJJJJj..",
    "..WWNNNNNNNNWG..",
    "..WNNssssssNNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNNssssssNNG..",
    "..WWNNNNNNNNWG..",
    "..WWWWWWWWWWWG..",
    ".RRWWWWWWWWWWRD.",
    "RRRWWWWWWWWWWRRD",
    "RLRWWWWWWWWWWRDD",
    "RLRWWWWWWWWWWRDD",
    "RLRRWWWWWWWWRRDD",
    "RLRRWWWWWWWWRRDD",
    "RRRrWWWWWWWWrRRD",
    "RrrrWWWWWWWWrrrD",
    "RZZrWZZZZZZWrZZD",
    "RZZ.WZZZZZZW.ZZD",
    ".ZZ..ZZZZZZ..ZZ.");
SPDEF(RK_RETRO,
    ".......RD.......",
    "......RRRD......",
    "......LRRD......",
    ".....RLRRDD.....",
    ".....RLRRDD.....",
    "....JJJJJJJj....",
    "....RLRRRRDD....",
    "...RRLRRRRDRD...",
    "...JJJJJJJJJj...",
    "..RRRLRRRRDRRD..",
    "..RRNNNNNNNNRG..",
    "..RNNssssssNNG..",
    "..RNsbbbbbbsNG..",
    "..RNsbbbbbbsNG..",
    "..RNsbbbbbbsNG..",
    "..RNsbbbbbbsNG..",
    "..RNNssssssNNG..",
    "..RRNNNNNNNNRG..",
    "..RRRRRRRRRRRG..",
    "..RRRRRRRRRRRG..",
    "..JJJJJJJJJJJj..",
    "...RRRRRRRRRG...",
    "..jRRRRRRRRRRj..",
    ".jjjRRRRRRRRjjj.",
    "jjjjRRRRRRRRjjjj",
    "jjjjRRRRRRRRjjjj",
    "jj.jjRRRRRRjj.jj",
    "j...jZZZZZZj...j",
    "....jZZZZZZj....",
    "....jZZZZZZj....");
SPDEF(RK_STUB,
    ".......AA.......",
    "......AAAA......",
    "....AAAAAAAA....",
    "...RRRRRRRRRD...",
    "..RRRLRRRRDRRD..",
    "..RRLRRRRRRDRD..",
    "..RRLRRRRRRDRD..",
    "..RRRRRRRRRRRD..",
    "..JJJJJJJJJJJj..",
    "..WWWWWWWWWWWG..",
    "..WWNNNNNNNNWG..",
    "..WNNssssssNNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNNssssssNNG..",
    "..WWNNNNNNNNWG..",
    "..WWWWWWWWWWWG..",
    "..WWWWWWWWWWWG..",
    "..JJJJJJJJJJJj..",
    "..WWWWWWWWWWWG..",
    "..WWWWWWWWWWWG..",
    "..SWWWWWWWWWWS..",
    ".SSZWWWWWWWWZSS.",
    "SS.ZZZZZZZZZZ.SS",
    "S..ZZZZZZZZZZ..S",
    "S...ZZZZZZZZ...S",
    "SS..ZZZZZZZZ..SS",
    "SSS.ZZZZZZZZ.SSS");
SPDEF(RK_RING,
    ".......AA.......",
    ".......AA.......",
    "......RRRD......",
    ".....RLRRDD.....",
    "....RRLRRDRD....",
    "...RRRLRRDRRD...",
    "...RRRRRRRRRD...",
    "..RRRRRRRRRRRD..",
    "..RRRRRRRRRRRD..",
    "..JJJJJJJJJJJj..",
    "..WWNNNNNNNNWG..",
    "..WNNssssssNNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNNssssssNNG..",
    "..WWNNNNNNNNWG..",
    "..WWWWWWWWWWWG..",
    "..WWWWWWWWWWWG..",
    "JJJJJJJJJJJJJJJj",
    "jjjjjjjjjjjjjjjj",
    "..WWWWWWWWWWWG..",
    "...WWWWWWWWWG...",
    "....WWWWWWWG....",
    "...rWWWWWWWWr...",
    "..rrWWWWWWWWrr..",
    ".rr.WZZZZZZW.rr.",
    ".r..WZZZZZZW..r.",
    "....rZZZZZZr....");

/* where the flames come out: up to three nozzles, as (first column, last column) in the 16-wide canvas; 0 = the classic rocket's own flame sprites */
typedef struct { const Sp *body; int nn; int a[3], b[3]; } RkShape;
#define NRKS 6
static const RkShape RKS[NRKS] = {
    { &ROCKET_BODY, 0, { 0 }, { 0 } },
    { &RK_DART,  1, { 5, 0, 0 },   { 10, 0, 0 } },
    { &RK_PODS,  3, { 5, 1, 13 },  { 10, 2, 14 } },
    { &RK_RETRO, 1, { 5, 0, 0 },   { 10, 0, 0 } },
    { &RK_STUB,  1, { 4, 0, 0 },   { 11, 0, 0 } },
    { &RK_RING,  1, { 5, 0, 0 },   { 10, 0, 0 } },
};
/* each flame is built as a little sprite so it turns with the rocket */
static void rk_flames(AWWorld *w, const RkShape *sh, const CraftPal *pal, int cx, int cy, int steps, int kind) {
    static char buf[12][17];
    static const char *rows[12];
    int ff = ((int)((float)w->t * 18.0f)) % 3;
    int L = kind == 0 ? 3 : (ff == 1 ? 7 : 5);
    for (int n = 0; n < sh->nn; n++) {
        int a = sh->a[n], b = sh->b[n], wd = b - a + 1;
        int Ln = L + (wd >= 8 ? 1 : 0) - (wd <= 2 ? 2 : 0);
        if (Ln < 2) Ln = 2;
        for (int r = 0; r < 12; r++) { memset(buf[r], '.', 16); buf[r][16] = 0; rows[r] = buf[r]; }
        for (int r = 0; r < Ln && r < 12; r++) {
            int wr = wd - (r * wd) / (Ln + 1); if (wr < 1) wr = 1;
            int c0 = a + (wd - wr) / 2;
            for (int c = c0; c < c0 + wr && c < 16; c++) {
                char ch = (r >= Ln - 1) ? 'f' : ((c > c0 && c < c0 + wr - 1) || wr <= 2 ? 'y' : 'o');
                buf[r][c] = ch;
            }
        }
        Sp fs = { Ln, rows };
        blit_rot_pal(w, &fs, 0, 30, 16, 38, 8.0f, 19.0f, cx, cy, steps, pal);
    }
}
static void draw_rocket_craft(AWWorld *w, int cx, int cy, int steps) {
    int si = w->rk_shape % NRKS;
    const RkShape *sh = &RKS[si];
    const CraftPal *pal = &RKPAL[w->rk_pal % NRKPAL];
    blit_rot_pal(w, sh->body, 0, 0, 16, 38, 8.0f, 19.0f, cx, cy, steps, pal);
    int kind = -1;
    if (w->stage == 0) { if (w->stage_t > 1.3f) kind = 0; }
    else if (w->stage >= 1 && w->stage <= 5) kind = 1;
    if (kind < 0) return;
    if (si == 0) {      /* the classic rocket keeps its own flame sprites */
        int ff = ((int)((float)w->t * 18.0f)) % 3;
        const Sp *fl = kind == 0 ? &ROCKET_FL0 : (ff == 1 ? &ROCKET_FL2 : &ROCKET_FL1);
        blit_rot_pal(w, fl, 0, 30, 16, 38, 8.0f, 19.0f, cx, cy, steps, pal);
    } else rk_flames(w, sh, pal, cx, cy, steps, kind);
}

/* ------------------------------------------------------------------ */
/* the helicopter (faces right)                                        */
/* ------------------------------------------------------------------ */
static void heli_ellipse_glass(AWWorld *w, int cxp, int cyp, float rx, float ry, int xmin) {
    for (int dy = (int)-ry - 1; dy <= (int)ry + 1; dy++)
        for (int dx = (int)-rx - 1; dx <= (int)rx + 1; dx++) {
            if (cxp + dx < xmin) continue;
            float u = (float)dx / rx, v = (float)dy / ry, d = u * u + v * v;
            if (d > 1.0f) continue;
            if (d > 0.72f) BLEND(w, cxp + dx, cyp + dy, 0x24344C, 215);                 /* the canopy frame */
            else BLEND(w, cxp + dx, cyp + dy, 0xBFEFFF, 58);                            /* a little glass tint over Archon */
        }
}
static void heli_line(AWWorld *w, int x0, int y0, int x1, int y1, Col c) {
    int dx = x1 > x0 ? x1 - x0 : x0 - x1, sxs = x0 < x1 ? 1 : -1;
    int dy = -(y1 > y0 ? y1 - y0 : y0 - y1), sys = y0 < y1 ? 1 : -1, err = dx + dy;
    for (;;) {
        PX(w, x0, y0, c);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sxs; }
        if (e2 <= dx) { err += dx; y0 += sys; }
    }
}
static void draw_h_heli(AWWorld *w, int sx, int sy, int blink) {
    float t = (float)w->t;
    const CraftPal *P = &RKPAL[w->heli_pal % NRKPAL];
    const FlyP *fp = &FLYP[M_HELI];
    int air = w->alt > 2.0f;
    float wf = 1.0f;                                                                    /* how fast the rotor is turning */
    if (w->phase == PH_IN) wf = clampf(w->phase_t / fp->tin, 0.0f, 1.0f);
    else if (w->phase == PH_OUT && w->touched) wf = 1.0f - 0.85f * clampf(w->grounded_t / fp->tout, 0.0f, 1.0f);
    int by = sy + (air ? (int)floorf(sinf(t * 3.3f) * 1.0f + 0.5f) : 0);
    int tail_up = (air && w->spd > 34.0f) ? 1 : 0;                                      /* nose down a touch at speed */
    const Col DARK = 0x30303C, STRUT = 0x5A5A6A;
    /* tail boom, fin and tail rotor */
    for (int lx = -26; lx <= -13; lx++) {
        int top = lx >= -18 ? -15 : (lx >= -23 ? -14 : -13), bot = -12;
        for (int ly = top; ly <= bot; ly++) PX(w, sx + lx, by + ly - tail_up, ly == bot ? P->D : (ly == top ? P->L : P->R));
        if (lx >= -22) PX(w, sx + lx, by - 13 - tail_up, P->W);                          /* a stripe along the boom */
    }
    for (int ly = -22; ly <= -13; ly++) {                                                /* the fin: swept back, wider at the base */
        int xr = -26 + (ly + 22) / 2, xl = -28 + (ly + 22) / 8;
        for (int lx = xl; lx <= xr; lx++) PX(w, sx + lx, by + ly - tail_up, (lx == xr || ly == -22) ? P->j : P->J);
    }
    R(w, sx - 22, by - 12 - tail_up, 5, 1, P->D);                                         /* little tail plane */
    {   /* tail rotor */
        int trx = sx - 29, try_ = by - 18 - tail_up;
        int ph = ((int)(t * 30.0f)) & 1;
        if (wf > 0.5f) {
            R(w, trx, try_ - 3, 1, 7, 0x23232F);
            if (ph) { PX(w, trx - 1, try_ - 2, 0x23232F); PX(w, trx + 1, try_ + 2, 0x23232F); }
            else    { PX(w, trx + 1, try_ - 2, 0x23232F); PX(w, trx - 1, try_ + 2, 0x23232F); }
            for (int dy = -3; dy <= 3; dy++) BLEND(w, trx + 1, try_ + dy, 0xDDE6F4, 40);
        } else {
            int e = (int)(3.0f * fabsf(cosf(t * 5.0f)) + 0.5f);
            R(w, trx, try_ - e, 1, 2 * e + 1, 0x23232F);
        }
    }
    /* skids and struts */
    R(w, sx - 11, by - 1, 24, 1, DARK); PX(w, sx + 13, by - 2, DARK); PX(w, sx - 12, by - 2, DARK);
    R(w, sx - 6, by - 5, 1, 4, STRUT); R(w, sx + 5, by - 5, 1, 4, STRUT);
    /* the hull behind the canopy */
    for (int ly = -18; ly <= -6; ly++) {
        int x0 = ly == -18 ? -11 : (ly == -17 ? -13 : -14);
        for (int lx = x0; lx <= -5; lx++) {
            Col c = (ly == -6) ? P->r : (ly >= -8 ? P->D : (ly <= -17 ? P->L : P->R));
            if (ly == -11 && lx >= -13) c = P->W;                                        /* a stripe */
            PX(w, sx + lx, by + ly, c);
        }
    }
    R(w, sx - 14, by - 6, 24, 1, P->r); R(w, sx - 13, by - 5, 22, 1, P->D);              /* the belly */
    PX(w, sx - 14, by - 6, P->D);
    /* an engine cowl on the roof, and the mast */
    R(w, sx - 11, by - 20, 8, 2, P->D); R(w, sx - 10, by - 21, 6, 1, P->R);
    R(w, sx - 2, by - 24, 2, 4, DARK);
    /* Archon sits in the front seat */
    draw_arch(w, sx - 4, by - 16, 4, blink, 0, 0);
    heli_ellipse_glass(w, sx + 3, by - 12, 9.0f, 6.5f, sx - 6);
    PX(w, sx + 1, by - 17, 0xFFFFFF); PX(w, sx + 2, by - 17, 0xFFFFFF); PX(w, sx + 0, by - 16, 0xDFF6FF); PX(w, sx + 5, by - 17, 0xDFF6FF);
    /* the rotor */
    {
        int ry = by - 24, hx = sx - 1;
        const int L = 16;
        float wf2 = clampf((wf - 0.30f) / 0.55f, 0.0f, 1.0f);
        float ph = t * (2.0f + 7.0f * wf);
        if (wf2 >= 0.6f) {
            /* up to speed: four blades that visibly turn. The disc is seen from a little above, so every blade's tip swings
             * left/right and up/down; the blades turn a fixed step every frame so the motion reads at 30 fps. */
            float th = (float)(int)(t * 30.0f + 0.5f) * 0.62f;
            float cs = cosf(th), sn = sinf(th);
            int a = (int)(34.0f * wf2);
            for (int dy = -2; dy <= 2; dy++)
                for (int dx = -L - 1; dx <= L + 1; dx++) {
                    float u = (float)dx / ((float)L + 1.5f), v = (float)dy / 2.6f;
                    if (u * u + v * v <= 1.0f) BLEND(w, hx + dx, ry + dy, 0xDDE6F4, a);
                }
            for (int b = 0; b < 4; b++) {
                float c2 = b == 0 ? cs : (b == 1 ? -sn : (b == 2 ? -cs : sn));
                float s2 = b == 0 ? sn : (b == 1 ? cs : (b == 2 ? -sn : -cs));
                heli_line(w, hx, ry, hx + (int)floorf((float)L * c2 + 0.5f), ry + (int)floorf(2.0f * s2 + 0.5f),
                          s2 < 0.0f ? 0x3C3C4E : 0x23232F);                              /* the far blades a touch lighter */
            }
            R(w, hx - 2, ry - 1, 5, 2, DARK); PX(w, hx, ry - 1, 0x8A8AA0);
        } else {
            int ext = (int)((float)L * (fabsf(cosf(ph)) * (1.0f - wf2) + wf2) + 0.5f);
            if (wf2 > 0.2f) {
                int a = (int)(54.0f * wf2);
                for (int dx = -ext; dx <= ext; dx++) { BLEND(w, hx + dx, ry - 1, 0xDDE6F4, a); BLEND(w, hx + dx, ry + 1, 0xDDE6F4, a); }
            }
            R(w, hx - ext, ry, 2 * ext + 1, 1, 0x23232F);
            R(w, hx - 2, ry - 1, 5, 2, DARK); PX(w, hx, ry - 1, 0x8A8AA0);
        }
    }
    /* beacon on the tail fin */
    if (fmodf(t, 1.3f) < 0.14f) { PX(w, sx - 27, by - 23 - tail_up, 0xFF3030); BLEND(w, sx - 28, by - 23 - tail_up, 0xFF3030, 110); BLEND(w, sx - 26, by - 23 - tail_up, 0xFF3030, 110); }
}

/* ------------------------------------------------------------------ */
/* hot-air balloons: traditional gored envelopes. Every trip has its own shape, pattern and colours. */
/* ------------------------------------------------------------------ */
#define NBLS    4
#define NBLPAL  12          /* 0-9 are everyday colours; 10 and 11 are the Easter pastels */
#define NBLPAT  6
typedef struct { float R, ht, fm, mouth, pw, q, e; int gores; } BalShape;
static const BalShape BLS[NBLS] = {
    /* 0 classic teardrop    */ { 15.0f, 34.0f, 0.42f, 0.34f, 1.9f, 1.6f, 2.0f, 7 },
    /* 1 round Montgolfiere  */ { 15.0f, 31.0f, 0.50f, 0.40f, 2.3f, 2.0f, 2.0f, 7 },
    /* 2 tall and slim       */ { 12.0f, 35.0f, 0.40f, 0.32f, 1.6f, 1.3f, 2.0f, 6 },
    /* 3 broad-shouldered    */ { 15.0f, 33.0f, 0.36f, 0.30f, 1.5f, 1.2f, 2.7f, 7 },
};
typedef struct { Col a, b, c, sk; } BalPal;     /* two main colours, a trim colour (crown, bands) and the skirt */
static const BalPal BLPAL[NBLPAL] = {
    { 0xE8442A, 0xFFF3C2, 0xFFC531, 0x2F4A9A },   /* red and cream, blue skirt        */
    { 0x3F8FE8, 0xFFFFFF, 0xFFC531, 0xE8442A },   /* blue and white, red skirt        */
    { 0x8E5BE0, 0xFFD23F, 0xFFFFFF, 0x4A2A8A },   /* purple and gold                  */
    { 0x1FB5A5, 0xFFF3C2, 0xE8442A, 0x14705F },   /* teal and cream                   */
    { 0xFF8A2A, 0x233A7A, 0xFFFFFF, 0x233A7A },   /* orange and navy                  */
    { 0x3FB84A, 0xFFE04A, 0xFFFFFF, 0x1F6A2A },   /* green and yellow                 */
    { 0xFF6FA8, 0xFFFFFF, 0x7A3EC8, 0xC83E7A },   /* pink and white                   */
    { 0xE23A3A, 0xFFFFFF, 0x2B4BA8, 0x2B4BA8 },   /* red, white and blue              */
    { 0xFF5A3C, 0xFF9A2A, 0xFFD84A, 0xB2301C },   /* sunset                           */
    { 0x2B2F4A, 0xFFD23F, 0xE8442A, 0xE8442A },   /* midnight and gold                */
    { 0xFFB3D1, 0xB8E6FF, 0xFFF3A0, 0xC9A8F0 },   /* Easter: pink, sky, butter, lilac */
    { 0xB8F0C8, 0xFFF3A0, 0xFFB3D1, 0xB8E6FF },   /* Easter: mint, butter, pink, sky  */
};
static const Col BLRAIN[7] = { 0xE8442A, 0xFF8A2A, 0xFFD23F, 0x4FC24A, 0x3F8FE8, 0x7A4AD8, 0xFF6FA8 };

/* half-width of the envelope at f (0 at the crown, 1 at the mouth): a full dome that narrows, round-shouldered, to the neck */
static float balloon_hw(const BalShape *S, float f) {
    if (f < S->fm) {
        float v = (S->fm - f) / S->fm;
        return S->R * powf(fmaxf(0.0f, 1.0f - powf(v, S->e)), 1.0f / S->e);
    }
    float v = (f - S->fm) / (1.0f - S->fm);
    return S->R * (S->mouth + (1.0f - S->mouth) * powf(fmaxf(0.0f, 1.0f - powf(v, S->pw)), 1.0f / S->q));
}

/* the envelope: the coloured gores run crown to mouth and bend round the curve (so they bunch at the edges), with a crown cap,
   a plain skirt, shaded seams and a darker outline. Returns the half-width of the mouth, where the lines are tied. */
static int balloon_env(AWWorld *w, int cx, int top, int shp, int pal, int pat) {
    const BalShape *S = &BLS[shp % NBLS];
    const BalPal *P = &BLPAL[pal % NBLPAL];
    int ht = (int)S->ht, G = S->gores;
    int skh = imax(3, ht * 11 / 100), crh = imax(2, ht / 12);
    int ihwA[48];
    for (int dy = 0; dy < ht; dy++) ihwA[dy] = (int)(balloon_hw(S, ((float)dy + 0.5f) / (float)ht) + 0.5f);
    for (int dy = 0; dy < ht; dy++) {
        float f = ((float)dy + 0.5f) / (float)ht;
        int ihw = ihwA[dy];
        int prevg = -1;
        for (int dx = -ihw; dx <= ihw; dx++) {
            float sn = clampf((float)dx / ((float)ihw + 0.5f), -1.0f, 1.0f);
            float th = asinf(sn), cs = sqrtf(1.0f - sn * sn);
            int gi = imax(0, imin(G - 1, (int)((th + 1.5708f) / 3.14159f * (float)G)));
            float fe = f - 0.07f * (1.0f - cs);                           /* bands droop towards the edges, seen from below */
            Col c;
            if (dy >= ht - skh) c = P->sk;
            else if (dy < crh) c = pat == 5 ? 0xFFFFFF : P->c;
            else switch (pat) {
                case 0:  c = (gi & 1) ? P->b : P->a; break;                                         /* two-tone gores */
                case 1:  c = (gi % 3 == 0) ? P->a : ((gi % 3 == 1) ? P->b : P->c); break;          /* three-tone gores */
                case 2:  c = (((int)(fe * 6.0f)) & 1) ? P->b : P->a; break;                         /* horizontal bands */
                case 3:  c = (fe > 0.27f && fe < 0.40f) ? P->c : ((gi & 1) ? P->b : P->a); break;   /* gores with a belt */
                case 4:  c = ((gi + (int)(fe * 7.0f)) & 1) ? P->b : P->a; break;                    /* harlequin */
                default: c = BLRAIN[gi % 7]; break;                                                 /* rainbow gores */
            }
            float lit = 0.80f + 0.28f * cosf(th + 0.55f);                  /* light from the upper left */
            lit = floorf(lit * 6.0f + 0.5f) / 6.0f;
            Col sh = lit < 1.0f ? mulc(c, lit) : c;
            if (th > -1.05f && th < -0.55f) sh = lerpc(sh, 0xFFFFFF, 0.20f);
            if (prevg >= 0 && gi != prevg && dy >= crh) sh = mulc(sh, 0.86f);   /* the seams between gores */
            prevg = gi;
            int edge = dx == -ihw || dx == ihw || dy == 0 || dy == ht - 1 || (dy > 0 && (dx < -ihwA[dy - 1] || dx > ihwA[dy - 1]));
            if (edge) sh = mulc(sh, 0.60f);
            else if (dy == ht - skh) sh = mulc(sh, 0.78f);                  /* where the skirt begins */
            PX(w, cx + dx, top + dy, sh);
        }
    }
    return ihwA[ht - 1];
}

static void draw_h_balloon(AWWorld *w, int sx, int sy, int blink) {
    float t = (float)w->t;
    int air = w->alt > 2.0f;
    int sway = air ? (int)floorf(sinf(t * 0.9f) * 1.0f + 0.5f) : 0;
    const BalShape *S = &BLS[w->bl_shape % NBLS];
    int ht = (int)S->ht;
    int basketTop = sy - 7;
    int envBottom = basketTop - 10;
    int envTop = envBottom - ht;
    int cx = sx + sway;
    int mhw = balloon_env(w, cx, envTop, w->bl_shape, w->bl_pal, w->bl_pat);
    rope_line(w, cx - mhw, envBottom, sx - 7 + sway, basketTop - 1, 0x4A3A2A);       /* the lines from the skirt to the basket */
    rope_line(w, cx + mhw, envBottom, sx + 7 + sway, basketTop - 1, 0x4A3A2A);
    if (air || w->phase == PH_IN) {   /* burner flame */
        int ff = ((int)(t * 12.0f)) & 1;
        R(w, cx - 1, envBottom + 1, 3, 3 + ff, 0xFFA030); R(w, cx, envBottom + 1, 1, 2 + ff, 0xFFE45E);
    }
    draw_arch(w, sx - 6 + sway, basketTop - 8, 4, blink, 0, 0);
    R(w, sx - 7 + sway, basketTop, 14, 7, 0x8A5A2B);
    for (int i = 0; i < 7; i += 2) R(w, sx - 7 + sway, basketTop + i, 14, 1, 0xC48A45);
    R(w, sx - 8 + sway, basketTop - 1, 16, 2, 0xB27A43);
}
