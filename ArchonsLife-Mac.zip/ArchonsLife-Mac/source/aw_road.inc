/*
 * Archon's Life v4 - road trips. A level road is laid just ahead of Archon; he hops into a vehicle (bicycle,
 * motorbike, roadster, electric car, pickup, forklift, semi truck or school bus) and drives along it.
 * Everything is drawn with rectangles; heights are measured up from the road surface. Included by aw_engine.c.
 */

enum { V_BIKE, V_MOTO, V_SEDAN, V_EV, V_PICKUP, V_FORK, V_SEMI, V_BUS, V_SKATE, V_SEGWAY, V_JEEP, V_N };
/* cruise speed (px/s), length (px), headlight x and height (fx < 0: no lamp) */
typedef struct { float speed; int len, fx, fy; } VehP;
static const VehP VEHP[V_N] = {
    { 26.0f, 22, 21, 8 }, { 58.0f, 26, 24, 9 }, { 52.0f, 34, 33, 5 }, { 56.0f, 38, 37, 5 },
    { 44.0f, 40, 39, 5 }, { 24.0f, 30, -1, 0 }, { 40.0f, 78, 77, 11 }, { 34.0f, 52, 51, 6 },
    { 38.0f, 22, -1, 0 }, { 42.0f, 24, 19, 20 }, { 36.0f, 38, 37, 13 },
};

static void vr(AWWorld *w, int X0, int GY, int x, int y, int ww, int hh, Col c) { R(w, X0 + x, GY - y - hh, ww, hh, c); }
static void vp(AWWorld *w, int X0, int GY, int x, int y, Col c) { PX(w, X0 + x, GY - 1 - y, c); }
static void vline(AWWorld *w, int X0, int GY, int x0, int y0, int x1, int y1, Col c) {   /* height coords */
    int dx = abs(x1 - x0), dy = abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx - dy;
    for (int guard = 0; guard < 64; guard++) {
        vp(w, X0, GY, x0, y0, c);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x0 += sx; }
        if (e2 < dx) { err += dx; y0 += sy; }
    }
}

/* a solid wheel; spokes turn with the distance travelled */
static void vwheel(AWWorld *w, int lx, int ybot, int d, Col rim) {
    float R0 = (float)d * 0.5f, cc = (float)(d - 1) * 0.5f;
    float a = (float)(w->ax / (double)R0);
    for (int dy = 0; dy < d; dy++)
        for (int dx = 0; dx < d; dx++) {
            float fx = (float)dx - cc, fy = (float)dy - cc, r = sqrtf(fx * fx + fy * fy);
            if (r > R0 - 0.1f) continue;
            PX(w, lx + dx, ybot - d + dy, r > R0 - 1.3f ? 0x1D1020 : (r > R0 * 0.36f ? rim : 0x6A7084));
        }
    for (int s = 0; s < 2; s++) {
        float an = a + (float)s * 3.14159f;
        PX(w, lx + (int)floorf(cc + cosf(an) * R0 * 0.55f + 0.5f), ybot - d + (int)floorf(cc + sinf(an) * R0 * 0.55f + 0.5f), 0xFFFFFF);
    }
}
static void vwheel_bike(AWWorld *w, int lx, int ybot, int d) {   /* thin tyre, turning spokes */
    float R0 = (float)d * 0.5f, cc = (float)(d - 1) * 0.5f;
    float a = (float)(w->ax / (double)R0);
    for (int dy = 0; dy < d; dy++)
        for (int dx = 0; dx < d; dx++) {
            float fx = (float)dx - cc, fy = (float)dy - cc, r = sqrtf(fx * fx + fy * fy);
            if (r > R0 - 0.1f || r < R0 - 1.15f) continue;
            PX(w, lx + dx, ybot - d + dy, 0x1D1020);
        }
    for (int s = 0; s < 3; s++) {
        float an = a + (float)s * 1.0472f;
        for (int k = -2; k <= 2; k++) {
            if (k == 0) continue;
            float rr = (float)k * (R0 - 1.4f) / 2.0f;
            PX(w, lx + (int)floorf(cc + cosf(an) * rr + 0.5f), ybot - d + (int)floorf(cc + sinf(an) * rr + 0.5f), 0xD8D8E6);
        }
    }
    PX(w, lx + (int)cc, ybot - d + (int)cc, 0x8A90A0);
}
static void vheadlight(AWWorld *w, int x, int y, float night) {   /* a soft beam at night (screen coords) */
    if (night < 0.25f) return;
    int a = (int)(46.0f * night);
    for (int i = 0; i < 22; i++) {
        int hw = 1 + i / 4;
        for (int dy = -hw; dy <= hw; dy++) if (((i + dy) & 1) == 0) BLEND(w, x + 2 + i, y + dy + i / 7, 0xFFF2B0, a - i * 2);
    }
}

#define NVB 16
static const Col V_BODY[NVB] = { 0xE8442A, 0x4FA6F5, 0xFFD23F, 0x2FC4B2, 0xA77BF0, 0xFF7AA8, 0x7DDB5C, 0xFF8A2A,
                                 0xF4F6FA, 0x2F5FA8, 0x2E8B57, 0xB02A3A, 0x30343E, 0x8FA3C0, 0xE8C36A, 0x1B9AAA };

static void veh_bike(AWWorld *w, int X0, int GY, uint32_t h, int blink) {
    Col fc = V_BODY[h % (uint32_t)NVB];
    vwheel_bike(w, X0 + 0, GY, 8); vwheel_bike(w, X0 + 14, GY, 8);
    int bbx = 10, bby = 3, sx = 7, sy = 10, hx = 15, hy = 10;
    vline(w, X0, GY, 3, 3, bbx, bby, fc); vline(w, X0, GY, 3, 3, sx, sy, fc); vline(w, X0, GY, bbx, bby, sx, sy, fc);
    vline(w, X0, GY, bbx, bby, hx, hy, mulc(fc, 0.85f)); vline(w, X0, GY, sx, sy, hx, hy, fc); vline(w, X0, GY, hx, hy, 17, 3, 0x8A90A0);
    vr(w, X0, GY, 15, 11, 1, 2, 0x4A4F5C); vr(w, X0, GY, 14, 13, 4, 1, 0x2A2A38);          /* stem + handlebar */
    vr(w, X0, GY, 4, 11, 5, 1, 0x2A2040);                                                  /* saddle */
    vp(w, X0, GY, 0, 4, 0xFF3030);                                                         /* rear light */
    /* pedalling legs */
    float a = (float)(w->ax * 0.33);
    for (int p = 0; p < 2; p++) {
        float an = a + (float)p * 3.14159f;
        int px = bbx + (int)floorf(cosf(an) * 3.0f + 0.5f), py = bby + (int)floorf(sinf(an) * 3.0f + 0.5f);
        vline(w, X0, GY, 8, 11, px, py, 0x3A2A52);
        vline(w, X0, GY, 8, 12, px, py + 1, 0x3A2A52);
        vp(w, X0, GY, px + 1, py, 0xFFFFFF);
    }
    draw_arch(w, X0 + 1, GY - 1 - 11 - 9, 4, blink, 0, 0);
}

static void veh_moto(AWWorld *w, int X0, int GY, uint32_t h, int blink, int bob) {
    Col c = V_BODY[h % (uint32_t)NVB];
    int g2 = GY - bob;
    vwheel(w, X0 + 0, GY, 8, 0xB8BCC8); vwheel(w, X0 + 18, GY, 8, 0xB8BCC8);
    vr(w, X0, g2, 0, 2, 8, 2, 0xB8C0CC); vr(w, X0, g2, 7, 2, 8, 6, 0x6B7080);              /* exhaust, engine */
    for (int i = 0; i < 4; i++) vr(w, X0, g2, 8 + i * 2, 3, 1, 4, 0x8E94A6);
    vr(w, X0, g2, 7, 2, 8, 1, 0x3A3F4C);
    vr(w, X0, g2, 9, 8, 8, 3, c); vr(w, X0, g2, 9, 10, 8, 1, lerpc(c, 0xFFFFFF, 0.3f));     /* tank */
    vr(w, X0, g2, 3, 8, 7, 2, 0x2A2040); vr(w, X0, g2, 1, 7, 3, 3, c);                     /* seat + tail */
    vline(w, X0, g2, 20, 12, 21, 3, 0x8A90A0); vline(w, X0, g2, 19, 12, 20, 3, 0x6A7084);  /* fork */
    vr(w, X0, g2, 17, 12, 4, 1, 0x2A2A38); vr(w, X0, g2, 20, 9, 3, 3, 0xFFF2A0);            /* bar, headlamp */
    vr(w, X0, g2, 19, 8, 6, 1, c);                                                         /* front fender */
    vline(w, X0, g2, 8, 10, 11, 4, 0x3A2A52); vline(w, X0, g2, 8, 11, 11, 5, 0x3A2A52); vp(w, X0, g2, 12, 4, 0xFFFFFF);
    draw_arch(w, X0 + 1, g2 - 1 - 10 - 9, 4, blink, 0, 0);
}

static void veh_sedan(AWWorld *w, int X0, int GY, uint32_t h, int blink, int bob) {
    Col c = V_BODY[h % (uint32_t)NVB];
    int g2 = GY - bob;
    vr(w, X0, g2, 9, 8, 3, 3, 0x3A2A3A);                                                   /* seat back */
    draw_arch(w, X0 + 8, g2 - 1 - 6 - 9, 4, blink, 0, 0);                                  /* only his top rows show above the door */
    vr(w, X0, g2, 1, 2, 32, 6, c);                                                         /* body */
    vr(w, X0, g2, 1, 2, 32, 1, mulc(c, 0.55f)); vr(w, X0, g2, 1, 3, 32, 1, mulc(c, 0.82f));
    vr(w, X0, g2, 22, 8, 11, 1, lerpc(c, 0xFFFFFF, 0.2f)); vr(w, X0, g2, 1, 8, 9, 1, lerpc(c, 0xFFFFFF, 0.2f));   /* hood + trunk */
    vr(w, X0, g2, 10, 7, 12, 1, lerpc(c, 0xFFFFFF, 0.35f));                                 /* door sill highlight */
    vr(w, X0, g2, 15, 3, 1, 4, mulc(c, 0.7f)); vp(w, X0, g2, 17, 5, 0xE6E6F0);               /* door seam + handle */
    vp(w, X0, g2, 1, 7, 0); vp(w, X0, g2, 32, 7, 0);
    vr(w, X0, g2, 20, 8, 2, 5, 0xBFE8FF); vp(w, X0, g2, 20, 12, 0xFFFFFF);                  /* windscreen */
    vr(w, X0, g2, 17, 9, 3, 1, 0x2A2A38);                                                  /* wheel */
    vr(w, X0, g2, 32, 4, 2, 3, 0xFFF2A0); vr(w, X0, g2, 0, 4, 1, 3, 0xFF3030);              /* lamps */
    vr(w, X0, g2, 31, 2, 3, 1, 0xB8C0CC);
    vr(w, X0, GY, 3, 3, 9, 4, 0x15101A); vr(w, X0, GY, 23, 3, 9, 4, 0x15101A);
    vwheel(w, X0 + 4, GY, 7, 0xC8CCD8); vwheel(w, X0 + 24, GY, 7, 0xC8CCD8);
}

static void veh_ev(AWWorld *w, int X0, int GY, uint32_t h, int blink, int bob) {
    static const Col EVC[10] = { 0xF4F6FA, 0xD83A3A, 0x3A6FD8, 0x30343E, 0xB8C0CC, 0x2FB6A0, 0x8A4BD0, 0xE8C36A, 0xFF7AA8, 0x7DDB5C };
    Col c = EVC[h % 10u];
    int g2 = GY - bob;
    vr(w, X0, g2, 1, 2, 36, 5, c);                                                         /* body */
    vr(w, X0, g2, 1, 2, 36, 1, mulc(c, 0.5f)); vr(w, X0, g2, 1, 3, 36, 1, mulc(c, 0.8f));
    vr(w, X0, g2, 28, 7, 7, 1, c);                                                         /* long sloping bonnet */
    vp(w, X0, g2, 1, 6, 0); vp(w, X0, g2, 36, 2, 0); vp(w, X0, g2, 36, 6, 0);
    Col glass = lerpc(0x7FB4D8, c, 0.12f);
    static const int RX0[5] = { 9, 11, 13, 15, 16 }, RX1[5] = { 30, 28, 26, 24, 23 };
    for (int r = 0; r < 5; r++) {                                                           /* glass canopy */
        vr(w, X0, g2, RX0[r], 7 + r, RX1[r] - RX0[r] + 1, 1, r == 4 ? lerpc(c, 0xFFFFFF, 0.25f) : glass);
        vp(w, X0, g2, RX0[r], 7 + r, mulc(c, 0.85f)); vp(w, X0, g2, RX1[r], 7 + r, mulc(c, 0.85f));
    }
    vr(w, X0, g2, 13, 7, 1, 4, mulc(c, 0.85f));                                             /* B-pillar */
    vline(w, X0, g2, 21, 8, 24, 10, lerpc(glass, 0xFFFFFF, 0.5f));                           /* glass glint */
    holo_window(w, X0 + 16, g2 - 1 - 10, blink);                                            /* Archon looks out */
    vr(w, X0, g2, 19, 3, 1, 4, mulc(c, 0.65f)); vp(w, X0, g2, 20, 5, 0xE6E6F0);             /* door seam + flush handle */
    static const int BX[5] = { 13, 12, 13, 12, 11 }, BY[5] = { 6, 5, 5, 4, 3 };
    for (int i = 0; i < 5; i++) vp(w, X0, g2, BX[i], BY[i], 0x7FF0FF);                       /* little lightning bolt */
    vr(w, X0, g2, 34, 5, 3, 1, 0xFFFFFF); vp(w, X0, g2, 36, 4, 0xFFF2A0);                    /* light bar */
    vr(w, X0, g2, 0, 4, 1, 3, 0xFF2A2A);
    vr(w, X0, GY, 4, 3, 9, 4, 0x15101A); vr(w, X0, GY, 26, 3, 9, 4, 0x15101A);
    vwheel(w, X0 + 5, GY, 7, 0xE4E8F0); vwheel(w, X0 + 27, GY, 7, 0xE4E8F0);
}

static void veh_pickup(AWWorld *w, int X0, int GY, uint32_t h, int blink, int bob) {
    Col c = V_BODY[h % (uint32_t)NVB];
    int g2 = GY - bob;
    int cargo = (int)((h >> 4) % 3u);
    vr(w, X0, g2, 1, 2, 38, 5, c);                                                         /* chassis */
    vr(w, X0, g2, 1, 2, 38, 1, mulc(c, 0.5f)); vr(w, X0, g2, 1, 3, 38, 1, mulc(c, 0.8f));
    vr(w, X0, g2, 30, 7, 9, 1, lerpc(c, 0xFFFFFF, 0.2f));                                    /* hood */
    vr(w, X0, g2, 1, 7, 20, 2, c); vr(w, X0, g2, 1, 7, 20, 1, lerpc(c, 0xFFFFFF, 0.25f));   /* bed walls */
    vr(w, X0, g2, 2, 6, 18, 1, 0x2A2430);
    if (cargo == 0) {                                                                       /* cardboard boxes */
        vr(w, X0, g2, 3, 9, 7, 6, 0xC8A060); vr(w, X0, g2, 6, 9, 1, 6, 0xE8DCC0);
        vr(w, X0, g2, 11, 9, 6, 4, 0xB08850); vr(w, X0, g2, 13, 9, 1, 4, 0xE8DCC0);
        vr(w, X0, g2, 4, 15, 5, 3, 0xC8A060);
    } else if (cargo == 1) {                                                                /* hay bales */
        for (int i = 0; i < 2; i++) { vr(w, X0, g2, 3 + i * 8, 9, 7, 5, 0xE0B850); vr(w, X0, g2, 3 + i * 8, 11, 7, 1, 0xB88A30); vr(w, X0, g2, 5 + i * 8, 9, 1, 5, 0xB88A30); }
        vr(w, X0, g2, 7, 14, 7, 5, 0xE0B850); vr(w, X0, g2, 7, 16, 7, 1, 0xB88A30);
    } else {                                                                                /* drums */
        for (int i = 0; i < 3; i++) { Col dc = i == 1 ? 0xE8442A : 0x4FA6F5; vr(w, X0, g2, 3 + i * 6, 9, 5, 7, dc); vr(w, X0, g2, 3 + i * 6, 12, 5, 1, mulc(dc, 0.7f)); vr(w, X0, g2, 4 + i * 6, 15, 3, 1, lerpc(dc, 0xFFFFFF, 0.4f)); }
    }
    vr(w, X0, g2, 21, 7, 11, 7, c);                                                         /* cab */
    vr(w, X0, g2, 22, 14, 9, 1, lerpc(c, 0xFFFFFF, 0.3f));
    vr(w, X0, g2, 22, 8, 9, 5, 0x2A3A50);                                                   /* glass */
    holo_window(w, X0 + 23, g2 - 1 - 12, blink);
    vr(w, X0, g2, 29, 8, 2, 5, 0xBFE8FF);
    vr(w, X0, g2, 27, 3, 1, 4, mulc(c, 0.65f)); vp(w, X0, g2, 25, 6, 0xE6E6F0);
    vr(w, X0, g2, 37, 5, 2, 2, 0xFFF2A0); vr(w, X0, g2, 38, 3, 1, 3, 0x30343E); vr(w, X0, g2, 36, 2, 4, 1, 0xB8C0CC);
    vr(w, X0, g2, 0, 4, 1, 3, 0xFF3030);
    vr(w, X0, GY, 3, 3, 10, 5, 0x15101A); vr(w, X0, GY, 27, 3, 10, 5, 0x15101A);
    vwheel(w, X0 + 4, GY, 8, 0xC8CCD8); vwheel(w, X0 + 28, GY, 8, 0xC8CCD8);
}

static void veh_fork(AWWorld *w, int X0, int GY, uint32_t h, int blink, int bob) {
    (void)h;
    int g2 = GY - bob;
    Col fy = 0xFFC21F;
    float t = (float)w->t;
    int fh = 3 + (int)(7.0f * (0.5f + 0.5f * sinf(t * 0.85f)));                              /* the forks rise and fall */
    vr(w, X0, g2, 8, 9, 6, 2, 0x2A2430);                                                    /* seat */
    draw_arch(w, X0 + 5, g2 - 1 - 11 - 9, 4, blink, 0, 0);
    vr(w, X0, g2, 0, 3, 19, 6, fy); vr(w, X0, g2, 0, 8, 19, 1, lerpc(fy, 0xFFFFFF, 0.3f));
    vr(w, X0, g2, 0, 3, 19, 1, 0x2A2430);
    vr(w, X0, g2, 0, 5, 7, 7, 0x3A3F4C); vr(w, X0, g2, 0, 11, 7, 1, 0x555B6B);               /* counterweight */
    for (int i = 0; i < 4; i++) vr(w, X0, g2, 1 + i * 2, 6, 1, 4, 0xFFC21F);
    vr(w, X0, g2, 2, 11, 1, 12, 0x2A2430); vr(w, X0, g2, 17, 11, 1, 12, 0x2A2430);             /* operator cage */
    vr(w, X0, g2, 1, 22, 18, 1, 0x2A2430);
    for (int i = 0; i < 4; i++) vr(w, X0, g2, 4 + i * 4, 22, 2, 1, 0x555B6B);
    if (((int)(t * 3.0f)) & 1) vr(w, X0, g2, 9, 23, 2, 1, 0xFF8A1F);                        /* beacon */
    vr(w, X0, g2, 19, 3, 2, 20, 0x7A8090); vr(w, X0, g2, 22, 3, 1, 19, 0x555B6B);           /* mast */
    vr(w, X0, g2, 20, fh - 1, 2, 5, 0x555B6B);                                              /* carriage */
    vr(w, X0, g2, 21, fh, 9, 1, 0xC8CED8); vr(w, X0, g2, 21, fh + 1, 9, 1, 0x8E94A6);        /* fork */
    vr(w, X0, g2, 22, fh + 2, 8, 2, 0xB07A3A); vr(w, X0, g2, 24, fh + 2, 1, 2, 0x8A5A2A); vr(w, X0, g2, 27, fh + 2, 1, 2, 0x8A5A2A);  /* pallet */
    vr(w, X0, g2, 23, fh + 4, 6, 6, 0xC8A060); vr(w, X0, g2, 25, fh + 4, 1, 6, 0xE8DCC0); vr(w, X0, g2, 23, fh + 9, 6, 1, 0xDDB878);
    vwheel(w, X0 + 1, GY, 6, 0xA0A8B8); vwheel(w, X0 + 10, GY, 8, 0xA0A8B8);
}

static void veh_semi(AWWorld *w, int X0, int GY, uint32_t h, int blink, int bob) {
    static const Col CAB[10] = { 0xD83A3A, 0x3A6FD8, 0x2FB05A, 0xFF8A2A, 0xF4F6FA, 0x8A4BD0, 0xFFD23F, 0x2FC4B2, 0x30343E, 0xFF7AA8 };
    static const Col TRL[5] = { 0xF4F6FA, 0x3A8FE8, 0xFFFFFF, 0x7DDB5C, 0xFFD23F };
    Col c = CAB[h % 10u], tc = TRL[(h >> 3) % 5u];
    Col stripe = CAB[(h >> 6) % 10u];
    int g2 = GY - bob;
    /* trailer */
    vr(w, X0, g2, 1, 5, 50, 19, tc);
    vr(w, X0, g2, 1, 23, 50, 1, lerpc(tc, 0xFFFFFF, 0.4f)); vr(w, X0, g2, 1, 5, 50, 1, mulc(tc, 0.6f));
    for (int i = 1; i < 5; i++) vr(w, X0, g2, 1 + i * 10, 6, 1, 17, mulc(tc, 0.86f));
    vr(w, X0, g2, 1, 9, 50, 2, stripe); vr(w, X0, g2, 1, 12, 50, 1, mulc(stripe, 1.2f));
    /* a cheerful sun emblem */
    for (int dy = -4; dy <= 4; dy++) for (int dx = -4; dx <= 4; dx++) if (dx * dx + dy * dy <= 16) vp(w, X0, g2, 24 + dx, 17 + dy, 0xFFD23F);
    vp(w, X0, g2, 22, 18, 0x1D1020); vp(w, X0, g2, 26, 18, 0x1D1020); vp(w, X0, g2, 22, 16, 0x1D1020); vp(w, X0, g2, 23, 15, 0x1D1020); vp(w, X0, g2, 24, 15, 0x1D1020); vp(w, X0, g2, 25, 15, 0x1D1020); vp(w, X0, g2, 26, 16, 0x1D1020);
    vr(w, X0, g2, 2, 3, 48, 2, 0x2A2A34); vr(w, X0, g2, 0, 3, 3, 2, 0xB8C0CC);                /* chassis, rear bumper */
    vr(w, X0, g2, 1, 6, 1, 2, 0xFF3030); vr(w, X0, g2, 0, 6, 1, 18, 0x9A9AA6);
    vr(w, X0, g2, 49, 4, 8, 1, 0x2A2A34);                                                  /* hitch */
    /* tractor unit */
    vr(w, X0, g2, 52, 4, 12, 16, c); vr(w, X0, g2, 52, 19, 12, 1, lerpc(c, 0xFFFFFF, 0.3f));   /* sleeper */
    vr(w, X0, g2, 64, 4, 13, 13, c); vr(w, X0, g2, 64, 16, 13, 1, lerpc(c, 0xFFFFFF, 0.3f));
    vr(w, X0, g2, 52, 4, 25, 2, mulc(c, 0.6f));
    vr(w, X0, g2, 52, 11, 6, 4, 0x2A3A50);                                                   /* sleeper window */
    vr(w, X0, g2, 69, 11, 8, 5, 0x2A3A50);                                                   /* windscreen */
    holo_window(w, X0 + 70, g2 - 1 - 15, blink);
    vr(w, X0, g2, 64, 8, 4, 4, 0xBFE8FF); vr(w, X0, g2, 64, 4, 1, 8, mulc(c, 0.7f)); vp(w, X0, g2, 66, 7, 0xE6E6F0);
    vr(w, X0, g2, 76, 3, 2, 12, 0xC8CED8); vr(w, X0, g2, 76, 11, 2, 2, 0xFFF2A0); vr(w, X0, g2, 75, 2, 3, 2, 0x4A4F5C);
    vr(w, X0, g2, 77, 15, 1, 3, 0x2A2A34);                                                  /* mirror */
    vr(w, X0, g2, 60, 20, 1, 8, 0xDCE2EA); vr(w, X0, g2, 62, 20, 1, 7, 0xDCE2EA);           /* exhaust stacks */
    vr(w, X0, g2, 56, 12, 6, 1, 0x555B6B);
    /* wheels */
    vr(w, X0, GY, 4, 3, 18, 5, 0x15101A);
    vwheel(w, X0 + 5, GY, 7, 0xC8CCD8); vwheel(w, X0 + 13, GY, 7, 0xC8CCD8);
    vr(w, X0, GY, 53, 3, 17, 6, 0x15101A);
    vwheel(w, X0 + 54, GY, 7, 0xC8CCD8); vwheel(w, X0 + 62, GY, 7, 0xC8CCD8); vwheel(w, X0 + 69, GY, 7, 0xC8CCD8);
}

static void veh_bus(AWWorld *w, int X0, int GY, uint32_t h, int blink, int bob) {
    Col y = 0xFFC21F;
    int g2 = GY - bob;
    vr(w, X0, g2, 1, 3, 50, 17, y); vr(w, X0, g2, 1, 19, 50, 1, lerpc(y, 0xFFFFFF, 0.35f)); vr(w, X0, g2, 1, 3, 50, 1, mulc(y, 0.5f));
    vr(w, X0, g2, 1, 9, 50, 1, 0x2A2430); vr(w, X0, g2, 1, 17, 50, 1, 0x2A2430); vr(w, X0, g2, 1, 4, 50, 1, mulc(y, 0.8f));
    static const Col FR[4] = { 0x6CCB52, 0xFF8A2A, 0xF0F0FF, 0x9AA4B8 };
    for (int i = 0; i < 6; i++) {
        int wx = 4 + i * 7;
        vr(w, X0, g2, wx, 11, 5, 5, 0xBFE8FF); vp(w, X0, g2, wx, 15, 0xFFFFFF);
        uint32_t q = hash2(h, (uint32_t)i + 90u);
        if (i >= 1 && i <= 4 && (q & 3u) != 0u) {                                           /* a friend aboard */
            int bounce = (((int)(w->t * 2.2f + (float)i)) & 3) == 0 ? 1 : 0;
            Col fc = FR[(q >> 4) % 4u];
            vr(w, X0, g2, wx + 1, 11 + bounce, 3, 3, fc);
            vp(w, X0, g2, wx + 1, 12 + bounce, 0x1D1020); vp(w, X0, g2, wx + 3, 12 + bounce, 0x1D1020);
        }
    }
    vr(w, X0, g2, 44, 11, 7, 6, 0x2A3A50);                                                  /* driver's windscreen */
    holo_window(w, X0 + 44, g2 - 1 - 15, blink);
    vr(w, X0, g2, 40, 3, 3, 12, 0x3A4A66); vr(w, X0, g2, 41, 4, 1, 10, 0xBFE8FF);           /* door */
    vr(w, X0, g2, 36, 20, 3, 1, 0xFF4A3A); vr(w, X0, g2, 12, 20, 3, 1, 0xFF4A3A);          /* roof lights */
    vr(w, X0, g2, 50, 5, 2, 2, 0xFFF2A0); vr(w, X0, g2, 50, 3, 2, 2, 0x2A2430); vr(w, X0, g2, 0, 8, 1, 2, 0xFF3030);
    vr(w, X0, g2, 0, 4, 1, 14, 0xB8861A);
    vr(w, X0, GY, 5, 3, 10, 5, 0x15101A); vr(w, X0, GY, 35, 3, 10, 5, 0x15101A);
    vwheel(w, X0 + 6, GY, 8, 0xC8CCD8); vwheel(w, X0 + 36, GY, 8, 0xC8CCD8);
}

/* a skateboard: he stands on the deck and now and then pops an ollie */
static int skate_hop(const AWWorld *w) {
    float ph = fmodf((float)w->t + 1.3f, 3.6f);
    if (ph > 0.6f || w->spd < 10.0f) return 0;
    return (int)(7.0f * sinf(3.14159f * ph / 0.6f) + 0.5f);
}
static void veh_skate(AWWorld *w, int X0, int GY, uint32_t h, int blink) {
    Col dk = V_BODY[h % (uint32_t)NVB];
    Col st = V_BODY[(h >> 5) % (uint32_t)NVB];
    int hop = skate_hop(w);
    int g2 = GY - hop;
    float ph = fmodf((float)w->t + 1.3f, 3.6f);
    int tilt = hop > 0 ? (ph < 0.3f ? 1 : -1) : 0;                       /* nose up on the way up, down on the way down */
    /* deck: a flat board with kicked-up ends */
    vr(w, X0, g2, 2, 3, 18, 2, dk); vr(w, X0, g2, 2, 5, 18, 1, 0x23232E);     /* deck + grip tape */
    vr(w, X0, g2, 2, 3, 18, 1, mulc(dk, 0.65f));
    vr(w, X0, g2, 8, 3, 3, 2, st); vr(w, X0, g2, 13, 3, 1, 2, st);              /* stripe */
    vr(w, X0, g2, 0, 4 + (tilt < 0 ? 0 : 1), 2, 2, dk); vr(w, X0, g2, 20, 4 + (tilt > 0 ? 2 : 1), 2, 2, dk);
    /* trucks and wheels */
    vr(w, X0, g2, 5, 2, 3, 1, 0x8A90A0); vr(w, X0, g2, 15, 2, 3, 1, 0x8A90A0);
    for (int i = 0; i < 2; i++) {
        int wxp = X0 + (i ? 15 : 4);
        vr(w, X0, g2, wxp - X0, 0, 4, 3, 0xF4F4F8);
        vr(w, X0, g2, wxp - X0 + 1, 1, 2, 1, 0xC8CCD8);
        vp(w, X0, g2, wxp - X0 + (((int)(w->ax * 0.9)) & 3), 1, 0x8A90A0);       /* a turning bearing dot */
    }
    /* Archon stands on the deck, knees bent when he lands */
    int knee = (hop == 0 && w->spd > 10.0f && ((int)(w->t * 2.0f) & 3) == 0) ? 1 : 0;
    draw_arch(w, X0 + 5, g2 - 1 - 4 - 12 + knee, 0, blink, 0, 0);
}

/* a Segway: one fat wheel, a platform and a tall handlebar column that he steers with */
static void veh_segway(AWWorld *w, int X0, int GY, uint32_t h, int blink, int bob) {
    Col c = V_BODY[h % (uint32_t)NVB];
    int g2 = GY - bob;
    float lean = w->spd > 12.0f ? 1.0f : 0.0f;
    vwheel(w, X0 + 6, GY, 11, 0xB8BCC8);                                   /* the big wheel, centre of the platform */
    vr(w, X0, g2, 2, 7, 15, 2, c); vr(w, X0, g2, 2, 8, 15, 1, lerpc(c, 0xFFFFFF, 0.3f));   /* platform */
    vr(w, X0, g2, 2, 7, 15, 1, mulc(c, 0.6f));
    vr(w, X0, g2, 3, 10, 5, 2, c); vr(w, X0, g2, 3, 11, 5, 1, mulc(c, 0.75f));              /* wheel arch above the tyre */
    vr(w, X0, g2, 3, 9, 14, 1, 0x23232E);                                                   /* grip */
    /* steering column leaning forward, handlebar on top */
    int cx0 = 15 + (int)lean;
    for (int y = 8; y < 22; y++) { vp(w, X0, g2, cx0 + (y - 8) / 9, y, 0x4A4F5C); vp(w, X0, g2, cx0 + 1 + (y - 8) / 9, y, 0x6A7084); }
    vr(w, X0, g2, cx0 - 1 + 1, 22, 5, 1, 0x23232E);                                         /* handlebar */
    vr(w, X0, g2, cx0 + 2, 23, 3, 1, c);
    vp(w, X0, g2, cx0 + 3, 19, 0xFFF2A0); vp(w, X0, g2, cx0 + 3, 20, 0xFFF2A0);              /* headlamp */
    vp(w, X0, g2, 1, 8, 0xFF3030);                                                          /* tail light */
    draw_arch(w, X0 + 4, g2 - 1 - 9 - 12, 0, blink, 0, 0);
    /* arm out to the handlebar */
    vline(w, X0, g2, 12, 15, cx0 + 1, 22, 0x3A2A52); vline(w, X0, g2, 12, 14, cx0 + 1, 21, 0x3A2A52);
}


/* ------------------------------------------------------------------ */
/* the little 4x4: a solid, rigid body on big knobby wheels. The wheels roll over every rock and hump in the trail;   */
/* the body never bends - it simply rides at the average height of its two axles.                                   */
/* ------------------------------------------------------------------ */
#define TRAIL_CELL 11
/* small rocks dotted along the dirt trail: how many pixels the rock rises above the trail surface at world x */
static int trail_rock(const AWWorld *w, int wx) {
    if (!w->jp_on || jeep_m(w, wx) < 0.99f) return 0;
    int cell = floordiv(wx, TRAIL_CELL);
    uint32_t q = hash2(w->jp_seed ^ 0x40CCU, (uint32_t)cell);
    if (rfn(q, 0) > 0.60f) return 0;
    int rw = 4 + (int)(rfn(q, 1) * 4.0f), rh = 1 + (int)(rfn(q, 2) * 2.99f);
    int c0 = cell * TRAIL_CELL + 1 + (int)(rfn(q, 3) * (float)(TRAIL_CELL - rw - 1));
    int dx = wx - c0;
    if (dx < 0 || dx >= rw) return 0;
    float u = ((float)dx + 0.5f) / (float)rw * 2.0f - 1.0f;
    return (int)floorf((float)rh * sqrtf(fmaxf(0.0f, 1.0f - u * u)) + 0.85f);
}
/* where a round wheel of radius R settles over the trail: the height of its centre above the baseline */
static float wheel_rest(const AWWorld *w, int wxc, float R) {
    float best = -1.0e9f;
    int Ri = (int)ceilf(R);
    for (int dx = -Ri; dx <= Ri; dx++) {
        float f = R * R - (float)(dx * dx);
        if (f < 0.0f) continue;
        float y = (float)(ground_h(w, wxc + dx) + trail_rock(w, wxc + dx)) + sqrtf(f);
        if (y > best) best = y;
    }
    return best;
}

static void vwheel_4x4(AWWorld *w, int lx, int ybot, int d) {   /* a fat knobby tyre with a chunky rim; the lugs turn as he drives */
    float R0 = (float)d * 0.5f, cc = (float)(d - 1) * 0.5f;
    float a = (float)(w->ax / (double)R0);
    for (int dy = 0; dy < d; dy++)
        for (int dx = 0; dx < d; dx++) {
            float fx = (float)dx - cc, fy = (float)dy - cc, r = sqrtf(fx * fx + fy * fy);
            if (r > R0 - 0.1f) continue;
            Col c;
            if (r > R0 * 0.58f) {
                float ang = atan2f(fy, fx) - a;
                int lug = ((int)floorf(ang * 12.0f / 6.28318f + 120.0f)) & 1;
                c = (r > R0 - 1.5f) ? (lug ? 0x4A4F5C : 0x15101A) : 0x23232E;
            } else c = r > R0 * 0.26f ? 0xC8CCD8 : 0x6A7084;
            PX(w, lx + dx, ybot - d + dy, c);
        }
    for (int s = 0; s < 4; s++) {
        float an = a + (float)s * 1.5708f;
        PX(w, lx + (int)floorf(cc + cosf(an) * R0 * 0.42f + 0.5f), ybot - d + (int)floorf(cc + sinf(an) * R0 * 0.42f + 0.5f), 0x3A3F4C);
    }
}

/* layer 0 sits behind Archon (seat, roll cage); layer 1 is in front of him (tub, hood, windscreen). Heights are above the body baseline. */
static void veh_jeep_parts(AWWorld *w, int X0, int GY, uint32_t h, int layer, float night) {
    static const Col JC[NVB] = { 0x4F9A4A, 0xFF8A2A, 0xE8442A, 0xFFD23F, 0x2FC4B2, 0xA77BF0, 0x4FA6F5, 0xFF7AA8,
                                 0xF4F6FA, 0x2F5FA8, 0x2E8B57, 0xB02A3A, 0x30343E, 0x8FA3C0, 0xE8C36A, 0x7DDB5C };
    Col c = JC[(h >> 3) % (uint32_t)NVB];
    Col dk = 0x2A2F3E, bar = 0x3A3F4C;
    float t = (float)w->t;
    if (layer == 0) {
        vr(w, X0, GY, 9, 11, 3, 7, 0x3A2A3A); vr(w, X0, GY, 9, 17, 3, 1, 0x56405A);                  /* seat back */
        vr(w, X0, GY, 6, 12, 2, 14, bar); vr(w, X0, GY, 6, 12, 1, 14, 0x555B6B);                     /* roll cage hoop */
        vr(w, X0, GY, 6, 24, 17, 2, bar); vr(w, X0, GY, 6, 25, 17, 1, 0x555B6B);                     /* roof bar */
        vline(w, X0, GY, 22, 24, 22, 19, bar);                                                       /* strut down to the windscreen */
        for (int i = 0; i < 3; i++) vr(w, X0, GY, 10 + i * 3, 26, 2, 2, (night > 0.3f) ? 0xFFF59A : 0xE8E8F0);   /* light bar */
        vline(w, X0, GY, 4, 14, 3, 29, 0x8A90A0);                                                    /* whip antenna */
        int fl = 3 + (int)floorf(sinf(t * 9.0f) * 1.0f + 0.5f);
        vr(w, X0, GY, 1 - fl / 3, 27, 3, 2, 0xFF8A2A); vr(w, X0, GY, 0 - fl / 3, 28, 2, 1, 0xFFB060);   /* its little flag */
        return;
    }
    /* the tub: one solid block that sits up above the wheels, like a lifted truck */
    vr(w, X0, GY, 2, 7, 34, 7, c);                                                                   /* body */
    vr(w, X0, GY, 2, 13, 34, 1, lerpc(c, 0xFFFFFF, 0.30f));
    vr(w, X0, GY, 2, 7, 34, 1, mulc(c, 0.55f)); vr(w, X0, GY, 2, 8, 34, 1, mulc(c, 0.8f));
    vr(w, X0, GY, 26, 14, 10, 2, c); vr(w, X0, GY, 26, 15, 10, 1, lerpc(c, 0xFFFFFF, 0.35f));      /* the hood */
    vr(w, X0, GY, 29, 15, 4, 1, mulc(c, 0.7f));                                                      /* hood vent */
    vr(w, X0, GY, 17, 8, 1, 5, mulc(c, 0.65f)); vp(w, X0, GY, 19, 10, 0xE6E6F0);                    /* door seam + handle */
    vr(w, X0, GY, 35, 7, 3, 9, 0x23232E);                                                            /* grille */
    for (int i = 0; i < 3; i++) vr(w, X0, GY, 36, 8 + i * 2, 1, 1, 0xB8C0CC);
    vr(w, X0, GY, 34, 13, 3, 2, 0xFFF2A0); vp(w, X0, GY, 35, 14, 0xFFFFFF);                         /* round headlamp */
    vr(w, X0, GY, 36, 5, 3, 3, 0xB8C0CC); vr(w, X0, GY, 36, 5, 3, 1, 0x6A7084);                    /* front bumper */
    vr(w, X0, GY, 0, 5, 3, 3, 0xB8C0CC); vr(w, X0, GY, 2, 10, 1, 2, 0xFF3030);                      /* rear bumper + tail lamp */
    vr(w, X0, GY, 3, 14, 3, 3, 0x4F8A3A); vr(w, X0, GY, 3, 16, 3, 1, 0x7DDB5C);                    /* a jerry can on the back */
    /* the windscreen: a short slanted frame with a glint */
    vline(w, X0, GY, 22, 14, 24, 21, dk); vline(w, X0, GY, 23, 14, 25, 21, dk);
    vline(w, X0, GY, 23, 16, 24, 19, 0xBFE8FF); vp(w, X0, GY, 23, 17, 0xFFFFFF);
    /* a splash of mud along the sills */
    static const int MX[7] = { 4, 9, 15, 20, 25, 31, 34 };
    for (int i = 0; i < 7; i++) vp(w, X0, GY, MX[i], 7 + (i & 1), 0x6A4A2C);
}

/* the 4x4 is rigid: the wheels follow the ground and the rocks, the body rides at the mean of the two axle heights */
static void veh_jeep(AWWorld *w, int sx, int sy, uint32_t h, int blink, float night) {
    (void)sy;
    const int D = 11, WB_R = 8, WB_F = 29;                 /* wheel diameter, and the wheel centres along the body */
    int X0 = sx - 19;
    int camI = (int)floor(w->cam);
    float R = (float)D * 0.5f;
    int cxr = camI + X0 + WB_R, cxf = camI + X0 + WB_F;     /* world x of the wheel centres */
    float hr = wheel_rest(w, cxr, R), hf = wheel_rest(w, cxf, R);   /* centre heights above the ground line */
    int ybr = w->gy - (int)floorf(hr - R + 0.5f), ybf = w->gy - (int)floorf(hf - R + 0.5f);   /* wheel bottoms (screen rows) */
    int GY = (ybr + ybf + 1) / 2;                                    /* the body's baseline: one rigid line, no tilt */
    if (night > 0.25f) vheadlight(w, X0 + 37, GY - 14, night);
    for (int layer = 0; layer < 2; layer++) {
        veh_jeep_parts(w, X0, GY, h, layer, night);
        if (layer == 0) draw_arch(w, X0 + 10, GY - 21, 4, blink, 0, 0);   /* Archon rides between the two layers */
    }
    vwheel_4x4(w, X0 + WB_R - (D - 1) / 2, ybr, D);
    vwheel_4x4(w, X0 + WB_F - (D - 1) / 2, ybf, D);
}

/* the dirt trail over the hills: sandy ground with wheel ruts and the odd pebble */
static void draw_trail(AWWorld *w) {
    if (!w->jp_on) return;
    int camI = (int)floor(w->cam);
    for (int x = 0; x < w->vw; x++) {
        int wx = camI + x;
        if (jeep_m(w, wx) < 0.55f) continue;
        int top = w->gy - ground_h(w, wx);
        uint32_t q = hash2(w->jp_seed ^ 0x7A11U, (uint32_t)wx);
        int rut = ((wx >> 3) & 3) == 1;
        PX(w, x, top, 0xE4CC98);
        PX(w, x, top + 1, 0xD0B07A);
        PX(w, x, top + 2, rut ? 0x9A7A48 : 0xB89A66);
        PX(w, x, top + 3, ((wx >> 2) & 1) ? 0xA88A58 : 0x9A7C4C);
        if ((q % 11u) == 0u) PX(w, x, top - 1, 0x9A8A78);                          /* a pebble */
        if ((q % 17u) == 3u) { PX(w, x, top - 1, 0x8A7A68); PX(w, x + 1, top - 1, 0x8A7A68); }
        if ((q % 23u) == 5u) PX(w, x, top + 4, 0x8A6E46);
        int rk = trail_rock(w, wx);                                                  /* small rocks the 4x4 rolls over */
        if (rk > 0) {
            int lft = trail_rock(w, wx - 1) < rk, rgt = trail_rock(w, wx + 1) < rk;
            for (int j = 1; j <= rk; j++) {
                Col c = j == rk ? 0xB4AC9E : 0x8E867A;
                if (lft && j >= rk - 1) c = 0xC4BCAE;
                if (rgt) c = mulc(c, 0.78f);
                if (j == 1) c = mulc(c, 0.82f);
                PX(w, x, top - j, c);
            }
        }
    }
}

static void draw_h_road(AWWorld *w, int sx, int sy, int blink) {
    const VehP *v = &VEHP[w->veh];
    int X0 = sx - v->len / 2, GY = sy;
    uint32_t h = hash2(w->seed ^ 0x70ADu, (uint32_t)(int)w->rd_x0);
    float night = bg_night(w);
    int moving = w->spd > 8.0f;
    int bob = moving && sinf((float)w->t * 8.0f) > 0.7f ? 1 : 0;
    if (w->veh == V_JEEP) { veh_jeep(w, sx, sy, h, blink, night); return; }
    /* contact shadow on the road */
    for (int x = 2; x < v->len - 1; x++) BLEND(w, X0 + x, GY, 0x000000, 70);
    if (v->fx >= 0) vheadlight(w, X0 + v->fx, GY - 1 - v->fy, night);
    switch (w->veh) {
        case V_BIKE:   veh_bike(w, X0, GY, h, blink); break;
        case V_MOTO:   veh_moto(w, X0, GY, h, blink, bob); break;
        case V_SEDAN:  veh_sedan(w, X0, GY, h, blink, bob); break;
        case V_EV:     veh_ev(w, X0, GY, h, blink, bob); break;
        case V_PICKUP: veh_pickup(w, X0, GY, h, blink, bob); break;
        case V_FORK:   veh_fork(w, X0, GY, h, blink, bob); break;
        case V_SEMI:   veh_semi(w, X0, GY, h, blink, bob); break;
        case V_SKATE:  veh_skate(w, X0, GY, h, blink); break;
        case V_SEGWAY: veh_segway(w, X0, GY, h, blink, bob); break;
        default:       veh_bus(w, X0, GY, h, blink, bob); break;
    }
}

/* the asphalt itself: a strip along the ground surface, with dashed centre line and the odd street lamp */
static void draw_road(AWWorld *w) {
    if (!w->rd_on) return;
    int camI = (int)floor(w->cam);
    float night = bg_night(w);
    for (int x = 0; x < w->vw; x++) {
        int wx = camI + x;
        if (road_m(w, wx) < 0.5f) continue;
        int top = w->gy - ground_h(w, wx);
        Col a = 0x565B6A;
        PX(w, x, top, 0x9AA0AE);
        PX(w, x, top + 1, a);
        PX(w, x, top + 2, ((wx >> 3) & 1) ? a : 0xFFD23F);
        PX(w, x, top + 3, a);
        PX(w, x, top + 4, 0x2E323E);
    }
    /* street lamps every 120 px */
    int k0 = floordiv(camI - 12, 120), k1 = floordiv(camI + w->vw + 12, 120);
    for (int k = k0; k <= k1; k++) {
        int wx = k * 120 + 60;
        if (road_m(w, wx) < 0.98f || road_m(w, wx - 6) < 0.98f || road_m(w, wx + 6) < 0.98f) continue;
        int top = w->gy - ground_h(w, wx), sx = wx - camI;
        R(w, sx, top - 22, 1, 22, 0x3A3F4C);
        R(w, sx - 1, top - 23, 5, 1, 0x3A3F4C);
        R(w, sx + 1, top - 22, 3, 1, night > 0.3f ? 0xFFF2B0 : 0xD8DCE6);
        if (night > 0.3f) {
            for (int dy = 0; dy < 20; dy++) for (int dx = -dy / 2 - 1; dx <= dy / 2 + 3; dx++) if (((dx + dy) & 1) == 0) BLEND(w, sx + dx, top - 21 + dy, 0xFFE9A0, 22);
        }
    }
}
