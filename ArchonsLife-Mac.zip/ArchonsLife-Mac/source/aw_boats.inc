/*
 * Archon's Life v5 - more boats. The sailboat is joined by a tugboat, a jet ski, a speedboat, a duck floatie and a
 * cruise ship. All the new ones sail from a little wooden pier at the near shore to a second pier on the far side,
 * so even the big ship never sits on dry land. Everything is drawn with rectangles; heights are measured up from the
 * hull bottom (two rows of which are under the waterline). Included by aw_engine.c after aw_road.inc.
 */

enum { B_SAIL, B_TUG, B_JET, B_SPEED, B_FLOAT, B_CRUISE, B_N };
/* cruise speed (px/s), length (px), trip length range (s), how quickly it gets up to speed, pier length (px; 0 = no pier) */
typedef struct { float speed, dlo, dhi, accel; int len, pier; } BoatP;
static const BoatP BOATP[B_N] = {
    { 32.0f, 11.0f, 15.0f, 1.2f, 36, 0 },      /* sailboat: as before, no pier */
    { 21.0f, 11.0f, 14.0f, 1.0f, 46, 40 },     /* tugboat */
    { 80.0f,  5.5f,  7.5f, 2.2f, 24, 28 },     /* jet ski */
    { 64.0f,  6.5f,  8.5f, 1.8f, 42, 38 },     /* speedboat */
    { 14.0f, 11.0f, 14.0f, 1.0f, 30, 30 },     /* duck floatie */
    { 18.0f, 11.0f, 14.0f, 0.7f, 92, 70 },     /* cruise ship */
};

/* (PIER_H, pier_deck and pier_near live in aw_engine.c next to the lake code) */

static void pier_span(AWWorld *w, double x0, double x1, int outer_right, int camI, float night) {
    int a = (int)floor(x0) - camI, b = (int)floor(x1) - camI;
    if (b < -6 || a > w->vw + 6) return;
    int top = w->gy - PIER_H;
    /* piles */
    for (int wx = (int)floor(x0); wx <= (int)floor(x1); wx++) {
        if (((wx - (int)floor(x0)) % 13) != 3) continue;
        int tt = w->gy - ground_h(w, wx);
        int yb = imin(tt, w->gy + 36);
        int x = wx - camI;
        for (int y = top + 3; y < yb; y++) {
            PX(w, x, y, 0x6B4A2A); PX(w, x + 1, y, 0x4F351E);
        }
        PX(w, x, top + 3, 0x9A7040);
    }
    /* deck */
    for (int x = a; x <= b; x++) {
        int wx = x + camI;
        PX(w, x, top, ((wx >> 2) & 1) ? 0xC89A5E : 0xB88A52);
        if (((wx + 1) & 7) == 0) PX(w, x, top, 0x7A5632);
        PX(w, x, top + 1, 0x8A6236);
        PX(w, x, top + 2, 0x4F351E);
    }
    /* a bollard and a lamp at the water end */
    int ex = outer_right ? b - 4 : a + 3;
    R(w, ex, top - 3, 3, 3, 0x4A4F5C); R(w, ex, top - 3, 3, 1, 0x7A8090);
    int lx = outer_right ? b - 1 : a + 1;
    R(w, lx, top - 12, 1, 12, 0x3A3F4C);
    R(w, lx - 1, top - 14, 3, 2, 0x3A3F4C);
    if (night > 0.25f) {
        int al = (int)(70.0f * night);
        for (int dy = -9; dy <= 9; dy++) for (int dx = -9; dx <= 9; dx++)
            if (dx * dx + dy * dy < 81 && ((dx + dy) & 1) == 0) BLEND(w, lx + dx, top - 12 + dy, 0xFFD27A, al * (81 - dx * dx - dy * dy) / 81);
        R(w, lx - 1, top - 14, 3, 2, 0xFFE9A8);
    } else R(w, lx - 1, top - 14, 3, 2, 0xC8CCD8);
}
static void draw_piers(AWWorld *w) {
    if (!w->lk_on || w->lk_pl <= 0) return;
    int camI = (int)floor(w->cam);
    float night = bg_night(w);
    pier_span(w, w->lk_x0 - 12.0, w->lk_x0 + (double)w->lk_pl, 1, camI, night);
    pier_span(w, w->lk_x1 - (double)w->lk_pl, w->lk_x1 + 12.0, 0, camI, night);
}

/* ---- the boats --------------------------------------------------------------------------------------------- */
static const Col B_TUGC[4] = { 0xD83A3A, 0x2F7BD8, 0x2FB05A, 0xFF8A2A };
static const Col B_JETC[5] = { 0xFF4FA0, 0x2FD4F0, 0xFFD23F, 0x7DDB5C, 0xFF6A2A };
static const Col B_SPDC[5] = { 0xE8442A, 0x2F7BD8, 0x2FC4B2, 0xFFD23F, 0xA77BF0 };
static const Col B_SHIPC[4] = { 0xC8383A, 0x2F7BD8, 0x1FA89A, 0xF08A2A };
#define NAVY 0x1A2448

static void nav_lights(AWWorld *w, int X0, int GY, int xb, int yb, float night) {   /* red + green at the bow when it is dark */
    if (night < 0.3f) return;
    vp(w, X0, GY, xb, yb, 0xFF4040); vp(w, X0, GY, xb, yb + 1, 0x40FF70);
}

static void boat_tug(AWWorld *w, int X0, int GY, uint32_t h, int blink, float night) {
    Col c = B_TUGC[h % 4u];
    vr(w, X0, GY, 4, 0, 37, 2, NAVY);                                                        /* below the waterline */
    vr(w, X0, GY, 1, 2, 44, 4, c); vr(w, X0, GY, 1, 2, 44, 1, mulc(c, 0.65f)); vr(w, X0, GY, 1, 5, 44, 1, lerpc(c, 0xFFFFFF, 0.3f));
    vr(w, X0, GY, 44, 5, 2, 2, c); vp(w, X0, GY, 45, 7, c);                                  /* raked bow */
    vr(w, X0, GY, 2, 6, 41, 1, 0xE6E6EE);                                                    /* rail */
    for (int i = 0; i < 6; i++) vr(w, X0, GY, 5 + i * 6, 3, 2, 2, 0x15101A);                 /* tyre fenders */
    vr(w, X0, GY, 3, 7, 3, 2, 0x4A4F5C); vr(w, X0, GY, 3, 9, 3, 1, 0x7A8090);                /* towing bitt */
    /* funnel with a white band and a black top */
    vr(w, X0, GY, 11, 7, 8, 16, c); vr(w, X0, GY, 17, 7, 2, 16, mulc(c, 0.75f));
    vr(w, X0, GY, 11, 15, 8, 2, 0xF4F4F8); vr(w, X0, GY, 11, 20, 8, 3, 0x23232E);
    vr(w, X0, GY, 17, 23, 1, 2, 0xFFD23F);                                                   /* whistle */
    /* wheelhouse */
    vr(w, X0, GY, 21, 7, 15, 9, 0xF4F4F8); vr(w, X0, GY, 21, 7, 15, 1, 0xC8CCD8);
    vr(w, X0, GY, 20, 16, 17, 1, c); vr(w, X0, GY, 21, 17, 15, 1, mulc(c, 0.7f));
    vr(w, X0, GY, 23, 9, 11, 5, NAVY);
    holo_window(w, X0 + 25, GY - 1 - 13, blink);
    vr(w, X0, GY, 21, 8, 1, 7, 0xD8DCE4);
    vp(w, X0, GY, 36, 9, 0xFF8A2A); vp(w, X0, GY, 36, 10, 0xFFFFFF);                          /* lifebuoy */
    /* mast and light */
    vr(w, X0, GY, 40, 7, 1, 11, 0x8A90A0); vr(w, X0, GY, 39, 17, 3, 1, 0xC8CCD8);
    vp(w, X0, GY, 40, 18, night > 0.3f ? 0xFFE070 : 0xE6E6F0);
    nav_lights(w, X0, GY, 44, 7, night);
}

static void boat_jet(AWWorld *w, int X0, int GY, uint32_t h, int blink, float night) {
    Col c = B_JETC[h % 5u];
    (void)night;
    draw_arch(w, X0 + 3, GY - 1 - 6 - 9, 4, blink, 0, 0);                                    /* rider first, bike-style */
    vr(w, X0, GY, 3, 0, 19, 2, NAVY);
    vr(w, X0, GY, 1, 2, 22, 3, c); vr(w, X0, GY, 22, 3, 2, 2, c); vp(w, X0, GY, 23, 5, lerpc(c, 0xFFFFFF, 0.3f));
    vr(w, X0, GY, 3, 3, 16, 1, 0xF4F4F8);                                                    /* stripe */
    vr(w, X0, GY, 2, 5, 18, 1, mulc(c, 0.8f));
    vr(w, X0, GY, 3, 5, 11, 2, 0x23232E); vr(w, X0, GY, 3, 6, 11, 1, 0x3A3A4A);              /* seat */
    vr(w, X0, GY, 0, 3, 3, 3, mulc(c, 0.7f));                                                /* tail */
    vr(w, X0, GY, 16, 5, 1, 5, 0x4A4F5C);                                                    /* steering column */
    vr(w, X0, GY, 14, 10, 5, 1, 0x23232E); vp(w, X0, GY, 14, 11, 0xC8CCD8); vp(w, X0, GY, 18, 11, 0xC8CCD8);
    vr(w, X0, GY, 18, 5, 3, 3, 0xBFE8FF);                                                    /* little screen */
    /* the rider's arms reach for the bars */
    vline(w, X0, GY, 11, 9, 15, 10, 0x3A2A52);
}

static void boat_speed(AWWorld *w, int X0, int GY, uint32_t h, int blink, float night) {
    Col c = B_SPDC[h % 5u];
    draw_arch(w, X0 + 9, GY - 1 - 8 - 9, 4, blink, 0, 0);                                    /* skipper first; the seat and windscreen go over him */
    vr(w, X0, GY, 3, 0, 34, 2, NAVY);
    vr(w, X0, GY, 0, 2, 36, 4, c); vr(w, X0, GY, 36, 3, 4, 3, c); vr(w, X0, GY, 40, 4, 2, 2, c); vp(w, X0, GY, 41, 6, c);
    vr(w, X0, GY, 0, 2, 36, 1, mulc(c, 0.6f));
    vr(w, X0, GY, 2, 3, 34, 1, 0xF4F4F8);                                                    /* white flash along the side */
    vr(w, X0, GY, 0, 5, 36, 1, 0xF4F4F8); vr(w, X0, GY, 36, 6, 5, 1, lerpc(c, 0xFFFFFF, 0.5f));
    vr(w, X0, GY, 7, 6, 11, 3, 0x2A2430); vr(w, X0, GY, 7, 8, 11, 1, 0x4A3A56);               /* seat */
    vr(w, X0, GY, 6, 6, 2, 6, 0x2A2430);                                                     /* back rest */
    vline(w, X0, GY, 22, 6, 26, 11, 0xBFE8FF); vline(w, X0, GY, 23, 6, 27, 11, 0xBFE8FF); vr(w, X0, GY, 21, 6, 2, 3, 0x4A4F5C);
    vr(w, X0, GY, 28, 6, 8, 1, mulc(c, 1.1f));
    vr(w, X0, GY, -2, 1, 3, 8, 0x2A2A38); vr(w, X0, GY, -3, 3, 1, 3, 0x555B6B); vr(w, X0, GY, -1, 9, 2, 1, 0x555B6B);   /* outboard */
    vr(w, X0, GY, 1, 6, 1, 8, 0x8A90A0);                                                     /* flag staff */
    int fl = (((int)(w->t * 7.0f)) & 1);
    vr(w, X0, GY, 2, 12, 4 - fl, 2, 0xFF4040);
    nav_lights(w, X0, GY, 40, 4, night);
}

static void boat_float(AWWorld *w, int X0, int GY, uint32_t h, int blink, float night) {
    static const Col DUCK[4] = { 0xFFD23F, 0xFF7AB0, 0x6FD0FF, 0xF4F4F8 };
    Col yl = DUCK[h % 4u];
    (void)night;
    draw_arch(w, X0 + 8, GY - 1 - 4 - 9, 4, blink, 0, 0);                                    /* he sits in the ring */
    /* ring, with the front rim over his legs */
    vr(w, X0, GY, 2, 1, 24, 1, mulc(yl, 0.8f));
    vr(w, X0, GY, 1, 2, 26, 3, yl); vr(w, X0, GY, 1, 2, 26, 1, mulc(yl, 0.85f));
    vr(w, X0, GY, 2, 5, 24, 1, lerpc(yl, 0xFFFFFF, 0.45f));
    vr(w, X0, GY, 4, 3, 4, 1, lerpc(yl, 0xFFFFFF, 0.55f));
    /* the duck's head and beak at the front, a tail at the back */
    vr(w, X0, GY, 22, 6, 5, 5, yl); vr(w, X0, GY, 22, 6, 1, 5, mulc(yl, 0.85f)); vr(w, X0, GY, 23, 10, 3, 1, lerpc(yl, 0xFFFFFF, 0.4f));
    vp(w, X0, GY, 25, 8, 0x15101A);
    vr(w, X0, GY, 27, 7, 3, 2, 0xFF8A2A); vr(w, X0, GY, 27, 7, 3, 1, 0xFFB45A);
    vr(w, X0, GY, 0, 5, 3, 3, yl); vp(w, X0, GY, 0, 8, yl);
    /* a pink drink with a straw, on the rim */
    vr(w, X0, GY, 3, 6, 2, 3, 0xFF5AA0); vr(w, X0, GY, 3, 8, 2, 1, 0xFFB0D0); vp(w, X0, GY, 4, 9, 0xFFFFFF); vp(w, X0, GY, 5, 10, 0xFFFFFF);
}

static void boat_cruise(AWWorld *w, int X0, int GY, uint32_t h, int blink, float night) {
    Col sc = B_SHIPC[h % 4u];
    float t = (float)w->t;
    int lit = night > 0.35f;
    /* hull: columns, so the bow can rake and the stern can tuck in */
    for (int x = 0; x < 92; x++) {
        int hb = 2, ht = 9;
        if (x < 7) hb = 2 + (7 - x) / 2 + (x < 3 ? 1 : 0);
        if (x >= 84) hb = 2 + (x - 83);
        if (x >= 80) ht = 9 + (x - 79) / 3;
        if (hb >= ht) continue;
        for (int y = hb; y < ht; y++) {
            Col c = y < 4 ? sc : 0xF4F4F8;
            if (y == 3) c = mulc(sc, 0.8f);
            if (y == ht - 1) c = 0xC8CCD8;
            vp(w, X0, GY, x, y, c);
        }
    }
    vr(w, X0, GY, 8, 0, 78, 2, NAVY);                                                        /* waterline paint, mostly below the surface */
    for (int x = 10; x < 82; x += 4) vp(w, X0, GY, x, 6, NAVY);                              /* portholes */
    /* decks with their windows */
    struct { int x0, x1, y0, rows, wy; } D[3] = { { 8, 80, 9, 6, 11 }, { 16, 70, 15, 5, 16 }, { 26, 60, 20, 4, 21 } };
    for (int d = 0; d < 3; d++) {
        vr(w, X0, GY, D[d].x0, D[d].y0, D[d].x1 - D[d].x0, D[d].rows, 0xF4F4F8);
        vr(w, X0, GY, D[d].x0 - 1, D[d].y0 + D[d].rows - 1, D[d].x1 - D[d].x0 + 2, 1, 0xC8CCD8);
        for (int x = D[d].x0 + 2; x < D[d].x1 - 1; x += 3) {
            uint32_t q = hash2(h + (uint32_t)d * 31u, (uint32_t)x);
            Col wc = lit ? (q % 5u == 0u ? 0x2A4C86 : 0xFFD36B) : 0x2A4C86;
            vr(w, X0, GY, x, D[d].wy, 2, 2, wc);
            if (!lit && (q & 7u) == 0u) vp(w, X0, GY, x, D[d].wy + 1, 0x6F9CE0);
        }
        vr(w, X0, GY, D[d].x0, D[d].y0, D[d].x1 - D[d].x0, 1, mulc(0xF4F4F8, 0.82f));
    }
    /* bridge up front, with Archon in the window */
    vr(w, X0, GY, 70, 15, 12, 6, 0xF4F4F8); vr(w, X0, GY, 69, 20, 14, 1, 0xC8CCD8); vr(w, X0, GY, 72, 16, 9, 4, NAVY);
    holo_window(w, X0 + 73, GY - 1 - 19, blink);
    vr(w, X0, GY, 75, 21, 1, 6, 0x8A90A0);                                                  /* mast, radar, pennant */
    vr(w, X0, GY, 73, 26, 5, 1, 0xC8CCD8);
    int fl = ((int)(t * 6.0f)) & 1;
    vr(w, X0, GY, 76, 26, 3 + fl, 1, 0xFF4040); vr(w, X0, GY, 76, 25, 2 + fl, 1, 0xFF4040);
    /* pool deck: a waterslide and a funnel */
    vr(w, X0, GY, 28, 24, 1, 4, 0x8A90A0); vr(w, X0, GY, 36, 24, 1, 2, 0x8A90A0);
    vline(w, X0, GY, 28, 28, 36, 26, 0xFFD23F); vline(w, X0, GY, 28, 27, 36, 25, 0xFF8A2A);
    vr(w, X0, GY, 44, 24, 11, 9, sc); vr(w, X0, GY, 52, 24, 3, 9, mulc(sc, 0.75f));
    vr(w, X0, GY, 44, 28, 11, 1, 0xF4F4F8); vr(w, X0, GY, 44, 31, 11, 2, NAVY);
    vp(w, X0, GY, 48, 29, 0xF4F4F8); vp(w, X0, GY, 49, 30, 0xF4F4F8); vp(w, X0, GY, 50, 29, 0xF4F4F8);   /* wave logo */
    /* lifeboats */
    for (int i = 0; i < 4; i++) { int lx = 14 + i * 13; if (lx + 5 > 44 && lx < 56) continue; vr(w, X0, GY, lx, 14, 6, 1, 0xFF8A2A); vr(w, X0, GY, lx + 1, 15, 4, 1, 0xD8631A); }
    nav_lights(w, X0, GY, 90, 11, night);
    if (lit) { vp(w, X0, GY, 75, 27, 0xFFE070); }
}

static void draw_h_vessel(AWWorld *w, int sx, int sy, int blink) {
    const BoatP *bp = &BOATP[w->boat];
    float t = (float)w->t;
    uint32_t h = hash2(w->seed ^ 0xB0A7u, w->lk_seed);
    float night = bg_night(w);
    int moving = w->spd > 20.0f;
    int bob;
    switch (w->boat) {
        case B_JET:    bob = (moving && sinf(t * 11.0f) > 0.3f) ? 1 : 0; break;
        case B_SPEED:  bob = (moving && sinf(t * 8.0f) > 0.5f) ? 1 : 0; break;
        case B_FLOAT:  bob = (int)floorf(sinf(t * 1.7f) * 1.0f + 0.5f); break;
        case B_CRUISE: bob = (int)floorf(sinf(t * 0.8f) * 0.9f + 0.5f); break;
        default:       bob = (int)floorf(sinf(t * 1.9f) * 0.8f + 0.5f); break;
    }
    int X0 = sx - bp->len / 2, GY = sy + 3 + bob;
    switch (w->boat) {
        case B_TUG:    boat_tug(w, X0, GY, h, blink, night); break;
        case B_JET:    boat_jet(w, X0, GY, h, blink, night); break;
        case B_SPEED:  boat_speed(w, X0, GY, h, blink, night); break;
        case B_FLOAT:  boat_float(w, X0, GY, h, blink, night); break;
        default:       boat_cruise(w, X0, GY, h, blink, night); break;
    }
}
