/*
 * Archon's Life - optional live weather (see aw_weather.h).
 *
 * Portable C99 + a tiny thread shim. HTTP is supplied by the platform layer.
 * Deliberately small and defensive: every failure just means "no temperature sign".
 */
#include "aw_weather.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
static unsigned long long mono_ms(void) { return (unsigned long long)GetTickCount64(); }
static void sleep_ms(int ms) { Sleep((DWORD)ms); }
#else
#include <pthread.h>
#include <sched.h>
#include <time.h>
static unsigned long long mono_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (unsigned long long)ts.tv_sec * 1000ull + (unsigned long long)(ts.tv_nsec / 1000000);
}
static void sleep_ms(int ms) {
    struct timespec ts;
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (long)(ms % 1000) * 1000000L;
    nanosleep(&ts, NULL);
}
#endif

/* ------------------------------------------------------------------ */
/* country defaults                                                    */
/* ------------------------------------------------------------------ */
static int in_list(const char *cc, const char *const *list) {
    if (!cc || !cc[0] || !cc[1]) return 0;
    for (; *list; list++) if ((*list)[0] == cc[0] && (*list)[1] == cc[1]) return 1;
    return 0;
}
int aw_country_uses_fahrenheit(const char *cc) {
    static const char *const f[] = { "US", "PR", "GU", "VI", "AS", "MP", "UM", "BS", "BZ", "KY", "PW", "FM", "MH", "LR", NULL };
    return in_list(cc, f);
}
int aw_country_uses_12h(const char *cc) {
    static const char *const h[] = { "US", "PR", "GU", "VI", "AS", "CA", "AU", "NZ", "IN", "PH", "EG", "SA", "CO", "PK", "BD", "MY", NULL };
    return in_list(cc, h);
}

/* ------------------------------------------------------------------ */
/* tiny JSON helpers (flat lookups are all we need)                    */
/* ------------------------------------------------------------------ */
static const char *skip_ws(const char *p) {
    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
    return p;
}

/* Find  "key" : value  and return a pointer at the start of value, or NULL. */
static const char *find_key(const char *json, const char *key) {
    char pat[40];
    size_t kl = strlen(key);
    if (kl + 3 > sizeof pat) return NULL;
    pat[0] = '"'; memcpy(pat + 1, key, kl); pat[kl + 1] = '"'; pat[kl + 2] = 0;
    const char *p = json;
    while ((p = strstr(p, pat)) != NULL) {
        const char *q = skip_ws(p + kl + 2);
        if (*q == ':') return skip_ws(q + 1);
        p += kl + 2;
    }
    return NULL;
}

/* Locale-independent number parse (strtod would honour a comma-decimal locale). Accepts "12.5" and 12.5. */
static int parse_num(const char *p, double *out) {
    if (*p == '"') p++;
    int neg = 0;
    if (*p == '-') { neg = 1; p++; } else if (*p == '+') p++;
    if (*p < '0' || *p > '9') return 0;
    double v = 0.0;
    while (*p >= '0' && *p <= '9') { v = v * 10.0 + (double)(*p - '0'); p++; }
    if (*p == '.') {
        double f = 0.1;
        p++;
        while (*p >= '0' && *p <= '9') { v += f * (double)(*p - '0'); f *= 0.1; p++; }
    }
    if (*p == 'e' || *p == 'E') {
        p++;
        int eneg = 0, e = 0;
        if (*p == '-') { eneg = 1; p++; } else if (*p == '+') p++;
        while (*p >= '0' && *p <= '9' && e < 400) { e = e * 10 + (*p - '0'); p++; }
        v *= pow(10.0, eneg ? -e : e);
    }
    *out = neg ? -v : v;
    return 1;
}

int aw_parse_geo(const char *json, double *lat, double *lon, char cc[3]) {
    if (!json || !lat || !lon) return 0;
    const char *s = find_key(json, "success");
    if (s && s[0] == 'f') return 0;                 /* ipwho.is reports failures this way */
    const char *a = find_key(json, "latitude"), *b = find_key(json, "longitude");
    double la, lo;
    if (!a || !b || !parse_num(a, &la) || !parse_num(b, &lo)) return 0;
    if (la < -90.0 || la > 90.0 || lo < -180.0 || lo > 180.0) return 0;
    if (la == 0.0 && lo == 0.0) return 0;           /* "null island" = unknown */
    *lat = la; *lon = lo;
    if (cc) {
        cc[0] = cc[1] = cc[2] = 0;
        const char *c = find_key(json, "country_code");
        if (c && c[0] == '"' && c[1] >= 'A' && c[1] <= 'Z' && c[2] >= 'A' && c[2] <= 'Z') { cc[0] = c[1]; cc[1] = c[2]; }
    }
    return 1;
}

int aw_parse_weather(const char *json, float *temp_c, int *code, int *is_day) {
    if (!json) return 0;
    const char *cur = find_key(json, "current");     /* skips "current_units" on purpose */
    if (!cur || *cur != '{') return 0;
    const char *t = find_key(cur, "temperature_2m");
    double tv, cv = 0.0, dv = 1.0;
    if (!t || !parse_num(t, &tv)) return 0;
    if (tv < -90.0 || tv > 65.0) return 0;
    const char *c = find_key(cur, "weather_code");
    if (c) parse_num(c, &cv);
    const char *d = find_key(cur, "is_day");
    if (d) parse_num(d, &dv);
    if (temp_c) *temp_c = (float)tv;
    if (code) *code = (int)cv;
    if (is_day) *is_day = dv >= 0.5 ? 1 : 0;
    return 1;
}

/* ------------------------------------------------------------------ */
/* shared state + worker                                               */
/* ------------------------------------------------------------------ */
#define REFRESH_MS   (20ull * 60ull * 1000ull)
#define STALE_MS     (3ull * 60ull * 60ull * 1000ull)
#define REGEO_MS     (6ull * 60ull * 60ull * 1000ull)
#define ACTIVE_MS    60000ull          /* worker only works while someone polled in the last minute */

static struct {
    volatile int lock;
    int refs, running;
    unsigned long long last_use;
    AWWeather snap;
    unsigned long long snap_ms;        /* 0 = no reading yet */
} G;

static void lock_(void) { while (__sync_lock_test_and_set(&G.lock, 1)) sleep_ms(1); }
static void unlock_(void) { __sync_lock_release(&G.lock); }

/* "47.6" style, no locale surprises */
static void fmt_tenths(char *dst, double v) {
    int t = (int)floor(v * 10.0 + 0.5);
    int neg = t < 0;
    if (neg) t = -t;
    char tmp[16]; int n = 0;
    int whole = t / 10, frac = t % 10;
    if (whole == 0) tmp[n++] = '0';
    while (whole > 0) { tmp[n++] = (char)('0' + whole % 10); whole /= 10; }
    char *d = dst;
    if (neg) *d++ = '-';
    while (n > 0) *d++ = tmp[--n];
    *d++ = '.'; *d++ = (char)('0' + frac); *d = 0;
}

static int fetch_geo(double *lat, double *lon, char cc[3]) {
    static const char *const urls[] = { "https://ipwho.is/", "https://get.geojs.io/v1/ip/geo.json", NULL };
    static char buf[8192];
    for (int i = 0; urls[i]; i++) {
        int n = aw_http_get(urls[i], buf, (int)sizeof buf);
        if (n > 0 && aw_parse_geo(buf, lat, lon, cc)) return 1;
    }
    return 0;
}

static int fetch_weather(double lat, double lon, float *t, int *code, int *day) {
    static char buf[8192];
    char url[256], a[24], b[24];
    fmt_tenths(a, lat); fmt_tenths(b, lon);
    strcpy(url, "https://api.open-meteo.com/v1/forecast?latitude=");
    strcat(url, a); strcat(url, "&longitude="); strcat(url, b);
    strcat(url, "&current=temperature_2m,weather_code,is_day&timezone=auto");
    int n = aw_http_get(url, buf, (int)sizeof buf);
    return n > 0 && aw_parse_weather(buf, t, code, day);
}

static unsigned long long backoff_ms(int fails) {
    static const unsigned long long t[] = { 30000ull, 60000ull, 120000ull, 300000ull, 600000ull };
    int i = fails - 1;
    if (i < 0) i = 0;
    if (i > 4) i = 4;
    return t[i];
}

static void worker_body(void) {
    double lat = 0.0, lon = 0.0;
    int have_loc = 0, fails = 0;
    char cc[3] = { 0, 0, 0 };
    unsigned long long geo_ms = 0, next_try = 0;
    for (;;) {
        unsigned long long now = mono_ms();
        lock_();
        int active = (now - G.last_use) < ACTIVE_MS;
        unlock_();
        if (!active) { sleep_ms(2000); continue; }
        if (now < next_try) { sleep_ms(500); continue; }
        if (have_loc && now - geo_ms > REGEO_MS) have_loc = 0;     /* laptop may have moved */
        if (!have_loc) {
            if (fetch_geo(&lat, &lon, cc)) { have_loc = 1; geo_ms = mono_ms(); }
            else { fails++; next_try = mono_ms() + backoff_ms(fails); continue; }
        }
        float t = 0.0f; int code = 0, day = 1;
        if (fetch_weather(lat, lon, &t, &code, &day)) {
            lock_();
            G.snap.valid = 1; G.snap.temp_c = t; G.snap.wmo_code = code; G.snap.is_day = day;
            G.snap.country[0] = cc[0]; G.snap.country[1] = cc[1]; G.snap.country[2] = 0;
            G.snap_ms = mono_ms();
            unlock_();
            fails = 0;
            next_try = mono_ms() + REFRESH_MS;
        } else {
            fails++;
            next_try = mono_ms() + backoff_ms(fails);
        }
    }
}

#ifdef _WIN32
static DWORD WINAPI worker_main(LPVOID arg) { (void)arg; worker_body(); return 0; }
static int spawn_worker(void) {
    HANDLE h = CreateThread(NULL, 0, worker_main, NULL, 0, NULL);
    if (!h) return 0;
    CloseHandle(h);
    return 1;
}
#else
static void *worker_main(void *arg) { (void)arg; worker_body(); return NULL; }
static int spawn_worker(void) {
    pthread_t th;
    pthread_attr_t at;
    pthread_attr_init(&at);
    pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
    int rc = pthread_create(&th, &at, worker_main, NULL);
    pthread_attr_destroy(&at);
    return rc == 0;
}
#endif

void aw_weather_start(void) {
    lock_();
    G.refs++;
    G.last_use = mono_ms();
    int need = !G.running;
    if (need) G.running = 1;
    unlock_();
    if (need && !spawn_worker()) { lock_(); G.running = 0; unlock_(); }
}

void aw_weather_stop(void) {
    lock_();
    if (G.refs > 0) G.refs--;
    unlock_();
    /* The thread is never torn down: with no readers it parks (see ACTIVE_MS) and the process
     * ends with the saver. That keeps unloading a .saver bundle safe. */
}

int aw_weather_get(AWWeather *out) {
    if (!out) return 0;
    unsigned long long now = mono_ms();
    lock_();
    G.last_use = now;
    *out = G.snap;
    if (!G.snap_ms || now - G.snap_ms > STALE_MS) out->valid = 0;
    unlock_();
    return out->valid;
}
