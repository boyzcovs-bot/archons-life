/*
 * Archon's Life - the deep dive.
 * Archon swims out in a mask and either snorkels along the surface above a shallow reef, or goes deep with a tank
 * past a sunken pirate ship, a giant clam, an octopus lair, squid and schools of small fish.
 * Included at the end of aw_extra.inc. Everything here is a pure function of the lake seed, world x and time.
 */

/* ------------------------------------------------------------------ */
/* clipped drawing: anything standing on the sea floor is cut off at the sand */
/* ------------------------------------------------------------------ */
static void dvR(AWWorld *w, int x, int y, int ww, int hh, Col c, int ymax) {
    if (y + hh > ymax) hh = ymax - y;
    if (hh > 0 && ww > 0) R(w, x, y, ww, hh, c);
}
static void dvP(AWWorld *w, int x, int y, Col c, int ymax) { if (y < ymax) PX(w, x, y, c); }
static void dvB(AWWorld *w, int x, int y, Col c, int a, int ymax) { if (y < ymax) BLEND(w, x, y, c, a); }

/* ------------------------------------------------------------------ */
/* Archon, diving                                                      */
/* ------------------------------------------------------------------ */
static void dv_fin(AWWorld *w, int x, int y, int k) {          /* a swim fin trailing to the left, tip kicking by k */
    for (int i = 0; i < 8; i++) {
        int dy = (i * k) / 4;
        PX(w, x - i, y + dy, 0x1D3A78);
        PX(w, x - i, y + dy + 1, i < 6 ? 0x2F5FA8 : 0x4FA6F5);
        if (i > 0 && i < 7) PX(w, x - i, y + dy + 2, 0x1D3A78);
    }
}

static void draw_h_dive(AWWorld *w, int sx, int sy, int blink) {
    float t = (float)w->t;
    int scuba = w->dive_kind;
    int bob = (int)floorf(sinf(t * (w->alt > -3.0f ? 2.0f : 1.1f)) + 0.5f);
    int x0 = sx - 6, y0;
    if (scuba) y0 = sy - 12 + (int)(clampf((w->alt + 10.0f) / 10.0f, 0.0f, 1.0f) * 4.0f + 0.5f) + bob;
    else y0 = sy - 6 + bob;
    const Col NAVY = 0x1D3A78, HOSE = 0x2A2F3E;
    {   /* a soft glow so he reads against the dark water */
        float deepk = scuba ? clampf(-w->alt / 20.0f, 0.0f, 1.0f) : 0.25f;
        int rad = 15;
        for (int dy = -rad; dy <= rad; dy++) for (int dx = -rad; dx <= rad; dx++) {
            int d2 = dx * dx + dy * dy;
            if (d2 > rad * rad || ((dx + dy) & 1) != 0) continue;
            int a = (int)(34.0f * deepk * (1.0f - (float)d2 / (float)(rad * rad)));
            if (a > 0) BLEND(w, x0 + 6 + dx, y0 + 6 + dy, 0xBFEFFF, a);
        }
    }

    if (scuba && w->alt < -12.0f) {   /* his lamp */
        for (int dy = -10; dy <= 10; dy++) for (int dx = 0; dx <= 44; dx++) {
            if (((dx + dy) & 1) != 0) continue;
            if (abs(dy) * 4 > dx + 6) continue;
            int al = (int)(44.0f * (1.0f - (float)dx / 44.0f));
            if (al > 0) BLEND(w, x0 + 13 + dx, y0 + 5 + dy, 0xFFF59A, al);
        }
    }
    if (scuba) {   /* the air tank on his back, drawn first so he floats in front of it */
        R(w, x0 - 6, y0 + 3, 6, 11, 0xF2C230); R(w, x0 - 5, y0 + 2, 4, 1, 0xF2C230); R(w, x0 - 4, y0 + 1, 2, 1, 0xF2C230);
        R(w, x0 - 6, y0 + 3, 1, 11, 0xFFE88A); R(w, x0 - 1, y0 + 3, 1, 11, 0xB88A1A);
        R(w, x0 - 6, y0 + 6, 6, 1, 0x6A7088); R(w, x0 - 6, y0 + 10, 6, 1, 0x6A7088);
        R(w, x0 - 4, y0 - 1, 2, 2, 0x8FA3C0); PX(w, x0 - 3, y0 - 2, 0xC9D8EE);
    }
    /* legs and fins */
    float kc = sinf(t * (scuba ? 6.0f : 8.5f));
    dv_fin(w, x0 + 3, y0 + 12, (int)floorf(kc * 3.0f + 0.5f));
    dv_fin(w, x0 + 9, y0 + 12, (int)floorf(-kc * 3.0f + 0.5f));
    draw_arch(w, x0, y0, 0, blink, 0, 0);
    /* mask */
    R(w, x0 + 1, y0 + 3, 10, 1, NAVY); R(w, x0 + 1, y0 + 3, 1, 5, NAVY); R(w, x0 + 10, y0 + 3, 1, 5, NAVY);
    R(w, x0 + 1, y0 + 7, 4, 1, NAVY); R(w, x0 + 7, y0 + 7, 4, 1, NAVY); R(w, x0 + 5, y0 + 6, 2, 1, NAVY);
    for (int dy = 4; dy <= 6; dy++) for (int dx = 2; dx <= 9; dx++) BLEND(w, x0 + dx, y0 + dy, 0xBFEFFF, 64);
    PX(w, x0 + 2, y0 + 4, 0xFFFFFF); PX(w, x0 + 3, y0 + 4, 0xDFF8FF);
    R(w, x0 - 2, y0 + 5, 3, 1, NAVY);
    /* mouthpiece */
    R(w, x0 + 4, y0 + 7, 4, 1, HOSE);
    if (scuba) {      /* the regulator hose runs back to the tank */
        R(w, x0 + 1, y0 + 8, 4, 1, HOSE); R(w, x0 - 1, y0 + 8, 2, 1, HOSE); R(w, x0 - 1, y0 + 1, 1, 7, HOSE);
        PX(w, x0 - 2, y0, HOSE); PX(w, x0 - 3, y0 - 1, HOSE);
        PX(w, x0 + 3, y0 + 8, 0x6A7088); PX(w, x0, y0 + 4, 0x6A7088);
    } else {          /* the snorkel */
        R(w, x0 + 1, y0 + 8, 4, 1, 0xFF8A2A);
        for (int i = -7; i <= 7; i++) R(w, x0 + 0, y0 + i, 2, 1, (i & 2) ? 0xFFD23F : 0xFF8A2A);
        R(w, x0 + 0, y0 - 8, 2, 1, 0xFFFFFF); PX(w, x0 + 2, y0 - 7, 0xFFFFFF);
    }
}

/* ------------------------------------------------------------------ */
/* the sunken pirate ship                                              */
/* ------------------------------------------------------------------ */
static void dv_hull(int lx, int yb, int *top, int *bottom) {
    float u = (float)lx / 46.0f, au = fabsf(u);
    int bot = yb - (int)((float)(lx + 46) * 0.13f) - (int)(9.0f * au * au * au);
    float hh = 13.0f + 9.0f * (1.0f - u * u);
    if (u < -0.50f) hh += (-0.50f - u) * 26.0f;          /* the tall stern castle */
    if (u > 0.60f) hh += (u - 0.60f) * 16.0f;            /* the upswept bow */
    *bottom = bot; *top = bot - (int)hh;
}
static void dv_wreck(AWWorld *w, int cx, int base, int bury, uint32_t h, float t) {
    int ymax = base + 1, yb = base + bury + 2;
    const Col W1 = 0x7A5632, W2 = 0x654428, WD = 0x3A2616, WL = 0x9A7040, ALG = 0x3F7A52;
    int holeA = -16 + (int)(rfn(h, 1) * 12.0f);      /* a hole torn in the hull */
    /* the hull: a rounded keel resting in the sand, bow cocked up */
    for (int lx = -46; lx <= 46; lx++) {
        int top, bottom; dv_hull(lx, yb, &top, &bottom);
        int x = cx + lx;
        for (int y = top; y < bottom; y++) {
            int dr = y - top;
            Col c = ((dr / 3) & 1) ? W1 : W2;
            if ((lx + 60) % 9 == 0) c = WD;                 /* plank seams */
            if (dr == 0) c = WL;
            else if (dr == 1) c = W1;
            if (dr == 11 && lx > -44 && lx < 44) c = 0x8E3A20;      /* the red stripe */
            if (y == bottom - 1 || y == bottom - 2) c = WD;
            int hole = lx >= holeA && lx <= holeA + 13 && dr > 4 && y < bottom - 3;
            if (hole) {
                c = 0x1A1410;
                if (((lx - holeA) & 3) == 0) c = W2;          /* the ribs show through */
                if ((lx - holeA) == 13 || (lx - holeA) == 0) c = WD;
            } else {
                uint32_t q = hash2(h, (uint32_t)(lx * 31 + y * 7));
                if (dr < 3 && (q & 3u) != 0u) c = lerpc(c, ALG, 0.55f);                     /* algae on the rail */
                else if (dr > 3 && (q % 53u) == 0u) c = lerpc(c, ALG, 0.5f);
                else if (dr > 6 && (q % 41u) == 0u) c = 0xCFC9B8;                           /* barnacles */
            }
            dvP(w, x, y, c, ymax);
        }
        /* rail posts, some of them snapped */
        if (lx > -26 && lx < 40 && ((lx + 60) % 6) == 0 && (hash2(h, (uint32_t)(lx + 300)) & 3u) != 0u) dvR(w, x, top - 3, 1, 3, WD, ymax);
        /* gun ports along the side */
        if (((lx + 58) % 14) == 0 && lx > -30 && lx < 40) {
            int py = top + 6;
            dvR(w, x, py, 4, 3, 0x1A1410, ymax); dvR(w, x, py, 4, 1, WD, ymax);
            if (((lx + 58) / 14) % 2 == 0) dvR(w, x + 3, py + 1, 3, 2, 0x4A4F5C, ymax);   /* a cannon still poking out */
        }
        if (lx >= -42 && lx <= -33 && ((lx + 42) % 5) < 3) dvR(w, x, top + 6, 1, 4, 0xC8A850, ymax);   /* stern windows, still glowing */
    }
    { int tp, bt; dv_hull(46, yb, &tp, &bt);                       /* the bowsprit */
      for (int i = 0; i < 14; i++) dvP(w, cx + 46 + i, tp - i / 2, i & 1 ? WD : W1, ymax);
      for (int i = 0; i < 9; i++) dvP(w, cx + 50 + i, tp + 3 - i / 2, 0xB8AE96, ymax);   /* a rotted jib */
    }
    /* the broken mast, its yard and the torn sail */
    int deck, tmp; dv_hull(-8, yb, &deck, &tmp);
    int mx = cx - 8, mt = deck - 36;
    dvR(w, mx, mt, 3, 37, W1, ymax); dvR(w, mx, mt, 1, 37, WL, ymax); dvR(w, mx + 2, mt, 1, 37, WD, ymax);
    PX(w, mx - 1, mt, WD); PX(w, mx + 3, mt - 1, W2); PX(w, mx + 1, mt - 2, WD);                       /* splintered top */
    dvR(w, mx - 4, mt + 8, 11, 2, WL, ymax);                                                              /* crow's nest */
    dvR(w, mx - 4, mt + 5, 1, 3, WD, ymax); dvR(w, mx + 6, mt + 5, 1, 3, WD, ymax);
    int yy = mt + 15;                                                                                     /* the yard */
    for (int i = -15; i <= 16; i++) dvP(w, mx + 1 + i, yy + i / 9, i % 7 == 0 ? WD : W1, ymax);
    for (int i = -13; i <= 14; i++) {                                                                     /* tattered sail, rippling in the current */
        float ph = t * 1.4f + (float)i * 0.35f;
        int len = 12 - (abs(i) * 5) / 12 - (int)(3.0f * (hash2(h, (uint32_t)(i + 99)) & 3u) / 3.0f);
        int ox = (int)floorf(sinf(ph) * 1.4f + 0.5f);
        for (int j = 0; j < len; j++) {
            int hole = ((i * 7 + j * 3) % 11) == 0;
            if (hole) continue;
            dvB(w, mx + 1 + i + ox, yy + 1 + j + i / 9, j > len - 3 ? 0xB8AE96 : 0xE6DDC4, 225, ymax);
        }
    }
    { int ft, fb; dv_hull(22, yb, &ft, &fb);                                                              /* a snapped foremast */
      dvR(w, cx + 21, ft - 11, 3, 12, W1, ymax); dvR(w, cx + 21, ft - 11, 1, 12, WL, ymax); PX(w, cx + 22, ft - 12, WD); PX(w, cx + 24, ft - 11, WD); }
    /* the pirate flag */
    {
        int fx = mx + 3, fy = mt - 3, rip = (int)floorf(sinf(t * 2.2f) * 0.8f + 0.5f);
        dvR(w, fx, fy - 4, 1, 8, WD, ymax);
        for (int i = 0; i < 10; i++) dvR(w, fx + 1 + i, fy - 4 + ((i / 3 + rip) & 1), 1, 6, 0x15151C, ymax);
        dvP(w, fx + 4, fy - 3, 0xF4F4F4, ymax); dvP(w, fx + 5, fy - 3, 0xF4F4F4, ymax); dvP(w, fx + 4, fy - 2, 0xF4F4F4, ymax); dvP(w, fx + 5, fy - 2, 0xF4F4F4, ymax);
        dvP(w, fx + 3, fy - 2, 0x15151C, ymax); dvP(w, fx + 6, fy - 2, 0x15151C, ymax); dvP(w, fx + 4, fy - 1, 0xF4F4F4, ymax); dvP(w, fx + 5, fy - 1, 0xF4F4F4, ymax);
        dvP(w, fx + 3, fy + 0, 0xF4F4F4, ymax); dvP(w, fx + 6, fy + 0, 0xF4F4F4, ymax);       /* crossbones */
    }
    /* anchor at the bow */
    {
        int ax = cx + 52, ay = base - 1;
        dvR(w, ax, ay - 12, 1, 11, 0x4A4F5C, ymax); dvR(w, ax - 2, ay - 12, 5, 1, 0x4A4F5C, ymax);
        for (int i = -4; i <= 4; i++) dvP(w, ax + i, ay - 2 + (abs(i) > 2 ? -(abs(i) - 2) : 0), 0x4A4F5C, ymax);
        dvP(w, ax - 4, ay - 4, 0x4A4F5C, ymax); dvP(w, ax + 4, ay - 4, 0x4A4F5C, ymax);
    }
    /* spilled treasure beside the hole */
    {
        int gx = cx + holeA + 2;
        ell_fill(w, gx, base - 1, 8.0f, 3.0f, 0, 0xE0A02A, ymax);
        ell_fill(w, gx - 1, base - 3, 5.0f, 2.0f, 0, 0xFFD23F, ymax);
        for (int i = 0; i < 9; i++) { uint32_t q = hash2(h, (uint32_t)(i + 700)); dvP(w, gx - 8 + (int)(rfn(q, 0) * 16.0f), base - 4 + (int)(rfn(q, 1) * 4.0f), rfn(q, 2) < 0.4f ? 0xFFF59A : 0xFFD23F, ymax); }
        if (sinf(t * 2.4f + rfn(h, 5) * 6.0f) > 0.55f) { PX(w, gx + 1, base - 5, 0xFFFFFF); PX(w, gx, base - 6, 0xFFFFFF); PX(w, gx + 2, base - 6, 0xFFFFFF); PX(w, gx + 1, base - 7, 0xFFFFFF); }
        dvR(w, gx + 9, base - 6, 7, 5, 0x8A5A2B, ymax); dvR(w, gx + 9, base - 6, 7, 1, 0xA06C35, ymax); dvR(w, gx + 9, base - 4, 7, 1, 0xFFD23F, ymax);   /* a broken chest */
    }
    /* seaweed draped over the stern */
    for (int i = 0; i < 3; i++) {
        int sx0 = cx - 44 + i * 4, len = 8 + (int)(rfn(h, 10 + i) * 8.0f);
        for (int j = 0; j < len; j++) {
            int sw = (int)floorf(sinf(t * 1.2f + (float)j * 0.3f + (float)i) * (0.4f + (float)j * 0.05f) + 0.5f);
            dvR(w, sx0 + sw, base - 12 - j - bury / 2, 2, 1, (j % 5 < 2) ? 0x2FA85A : 0x1F8A48, ymax);
        }
    }
}

/* ------------------------------------------------------------------ */
/* the giant clam                                                      */
/* ------------------------------------------------------------------ */
static void dv_clam(AWWorld *w, int cx, int base, uint32_t h, float t) {
    int ymax = base + 1;
    float cyc = fmodf(t * 0.15f + rfn(h, 1), 1.0f);
    float f = cyc < 0.42f ? sstep(0.0f, 0.42f, cyc) : (cyc < 0.80f ? 1.0f : (cyc < 0.85f ? 1.0f - (cyc - 0.80f) / 0.05f : 0.0f));
    float th = f * 0.62f;                                      /* how far the upper shell is raised (radians) */
    float cs = cosf(th), sn = sinf(th);
    const Col SH = 0xE6D8B4, SHD = 0xB8A57C, SHL = 0xFFF3D2, ALG = 0x4F8A5A;
    int rimy = base - 7, hx = cx + 15;
    /* the mantle shows in the gap when he is open */
    if (f > 0.04f) {
        for (int x = cx - 14; x <= cx + 14; x++) {
            float u = (float)(hx - x);                         /* distance from the hinge */
            int ytop;
            ytop = rimy - (int)(u * tanf(th) * 0.5f + 0.5f) - 1;
            for (int y = ytop; y < rimy; y++) {
                int k = (x * 5 + y * 3 + (int)(t * 4.0f)) % 9;
                Col c = k < 3 ? 0x2FA8D8 : (k < 6 ? 0x8A5AD8 : 0x2FC4B2);
                if (y == ytop) c = (x & 1) ? 0xFF7AC8 : 0xFFB0DC;          /* the scalloped lip */
                dvP(w, x, y, c, ymax);
            }
        }
    }
    /* the lower shell: a ribbed bowl */
    for (int dx = -15; dx <= 15; dx++) {
        int hh = (int)(7.0f * sqrtf(fmaxf(0.0f, 1.0f - (float)(dx * dx) / 225.0f)) + 0.5f);
        for (int dy = 0; dy < hh + 1; dy++) {
            int y = rimy + dy;
            Col c = ((dx + 30) % 4 == 0) ? SHD : SH;
            if (dy == hh) c = SHD; else if (dy == 0) c = SHL;
            if (((hash2(h, (uint32_t)(dx * 13 + dy)) & 15u) == 0u)) c = lerpc(c, ALG, 0.6f);
            dvP(w, cx + dx, y, c, ymax);
        }
    }
    /* the upper shell: a ribbed dome hinged at the right-hand end */
    for (int iu = 0; iu < 60; iu++) {
        float u = (float)iu * 0.5f;
        float hhf = 8.0f * sinf(3.14159f * u / 30.0f);
        for (int iv = 0; iv < (int)(hhf * 2.0f) + 1; iv++) {
            float v = (float)iv * 0.5f;
            int sxp = hx + (int)floorf(-u * cs + v * sn + 0.5f), syp = rimy + (int)floorf(-u * sn - v * cs + 0.5f);
            Col c = (((int)u + 30) % 4 == 0) ? SHD : SH;
            if (iv >= (int)(hhf * 2.0f)) c = SHL;
            else if (iv == 0) c = SHD;
            if (((hash2(h, (uint32_t)(iu * 17 + iv)) & 15u) == 0u)) c = lerpc(c, ALG, 0.6f);
            dvP(w, sxp, syp, c, ymax);
        }
    }
    /* the pearl */
    if (f > 0.30f) {
        int px = cx - 1, py = rimy - 3;
        ell_fill(w, px, py, 3.0f, 3.0f, 0, 0xF4EEF8, ymax); PX(w, px - 1, py - 1, 0xFFFFFF); PX(w, px + 1, py + 1, 0xC9B8E0);
        if (sinf(t * 2.2f + rfn(h, 2) * 6.0f) > 0.6f) { PX(w, px + 2, py - 4, 0xFFFFFF); PX(w, px + 2, py - 5, 0xFFFFFF); PX(w, px + 1, py - 4, 0xFFFFFF); PX(w, px + 3, py - 4, 0xFFFFFF); }
    }
    /* a few bubbles drifting up from him */
    if (f > 0.3f) for (int i = 0; i < 3; i++) {
        float p = fmodf(t * 0.5f + (float)i * 0.33f + rfn(h, 3), 1.0f);
        int bx = cx - 6 + i * 6 + (int)floorf(sinf(t * 2.0f + (float)i * 2.0f) * 1.5f + 0.5f), by = rimy - 8 - (int)(p * 34.0f);
        BLEND(w, bx, by, 0xCFF3FF, (int)(200.0f * (1.0f - p))); BLEND(w, bx + 1, by, 0xCFF3FF, (int)(120.0f * (1.0f - p)));
    }
}

/* ------------------------------------------------------------------ */
/* an octopus tentacle-draped lair                                     */
/* ------------------------------------------------------------------ */
static void dv_octo_big(AWWorld *w, int x, int y, Col c, float t, float ph, int dir) {
    int bob = (int)floorf(sinf(t * 1.6f + ph) * 1.0f + 0.5f);
    int cy = y + bob;
    ell_fill(w, x, cy, 7.0f, 6.0f, 0, c, BIGY);
    ell_fill(w, x - 2, cy - 2, 3.5f, 2.4f, 0, lerpc(c, 0xFFFFFF, 0.32f), BIGY);
    int bl = fmodf(t + ph, 4.5f) < 0.18f;
    R(w, x - 5, cy, 4, 4, 0xFFFFFF); R(w, x + 1, cy, 4, 4, 0xFFFFFF);
    if (!bl) { R(w, x - 4 + (dir > 0 ? 1 : 0), cy + 1, 2, 3, 0x1D1020); R(w, x + 2 + (dir > 0 ? 1 : 0), cy + 1, 2, 3, 0x1D1020); }
    else { R(w, x - 5, cy + 2, 4, 1, mulc(c, 0.6f)); R(w, x + 1, cy + 2, 4, 1, mulc(c, 0.6f)); }
}
static void dv_rock(AWWorld *w, int cx, int cy, float rx, float ry, int ymax) {   /* a lit, shaded boulder */
    ell_fill(w, cx, cy, rx, ry, 0, 0x45485A, ymax);
    ell_fill(w, cx - 1, cy - 1, rx - 1.5f, ry - 1.5f, 0, 0x6B6F7E, ymax);
    ell_fill(w, cx - 3, cy - 2, rx * 0.55f, ry * 0.5f, 0, 0x8A8FA2, ymax);
}
static void dv_lair(AWWorld *w, int cx, int base, uint32_t h, float t) {
    int ymax = base + 1;
    Col rk = 0x6B6F7E, rl = 0x8A8FA2, rd = 0x4A4D5C;
    /* a rock arch with a dark hollow */
    dv_rock(w, cx - 12, base - 8, 13.0f, 10.0f, ymax);
    dv_rock(w, cx + 12, base - 6, 11.0f, 8.0f, ymax);
    dv_rock(w, cx, base - 14, 14.0f, 7.0f, ymax);
    ell_fill(w, cx, base - 5, 7.0f, 6.0f, 0, 0x14101C, ymax);                         /* the hollow */
    for (int i = 0; i < 16; i++) { uint32_t q = hash2(h, (uint32_t)(i + 40)); dvP(w, cx - 22 + (int)(rfn(q, 0) * 44.0f), base - 18 + (int)(rfn(q, 1) * 17.0f), (i & 1) ? rl : rd, ymax); }
    /* the octopus peering out */
    Col oc = (h & 1u) ? 0xE0508A : 0xFF8A4A;
    int ex = cx + 1, ey = base - 7;
    float reach = 0.5f + 0.5f * sinf(t * 0.7f + rfn(h, 2) * 6.0f);
    dv_octo_big(w, ex, ey, oc, t, rfn(h, 3) * 6.0f, 1);
    for (int i = 0; i < 6; i++) {                                                     /* tentacles curling out over the rock */
        int bx = ex - 6 + i * 2;
        for (int j = 0; j < 14; j++) {
            float amp = (0.8f + (float)j * 0.22f) * (0.6f + 0.6f * reach);
            int ox = (int)floorf(sinf(t * 2.4f + (float)i * 0.9f - (float)j * 0.5f) * amp + 0.5f) + (i - 3) * j / 5;
            int py = ey + 5 + j;
            if (py >= ymax) break;
            dvP(w, bx + ox, py, j > 10 ? mulc(oc, 0.82f) : oc, ymax);
            if (j % 3 == 1) dvP(w, bx + ox, py, lerpc(oc, 0xFFFFFF, 0.35f), ymax);
        }
    }
    /* shells and a crab claw by the entrance */
    PX(w, cx - 18, base - 1, 0xF4E8D0); PX(w, cx - 17, base - 1, 0xF4E8D0); PX(w, cx - 17, base - 2, 0xD8C8A8);
    PX(w, cx + 18, base - 1, 0xFFB0C0); PX(w, cx + 19, base - 1, 0xFFB0C0); PX(w, cx + 18, base - 2, 0xE890A0);
}

/* ------------------------------------------------------------------ */
/* squid and schools                                                   */
/* ------------------------------------------------------------------ */
static void dv_squid(AWWorld *w, int x, int y, int len, int dir, Col c, float t, float ph, float pulse) {
    /* head and arms trail behind; the pointed mantle leads. pulse 0..1 = how hard he is jetting */
    float L = (float)len * 0.62f, ry = (float)len * (0.15f - 0.025f * pulse);
    int hx = x - dir * (int)((float)len * 0.12f);
    Col lt = lerpc(c, 0xFFFFFF, 0.38f), dk = mulc(c, 0.72f);
    for (int k = 0; k < (int)L; k++) {
        float q = (float)k / L;
        float hh = ry * powf(fmaxf(0.0f, 1.0f - q * q * q), 0.55f) * (0.55f + 0.45f * sinf(q * 3.0f + 0.2f));
        int ih = (int)(hh + 0.5f);
        int px = hx + dir * k;
        for (int j = -ih; j <= ih; j++) {
            Col cc = j < -ih / 2 ? dk : (j > ih / 2 ? lt : c);
            if (((px * 7 + j * 5) % 13) == 0 && abs(j) < ih) cc = lerpc(cc, 0xFFD0E0, 0.55f * (0.5f + 0.5f * sinf(t * 3.0f + (float)px)));   /* colour flickers */
            PX(w, px, y + j, cc);
        }
    }
    /* the fins on the tip of the mantle */
    for (int k = 0; k < (int)(L * 0.34f); k++) {
        int px = hx + dir * ((int)L - 1 - k);
        int fh = (int)((float)(k + 1) * 0.55f * (1.0f - (float)k / (L * 0.34f)) + 0.6f) + (int)(ry * 0.6f);
        PX(w, px, y - (int)ry - (fh > 0 ? fh / 2 : 0), dk); PX(w, px, y + (int)ry + (fh > 0 ? fh / 2 : 0), dk);
    }
    /* the head with big eyes */
    ell_fill(w, hx, y, ry * 0.95f, ry * 0.9f, 0, lt, BIGY);
    int ex = hx + dir * 0;
    R(w, ex - 1, y - (int)(ry * 0.6f), 3, 3, 0xFFFFFF); PX(w, ex + dir, y - (int)(ry * 0.6f) + 1, 0x101018);
    /* eight arms and two long tentacles, rippling behind him */
    for (int i = 0; i < 8; i++) {
        float yo = ((float)i - 3.5f) * ((ry * 1.5f) / 7.0f);
        int al = (int)((float)len * (0.36f + 0.05f * (float)(i % 3)));
        for (int j = 1; j <= al; j++) {
            int oy2 = (int)floorf(sinf(t * 3.4f + (float)i * 0.8f - (float)j * 0.5f + ph) * (0.4f + (float)j * 0.09f) + 0.5f) + (int)(yo * (1.0f - (float)j / (float)al * 0.5f));
            PX(w, hx - dir * (j + 1), y + oy2, j > al - 3 ? dk : c);
        }
    }
    for (int s = -1; s <= 1; s += 2) {
        int al = (int)((float)len * 0.95f);
        for (int j = 1; j <= al; j++) {
            int oy2 = (int)floorf(sinf(t * 2.2f + (float)s * 1.2f - (float)j * 0.34f + ph) * (0.5f + (float)j * 0.10f) + 0.5f) + s;
            PX(w, hx - dir * (j + 1), y + oy2, c);
            if (j > al - 4) PX(w, hx - dir * (j + 1), y + oy2 + 1, dk);
        }
    }
}

static void dv_sfish(AWWorld *w, int x, int y, int dir, Col c, int fr, int ymax) {   /* a tiny fish: 4 px and a flicking tail */
    dvP(w, x, y, c, ymax); dvP(w, x + dir, y, c, ymax); dvP(w, x + dir * 2, y, lerpc(c, 0xFFFFFF, 0.3f), ymax);
    dvP(w, x - dir, y - 1 + fr, mulc(c, 0.85f), ymax); dvP(w, x - dir, y + fr, mulc(c, 0.85f), ymax);
    dvP(w, x + dir * 2, y - 1, 0x101018, ymax);
    dvP(w, x, y + 1, lerpc(c, 0xFFFFFF, 0.5f), ymax);
}

/* seven more kinds of fish, facing dir: 1 angelfish, 2 clownfish, 3 pufferfish, 4 blue tang, 5 needlefish, 6 butterflyfish, 7 a little ray.
   (Kind 0 is the original small tetra, drawn by draw_fish.) c1 is the main colour, c2 the markings. */
static double dv_travel(const AWWorld *w, uint32_t h, float t, float speed, int *dirOut);
static void fish_pal(int kind, uint32_t h, Col *c1, Col *c2) {
    int v = (int)((h >> 3) & 1u);
    switch (kind) {
        case 1: *c1 = v ? 0xFFC83F : 0xE8ECF4; *c2 = 0x1D1020; break;
        case 2: *c1 = v ? 0xFF7A1F : 0xFF5A2A; *c2 = 0xFFFFFF; break;
        case 3: *c1 = v ? 0xE8D27A : 0xC8D890; *c2 = 0xFFF5C8; break;
        case 4: *c1 = v ? 0x2F6BE0 : 0x3A8FE8; *c2 = 0xFFD23F; break;
        case 5: *c1 = v ? 0xB8D8D0 : 0xD0DCE8; *c2 = 0x4F7A7A; break;
        case 6: *c1 = 0xFFE04A; *c2 = 0xFFFFFF; break;
        default: *c1 = v ? 0x7A8EB8 : 0x9A78B8; *c2 = 0xD8E4F4; break;
    }
}
static void draw_fish_sp(AWWorld *w, int x, int y, int dir, int kind, Col c1, Col c2, int fr) {
    Col eye = 0x101018;
    switch (kind) {
        case 1:   /* angelfish: a tall disc with long fins */
            ell_fill(w, x, y, 2.4f, 3.2f, 0, c1, BIGY);
            for (int i = 0; i < 4; i++) { PX(w, x - dir, y - 4 - i, c1); PX(w, x - dir, y + 4 + i, mulc(c1, 0.85f)); }
            R(w, x, y - 3, 1, 7, c2); R(w, x - dir * 2, y - 2, 1, 5, c2);
            PX(w, x - dir * 3, y - 1 + fr, c1); PX(w, x - dir * 3, y + fr, c1); PX(w, x - dir * 3, y + 1, mulc(c1, 0.85f));
            PX(w, x + dir * 2, y - 1, eye); break;
        case 2:   /* clownfish: orange with white bands */
            ell_fill(w, x, y, 3.6f, 2.2f, 0, c1, BIGY);
            R(w, x + dir, y - 2, 1, 5, c2); R(w, x - dir * 2, y - 2, 1, 5, c2);
            PX(w, x - dir * 4, y - 1 + fr, c1); PX(w, x - dir * 4, y + fr, c1); PX(w, x - dir * 5, y - 1 + fr, mulc(c1, 0.85f));
            PX(w, x + dir * 2, y - 1, eye); PX(w, x - dir * 5, y + fr, c2); break;
        case 3:   /* pufferfish: a round, spiky ball */
            ell_fill(w, x, y, 3.6f, 3.2f, 0, c1, BIGY); ell_fill(w, x + dir, y + 1, 2.8f, 1.8f, 0, c2, BIGY);
            for (int i = 0; i < 8; i++) { float a = (float)i * 0.785f; PX(w, x + (int)(cosf(a) * 4.6f + (cosf(a) < 0 ? -0.5f : 0.5f)), y + (int)(sinf(a) * 4.2f + (sinf(a) < 0 ? -0.5f : 0.5f)), mulc(c1, 0.8f)); }
            PX(w, x - dir * 4, y - 1 + fr, mulc(c1, 0.85f)); PX(w, x - dir * 4, y + fr, mulc(c1, 0.85f));
            PX(w, x + dir * 2, y - 1, eye); PX(w, x + dir * 3, y + 1, mulc(c1, 0.5f)); break;
        case 4:   /* blue tang: a flat blue oval with a yellow tail */
            ell_fill(w, x, y, 4.0f, 2.6f, 0, c1, BIGY);
            R(w, x - 2, y - 1, 4, 1, 0x101830); PX(w, x + dir, y, 0x101830); PX(w, x + dir * 2, y + 1, 0x101830);
            PX(w, x - dir * 4, y - 1 + fr, c2); PX(w, x - dir * 4, y + fr, c2); PX(w, x - dir * 5, y - 1 + fr, c2); PX(w, x - dir * 5, y + 1 - fr, c2);
            PX(w, x + dir * 2, y - 1, 0xFFFFFF); break;
        case 5:   /* needlefish: long, slim, with a beak */
            for (int i = -5; i <= 5; i++) { PX(w, x + i * dir, y, c1); PX(w, x + i * dir, y - 1, c2); }
            PX(w, x + 6 * dir, y, c2); PX(w, x + 7 * dir, y, c2);
            PX(w, x - 6 * dir, y - 1 + fr, c1); PX(w, x - 6 * dir, y + 1 - fr, c1); PX(w, x + 4 * dir, y - 1, eye); break;
        case 6:   /* butterflyfish: a yellow disc with a black eye-stripe */
            ell_fill(w, x, y, 3.2f, 3.2f, 0, c1, BIGY);
            R(w, x + dir * 2 - (dir < 0 ? 0 : 0), y - 3, 1, 6, 0x101018); R(w, x - dir * 2, y - 2, 1, 2, c2);
            PX(w, x - dir * 4, y - 1 + fr, mulc(c1, 0.85f)); PX(w, x - dir * 4, y + fr, mulc(c1, 0.85f));
            PX(w, x + dir * 1, y - 1, eye); break;
        default:  /* a little ray: wings that flap */
            for (int i = -5; i <= 5; i++) {
                int hh = (5 - abs(i)) / 3 + (fr && abs(i) > 2 ? 0 : 1);
                for (int j = 0; j < hh; j++) PX(w, x + i, y - j + (abs(i) > 3 ? (fr ? -1 : 1) : 0), j == 0 ? c2 : c1);
            }
            for (int i = 1; i <= 4; i++) PX(w, x - dir * (5 + i), y + 1 - (i & 1), mulc(c1, 0.8f));
            PX(w, x + dir * 2, y - 1, eye); break;
    }
}
/* a few bigger, lone swimmers drifting along the reef */
static void dv_lone(AWWorld *w, int camI, float t) {
    int n = w->lk_dive == 2 ? 6 : 4;
    for (int j = 0; j < n; j++) {
        uint32_t h = hash2(w->lk_seed ^ 0x10E5U, (uint32_t)j);
        int dir; double xw = dv_travel(w, h, t, 5.0f + 6.0f * rfn(h, 8), &dir);
        if (xw < w->lk_x0 + 50.0 || xw > w->lk_x1 - 50.0) continue;
        int bed = lake_depth(w, (int)floor(xw));
        if (bed < 22) continue;
        float want = (float)bed * (0.22f + 0.45f * rfn(h, 9)) + 8.0f + sinf(t * 0.9f + (float)j * 1.7f) * 3.0f;
        int fy = w->gy + (int)want;
        if (fy > w->gy + bed - 8) fy = w->gy + bed - 8;
        if (fy < w->gy + 8) fy = w->gy + 8;
        int kind = 1 + (int)(rfn(h, 10) * 7.0f) % 7;
        Col c1, c2; fish_pal(kind, h, &c1, &c2);
        draw_fish_sp(w, (int)floor(xw) - camI, fy, dir, kind, c1, c2, ((int)(t * 5.0f + (float)j)) & 1);
    }
}

/* a swimmer whose position is a pure function of time: it loops up and down the lake, forever */
static double dv_travel(const AWWorld *w, uint32_t h, float t, float speed, int *dirOut) {
    double lo = w->lk_x0 + 70.0, hi = w->lk_x1 - 70.0, L = hi - lo;
    if (L < 120.0) L = 120.0;
    int dir = (h & 1u) ? 1 : -1;
    double p = fmod((double)rfn(h, 7) * L + (double)speed * (double)t, L);
    *dirOut = dir;
    return dir > 0 ? lo + p : hi - p;
}

static void dv_schools(AWWorld *w, int camI, float t) {
    int nsch = w->lk_dive == 2 ? 4 : 3;
    static const Col SC[9] = { 0xFFD23F, 0x4FA6F5, 0xFF8A2A, 0x9AE86A, 0xFF7AA8, 0xC9D8EE, 0xE05A5A, 0x6AE0D0, 0xB08AE8 };
    for (int j = 0; j < nsch; j++) {
        uint32_t h = hash2(w->lk_seed ^ 0x5C001U, (uint32_t)j);
        int dir;
        double cxw = dv_travel(w, h, t, 7.0f + 5.0f * rfn(h, 8), &dir);
        float depthF = 0.18f + 0.55f * rfn(h, 9);
        Col c = SC[(int)(rfn(h, 10) * 9.0f) % 9];
        int n = 14 + (int)(rfn(h, 11) * 8.0f);
        for (int i = 0; i < n; i++) {
            uint32_t q = hash2(h, (uint32_t)(i + 5));
            float a = rfn(q, 0) * 6.28f, r = sqrtf(rfn(q, 1));
            float ox = cosf(a + t * 0.35f * (rfn(q, 2) < 0.5f ? 1.0f : -1.0f)) * r * 22.0f + sinf(t * 0.8f + (float)i) * 2.0f;
            float oyv = sinf(a + t * 0.5f) * r * 9.0f + sinf(t * 1.3f + (float)i * 1.7f) * 1.4f;
            double fx = cxw + (double)ox;
            if (fx < w->lk_x0 + 40.0 || fx > w->lk_x1 - 40.0) continue;
            int bed = lake_depth(w, (int)floor(fx));
            if (bed < 18) continue;
            float want = (float)bed * depthF + 6.0f;
            int fy = w->gy + (int)(want + oyv);
            if (fy > w->gy + bed - 6) fy = w->gy + bed - 6;
            if (fy < w->gy + 5) fy = w->gy + 5;
            int fdir = (ox * (float)dir > -6.0f || i % 7 == 0) ? dir : -dir;
            fdir = dir;
            dv_sfish(w, (int)floor(fx) - camI, fy, fdir, c, ((int)(t * 7.0f + (float)i)) & 1, BIGY);
        }
    }
}

static void dv_squids(AWWorld *w, int camI, float t) {
    int n = w->lk_dive == 2 ? 3 : 1;
    for (int j = 0; j < n; j++) {
        uint32_t h = hash2(w->lk_seed ^ 0x5E1D0U, (uint32_t)j);
        int giant = (j == 0 && w->lk_dive == 2);
        const float P = giant ? 3.6f : 2.5f;                   /* one jet every P seconds */
        float V = giant ? 15.0f : 30.0f;
        double lo = w->lk_x0 + 70.0, hi = w->lk_x1 - 70.0, L = hi - lo;
        int dir = (h & 1u) ? 1 : -1;
        float tt = t + rfn(h, 4) * 40.0f;
        float trav = V * (tt * 0.5f - P * sinf(6.28318f * tt / P) / 12.566f);     /* the integral of V sin^2 */
        double p = fmod((double)rfn(h, 7) * L + (double)trav, L);
        double xw = dir > 0 ? lo + p : hi - p;
        int bed = lake_depth(w, (int)floor(xw));
        if (bed < 24) continue;
        float depthF = giant ? 0.66f : 0.30f + 0.2f * rfn(h, 9);
        float yy = (float)w->gy + (float)bed * depthF + sinf(tt * 0.31f + rfn(h, 5) * 6.0f) * 6.0f;
        float pulse = sinf(3.14159f * tt / P); pulse *= pulse;
        Col c = giant ? 0xB02A3A : (j == 1 ? 0xE0607A : 0xFF8A6A);
        int len = giant ? 46 : (w->lk_dive == 2 ? 22 : 15);
        dv_squid(w, (int)floor(xw) - camI, (int)yy, len, dir, c, t, rfn(h, 6) * 6.0f, pulse);
    }
}

/* shafts of sunlight from the surface */
static void dv_rays(AWWorld *w, int camI, float t) {
    int reach = w->lk_dive == 2 ? 92 : 34;
    for (int x = 0; x < w->vw; x++) {
        int wx = camI + x;
        int top = w->gy - ground_h(w, wx);
        if (top <= w->gy + 2) continue;
        for (int dd = 3; dd < reach; dd++) {
            int y = w->gy + dd;
            if (y >= top) break;
            float s = sinf((float)(wx + dd / 2) * 0.115f + sinf(t * 0.21f + (float)(wx / 61)) * 1.5f) * sinf((float)(wx + dd / 3) * 0.043f + t * 0.13f);
            if (s > 0.38f) {
                int a = (int)((s - 0.38f) * 46.0f * (1.0f - (float)dd / (float)reach));
                if (a > 0 && (((x + dd) & 1) == 0)) BLEND(w, x, y, 0xFFF6C8, a);
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/* the whole scene                                                     */
/* ------------------------------------------------------------------ */
#define DVSLOT 200
static void draw_dive_scene(AWWorld *w) {
    if (!w->lk_on || !w->lk_dive) return;
    int camI = (int)floor(w->cam);
    float t = (float)w->t;
    dv_rays(w, camI, t);
    dv_schools(w, camI, t);
    dv_lone(w, camI, t);
    int k0 = floordiv(camI - 110, DVSLOT), k1 = floordiv(camI + w->vw + 110, DVSLOT);
    static const int KIND[5] = { 0, 1, 2, 1, 0 };   /* wreck, clam, octopus lair ... */
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->lk_seed ^ 0xD1FEU, (uint32_t)k);
        int wx = k * DVSLOT + 70 + (int)(rfn(h, 1) * 70.0f);
        if ((double)wx < w->lk_x0 + 100.0 || (double)wx > w->lk_x1 - 100.0) continue;
        int bed = lake_depth(w, wx);
        if (bed < 26) continue;
        int kind = KIND[(int)(((uint32_t)k + (w->lk_seed >> 9)) % 5u)];
#ifdef AW_UNDER_DEBUG
        if (getenv("AW_DVK")) kind = atoi(getenv("AW_DVK"));
#endif
        int base = w->gy + bed;
        /* the sea floor beneath a feature is levelled so it sits properly */
        int x = wx - camI;
        if (kind == 0) {
            if (w->lk_dive == 2) dv_wreck(w, x, base, 3, h, t);
            else dv_wreck(w, x, base, bed > 30 ? 24 : 18, h, t);          /* only the mast and upper deck show in a shallow reef */
        } else if (kind == 1) dv_clam(w, x, base, h, t);
        else dv_lair(w, x, base, h, t);
    }
    dv_squids(w, camI, t);
}
