/*
 * Archon's Life - sprite art (ASCII pixel art) and blitters.
 * Included by aw_engine.c (needs Col, AWWorld, PX, BLEND, R).
 *
 * Each sprite is an array of row strings. '.' (or a missing column) is transparent.
 */

typedef struct { int h; const char *const *r; } Sp;
#define SPDEF(name, ...) \
    static const char *const name##_r[] = { __VA_ARGS__ }; \
    static const Sp name = { (int)(sizeof(name##_r) / sizeof(name##_r[0])), name##_r };

static int sp_w(const Sp *s) {
    int m = 0;
    for (int i = 0; i < s->h; i++) { int l = (int)strlen(s->r[i]); if (l > m) m = l; }
    return m;
}

/* tint 0 = normal Archon orange, 1 = blue Archon */
static Col sp_col(char c, int tint) {
    if (tint >= 2 && tint <= 6) {   /* the cats' five coats: orange tabby, grey, black, white, tuxedo */
        static const Col PB[5] = { 0xF09A3E, 0x9AA0AE, 0x3A3646, 0xFFFFFF, 0x2E2C3A };
        static const Col PD[5] = { 0xC06A1E, 0x6A7080, 0x24202E, 0xD8D2C8, 0x1A1A24 };
        static const Col PL[5] = { 0xFFE0B0, 0xE6E8F0, 0x6A6478, 0xFFF3E4, 0xFFFFFF };
        static const Col PE[5] = { 0x2A1A10, 0x2A1A10, 0xFFE45E, 0x2A1A10, 0xB8F060 };
        switch (c) { case '@': return PB[tint - 2]; case '#': return PD[tint - 2]; case '%': return PL[tint - 2]; case '*': return PE[tint - 2]; default: break; }
    }
    if (tint == 1) {
        switch (c) {
            case 'O': return 0x4F8FF5; case 'D': return 0x2F5FC8; case 'L': case 'H': return 0x9AC4FF;
            case 'C': return 0xFFB6E0; case 'M': return 0x1F3F90; default: break;
        }
    }
    switch (c) {
        /* Archon */
        case 'Y': return 0xFFD23F; case 'P': return 0xFF4D6D; case 'H': return 0xFF9A6A; case 'O': return 0xFF6A3A;
        case 'D': return 0xD44A22; case 'L': return 0xFF9A6A; case 'K': return 0x1D1020; case 'C': return 0xFF9EB5;
        case 'M': return 0xA7341A;
        /* neutrals */
        case 'W': return 0xFFFFFF; case 'G': return 0xC9D8EE; case 'S': return 0x8FA3C0; case 'Z': return 0x4A4A5A;
        case 'A': return 0xA9A9B8; case 'k': return 0x101018;
        /* colours */
        case 'R': return 0xE8442A; case 'r': return 0xB02A1A; case 'B': return 0x4FA6F5; case 'b': return 0xA8D8FF;
        case 'N': return 0x2F5FA8; case 'n': return 0x1D3A78; case 'T': return 0x2FC4B2; case 'U': return 0x1B8F85;
        case 'E': return 0x6CCB52; case 'F': return 0x3F9B3A; case 'g': return 0xB4F08E; case 'V': return 0xA77BF0;
        case 'X': return 0x7449C4; case 'v': return 0xD2B8FF; case 'Q': return 0x8A5A2B; case 'J': return 0xC48A45;
        case 'I': return 0xFFF3C2; case 'p': return 0xFF8FB8; case 'm': return 0xE0508A;
        /* flames etc. */
        case 'y': return 0xFFE45E; case 'o': return 0xFFA030; case 'f': return 0xFF5A2A; case 's': return 0x9FE8FF;
        case 'c': return 0x3FB6D8;
        /* v3 friends and rides */
        case 'q': return 0xE0A02A; case 't': return 0xFFF59A; case 'l': return 0x9FE8FF; case 'x': return 0x4FA05A;
        case 'e': return 0xD6E8A0; case 'a': return 0x8FE8C0; case '0': return 0x2E8B6A; case '1': return 0x4A2E1C;
        case '2': return 0x7A4A2A; case '3': return 0xE8C9A0; case '4': return 0xC9A07A; case '5': return 0xFF9EB5;
        case '6': return 0x6A5A5E; case '7': return 0x3A2A22;
        default: return 0;
    }
}

static void blit(AWWorld *w, const Sp *s, int x, int y, int flip, int tint) {
    int sw = sp_w(s);
    for (int r = 0; r < s->h; r++) {
        int len = (int)strlen(s->r[r]);
        for (int c = 0; c < len; c++) {
            char ch = s->r[r][c];
            if (ch == '.' || ch == ' ') continue;
            Col col = sp_col(ch, tint);
            PX(w, flip ? x + (sw - 1 - c) : x + c, y + r, col);
        }
    }
}
/* only columns within [c0,c1) of the sprite (used for sprouting wings) */
static void blit_cols(AWWorld *w, const Sp *s, int x, int y, int flip, int c0, int c1) {
    int sw = sp_w(s);
    for (int r = 0; r < s->h; r++) {
        int len = (int)strlen(s->r[r]);
        for (int c = c0; c < c1 && c < len; c++) {
            char ch = s->r[r][c];
            if (ch == '.' || ch == ' ') continue;
            PX(w, flip ? x + (sw - 1 - c) : x + c, y + r, sp_col(ch, 0));
        }
    }
}
/* sprite with a 1-px translucent dark outline so it reads on any sky */
static void blit_outlined(AWWorld *w, const Sp *s, int x, int y, int flip, int tint, int a256) {
    int sw = sp_w(s);
    for (int r = -1; r <= s->h; r++) {
        for (int c = -1; c <= sw; c++) {
            int solid = 0;
            #define SOLID(rr, cc) ((rr) >= 0 && (rr) < s->h && (cc) >= 0 && (cc) < (int)strlen(s->r[rr]) && s->r[rr][cc] != '.' && s->r[rr][cc] != ' ')
            if (SOLID(r, c)) continue;
            if (SOLID(r, c - 1) || SOLID(r, c + 1) || SOLID(r - 1, c) || SOLID(r + 1, c)) solid = 1;
            #undef SOLID
            if (solid) BLEND(w, flip ? x + (sw - 1 - c) : x + c, y + r, 0x1D1020, a256);
        }
    }
    blit(w, s, x, y, flip, tint);
}

/* Rotated blit (rotation about a pivot, angle in 45-degree steps, clockwise from "up"). The sprite sits at
 * (ox,oy) inside a cw x ch canvas; the canvas pivot (px,py) is drawn at dest (cx,cy). */
static void blit_rot(AWWorld *w, const Sp *s, int ox, int oy, int cw, int ch, float px, float py, int cx, int cy, int steps) {
    static const float COS[8] = { 1.0f, 0.70710678f, 0.0f, -0.70710678f, -1.0f, -0.70710678f, 0.0f, 0.70710678f };
    static const float SIN[8] = { 0.0f, 0.70710678f, 1.0f, 0.70710678f, 0.0f, -0.70710678f, -1.0f, -0.70710678f };
    steps &= 7;
    float c = COS[steps], sn = SIN[steps];
    int R_ = (int)ceilf(sqrtf((float)(cw * cw + ch * ch))) / 2 + 2;
    for (int dy = -R_; dy <= R_; dy++) {
        for (int dx = -R_; dx <= R_; dx++) {
            float fx = (float)dx + 0.5f, fy = (float)dy + 0.5f;
            float u = px + fx * c + fy * sn;
            float v = py - fx * sn + fy * c;
            int iu = (int)floorf(u) - ox, iv = (int)floorf(v) - oy;
            if (iv < 0 || iv >= s->h || iu < 0) continue;
            if (iu >= (int)strlen(s->r[iv])) continue;
            char chh = s->r[iv][iu];
            if (chh == '.' || chh == ' ') continue;
            PX(w, cx + dx, cy + dy, sp_col(chh, 0));
        }
    }
}

/* ------------------------------------------------------------------ */
/* Archon                                                              */
/* ------------------------------------------------------------------ */
/* Archon is a hologram: his old self, drawn in light. His colours drift through the rainbow (starting from his usual orange), he flickers and glitches, and every
 * so often he fades almost see-through. Eyes and mouth stay solid so you can always see who he is. */
static Col hsv_col(float h, float s, float v) {
    h -= floorf(h);
    float r6 = h * 6.0f; int i = (int)r6; float f = r6 - (float)i;
    float p = v * (1.0f - s), q = v * (1.0f - s * f), t = v * (1.0f - s * (1.0f - f)), r, g, b;
    switch (i % 6) { case 0: r = v; g = t; b = p; break; case 1: r = q; g = v; b = p; break; case 2: r = p; g = v; b = t; break;
                     case 3: r = p; g = q; b = v; break; case 4: r = t; g = p; b = v; break; default: r = v; g = p; b = q; break; }
    return ((Col)(r * 255.0f + 0.5f) << 16) | ((Col)(g * 255.0f + 0.5f) << 8) | (Col)(b * 255.0f + 0.5f);
}
static float sstep(float a, float b, float x) { float t = clampf((x - a) / (b - a), 0.0f, 1.0f); return t * t * (3.0f - 2.0f * t); }

/* how solid he is right now: ~0.86 = nearly solid, ~0.3 = a ghost you can see the scenery through */
static float holo_presence(const AWWorld *w) {
    float t = (float)w->t;
    float u = fmodf(t + 4.0f, 14.0f) / 14.0f;                      /* a fade every 14 s: out, hold, back in */
    float ghost = sstep(0.00f, 0.07f, u) * (1.0f - sstep(0.17f, 0.26f, u));
    float u2 = fmodf(t + 11.0f, 31.0f) / 31.0f;                    /* and now and then a deeper, longer one */
    float deep = sstep(0.00f, 0.04f, u2) * (1.0f - sstep(0.09f, 0.14f, u2));
    float a = 0.86f - 0.46f * ghost - 0.22f * deep;
    return a * (0.94f + 0.06f * sinf(t * 11.0f));
}

/* Draws Archon-lettered rows (Y crown, P crown gem, H/L light, O body, D shade, K eyes, C cheeks, M mouth) as a hologram. */
static void holo_draw_rows(AWWorld *w, const char *const *rows, int nrows, int ncols, int x, int y, int aura) {
    float t = (float)w->t, pres = holo_presence(w);
    float hue0 = 0.045f + t * 0.085f;                                  /* starts at his orange and drifts round the colour wheel */
    int gl = fmodf(t, 7.3f) < 0.17f;                                   /* a glitch burst every ~7 s */
    uint32_t gseed = (uint32_t)(t * 24.0f);
    for (int r = 0; r < nrows; r++) {
        int off = 0;
        if (gl) { uint32_t q = hash2(gseed, (uint32_t)r); if ((q & 3u) == 0u) off = (q & 4u) ? 1 : -1; }
        for (int c = 0; c < ncols; c++) {
            char ch = rows[r][c];
            if (ch == '.' || ch == 0) continue;
            float h = hue0 + 0.020f * (float)r + 0.010f * (float)c + 0.04f * sinf(t * 0.7f + (float)r * 0.5f);
            Col col; float al = pres;
            switch (ch) {
                case 'Y': col = hsv_col(h + 0.10f, 0.78f, 1.00f); al += 0.10f; break;            /* crown */
                case 'P': col = hsv_col(h + 0.50f, 0.85f, 0.90f + 0.10f * sinf(t * 4.0f)); al += 0.20f; break;   /* crown gem */
                case 'H': case 'L': col = hsv_col(h + 0.02f, 0.34f, 1.00f); al += 0.10f; break;   /* highlights */
                case 'D': col = hsv_col(h + 0.05f, 0.88f, 0.66f); al += 0.10f; break;             /* shade */
                case 'C': col = hsv_col(h + 0.45f, 0.40f, 1.00f); al += 0.10f; break;             /* cheeks */
                case 'K': col = 0x1D1020; al = fmaxf(al, 0.80f) + 0.15f; break;                    /* eyes: always solid */
                case 'M': col = hsv_col(h, 0.90f, 0.45f); al = fmaxf(al, 0.75f) + 0.15f; break;   /* mouth */
                default:  col = hsv_col(h, 0.74f, 0.98f); break;                                   /* body */
            }
            if (((y + r + w->oy) & 1) == 0) al *= 0.82f;                  /* scanlines */
            int a = (int)(clampf(al, 0.0f, 1.0f) * 255.0f);
            if (gl && off) {                                              /* colour-split glitch */
                BLEND(w, x + c + off - 1, y + r, 0x20E8FF, a / 3); BLEND(w, x + c + off + 1, y + r, 0xFF30D8, a / 3);
            }
            BLEND(w, x + c + off, y + r, col, a);
        }
    }
    if (aura) {   /* a dark rim so he reads on pale skies, then a soft glow outside it */
        for (int r = -2; r <= nrows + 1; r++) for (int c = -2; c <= ncols + 1; c++) {
            int self = r >= 0 && r < nrows && c >= 0 && c < ncols && rows[r][c] != '.' && rows[r][c] != 0;
            if (self) continue;
            int d1 = 0, d2 = 0;
            for (int rr = r - 2; rr <= r + 2; rr++) for (int cc = c - 2; cc <= c + 2; cc++) {
                if (rr < 0 || rr >= nrows || cc < 0 || cc >= ncols || rows[rr][cc] == '.' || rows[rr][cc] == 0) continue;
                int dist = abs(rr - r) + abs(cc - c);
                if (dist == 1) d1 = 1; else if (dist == 2) d2 = 1;
            }
            if (d1 && r < nrows - 2) BLEND(w, x + c, y + r, 0x2A1A5A, (int)(120.0f * (0.35f + pres)));
            else if (d1 || d2) BLEND(w, x + c, y + r, hsv_col(hue0 + 0.020f * (float)r, 0.55f, 1.0f), (int)(52.0f * (0.4f + pres)));
        }
    }
}

/* his face alone, for portholes, domes and windows */
static void holo_face(AWWorld *w, int x, int y) {
    static const char *const F[5] = { ".OOOOOO.", "OOKOOKOO", "OOKOOKOO", "OOOMMOOO", ".OOOOOO." };
    holo_draw_rows(w, F, 5, 8, x, y, 0);
}
static void holo_window(AWWorld *w, int x, int y, int blink) {   /* the submarine tower window */
    static const char *const F[4] = { "OOOOOOO", "OOKOOKO", "OOOOOOO", "DDDMMDD" };
    static const char *const FB[4] = { "OOOOOOO", "OKKOKKO", "OOOOOOO", "DDDDDDD" };
    holo_draw_rows(w, blink ? FB : F, 4, 7, x, y, 0);
}

static const char *const ARCH_ROWS[12] = {
    "...Y.YY.Y...",
    "...YYPPYY...",
    "..HHHHHHHH..",
    ".DOOOOOOOOL.",
    ".DOKOOOOKOL.",
    ".DOKOOOOKOL.",
    "DDOKOOOOKOLL",
    "DDCOOMMOOCLL",
    ".DOOOOOOOOL.",
    "..DDDDDDDD..",
    "..DD....DD..",
    "..DD....DD..",
};
/* legs: 0 stand, 1 walkA, 2 walkB, 3 dangle, 4 none (seated) */
static void draw_arch(AWWorld *w, int x, int y, int legs, int blink, int tint, int flip) {
    char b[12][13];
    for (int r = 0; r < 12; r++) { memcpy(b[r], ARCH_ROWS[r], 12); b[r][12] = 0; }
    if (legs == 1) memcpy(b[11], "..DD........", 12);
    if (legs == 2) memcpy(b[11], "........DD..", 12);
    if (legs == 3) { memcpy(b[10], "..DD....DD..", 12); memcpy(b[11], ".DD......DD.", 12); }
    if (legs == 4) { memcpy(b[10], "............", 12); memcpy(b[11], "............", 12); }
    if (blink) { memcpy(b[4], ".DOOOOOOOOL.", 12); memcpy(b[6], "DDOOOOOOOOLL", 12); memcpy(b[5], ".DOOOOOOOOL.", 12); }
    if (flip) {
        for (int r = 0; r < 12; r++) for (int c = 0; c < 6; c++) { char t = b[r][c]; b[r][c] = b[r][11 - c]; b[r][11 - c] = t; }
        for (int r = 0; r < 12; r++) for (int c = 0; c < 12; c++) { if (b[r][c] == 'L') b[r][c] = 'd'; else if (b[r][c] == 'D') b[r][c] = 'L'; }
        for (int r = 0; r < 12; r++) for (int c = 0; c < 12; c++) { if (b[r][c] == 'd') b[r][c] = 'D'; }
    }
    if (tint == 0) {
        const char *rows[12];
        for (int r = 0; r < 12; r++) rows[r] = b[r];
        holo_draw_rows(w, rows, 12, 12, x, y, 1);
        return;
    }
    /* faint outline */
    for (int r = 0; r < 12; r++) for (int c = 0; c < 12; c++) {
        if (b[r][c] != '.') continue;
        int near = 0;
        if (c > 0 && b[r][c - 1] != '.') near = 1;
        if (c < 11 && b[r][c + 1] != '.') near = 1;
        if (r > 0 && b[r - 1][c] != '.') near = 1;
        if (r < 11 && b[r + 1][c] != '.') near = 1;
        if (near && r < 10) BLEND(w, x + c, y + r, 0x1D1020, 95);
    }
    for (int r = 0; r < 12; r++) for (int c = 0; c < 12; c++)
        if (b[r][c] != '.') PX(w, x + c, y + r, sp_col(b[r][c], tint));
}

/* ------------------------------------------------------------------ */
/* wings (left wing; mirrored for the right)                           */
/* ------------------------------------------------------------------ */
SPDEF(WING_UP,
    "WW.........",
    "WWW........",
    "GWWW.......",
    ".GWWW......",
    ".GWWWW.....",
    "..GWWWW....",
    "..GGWWWW...",
    "...GGWWWWY.",
    "....GGGWWYY",
    "......GGGYY");
SPDEF(WING_MID,
    "...........",
    "...........",
    "...........",
    "WW.........",
    "WWWWW......",
    "GWWWWWWW...",
    ".GGWWWWWWY.",
    "..GGGWWWWYY",
    "....GGGGGYY",
    "...........");
SPDEF(WING_DN,
    "...........",
    "...........",
    "...........",
    "...........",
    ".......WWYY",
    "....WWWWWYY",
    "..GWWWWWWY.",
    ".GWWWWWWG..",
    "GWWWWGGG...",
    "WWGG.......");

/* ------------------------------------------------------------------ */
/* flying car                                                          */
/* ------------------------------------------------------------------ */
SPDEF(CAR_BODY,
    "...................Ws",
    "..TT................Ws",
    "..TTT................Ws",
    "..TTTTTTTTTTTTTTTTTTTTTTWW",
    ".TTTTTTTTTTTTTTTTTTTTTTTTTTT",
    "TTTTTTTTTTTTTTTTTTTTTTTTTTTTy",
    "UUUUUUUUUUUUUUUUUUUUUUUUUUUUU",
    ".WWWWWWWWWWWWWWWWWWWWWWWWWWW");

/* ------------------------------------------------------------------ */
/* rocket (nose up). Canvas 16 x 38. Body rows 0-29, flame rows 30-37  */
/* ------------------------------------------------------------------ */
SPDEF(ROCKET_BODY,
    "......RRRR......",
    ".....RRLRRD.....",
    ".....RLRRRD.....",
    "....RRLRRRRD....",
    "....RLRRRRRD....",
    "...RRLRRRRRRD...",
    "...RRRRRRRRRD...",
    "..RRRRRRRRRRRD..",
    "..WWWWWWWWWWWG..",
    "..WWWWWWWWWWWG..",
    "..WWNNNNNNNNWG..",
    "..WNNssssssNNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNsbbbbbbsNG..",
    "..WNNssssssNNG..",
    "..WWNNNNNNNNWG..",
    "..WWWWWWWWWWWG..",
    "..RRRRRRRRRRRR..",
    "..rrrrrrrrrrrr..",
    "..WWWWWWWWWWWG..",
    "..WWWWWWWWWWWG..",
    "..WWWWWWWWWWGG..",
    ".RRWWWWWWWWWGRR.",
    ".RRWWWWWWWWWGRR.",
    "RRRWWWWWWWWWGRRr",
    "RRRGGGGGGGGGGRRr",
    "RRr..ZZZZZZ..rRR",
    "Rr...ZZZZZZ...rR");
SPDEF(ROCKET_FL0,
    "......ooooo.....",
    ".......oyyo.....",
    "........yy......");
SPDEF(ROCKET_FL1,
    ".....oooooooo...",
    "......oyyyyo....",
    ".......oyyo.....",
    "........yy......",
    "........o.......");
SPDEF(ROCKET_FL2,
    ".....oofooooo...",
    "......ofyyyyo...",
    ".......oyyyo....",
    ".......oyyo.....",
    "........yo......",
    "........o.......",
    "........f.......");
SPDEF(MINI_FACE,
    ".OOOOOO.",
    "OOKOOKOO",
    "OOKOOKOO",
    "OOOMMOOO",
    ".OOOOOO.");

/* ------------------------------------------------------------------ */
/* jetpack (drawn on the back of Archon, left side)                    */
/* ------------------------------------------------------------------ */
SPDEF(JET_PACK,
    "SSSSS",
    "SWWSZ",
    "SWWSZ",
    "SRRSZ",
    "SWWSZ",
    "SSSSS",
    ".ZZZ.");

/* ------------------------------------------------------------------ */
/* guests                                                              */
/* ------------------------------------------------------------------ */
SPDEF(FOX_A,
    ".........O.O..",
    "........OOOOO.",
    "...OO...OKOKO.",
    "..OOWO.OOOOOOK",
    ".OOWWOOOOOOOWW",
    ".OOOOOOOOOOOW.",
    "..OOOOOOOOOO..",
    "..D.D....D.D..",
    "..D.D....D.D..");
SPDEF(FOX_B,
    ".........O.O..",
    "........OOOOO.",
    "...OO...OKOKO.",
    "..OOWO.OOOOOOK",
    ".OOWWOOOOOOOWW",
    ".OOOOOOOOOOOW.",
    "..OOOOOOOOOO..",
    "...D.D..D..D..",
    "..D...D.D.D...");

/* v5: more cute dogs (they come to walk with Archon like the fox) */
SPDEF(CORGI_A,
    ".........q.q..",
    "........qqqqq.",
    "........qKqKq.",
    "..qq...qqqWWWK",
    ".qqqqqqqqWWWWm",
    ".qqqqqqqqqWWW.",
    "..qqqqqqqqqq..",
    "..W.W....W.W..",
    "..W.W....W.W..");
SPDEF(CORGI_B,
    ".........q.q..",
    "........qqqqq.",
    "..qq....qKqKq.",
    "..qq...qqqWWWK",
    ".qqqqqqqqWWWWm",
    ".qqqqqqqqqWWW.",
    "..qqqqqqqqqq..",
    "...W.W..W..W..",
    "..W...W.W.W...");
SPDEF(DALM_A,
    "........kWWWk.",
    "........kKWKk.",
    "..Wk....kWWWWK",
    ".WWWWWRRWWWWm.",
    ".WkWWWWWWkWWW.",
    "..WWkWWWWWWW..",
    "..WWWWkWWWW...",
    "..W.W....W.W..",
    "..W.W....W.W..");
SPDEF(DALM_B,
    "........kWWWk.",
    "........kKWKk.",
    ".Wk.....kWWWWK",
    ".WWWWWRRWWWWm.",
    ".WkWWWWWWkWWW.",
    "..WWkWWWWWWW..",
    "..WWWWkWWWW...",
    "...W.W..W..W..",
    "..W...W.W.W...");
SPDEF(HUSKY_A,
    ".AA......Z..Z.",
    ".A......ZZZZZ.",
    ".AA.....ZbWbZ.",
    "..AA...AZWWWWK",
    ".AAAAAAAAWWWWm",
    ".AAAAAAAAAWWW.",
    "..AAWWWWWWWW..",
    "..W.W....W.W..",
    "..W.W....W.W..");
SPDEF(HUSKY_B,
    "..AA......Z..Z",
    "..A.....ZZZZZ.",
    "..AA....ZbWbZ.",
    "...AA..AZWWWWK",
    ".AAAAAAAAWWWWm",
    ".AAAAAAAAAWWW.",
    "..AAWWWWWWWW..",
    "...W.W..W..W..",
    "..W...W.W.W...");
/* v6: cats (five coats, see sp_col) and a little white terrier */
SPDEF(CAT_A,
    ".........#..#.",
    "@........@@@@@",
    "@........@*@*@",
    "#..#@@@@@@@%%p",
    "@.#@@#@@#@@%%.",
    "@.@@@@@@@@@@..",
    ".#@@@@@@@@@@..",
    "..%.%....%.%..",
    "..%.%....%.%..");
SPDEF(CAT_B,
    ".........#..#.",
    ".@.......@@@@@",
    ".@.......@*@*@",
    "#.#.@@@@@@@%%p",
    "@.#@@#@@#@@%%.",
    "@.@@@@@@@@@@..",
    ".#@@@@@@@@@@..",
    "...%.%..%..%..",
    "..%...%.%.%...");
SPDEF(TERR_A,
    ".........W.W..",
    "........WWWWW.",
    "..W.....WKWKW.",
    "..WW..WWWWWWWK",
    ".WWWWWWWWWWWWp",
    ".WGWWWWWWWRRW.",
    "..WWGWWWWWWW..",
    "..W.W....W.W..",
    "..W.W....W.W..");
SPDEF(TERR_B,
    ".........W.W..",
    "........WWWWW.",
    ".W......WKWKW.",
    ".WW...WWWWWWWK",
    ".WWWWWWWWWWWWp",
    ".WGWWWWWWWRRW.",
    "..WWGWWWWWWW..",
    "...W.W..W..W..",
    "..W...W.W.W...");
SPDEF(SLIME_A,
    "...EEEEEE...",
    "..EEgEEEEE..",
    ".EEgEEEEEEE.",
    ".EEEEEEEEEE.",
    "EEEKEEEKEEEE",
    "EEEKEEEKEEEE",
    "EEEEEMMEEEEE",
    "FFFFFFFFFFFF");
SPDEF(SLIME_B,
    "............",
    "...EEEEEE...",
    "..EEgEEEEE..",
    ".EEgEEEEEEE.",
    "EEEEEEEEEEEE",
    "EEEKEEEKEEEE",
    "EEEEEMMEEEEE",
    "FFFFFFFFFFFF");
SPDEF(ROBOT_A,
    "....R.......",
    "....A.......",
    "..SSSSSSS...",
    "..SBBSBBS...",
    "..SBKSKBS...",
    "..SSSMSSS...",
    "..SSSSSSS...",
    ".AAZZZZZAA..",
    "AA.ZRGRZ.AA.",
    "...ZZZZZ....",
    "...Z...Z....",
    "..ZZ...ZZ...");
SPDEF(ROBOT_B,
    "....R.......",
    "....A.......",
    "..SSSSSSS...",
    "..SBBSBBS...",
    "..SBKSKBS...",
    "..SSSMSSS...",
    "..SSSSSSS...",
    ".AAZZZZZAA..",
    "AA.ZRGRZ.AA.",
    "...ZZZZZ....",
    "..Z.....Z...",
    "..ZZ...ZZ...");
SPDEF(WISP_F,
    "....o....",
    "...oo.o..",
    "..ooyoo..",
    "..oyyyo..",
    ".ooyyyoo.",
    ".oyKyKyo.",
    ".oyyyyyo.",
    ".ooyMyoo.",
    "..ooooo..",
    "...ooo...");
SPDEF(WISP_W,
    "....B....",
    "...BBB...",
    "..BBbBB..",
    "..BbBBB..",
    ".BBbBBBB.",
    ".BKBBKBB.",
    ".BBBBBBB.",
    ".BBBMBBB.",
    "..BBBBB..",
    "...BBB...");
SPDEF(WISP_E,
    "...F.E...",
    "....FE...",
    "..JJJJJ..",
    ".JJJJJJJ.",
    "JJJJJJJJJ",
    "JJKJJJKJJ",
    "JJJJJJJJJ",
    "JJJJMJJJJ",
    ".JJQQQJJ.",
    "..QQQQQ..");
SPDEF(WISP_A,
    "..WWW....",
    ".WWWWW.W.",
    "WWWWWWWWW",
    "WWKWWWKWW",
    "WWWWWWWWW",
    "WWWWMWWWW",
    ".GWWWWWG.",
    "..GGWGG..");
SPDEF(GHOST,
    "...WWWWW...",
    "..WWWWWWW..",
    ".WWWWWWWWWG",
    ".WWKWWWKWWG",
    ".WWKWWWKWWG",
    ".WWWWWWWWWG",
    ".WWWWMMWWWG",
    ".WWWWWWWWWG",
    ".WWWWWWWWWG",
    ".WWWWWWWWWG",
    ".WW.WWW.WWG",
    "..W..W..W..");
SPDEF(WIZARD,
    "..........X..............",
    ".........XVX.............",
    "........XtVVX............",
    ".......XXXXXXX.......t...",
    "......XXXXXXXXX.....tIt..",
    "........JJJJJ........t...",
    "........JKJKJ........J...",
    ".otttttXWWWWWVyyyyyyyJyo.",
    "..yyyyyVXWWWVXyyyyyyyJy..",
    "..oyyyVXXXWVXXXyyyyyyyo..",
    "...oyyXXXXVXXXXyyyyyyo...",
    "....oyykkyyyykkyyyyyo....",
    ".....ooyyyyyyyyyyyoo.....",
    ".......ooyyyyyyyoo.......",
    ".........ooooooo.........");
SPDEF(DRAGON_UP,
    "..............E...E.............",
    ".............EEE.EEE............",
    "............EEEEEEEEE...........",
    "...........FEEEEEEEEF...........",
    "............FEEEEEEF....Y.Y.....",
    "...EE.....EEEEEEEEEEE..YEEEE....",
    ".EEEEEE.EEEEEEEEEEEEEEEEEKEEEE..",
    "EEFEEEEEEEEEEEEEEEEEEEEEEEEEEEEo",
    ".FFEEEEEEEJJJJJJJEEEEEEEEEEEEE..",
    "..FFFFEEEEJJJJJJJJEEEEEEEEEEF...",
    "....FFFFFFFEEEEEEEEEEEEEFFF.....",
    "........F.F......F.F............");
SPDEF(DRAGON_DN,
    "................................",
    "................................",
    "................................",
    "................................",
    "......................Y.Y.......",
    "...EE.................YEEEE.....",
    ".EEEEEE.EEEEEEEEEEEEEEEEEKEEEE..",
    "EEFEEEEEEEEEEEEEEEEEEEEEEEEEEEEo",
    ".FFEEEEEEEJJJJJJJEEEEEEEEEEEEE..",
    "..FFFFEEEEJJJJJJJJEEEEEEEEEEF...",
    "....FFFFFFFEEEEEEEEEEEEEFFF.....",
    ".........FEEEEEEEF..F.F.........",
    "..........FEEEEEF...............",
    "...........FEEEF................",
    "............FEEF................",
    ".............FF.................");
SPDEF(UFO,
    "........ssssss........",
    ".......sWWssssss......",
    "......sWbsssEsssss....",
    "...AAAAAAAAAAAAAAAA...",
    ".AAWWAAWWAAWWAAWWAAAA.",
    "AAAAAAAAAAAAAAAAAAAAAA",
    ".SSSSSSSSSSSSSSSSSSSS.",
    "..ZZ..ZZ......ZZ..ZZ..");
SPDEF(HEART,
    ".p.p.",
    "ppppp",
    ".ppp.",
    "..p..");
