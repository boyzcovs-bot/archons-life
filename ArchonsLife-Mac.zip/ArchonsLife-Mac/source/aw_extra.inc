/*
 * Archon's Life v3 - seasons, lakes, underground, and the new rides.
 * Included by aw_engine.c after update_palette()'s dependencies (needs AWWorld, PX, R, BLEND, blit*, panel_*).
 */

#define BIGY 0x3FFFFFFF

/* rotated filled ellipse (angle in radians, clockwise on screen); draws only rows above ymax */
static void ell_fill(AWWorld *w, int cx, int cy, float rx, float ry, float ang, Col c, int ymax) {
    float ca = cosf(ang), sa = sinf(ang);
    int R_ = (int)ceilf(fmaxf(rx, ry)) + 1;
    for (int dy = -R_; dy <= R_; dy++) {
        if (cy + dy >= ymax) break;
        for (int dx = -R_; dx <= R_; dx++) {
            float u = ((float)dx * ca + (float)dy * sa) / rx;
            float v = (-(float)dx * sa + (float)dy * ca) / ry;
            if (u * u + v * v <= 1.0f) PX(w, cx + dx, cy + dy, c);
        }
    }
}
static void blit_rows(AWWorld *w, const Sp *s, int x, int y, int r0, int r1, int flip) {
    int sw = sp_w(s);
    for (int r = r0; r < r1 && r < s->h; r++) {
        int len = (int)strlen(s->r[r]);
        for (int c = 0; c < len; c++) {
            char ch = s->r[r][c];
            if (ch == '.' || ch == ' ') continue;
            PX(w, flip ? x + (sw - 1 - c) : x + c, y + r, sp_col(ch, 0));
        }
    }
}

/* ------------------------------------------------------------------ */
/* seasons                                                             */
/* ------------------------------------------------------------------ */
/* how much each biome takes on the season (a volcano stays a volcano) */
static const float SEA_SUS[NPAL] = { 1.00f, 0.30f, 0.75f, 0.85f, 0.00f, 0.75f, 0.55f, 0.35f, 1.00f };

/* A random walk over the four seasons that never repeats the one before it. */
static int season_idx(AWWorld *w, int k) {
    if (k <= w->sea_k0) return w->sea_f0;
    if (k < w->sea_ck) { w->sea_ck = w->sea_k0; w->sea_cf = w->sea_f0; }
    while (w->sea_ck < k) {
        w->sea_ck++;
        w->sea_cf = (w->sea_cf + 1 + (int)(hash2(w->seed ^ 0x5EA5U, (uint32_t)w->sea_ck) % 3U)) & 3;
    }
    return w->sea_cf;
}

static void update_season(AWWorld *w) {
    double u = (w->ax + w->sea_off) / SEA_LEN;
    double fi = floor(u), f = u - fi;
    int k = (int)fi;
    float t = 0.0f;
    if (f > 0.78) { double s = (f - 0.78) / 0.22; t = (float)(s * s * (3.0 - 2.0 * s)); }
    int a = season_idx(w, k), b = season_idx(w, k + 1);
    float sus = lerpf(SEA_SUS[w->pa], SEA_SUS[w->pb], w->pt);
    if (w->hol == H_XMAS_EVE || w->hol == H_XMAS) { a = b = SE_WINTER; t = 0.0f; sus = 0.88f + 0.12f * sus; }       /* the holidays set the season */
    else if (w->hol == H_THANKS || w->hol == H_HALLOWEEN) { a = b = SE_AUTUMN; t = 0.0f; sus = 0.88f + 0.12f * sus; }
    w->sea_a = a; w->sea_b = b; w->sea_t = t;
    for (int i = 0; i < 4; i++) w->sea_k[i] = 0.0f;
    w->sea_k[a] += (1.0f - t) * sus;
    w->sea_k[b] += t * sus;
}

#define MX(field, tgt, kk, s) do { float m_ = (kk) * (s); if (m_ > 0.002f) p->field = lerpc(p->field, (Col)(tgt), m_ > 1.0f ? 1.0f : m_); } while (0)
static void season_grade(AWWorld *w) {
    Pal *p = &w->cur;
    const float *k = w->sea_k;
    float lum = (float)(((p->sky_mid >> 16) & 255) * 3 + ((p->sky_mid >> 8) & 255) * 6 + (p->sky_mid & 255)) / 2550.0f;
    float sk = 0.30f + 0.70f * clampf(lum * 1.5f, 0.0f, 1.0f);   /* dark skies are tinted less */
    /* spring: fresh greens, pink blossom */
    MX(fol1, 0x62D45A, k[SE_SPRING], 0.50f); MX(fol2, 0x35A85A, k[SE_SPRING], 0.45f);
    MX(grass_main, 0x92F26A, k[SE_SPRING], 0.35f); MX(grass_pale, 0xCCFFA6, k[SE_SPRING], 0.30f); MX(grass_dark, 0x58C050, k[SE_SPRING], 0.30f);
    MX(tick_light, 0xA8F58A, k[SE_SPRING], 0.30f);
    MX(sky_top, 0x5DB8FF, k[SE_SPRING], 0.12f * sk); MX(sky_bot, 0xDFF6FF, k[SE_SPRING], 0.14f * sk);
    MX(acc1, 0xFF8FC8, k[SE_SPRING], 0.30f);
    /* summer: deep saturated greens, hot clear sky */
    MX(fol1, 0x2F9B3A, k[SE_SUMMER], 0.35f); MX(fol2, 0x1F7A32, k[SE_SUMMER], 0.35f);
    MX(grass_main, 0x6BD03F, k[SE_SUMMER], 0.30f); MX(grass_dark, 0x3C9F2E, k[SE_SUMMER], 0.30f);
    MX(sky_top, 0x2F9BF0, k[SE_SUMMER], 0.25f * sk); MX(sky_mid, 0x7FC8FA, k[SE_SUMMER], 0.20f * sk); MX(sky_bot, 0xDCF3FF, k[SE_SUMMER], 0.15f * sk);
    MX(cel_col, 0xFFF080, k[SE_SUMMER], 0.30f);
    MX(acc2, 0xFFE040, k[SE_SUMMER], 0.30f);
    /* autumn: orange and red foliage, straw grass, warm light */
    MX(fol1, 0xE86E22, k[SE_AUTUMN], 0.88f); MX(fol2, 0xB83A18, k[SE_AUTUMN], 0.88f);
    MX(grass_pale, 0xE8D880, k[SE_AUTUMN], 0.65f); MX(grass_main, 0xC9A244, k[SE_AUTUMN], 0.65f); MX(grass_dark, 0x9A7424, k[SE_AUTUMN], 0.65f);
    MX(tick_dark, 0x9A7424, k[SE_AUTUMN], 0.65f); MX(tick_light, 0xF0E4A0, k[SE_AUTUMN], 0.65f);
    MX(sky_top, 0xE9A86A, k[SE_AUTUMN], 0.10f * sk); MX(sky_mid, 0xFFD7A0, k[SE_AUTUMN], 0.18f * sk); MX(sky_bot, 0xFFE9C6, k[SE_AUTUMN], 0.22f * sk);
    MX(acc1, 0xFFB020, k[SE_AUTUMN], 0.40f);
    /* winter: snow on the ground and the leaves, pale sky, white peaks */
    MX(fol1, 0xCFE3EC, k[SE_WINTER], 0.60f); MX(fol2, 0x93B2C6, k[SE_WINTER], 0.55f);
    MX(grass_pale, 0xFFFFFF, k[SE_WINTER], 0.95f); MX(grass_main, 0xE8F3FB, k[SE_WINTER], 0.92f); MX(grass_dark, 0xC2DAEB, k[SE_WINTER], 0.90f);
    MX(tick_dark, 0xC2DAEB, k[SE_WINTER], 0.90f); MX(tick_light, 0xFFFFFF, k[SE_WINTER], 0.90f);
    MX(sky_top, 0xA9BED4, k[SE_WINTER], 0.28f * sk); MX(sky_mid, 0xCDD9E6, k[SE_WINTER], 0.30f * sk); MX(sky_bot, 0xEEF3F8, k[SE_WINTER], 0.30f * sk);
    MX(cloud, 0xFFFFFF, k[SE_WINTER], 0.40f); MX(cloud_sh, 0xC4D2E0, k[SE_WINTER], 0.40f);
    MX(far_c, 0xDCE8F2, k[SE_WINTER], 0.38f * sk); MX(mid_c, 0xBFD2E2, k[SE_WINTER], 0.30f * sk); MX(near_c, 0xA3BDD3, k[SE_WINTER], 0.22f * sk);
    MX(liq, 0x2F6FB5, k[SE_WINTER], 0.25f); MX(acc1, 0xBFEFFF, k[SE_WINTER], 0.30f);
    if (k[SE_WINTER] > 0.5f && p->cap < k[SE_WINTER]) { p->cap = k[SE_WINTER]; p->cap_c = 0xFFFFFF; }
}
#undef MX

/* seasonal sprinkles on a tree tier (stable per tree via w->dkey) */
static void season_dots(AWWorld *w, int x, int y, int wd, int tier) {
    if (wd < 4) return;
    uint32_t h = hash2(w->dkey, (uint32_t)tier);
    if (w->sea_k[SE_WINTER] > 0.40f) R(w, x - wd / 2 + 1, y, wd - 2, 1, 0xF4FAFF);
    if (w->sea_k[SE_SPRING] > 0.40f) {
        for (int i = 0; i < 3; i++)
            PX(w, x - wd / 2 + 1 + (int)(rfn(h, i) * (float)(wd - 2)), y + (int)(rfn(h, 4 + i) * 2.0f), (i & 1) ? 0xFFFFFF : 0xFFB6D5);
    }
    if (w->sea_k[SE_AUTUMN] > 0.40f) {
        for (int i = 0; i < 2; i++)
            PX(w, x - wd / 2 + 1 + (int)(rfn(h, i) * (float)(wd - 2)), y + (int)(rfn(h, 4 + i) * 2.0f), i ? 0xFFC84A : 0xFF8A2A);
    }
}

/* ---- little vegetable gardens: carrots and turnips growing in tilled beds (world-fixed, one every so often on flat dry ground) ---- */
static int lm_hit(AWWorld *w, int a, int b);
#define CROP_SLOT 400
/* is there a garden in slot k? gives its left edge, how many plants and what is grown (0 mixed, 1 carrots, 2 turnips) */
static int crop_patch(AWWorld *w, int k, int *x0o, int *no, int *kindo) {
    uint32_t h = hash2(w->seed ^ 0xC20B0F5U, (uint32_t)k);
    if (rfn(h, 0) > 0.60f) return 0;
    int n = 5 + (int)(rfn(h, 1) * 4.0f);
    const int SP = 6, W = (n - 1) * SP + 1;
    int x0 = k * CROP_SLOT + 34 + (int)(rfn(h, 2) * (float)(CROP_SLOT - 68 - W));
    float km = rfn(h, 3);
    int kind = km < 0.22f ? 1 : (km < 0.44f ? 2 : 0);
    int h0 = ground_h(w, x0);
    if (h0 < 0) return 0;
    for (int x = x0 - 4; x <= x0 + W + 4; x += 2) {
        int g = ground_h(w, x);
        if (g < 0 || g < h0 - 2 || g > h0 + 2) return 0;
    }
    if (road_m(w, x0 - 6) > 0.0f || road_m(w, x0 + W + 6) > 0.0f || road_m(w, x0 + W / 2) > 0.0f) return 0;
    if (w->jp_on && (jeep_m(w, x0 - 6) > 0.0f || jeep_m(w, x0 + W + 6) > 0.0f || jeep_m(w, x0 + W / 2) > 0.0f)) return 0;
    if (pier_near(w, (double)(x0 - 6)) || pier_near(w, (double)(x0 + W + 6)) || pier_near(w, (double)(x0 + W / 2))) return 0;
    if (w->lk_on && x0 - 26 <= (int)w->lk_x1 && x0 + W + 26 >= (int)w->lk_x0) return 0;
    if (lm_hit(w, x0 - 10, x0 + W + 10)) return 0;
    *x0o = x0; *no = n; *kindo = kind;
    return 1;
}

static void draw_crops(AWWorld *w) {
    if (w->mode == M_DIVE || w->mode == M_SUB) return;
    const Pal *p = &w->cur;
    int camI = (int)floor(w->cam);
    const int SP = 6;
    float wint = w->sea_k[SE_WINTER] > 0.0f ? w->sea_k[SE_WINTER] : 0.0f;
    Col gd = lerpc(lerpc(0x3FA34D, p->fol1, 0.18f), 0xDDEBF2, wint * 0.45f);
    Col gl = lerpc(lerpc(0x86D65C, p->fol2, 0.12f), 0xEAF4F8, wint * 0.45f);
    Col gk = mulc(gd, 0.78f);
    for (int k = floordiv(camI - 70, CROP_SLOT); k <= floordiv(camI + w->vw + 6, CROP_SLOT); k++) {
        int x0, n, kind;
        if (!crop_patch(w, k, &x0, &n, &kind)) continue;
        uint32_t h = hash2(w->seed ^ 0xC20B0F5U, (uint32_t)k);
        int W = (n - 1) * SP + 1;
        if (x0 + W + 8 < camI || x0 - 10 > camI + w->vw) continue;
        /* the tilled bed: soil furrows replace the grass, with a raised ridge down the middle */
        Col sl = p->dirt_lt, sm = p->dirt, sd = p->dirt_dk;
        for (int wx = x0 - 4; wx <= x0 + W + 3; wx++) {
            int x = wx - camI, g = ground_h(w, wx);
            if (g < 0) continue;
            int top = w->gy - g, edge = (wx < x0 - 2 || wx > x0 + W + 1);
            if (!edge) PX(w, x, top - 1, lerpc(sl, 0xF4FAFF, wint * 0.8f));
            PX(w, x, top, edge ? sm : sl);
            PX(w, x, top + 1, (wx & 1) ? sd : sm);
            PX(w, x, top + 2, (wx & 1) ? sm : sd);
            if (!edge) { PX(w, x, top + 3, (wx & 1) ? sd : sm); PX(w, x, top + 4, (wx & 1) ? sm : sd); }   /* the furrows go down through the turf */
        }
        /* the plants */
        for (int i = 0; i < n; i++) {
            int wx = x0 + 2 + i * SP, x = wx - camI, g = ground_h(w, wx);
            if (g < 0) continue;
            int base = w->gy - g;                                    /* the soil surface at this plant */
            int carrot = kind == 1 ? 1 : (kind == 2 ? 0 : (i & 1) == (int)(h & 1u));
            int tall = (int)(rfn(h, 4 + i) * 2.0f);                  /* a little growth variety */
            if (carrot) {
                Col o1 = 0xFF8A1E, o2 = 0xE0680C, o3 = 0xFFB050;
                /* feathery tops */
                R(w, x, base - 5 - tall, 1, 4 + tall, gd);           /* centre stem */
                PX(w, x, base - 6 - tall, gl);
                PX(w, x - 1, base - 5 - tall, gl); PX(w, x + 1, base - 5 - tall, gl);
                PX(w, x - 2, base - 6 - tall, gl); PX(w, x + 2, base - 6 - tall, gl);
                PX(w, x - 1, base - 4 - tall, gd);  PX(w, x + 1, base - 4 - tall, gd);
                PX(w, x - 1, base - 3, gd);         PX(w, x + 1, base - 3, gd);
                PX(w, x - 2, base - 4, gk);         PX(w, x + 2, base - 4, gk);
                PX(w, x - 1, base - 2, gk);         PX(w, x + 1, base - 2, gk);
                /* the orange shoulder peeking out, then the root going down into the dirt */
                R(w, x - 1, base - 1, 3, 1, o1); PX(w, x - 1, base - 1, o3);
                R(w, x - 1, base, 3, 2, o1); PX(w, x + 1, base, o2); PX(w, x + 1, base + 1, o2);
                R(w, x - 1, base + 2, 3, 1, o2);
                R(w, x - 1, base + 3, 2, 2, o2); PX(w, x - 1, base + 3, o1);
                R(w, x, base + 5, 1, 2, o2);
                PX(w, x - 1, base + 1, 0xE0680C);                    /* a ring line */
            } else {
                Col pu = 0xA352B8, pl = 0xC77ADA, wh = 0xF2ECF2, wd = 0xD8CCD8;
                /* broad leaves */
                R(w, x, base - 6 - tall, 1, 3 + tall, gd);
                PX(w, x - 2, base - 7 - tall, gl); PX(w, x + 2, base - 7 - tall, gl);
                PX(w, x - 2, base - 6 - tall, gl); PX(w, x - 1, base - 6 - tall, gd); PX(w, x + 1, base - 6 - tall, gd); PX(w, x + 2, base - 6 - tall, gl);
                PX(w, x - 1, base - 5 - tall, gl); PX(w, x, base - 5 - tall, gl); PX(w, x + 1, base - 5 - tall, gl);
                PX(w, x - 1, base - 4, gd); PX(w, x + 1, base - 4, gd);
                /* the round white root with a purple shoulder, half out of the ground */
                R(w, x - 1, base - 3, 3, 1, pu); PX(w, x - 1, base - 3, pl);
                R(w, x - 2, base - 2, 5, 2, pu); PX(w, x - 2, base - 2, pl); PX(w, x - 1, base - 2, pl);
                R(w, x - 2, base, 5, 1, lerpc(pu, wh, 0.55f));
                R(w, x - 2, base + 1, 5, 2, wh); PX(w, x + 2, base + 1, wd); PX(w, x + 2, base + 2, wd);
                R(w, x - 1, base + 3, 3, 1, wd);
                PX(w, x, base + 4, wd);
            }
        }
        /* a wee stake at the left end showing what is in the bed */
        {
            int wx = x0 - 3, x = wx - camI, g = ground_h(w, wx);
            if (g >= 0) {
                int base = w->gy - g;
                R(w, x, base - 5, 1, 6, 0x7A4A24);
                int cr = kind == 1 || (kind == 0 && (h & 1u) == 0u);
                R(w, x - 1, base - 8, 3, 3, 0xFFF3C2);
                PX(w, x, base - 7, cr ? 0xFF8A1E : 0xA352B8); PX(w, x - 1, base - 6, cr ? 0xFF8A1E : 0xF2ECF2); PX(w, x + 1, base - 6, cr ? 0x3FA34D : 0x3FA34D);
            }
        }
    }
}

static void draw_season_flora(AWWorld *w) {
    int camI = (int)floor(w->cam);
    const int S = 19;
    int k0 = floordiv(camI - 10, S), k1 = floordiv(camI + w->vw + 10, S);
    static const Col tul[5] = { 0xFF4D6D, 0xFFD23F, 0xFF8FB8, 0xFFFFFF, 0xB58CFF };
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ 0x5EA5F10U, (uint32_t)k);
        float b = rfn(h, 0);
        int se = b < 0.30f ? SE_SPRING : (b < 0.52f ? SE_SUMMER : (b < 0.72f ? SE_AUTUMN : (b < 0.92f ? SE_WINTER : -1)));
        if (se < 0) continue;
        if (w->sea_k[se] <= rfn(h, 7) * 0.95f + 0.02f) continue;
        int wx = k * S + 3 + (int)(rfn(h, 1) * (float)(S - 6));
        int gh = ground_h(w, wx);
        if (gh < 0 || ground_h(w, wx - 2) != gh || ground_h(w, wx + 2) != gh) continue;
        if (road_m(w, wx - 4) > 0.0f || road_m(w, wx + 4) > 0.0f || pier_near(w, (double)wx)) continue;
        int x = wx - camI, base = w->gy - gh;
        float v = rfn(h, 3);
        int c = (int)(rfn(h, 2) * 5.0f) % 5;
        switch (se) {
            case SE_SPRING:
                if (v < 0.3f) {                              /* blossom bush */
                    R(w, x - 4, base - 4, 9, 4, w->cur.fol1); R(w, x - 3, base - 6, 7, 2, w->cur.fol1);
                    PX(w, x - 2, base - 5, 0xFFB6D5); PX(w, x + 1, base - 6, 0xFFFFFF); PX(w, x + 3, base - 3, 0xFFB6D5); PX(w, x - 3, base - 2, 0xFFFFFF);
                } else {                                     /* tulip */
                    R(w, x, base - 4, 1, 4, 0x3FA34D); PX(w, x + 1, base - 2, 0x3FA34D);
                    R(w, x - 1, base - 7, 3, 3, tul[c]); PX(w, x, base - 8, tul[c]); PX(w, x, base - 5, mulc(tul[c], 0.75f));
                }
                break;
            case SE_SUMMER: {                                /* sunflower */
                int hgt = 8 + (int)(rfn(h, 4) * 4.0f);
                R(w, x, base - hgt, 1, hgt, 0x3FA34D); R(w, x + 1, base - hgt / 2, 2, 1, 0x3FA34D); PX(w, x - 1, base - hgt / 2 - 2, 0x3FA34D);
                R(w, x - 2, base - hgt - 2, 5, 5, 0xFFD23F); R(w, x - 1, base - hgt - 3, 3, 1, 0xFFD23F); R(w, x - 1, base - hgt + 3, 3, 1, 0xFFD23F);
                R(w, x - 1, base - hgt - 1, 3, 3, 0x7A4A24); PX(w, x, base - hgt, 0x4F2F18);
            } break;
            case SE_AUTUMN:
                if (v < 0.55f) {                             /* pumpkin */
                    R(w, x - 4, base - 5, 9, 5, 0xE8742A); R(w, x - 3, base - 6, 7, 1, 0xE8742A); R(w, x - 3, base - 1, 7, 1, 0xC4561A);
                    R(w, x - 1, base - 5, 1, 5, 0xC4561A); R(w, x + 2, base - 5, 1, 5, 0xC4561A); R(w, x, base - 8, 1, 2, 0x3F7A2A); PX(w, x - 3, base - 5, 0xFFA060);
                } else {                                     /* pile of leaves */
                    R(w, x - 5, base - 2, 11, 2, 0xC9401E); R(w, x - 3, base - 4, 7, 2, 0xE8642A); R(w, x - 1, base - 5, 3, 1, 0xFFB020);
                    PX(w, x - 4, base - 3, 0xFFB020); PX(w, x + 3, base - 3, 0xB8301A); PX(w, x + 6, base - 1, 0xFFB020);
                }
                break;
            default:
                if (v < 0.22f) {                             /* snowman */
                    ell_fill(w, x, base - 4, 4.4f, 4.0f, 0, 0xF4FAFF, BIGY); R(w, x - 3, base - 2, 6, 2, 0xD6E8F4);
                    ell_fill(w, x, base - 10, 3.4f, 3.2f, 0, 0xFFFFFF, BIGY);
                    ell_fill(w, x, base - 15, 2.8f, 2.6f, 0, 0xFFFFFF, BIGY);
                    PX(w, x - 1, base - 16, 0x1D1020); PX(w, x + 1, base - 16, 0x1D1020); R(w, x, base - 15, 3, 1, 0xFF8A2A);
                    R(w, x - 3, base - 13, 7, 1, 0xE8442A); R(w, x + 2, base - 12, 1, 2, 0xE8442A);
                    R(w, x - 8, base - 12, 4, 1, 0x6B3E1F); PX(w, x - 9, base - 13, 0x6B3E1F); R(w, x + 4, base - 11, 4, 1, 0x6B3E1F); PX(w, x + 8, base - 12, 0x6B3E1F);
                    PX(w, x, base - 9, 0x1D1020); PX(w, x, base - 6, 0x1D1020);
                } else {                                     /* snow drift */
                    R(w, x - 5, base - 2, 11, 2, 0xF4FAFF); R(w, x - 3, base - 4, 7, 2, 0xFFFFFF); R(w, x - 5, base - 1, 11, 1, 0xCFE3F2); PX(w, x - 1, base - 5, 0xFFFFFF);
                }
                break;
        }
    }
}

/* ------------------------------------------------------------------ */
/* lakes                                                               */
/* ------------------------------------------------------------------ */
static Col water_col(const AWWorld *w, int dd) {
    const Pal *p = &w->cur;
    float f = (float)dd / (0.46f * (float)w->vh);
    f = f < 0.0f ? 0.0f : (f > 1.0f ? 1.0f : f);
    Col sh = lerpc(p->liq_hi, p->liq, 0.45f);
    Col dp = lerpc(mulc(p->liq, 0.38f), 0x07122E, 0.45f);
    return f < 0.30f ? lerpc(sh, p->liq, f / 0.30f) : lerpc(p->liq, dp, (f - 0.30f) / 0.70f);
}

static void draw_water(AWWorld *w) {
    if (!w->lk_on) return;
    int camI = (int)floor(w->cam);
    float t = (float)w->t;
    float fade = 0.40f * (float)w->vh;
    for (int x = 0; x < w->vw; x++) {
        int wx = camI + x;
        int top = w->gy - ground_h(w, wx);
        if (top <= w->gy) continue;
        for (int y = imax(w->gy, -w->oy); y < top && y + w->oy < w->vh; y++) {
            int dd = y - w->gy;
            Col c = water_col(w, (dd / 5) * 5);
            float rp = sinf((float)(wx + dd / 3) * 0.075f + t * 0.35f) * sinf((float)(wx - dd / 4) * 0.031f + t * 0.17f);
            if (rp > 0.25f) { float k = (rp - 0.25f) * 0.30f * (1.0f - (float)dd / fade); if (k > 0.0f) c = lerpc(c, 0xFFFFFF, k); }
            if (dd < 14 && ((wx * 7 + dd * 13 + (int)(t * 3.0f)) % 17) == 0) c = lerpc(c, 0xFFFFFF, 0.25f);
            w->px[(y + w->oy) * w->vw + x] = c;
        }
    }
}

/* tint over everything that swims (so the sub, fish and signs look submerged), foam, winter ice */
static void draw_water_front(AWWorld *w) {
    if (!w->lk_on) return;
    int camI = (int)floor(w->cam);
    float t = (float)w->t;
    const Pal *p = &w->cur;
    Col deepc = lerpc(mulc(p->liq, 0.45f), 0x07122E, 0.4f);
    int ice = w->sea_k[SE_WINTER] > 0.35f;
    float fade = 0.40f * (float)w->vh;
    for (int x = 0; x < w->vw; x++) {
        int wx = camI + x;
        int top = w->gy - ground_h(w, wx);
        if (top <= w->gy) continue;
        for (int y = imax(w->gy + 1, -w->oy); y < top && y + w->oy < w->vh; y++) {
            int dd = y - w->gy;
            int a = 38 + (int)(80.0f * (float)dd / fade);
            if (a > 118) a = 118;
            uint32_t *px = &w->px[(y + w->oy) * w->vw + x];
            Col d = *px;
            int r = (int)((d >> 16) & 255) + ((((int)((deepc >> 16) & 255) - (int)((d >> 16) & 255)) * a) >> 8);
            int g = (int)((d >> 8) & 255) + ((((int)((deepc >> 8) & 255) - (int)((d >> 8) & 255)) * a) >> 8);
            int b = (int)(d & 255) + ((((int)(deepc & 255) - (int)(d & 255)) * a) >> 8);
            *px = rgb(r, g, b);
        }
        /* foam line */
        int wave = ((wx + (int)(t * 7.0f)) & 7) < 3;
        PX(w, x, w->gy, wave ? p->liq_hi : lerpc(p->liq_hi, p->liq, 0.45f));
        if (((wx * 3 + (int)(t * 5.0f)) & 15) < 2) PX(w, x, w->gy + 1, lerpc(p->liq_hi, 0xFFFFFF, 0.5f));
        if (ice) {   /* drifting floes */
            int wa = wx + (int)(t * 1.6f);
            int cell = floordiv(wa, 34);
            uint32_t h = hash2(w->lk_seed ^ 0x1CEU, (uint32_t)cell);
            if (rfn(h, 0) < 0.30f + 0.5f * w->sea_k[SE_WINTER]) {
                int s0 = cell * 34 + (int)(rfn(h, 1) * 12.0f), len = 10 + (int)(rfn(h, 2) * 14.0f);
                if (wa >= s0 && wa < s0 + len) {
                    int e = (wa == s0 || wa == s0 + len - 1);
                    if (!e) PX(w, x, w->gy - 1, 0xFFFFFF);
                    PX(w, x, w->gy, 0xF0F8FF);
                    PX(w, x, w->gy + 1, e ? 0xCFE8F6 : 0xA8CCE4);
                    if (!e && ((wa + cell) & 3) == 0) PX(w, x, w->gy + 2, 0x86B4D4);
                }
            }
        }
    }
}

static void draw_seabed(AWWorld *w) {
    if (!w->lk_on) return;
    int camI = (int)floor(w->cam);
    float t = (float)w->t;
    const int S = 13;
    int k0 = floordiv(camI - 24, S), k1 = floordiv(camI + w->vw + 24, S);
    static const Col cor[5] = { 0xFF6FA3, 0xFF8A4A, 0xB58CFF, 0xFFD23F, 0x4FE0C8 };
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->lk_seed ^ 0xBEDU, (uint32_t)k);
        if (rfn(h, 0) > 0.62f) continue;
        int wx = k * S + (int)(rfn(h, 1) * (float)S);
        if ((double)wx <= w->lk_x0 + 14.0 || (double)wx >= w->lk_x1 - 14.0) continue;
        int d = lake_depth(w, wx);
        if (d < 12) continue;
        int x = wx - camI, base = w->gy + d;
        float kind = rfn(h, 2);
        Col cc = cor[(int)(rfn(h, 3) * 5.0f) % 5];
        if (kind < 0.36f) {                                   /* kelp */
            int hk = 14 + (int)(rfn(h, 4) * 24.0f);
            float ph = rfn(h, 5) * 6.28f;
            for (int i = 0; i < hk; i++) {
                int sw = (int)floorf(sinf(t * 1.2f + (float)i * 0.25f + ph) * (0.5f + (float)i * 0.045f) + 0.5f);
                Col kc = (i % 5 < 2) ? 0x2FA85A : 0x1F8A48;
                R(w, x + sw, base - i, 2, 1, kc);
                if (i % 6 == 3) PX(w, x + sw + 2 + (i & 1), base - i, 0x44C070);
                if (i % 6 == 0 && i > 0) PX(w, x + sw - 1, base - i, 0x1A7A3E);
            }
        } else if (kind < 0.58f) {                            /* branching coral */
            for (int f = -1; f <= 1; f++) {
                int hg = 7 + (int)(rfn(h, 6 + (f + 1)) * 8.0f);
                R(w, x + f * 3, base - hg, 2, hg, cc);
                PX(w, x + f * 3, base - hg - 1, lerpc(cc, 0xFFFFFF, 0.5f));
                PX(w, x + f * 3 + 2, base - hg / 2, cc);
            }
            R(w, x - 4, base - 2, 9, 2, mulc(cc, 0.75f));
        } else if (kind < 0.70f) {                            /* fan coral */
            for (int dy = 0; dy < 10; dy++) {
                int hw = 2 + dy / 2 + (dy > 7 ? -(dy - 7) : 0);
                for (int dx = -hw; dx <= hw; dx++) PX(w, x + dx, base - 3 - (9 - dy), ((dx + dy) % 3 == 0) ? mulc(cc, 0.8f) : cc);
            }
            R(w, x, base - 3, 1, 3, mulc(cc, 0.7f));
        } else if (kind < 0.80f) {                            /* brain coral */
            ell_fill(w, x, base - 3, 6.0f, 4.0f, 0, cc, base);
            for (int i = 0; i < 9; i++) { uint32_t q = hash2(h, (uint32_t)i); PX(w, x - 4 + (int)(rfn(q, 0) * 9.0f), base - 6 + (int)(rfn(q, 1) * 5.0f), mulc(cc, 0.65f)); }
        } else if (kind < 0.89f) {                            /* rock */
            Col g = lerpc(0x7A8296, w->cur.dirt, 0.3f);
            ell_fill(w, x, base - 3, 6.5f, 4.0f, 0, g, base + 1); R(w, x - 3, base - 6, 3, 1, mulc(g, 1.3f));
            if (rfn(h, 8) < 0.5f) ell_fill(w, x + 7, base - 2, 3.5f, 2.5f, 0, mulc(g, 0.85f), base + 1);
        } else if (kind < 0.96f) {                            /* starfish / shell */
            Col sc = rfn(h, 9) < 0.5f ? 0xFF8A2A : 0xFF7AA8;
            R(w, x - 1, base - 2, 3, 1, sc); R(w, x, base - 3, 1, 3, sc); PX(w, x - 2, base - 1, sc); PX(w, x + 2, base - 1, sc); PX(w, x, base - 2, lerpc(sc, 0xFFFFFF, 0.5f));
        } else {                                              /* treasure chest */
            R(w, x - 5, base - 6, 10, 6, 0x8A5A2B); R(w, x - 5, base - 8, 10, 2, 0xA06C35); R(w, x - 5, base - 5, 10, 1, 0xFFD23F);
            R(w, x - 1, base - 6, 2, 3, 0xFFD23F); PX(w, x, base - 5, 0x4F2F18);
            if (sinf(t * 2.0f + (float)k) > 0.6f) PX(w, x + 3, base - 9, 0xFFFFFF);
        }
    }
}

/* underground: caves, rocks, ores, crystals, fossils, dinosaur skeletons (aw_under.inc) */
#include "aw_under.inc"

/* the digger's tunnel: remembered per world column */
static void dig_record(AWWorld *w, float yc) {
    int ax = (int)floor(w->ax);
    for (int dx = -3; dx <= 17; dx++) {
        int wx = ax + dx, i = wx & (TRN - 1);
        int r = 10;
        if (dx > 8) r = 10 - (dx - 8) * 7 / 9;
        if (r < 3) r = 3;
        w->tr_x[i] = wx;
        w->tr_y[i] = (short)floorf(yc + w->dig_slope * (float)dx + 0.5f);
        w->tr_r[i] = (short)r;
    }
}
static void draw_tunnels(AWWorld *w) {
    int camI = (int)floor(w->cam);
    const Pal *p = &w->cur;
    Col wall = lerpc(mulc(p->dirt_dk, 0.55f), 0x0C0706, 0.55f);
    Col rimc = lerpc(p->dirt_dk, 0x0C0706, 0.30f);
    Col fleck = lerpc(wall, 0x3A2418, 0.6f);
    for (int x = 0; x < w->vw; x++) {
        int wx = camI + x, i = wx & (TRN - 1);
        if (w->tr_x[i] != wx) continue;
        int yc = w->tr_y[i], r = w->tr_r[i];
        int top = w->gy - ground_h(w, wx);
        for (int y = yc - r; y <= yc + r; y++) {
            if (y < top) continue;
            int sy = y + w->oy;
            if ((unsigned)sy >= (unsigned)w->vh) continue;
            int e = imin(y - (yc - r), (yc + r) - y);
            Col c = e == 0 ? rimc : wall;
            if (e > 1 && ((wx * 5 + y * 7) % 9) == 0) c = fleck;
            w->px[sy * w->vw + x] = c;
        }
    }
}
static void draw_dig_light(AWWorld *w) {
    if (w->mode != M_DIG || w->alt > -6.0f) return;
    int camI = (int)floor(w->cam);
    int sx = (int)floor(w->ax) - camI + 18, sy = (int)floorf(w->ay) - 8;
    float ang = atan2f(w->dig_slope, 1.0f), len = 54.0f, half = 0.55f;
    for (int dy = -40; dy <= 40; dy++) for (int dx = 0; dx <= 54; dx++) {
        if (((dx + dy) & 1) != 0) continue;
        float d = sqrtf((float)(dx * dx + dy * dy));
        if (d > len || d < 1.0f) continue;
        float a = atan2f((float)dy, (float)dx) - ang;
        if (fabsf(a) > half) continue;
        int al = (int)(58.0f * (1.0f - d / len) * (1.0f - 0.6f * fabsf(a) / half));
        if (al > 0) BLEND(w, sx + dx, sy + dy, 0xFFE9A0, al);
    }
}

/* ------------------------------------------------------------------ */
/* Archon's new rides                                                  */
/* ------------------------------------------------------------------ */
static const float RCOS[8] = { 1.0f, 0.70710678f, 0.0f, -0.70710678f, -1.0f, -0.70710678f, 0.0f, 0.70710678f };
static const float RSIN[8] = { 0.0f, 0.70710678f, 1.0f, 0.70710678f, 0.0f, -0.70710678f, -1.0f, -0.70710678f };

static void draw_h_dig(AWWorld *w, int sx, int sy) {
    float t = (float)w->t;
    int steps = w->dig_head > 0.5f ? 7 : (w->dig_head < -0.5f ? 1 : 0);
    int rattle = (w->alt < -2.0f && (((int)(t * 30.0f)) & 1)) ? 1 : 0;
    int cx = sx + rattle, cy = sy - 7;
    const Sp *dr = (((int)(t * 16.0f)) & 1) ? &DIG_DRILL_A : &DIG_DRILL_B;
    blit_rot(w, &DIG_BODY, 0, 1, 40, 22, 13.0f, 11.0f, cx, cy, steps);
    blit_rot(w, dr, 26, 6, 40, 22, 13.0f, 11.0f, cx, cy, steps);
    float vx = -3.0f, vy = -5.0f;
    int px = cx + (int)floorf(vx * RCOS[steps] - vy * RSIN[steps] + 0.5f);
    int py = cy + (int)floorf(vx * RSIN[steps] + vy * RCOS[steps] + 0.5f);
    holo_face(w, px - 4, py - 2);
}

static void draw_h_sub(AWWorld *w, int sx, int sy, int blink) {
    float t = (float)w->t;
    int bob = w->alt > -3.0f ? (int)floorf(sinf(t * 2.0f) * 1.0f + 0.5f) : (int)floorf(sinf(t * 1.1f) + 0.5f);
    int left = sx - 20, top = sy - 14 + bob;
    if (w->alt < -12.0f) {   /* headlamp beam */
        for (int dy = -10; dy <= 10; dy++) for (int dx = 0; dx <= 42; dx++) {
            if (((dx + dy) & 1) != 0) continue;
            if (abs(dy) * 4 > dx + 6) continue;
            int al = (int)(46.0f * (1.0f - (float)dx / 42.0f));
            if (al > 0) BLEND(w, sx + 20 + dx, top + 13 + dy, 0xFFF59A, al);
        }
    }
    blit(w, &SUB_BODY, left, top, 0, 0);
    holo_window(w, left + 16, top + 6, blink);
    int ph = ((int)(t * 18.0f)) & 1;
    R(w, left - 1, top + 11 + ph, 1, 6 - 2 * ph, 0x8FA3C0);
}

static void draw_h_boat(AWWorld *w, int sx, int sy, int blink) {
    float t = (float)w->t;
    int bob = (int)floorf(sinf(t * 2.3f) * 1.0f + 0.5f);
    int htop = sy - 8 + bob, left = sx - 18, stop = htop - 30;
    const Sp *sail = (((int)(t * 1.4f)) & 1) ? &BOAT_SAIL_B : &BOAT_SAIL_A;
    float hoist = 1.0f;
    if (w->stage == 1) hoist = clampf((w->stage_t - 0.25f) / 0.9f, 0.0f, 1.0f);
    int r0 = 30 - (int)(hoist * 30.0f + 0.5f);
    blit_rows(w, sail, left, stop, imax(r0, 0), 30, 0);
    draw_arch(w, sx - 11, stop + 20, 4, blink, 0, 0);
    blit(w, &BOAT_HULL, left, htop, 0, 0);
}

/* ------------------------------------------------------------------ */
/* signs for the deep places                                           */
/* ------------------------------------------------------------------ */
static void carrier_mine(AWWorld *w, int xc, int yc, uint32_t k, int info, int U) {
    int pw, ph; panel_dims(w, info, U, &pw, &ph);
    const Pal *p = &w->cur;
    float t = (float)w->t;
    int rx = pw / 2 + 17, ry = ph / 2 + 14;
    Col wall = lerpc(mulc(p->dirt_dk, 0.55f), 0x0C0706, 0.55f), rimc = lerpc(p->dirt_dk, 0x0C0706, 0.30f);
    ell_fill(w, xc, yc, (float)rx + 1.0f, (float)ry + 1.0f, 0, rimc, BIGY);
    ell_fill(w, xc, yc, (float)rx, (float)ry, 0, wall, BIGY);
    int x = xc - pw / 2, y = yc - ph / 2;
    if (k & 1u) {      /* timber frame with lanterns */
        R(w, x - 6, y - 7, pw + 12, 3, 0x7A4A24); R(w, x - 6, y - 7, pw + 12, 1, 0xB27A43);
        R(w, x - 6, y - 7, 3, ph + 14, 0x6B3E1F); R(w, x - 6, y - 7, 1, ph + 14, 0x8A5A2B);
        R(w, x + pw + 3, y - 7, 3, ph + 14, 0x6B3E1F); R(w, x + pw + 3, y - 7, 1, ph + 14, 0x8A5A2B);
        R(w, x + 4, y - 4, 1, 3, 0x8FA3C0); R(w, x + pw - 5, y - 4, 1, 3, 0x8FA3C0);
        for (int s = 0; s < 2; s++) {
            int lx = s ? x + pw + 8 : x - 11, ly = y + ph / 2 - 2;
            int fl = ((int)(t * 9.0f + (float)s * 3.0f)) & 1;
            for (int dy = -9; dy <= 9; dy++) for (int dx = -9; dx <= 9; dx++)
                if (dx * dx + dy * dy < 81 && ((dx + dy) & 1) == 0) BLEND(w, lx + 1 + dx, ly + 2 + dy, 0xFFC860, 26 + fl * 6);
            R(w, lx, ly - 1, 3, 1, 0x4A4A5A); R(w, lx, ly, 3, 4, 0xFFC84A); R(w, lx + 1, ly + 1, 1, 2, 0xFFF59A); R(w, lx, ly + 4, 3, 1, 0x4A4A5A);
        }
    } else {           /* crystal alcove */
        static const Col gc[3] = { 0x7DF9FF, 0xFF7AD9, 0xB58CFF };
        Col c = gc[(k >> 3) % 3u];
        for (int dy = -ry; dy <= ry; dy++) for (int dx = -rx - 6; dx <= rx + 6; dx++) {
            float u = (float)dx / (float)(rx + 6), v = (float)dy / (float)(ry + 6);
            if (u * u + v * v < 1.0f && ((dx + dy) & 1) == 0 && u * u + v * v > 0.45f) BLEND(w, xc + dx, yc + dy, c, 22);
        }
        for (int s = 0; s < 2; s++) {
            int bx = s ? xc + rx - 6 : xc - rx + 4;
            for (int i = 0; i < 3; i++) {
                int bh = 6 + i * 3 + (int)(((k >> (5 + i)) & 3u));
                R(w, bx + i * 3 - 3, yc + ry - 3 - bh, 3, bh, c); PX(w, bx + i * 3 - 2, yc + ry - 4 - bh, lerpc(c, 0xFFFFFF, 0.6f)); R(w, bx + i * 3 - 3, yc + ry - 3 - bh, 1, bh, lerpc(c, 0xFFFFFF, 0.45f));
            }
        }
        if (sinf(t * 2.1f + (float)k) > 0.7f) PX(w, xc - rx + 8, yc + ry - 14, 0xFFFFFF);
        R(w, x - 2, y - 2, pw + 4, ph + 4, 0x2A3A66); R(w, x - 2, y - 2, pw + 4, 1, lerpc(c, 0xFFFFFF, 0.3f));
    }
    if (k & 1u) R(w, x - 2, y - 2, pw + 4, ph + 4, 0x4F2F18);
    panel_face(w, x, y, info, U);
}

static void carrier_seabed(AWWorld *w, int xc, int base, uint32_t k, int info, int U) {
    int pw, ph; panel_dims(w, info, U, &pw, &ph);
    float t = (float)w->t;
    int bottom = base - 10, x = xc - pw / 2, y = bottom - ph;
    R(w, x + pw / 5, bottom, 3, 10, 0x4F5A3A); R(w, x + pw / 5, bottom, 1, 10, 0x6B7A4A);
    R(w, x + pw - pw / 5 - 3, bottom, 3, 10, 0x4F5A3A); R(w, x + pw - pw / 5 - 3, bottom, 1, 10, 0x6B7A4A);
    R(w, x - 2, y - 2, pw + 4, ph + 4, 0x5A6A48); R(w, x - 2, y - 2, pw + 4, 1, 0x86A06A); R(w, x - 2, y + ph + 1, pw + 4, 1, 0x34402A);
    panel_face(w, x, y, info, U);
    /* barnacles and weed */
    for (int i = 0; i < 5; i++) { uint32_t q = hash2(k, (uint32_t)i); PX(w, x - 2 + (int)(rfn(q, 0) * (float)(pw + 4)), y - 3 + (int)(rfn(q, 1) * 2.0f), 0xD8E0C8); }
    for (int s = 0; s < 3; s++) {
        int bx = x + (s * (pw - 2)) / 2;
        for (int i = 0; i < 9; i++) { int sw = (int)floorf(sinf(t * 1.3f + (float)i * 0.4f + (float)s) * 1.2f + 0.5f); R(w, bx + sw, y - 3 - i, 1, 1, 0x2FA85A); }
    }
    /* a glow-orb on a stalk */
    int ox = x + pw + 7, oy2 = bottom - 3 + (int)floorf(sinf(t * 1.1f + (float)k) * 1.5f);
    for (int dy = -6; dy <= 6; dy++) for (int dx = -6; dx <= 6; dx++)
        if (dx * dx + dy * dy < 36 && ((dx + dy) & 1) == 0) BLEND(w, ox + dx, oy2 + dy, 0x9FFFE8, 30);
    R(w, ox - 1, oy2 - 1, 3, 3, 0xCFFFF4); PX(w, ox, oy2, 0xFFFFFF); R(w, ox, oy2 + 2, 1, 14, 0x2FA85A);
}

#define DSLOT 230
static void draw_deep_panels(AWWorld *w) {
    static const int SEQ[4] = { INFO_TIME, INFO_DATE, INFO_TIME, INFO_TEMP };
    int camI = (int)floor(w->cam);
    int U = panel_U(w);
    int k0 = floordiv(camI - 200, DSLOT), k1 = floordiv(camI + w->vw + 200, DSLOT);
    if (w->mode == M_DIG) {
        for (int k = k0; k <= k1; k++) {
            uint32_t h = hash2(w->seed ^ 0x3D16U, (uint32_t)k);
            int info = SEQ[(k + (int)(w->seed >> 13)) & 3];
            if (info == INFO_TEMP && !w->w_valid) info = INFO_TIME;
            int xc = k * DSLOT + DSLOT / 2 + (int)((rfn(h, 2) - 0.5f) * 40.0f) - camI;
            int yc = w->gy + (int)((0.52f + (rfn(h, 3) - 0.5f) * 0.05f) * (float)w->vh);
            w->ink = ink_pick(w->seed ^ 0xAB30u, k); w->dfmt = date_fmt_pick(w->seed ^ 0xAB30u, k);
            carrier_mine(w, xc, yc, h, info, U);
        }
    }
    if (w->lk_on) {
        for (int k = k0; k <= k1; k++) {
            uint32_t h = hash2(w->lk_seed ^ 0x5EA5160U, (uint32_t)k);
            int info = SEQ[(k + (int)(w->seed >> 7)) & 3];
            if (info == INFO_TEMP && !w->w_valid) info = INFO_TIME;
            int wx = k * DSLOT + DSLOT / 2 + (int)((rfn(h, 2) - 0.5f) * 40.0f);
            if ((double)wx < w->lk_x0 + 60.0 || (double)wx > w->lk_x1 - 60.0) continue;
            int d = lake_depth(w, wx);
            if (d < 60) continue;
            w->ink = ink_pick(w->lk_seed ^ 0xAB40u, k); w->dfmt = date_fmt_pick(w->lk_seed ^ 0xAB40u, k);
            carrier_seabed(w, wx - camI, w->gy + d, h, info, U);
        }
    }
}

#include "aw_landmark.inc"
#include "aw_dive.inc"
