/*
 * Archon's Life - macOS HTTPS GET.
 *
 * Uses the libcurl that ships with macOS, loaded with dlopen so the saver needs no extra
 * frameworks or headers to build. Any failure (library missing, sandbox blocks the network,
 * offline) just returns -1 and the saver leaves the temperature sign out.
 */
#include <dlfcn.h>
#include <stddef.h>
#include <string.h>
#include "aw_weather.h"

typedef void CURL;
typedef struct { char *buf; int cap; int len; int overflow; } Sink;

static void  *(*c_init)(void);
static int    (*c_setopt)(CURL *, int, ...);
static int    (*c_perform)(CURL *);
static int    (*c_getinfo)(CURL *, int, ...);
static void   (*c_cleanup)(CURL *);
static int    g_loaded = 0;   /* 0 = not tried, 1 = ok, -1 = unavailable */

#define CURLOPT_WRITEDATA      10001
#define CURLOPT_URL            10002
#define CURLOPT_TIMEOUT           13
#define CURLOPT_USERAGENT      10018
#define CURLOPT_FOLLOWLOCATION    52
#define CURLOPT_NOSIGNAL          99
#define CURLOPT_CONNECTTIMEOUT    78
#define CURLOPT_WRITEFUNCTION  20011
#define CURLINFO_RESPONSE_CODE 0x200002

static int load_curl(void) {
    if (g_loaded) return g_loaded > 0;
    static const char *const names[] = { "/usr/lib/libcurl.4.dylib", "libcurl.4.dylib", "libcurl.dylib", NULL };
    void *h = NULL;
    for (int i = 0; names[i] && !h; i++) h = dlopen(names[i], RTLD_LAZY | RTLD_LOCAL);
    if (h) {
        *(void **)&c_init = dlsym(h, "curl_easy_init");
        *(void **)&c_setopt = dlsym(h, "curl_easy_setopt");
        *(void **)&c_perform = dlsym(h, "curl_easy_perform");
        *(void **)&c_getinfo = dlsym(h, "curl_easy_getinfo");
        *(void **)&c_cleanup = dlsym(h, "curl_easy_cleanup");
    }
    g_loaded = (h && c_init && c_setopt && c_perform && c_getinfo && c_cleanup) ? 1 : -1;
    return g_loaded > 0;
}

static size_t sink_cb(char *p, size_t sz, size_t n, void *ud) {
    Sink *s = (Sink *)ud;
    size_t t = sz * n;
    if ((size_t)s->len + t >= (size_t)s->cap) { s->overflow = 1; return 0; }   /* abort the transfer */
    memcpy(s->buf + s->len, p, t);
    s->len += (int)t;
    return t;
}

int aw_http_get(const char *url, char *buf, int cap) {
    if (!url || !buf || cap < 16) return -1;
    buf[0] = 0;
    if (!load_curl()) return -1;
    CURL *c = c_init();
    if (!c) return -1;
    Sink s = { buf, cap, 0, 0 };
    c_setopt(c, CURLOPT_URL, url);
    c_setopt(c, CURLOPT_WRITEFUNCTION, (void *)sink_cb);
    c_setopt(c, CURLOPT_WRITEDATA, (void *)&s);
    c_setopt(c, CURLOPT_TIMEOUT, 8L);
    c_setopt(c, CURLOPT_CONNECTTIMEOUT, 5L);
    c_setopt(c, CURLOPT_NOSIGNAL, 1L);
    c_setopt(c, CURLOPT_FOLLOWLOCATION, 1L);
    c_setopt(c, CURLOPT_USERAGENT, "ArchonsLife/2.0");
    int rc = c_perform(c);
    long code = 0;
    c_getinfo(c, CURLINFO_RESPONSE_CODE, &code);
    c_cleanup(c);
    if (rc != 0 || code != 200 || s.overflow) return -1;
    buf[s.len] = 0;
    return s.len;
}
