/*
 * Archon's Life - shared pixel-world engine.
 *
 * Portable C99, no dependencies beyond libc/libm. The Windows (.scr) and macOS
 * (.saver) front-ends both drive this: they create a small virtual framebuffer,
 * call aw_step() / aw_render() each frame, then scale the pixels up with
 * nearest-neighbour filtering.
 *
 * Pixel format: uint32_t 0x00RRGGBB (row-major, top-down).
 */
#ifndef AW_ENGINE_H
#define AW_ENGINE_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct AWWorld AWWorld;

/* Integer upscale factor that gives ~192 virtual rows on the given pixel size. */
int  aw_pick_scale(int pixel_w, int pixel_h);

/* vw x vh = virtual (art) resolution. seed = any value (e.g. time ^ monitor index). */
AWWorld *aw_create(int vw, int vh, uint32_t seed);
void     aw_destroy(AWWorld *w);
void     aw_resize(AWWorld *w, int vw, int vh);

/* Advance the simulation by dt seconds, then draw into the framebuffer. */
void     aw_step(AWWorld *w, double dt);
void     aw_render(AWWorld *w);

const uint32_t *aw_pixels(const AWWorld *w);
int      aw_width(const AWWorld *w);
int      aw_height(const AWWorld *w);

/* Display preferences for the info signs (defaults: 12-hour clock, Fahrenheit). */
void     aw_set_prefs(AWWorld *w, int clock24, int fahrenheit);
/* Current weather for the temperature sign. temp in Celsius, WMO weather code (Open-Meteo). */
void     aw_set_weather(AWWorld *w, int valid, float temp_c, int wmo_code, int is_day);

/* Test hooks. */
void     aw_debug_warp(AWWorld *w, double seconds); /* fast-forward (30 fps steps) */
void     aw_debug_set_time(AWWorld *w, int hour, int min, int sec, int wday, int mon0, int mday);
void     aw_debug_set_year(AWWorld *w, int year);
void     aw_debug_landmark(AWWorld *w, int k);        /* -1 = by chance, 0 Pisa 1 Sphinx 2 Las Vegas 3 Space Needle 4 Eiffel 5 Liberty 6 Big Ben 7 Taj Mahal 8 Stonehenge 9 St. Louis Arch 10 Sydney 11 Rome 12 Great Wall 13 Fuji 14 Golden Gate 15 Rio 16 Chichen Itza 17 Athens 18 Easter Island 19 Dubai 20 Moscow 21 Hollywood 22 Toronto 23 Uluru 24 Neuschwanstein */
void     aw_debug_holiday(AWWorld *w, int h);        /* -1 = by the calendar, 0 none, 1 Christmas Eve 2 Christmas 3 Valentine's 4 Thanksgiving 5 Chinese New Year 6 Veterans Day 7 New Year's Day 8 Halloween 9 New Year's Eve 10 Easter 11 Presidents' Day */
int      aw_debug_holiday_now(const AWWorld *w);
void     aw_debug_datefmt(AWWorld *w, int f);        /* -1 = per sign, 0..4 pins the date layout */
void     aw_debug_force_mode(AWWorld *w, int mode);   /* 0 walk 1 wings 2 car 3 rocket 4 balloon 5 carpet 6 jetpack 7 digger 8 submarine 9 sailboat 10 road trip 11 scuba/snorkel dive 12 helicopter */
void     aw_debug_force_guest(AWWorld *w, int type);  /* 1 fox 2 slime 3 robot 4 blue 5-8 wisps 9 ghost 10 birds 11 wizard 12 dragon 13 ufo 28 cat 29 white terrier 30 person
                                                         14 hedgehog 15 worm 16 mole 17 beetle (underground) 18 fish 19 jellyfish 20 turtle 21 crab
                                                         22 octopus 23 whale (underwater) 24 dolphin (sailing) 31 leaping fish (sailing)
                                                         32 little spaceship 33 alien jellyfish (rocket trips) */
void     aw_debug_season(AWWorld *w, int season);     /* 0 spring 1 summer 2 autumn 3 winter (the walk through the seasons carries on from there) */
int      aw_debug_season_now(const AWWorld *w);
int      aw_debug_lake(const AWWorld *w);
int      aw_debug_mode(const AWWorld *w);
int      aw_debug_stage(const AWWorld *w);
int      aw_debug_guests(const AWWorld *w);
float    aw_debug_alt(const AWWorld *w);
void     aw_debug_rocket(AWWorld *w, int shape, int pal);   /* call BEFORE aw_debug_force_mode(w,3): shape 0..5 and palette 0..9 (-1 = random) */
void     aw_debug_balloon(AWWorld *w, int shape, int pal, int pat);   /* call BEFORE aw_debug_force_mode(w,4): shape 0..3, palette 0..11, pattern 0..5 (-1 = random) */
void     aw_debug_heli(AWWorld *w, int pal);                /* call BEFORE aw_debug_force_mode(w,12): palette 0..9 (-1 = random) */
void     aw_debug_shovel(AWWorld *w, int v);        /* call BEFORE aw_debug_force_mode(w,7); 0 random, 1 digs by hand with a shovel, 2 drives the drill */
void     aw_debug_veh(AWWorld *w, int kind);        /* call BEFORE aw_debug_force_mode(w,10); picks the road trip vehicle: 0 bicycle 1 motorbike 2 roadster 3 electric car 4 pickup 5 forklift 6 semi 7 school bus */
int      aw_debug_veh_now(const AWWorld *w);
void     aw_debug_carrier(AWWorld *w, int kind, int style);   /* -1 = auto; kinds 0 signpost 1 blimp 2 balloons 3 drone 4 birds; style picks the balloon shape */
void     aw_debug_boat(AWWorld *w, int kind);       /* call BEFORE aw_debug_force_mode(w,9); 0 sailboat 1 tugboat 2 jet ski 3 speedboat 4 duck floatie 5 cruise ship */
int      aw_debug_boat_now(const AWWorld *w);
void     aw_debug_dive(AWWorld *w, int kind);       /* call BEFORE aw_debug_force_mode(w,11); 0 snorkel 1 scuba */
int      aw_debug_dive_now(const AWWorld *w);
int      aw_debug_ground(const AWWorld *w);          /* height of the ground under Archon (negative over a lake) */
void     aw_debug_bg(AWWorld *w, int style);        /* pin the backdrop: 0 mountains 1 hills 2 forest 3 city 4 suburb 5 farm 6 mesas, -1 = automatic */
float    aw_debug_holo(const AWWorld *w);          /* how solid the hologram is right now: ~0.85 solid, ~0.3 ghost */

#ifdef __cplusplus
}
#endif
#endif
