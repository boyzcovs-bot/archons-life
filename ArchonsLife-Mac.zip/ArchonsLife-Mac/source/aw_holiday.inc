/*
 * Archon's Life - the easter-egg days.
 * Christmas Eve and Day, Valentine's Day, Halloween, Thanksgiving, Chinese New Year, Veterans Day, New Year's Eve and New Year's Day.
 * No other holiday does anything. Included from aw_text.inc (before draw_panels).
 */

#ifndef BIGY
#define BIGY 0x3FFFFFFF
#endif
static void ell_fill(AWWorld *w, int cx, int cy, float rx, float ry, float ang, Col c, int ymax);
static void hol_bat(AWWorld *w, int x, int y, int flap, Col c, int a);
static void hol_ghost(AWWorld *w, int x, int y, int ph, int a, int sz);
static void hol_jack(AWWorld *w, int x, int base, int r, int ph);

/* Chinese New Year (Lunar New Year) 2024-2044, month/day */
static const unsigned char CNY_MD[21][2] = {
    {2,10},{1,29},{2,17},{2,6},{1,26},{2,13},{2,3},{1,23},{2,11},{1,31},{2,19},
    {2,8},{1,28},{2,15},{2,4},{1,24},{2,12},{2,1},{1,22},{2,10},{1,30},
};

static int hol_detect(const AWWorld *w) {
    int m = w->tm_mon + 1, d = w->tm_mday;
    if (m == 12 && d == 24) return H_XMAS_EVE;
    if (m == 12 && d == 25) return H_XMAS;
    if (m == 2 && d == 14) return H_VALENTINE;
    if (m == 11 && d == 11) return H_VETS;
    if (m == 11 && w->tm_wday == 4 && d >= 22 && d <= 28) return H_THANKS;      /* the fourth Thursday of November */
    if (m == 1 && d == 1) return H_NEWYEAR;
    if (m == 12 && d == 31) return H_NYE;
    if (m == 10 && d == 31) return H_HALLOWEEN;
    int yi = w->tm_year - 2024;
    if (yi >= 0 && yi < 21 && m == CNY_MD[yi][0] && d == CNY_MD[yi][1]) return H_CNY;
    return H_NONE;
}

/* ---------------------------------------------------------------- sky ---- */
#define HMX(field, tgt, k) do { p->field = lerpc(p->field, (Col)(tgt), (k)); } while (0)
static void hol_grade(AWWorld *w) {
    Pal *p = &w->cur;
    switch (w->hol) {
        case H_XMAS_EVE:
            HMX(sky_top, 0x101C4A, 0.80f); HMX(sky_mid, 0x26397A, 0.72f); HMX(sky_bot, 0x7A8CC8, 0.55f);
            HMX(cloud, 0x8C9CD0, 0.55f); HMX(cloud_sh, 0x5A6AA8, 0.55f);
            HMX(far_c, 0x34457E, 0.42f); HMX(mid_c, 0x3E5088, 0.38f); HMX(near_c, 0x4B5E96, 0.34f);
            if (p->stars < 0.95f) p->stars = 0.95f;
            break;
        case H_XMAS:
            HMX(sky_top, 0x6FAEE8, 0.40f); HMX(sky_mid, 0xA8D4F4, 0.40f); HMX(sky_bot, 0xEAF4FF, 0.40f);
            break;
        case H_VALENTINE:
            HMX(sky_top, 0xEE7FAA, 0.62f); HMX(sky_mid, 0xFFA8C8, 0.60f); HMX(sky_bot, 0xFFDCE8, 0.58f);
            HMX(cloud, 0xFFEAF2, 0.65f); HMX(cloud_sh, 0xF2B6CC, 0.55f);
            HMX(far_c, 0xD68CB0, 0.34f); HMX(mid_c, 0xC57AA2, 0.32f); HMX(near_c, 0xB46894, 0.30f);
            p->stars = 0.0f;
            break;
        case H_THANKS:
            HMX(sky_top, 0xD98A4C, 0.30f); HMX(sky_mid, 0xF2B67A, 0.34f); HMX(sky_bot, 0xFFE0B0, 0.34f);
            break;
        case H_CNY:
            HMX(sky_top, 0x4A0A20, 0.86f); HMX(sky_mid, 0xA81E2C, 0.70f); HMX(sky_bot, 0xFF8434, 0.55f);
            HMX(cloud, 0xFF9C84, 0.45f); HMX(cloud_sh, 0xB8324A, 0.55f);
            HMX(far_c, 0x6E1A2C, 0.50f); HMX(mid_c, 0x5A1426, 0.46f); HMX(near_c, 0x4A1022, 0.42f);
            if (p->stars < 0.55f) p->stars = 0.55f;
            break;
        case H_VETS:
            HMX(sky_top, 0x2E78D8, 0.45f); HMX(sky_mid, 0x6CB2F2, 0.40f); HMX(sky_bot, 0xD8ECFF, 0.40f);
            HMX(cloud, 0xFFFFFF, 0.4f);
            break;
        case H_NEWYEAR: case H_NYE:
            HMX(sky_top, 0x050824, 0.96f); HMX(sky_mid, 0x121A48, 0.90f); HMX(sky_bot, 0x2B2A6E, 0.80f);
            HMX(cloud, 0x39407A, 0.65f); HMX(cloud_sh, 0x232A58, 0.65f);
            HMX(far_c, 0x151C44, 0.70f); HMX(mid_c, 0x1B2552, 0.66f); HMX(near_c, 0x232E62, 0.62f);
            p->stars = 1.0f;
            break;
        case H_HALLOWEEN:
            HMX(sky_top, 0x120626, 0.90f); HMX(sky_mid, 0x3E1458, 0.82f); HMX(sky_bot, 0xE8742A, 0.62f);
            HMX(cloud, 0x5A3470, 0.62f); HMX(cloud_sh, 0x2E1846, 0.66f);
            HMX(far_c, 0x2A1240, 0.62f); HMX(mid_c, 0x241038, 0.58f); HMX(near_c, 0x1E0E30, 0.52f);
            if (p->stars < 0.85f) p->stars = 0.85f;
            break;
        default: break;
    }
}
#undef HMX
static void hol_cel(AWWorld *w) {
    switch (w->hol) {
        case H_XMAS_EVE: case H_CNY: case H_NEWYEAR: case H_NYE: case H_HALLOWEEN:
            w->cel_kind = 1; w->cel_col = w->hol == H_CNY ? 0xFFE0A0 : (w->hol == H_HALLOWEEN ? 0xFFA23A : 0xF4F1D0); w->cel_y = 0.22f; break;
        case H_VALENTINE: w->cel_col = 0xFFF0F4; break;
        default: break;
    }
}

/* ------------------------------------------------------------ fireworks ---- */
static const Col FW_COL[8] = { 0xFF4D6D, 0xFFD23F, 0xFF8A2A, 0xFFFFFF, 0x7DF9FF, 0xFF7AD9, 0x6CFF8A, 0xB58CFF };
static void hol_fireworks(AWWorld *w, int lanes, int ncol, float scale) {
    float t = (float)w->t;
    int soy = w->oy; w->oy = 0;
    for (int j = 0; j < lanes; j++) {
        float P = 2.7f + 0.37f * (float)(j % 3), off = (float)j * 0.83f;
        float tt = t - off;
        int k = (int)floorf(tt / P);
        float age = tt - (float)k * P;
        uint32_t h = hash2(w->seed ^ 0xF1AEU, (uint32_t)(k * 16 + j));
        int cx = (int)((0.10f + 0.80f * rfn(h, 0)) * (float)w->vw);
        int cy = (int)((0.10f + 0.34f * rfn(h, 1)) * (float)w->gy);
        Col c1 = FW_COL[(int)(rfn(h, 2) * (float)ncol) % ncol], c2 = FW_COL[(int)(rfn(h, 3) * (float)ncol) % ncol];
        int kind = (int)(rfn(h, 4) * 4.0f);
        const float RISE = 0.55f, LIFE = 1.9f;
        if (age < RISE) {                                    /* the rocket going up */
            float u = age / RISE; u = 1.0f - (1.0f - u) * (1.0f - u);
            int ry = w->gy - (int)((float)(w->gy - cy) * u);
            for (int q = 0; q < 6; q++) {
                float uq = fmaxf(0.0f, u - (float)q * 0.035f);
                int yq = w->gy - (int)((float)(w->gy - cy) * uq);
                PX(w, cx + (q & 1), yq + q, lerpc(0xFFE9A0, 0x6A3A18, (float)q / 6.0f));
            }
            PX(w, cx, ry, 0xFFFFFF);
            continue;
        }
        float ba = age - RISE;
        if (ba > LIFE) continue;
        float f = 1.0f - ba / LIFE;
        int N = kind == 2 ? 20 : 30;
        float R0 = 24.0f * scale * (0.85f + 0.3f * rfn(h, 5));
        if (ba < 0.10f) {                                    /* the flash */
            int fr = (int)(7.0f * scale * (1.0f - ba / 0.10f)) + 1;
            for (int dy = -fr; dy <= fr; dy++) for (int dx = -fr; dx <= fr; dx++)
                if (dx * dx + dy * dy <= fr * fr) BLEND(w, cx + dx, cy + dy, 0xFFFFFF, 150);
        }
        for (int i = 0; i < N; i++) {
            uint32_t q = hash2(h, (uint32_t)(i + 40));
            float th = (float)i * 6.2831853f / (float)N + (rfn(q, 0) - 0.5f) * 0.25f;
            float sp = (kind == 1 ? 1.0f : 0.55f + 0.55f * rfn(q, 1));
            Col c = (kind == 3 && (i & 1)) ? c2 : c1;
            if (kind == 2) c = lerpc(0xFFD23F, 0xFFA030, rfn(q, 2));
            for (int tr = 0; tr < (kind == 2 ? 6 : 3); tr++) {
                float bt = ba - (float)tr * (kind == 2 ? 0.07f : 0.045f);
                if (bt < 0.0f) break;
                float rad = R0 * sp * (1.0f - expf(-2.6f * bt));
                float grav = (kind == 2 ? 34.0f : 15.0f) * bt * bt;
                int px = cx + (int)(cosf(th) * rad), py = cy + (int)(sinf(th) * rad + grav);
                float fv = f * (1.0f - (float)tr * 0.30f);
                if (fv <= 0.05f) continue;
                if (kind == 2 || fv > 0.35f || ((i + (int)(ba * 20.0f)) & 1)) {
                    Col cc = lerpc(0x0A0A22, c, clampf(fv * 1.15f, 0.0f, 1.0f));
                    PX(w, px, py, tr == 0 && f > 0.6f ? lerpc(c, 0xFFFFFF, 0.5f) : cc);
                }
            }
        }
    }
    w->oy = soy;
}

/* ---------------------------------------------- New Year's Eve helpers ---- */
/* seconds left until midnight by the computer's own clock (never less than 1: at midnight the day becomes New Year's Day) */
static int nye_left(const AWWorld *w) {
    int s = 86400 - (w->tm_hour * 3600 + w->tm_min * 60 + w->tm_sec);
    return s < 1 ? 1 : s;
}
/* how far the evening has built up: 0 at six in the evening, 1 at midnight */
static float nye_build(const AWWorld *w) { return clampf(1.0f - (float)nye_left(w) / (6.0f * 3600.0f), 0.0f, 1.0f); }
/* the year the lights say: on New Year's Eve it is the coming one */
static int hol_year(const AWWorld *w) { return w->tm_year + (w->hol == H_NYE ? 1 : 0); }
/* the last ten seconds, counted out big in front of everything (screen space: the caller has zeroed oy) */
static void nye_countdown(AWWorld *w) {
    int left = nye_left(w);
    if (left > 10) return;
    char s[4]; snprintf(s, sizeof s, "%d", left);
    int n = (int)strlen(s), U = w->vh / 36; if (U < 2) U = 2; if (U > 8) U = 8;
    int cw = 6 * U, tw = n * cw - U, th = 7 * U;
    int x0 = w->vw / 2 - tw / 2, y0 = (int)((float)w->gy * 0.20f);
    for (int y = y0 - 8; y < y0 + th + 8; y++) for (int x = x0 - 10; x < x0 + tw + 10; x++) BLEND(w, x, y, 0x0A0E2A, 150);
    R(w, x0 - 10, y0 - 8, tw + 20, 1, 0xFFD23F); R(w, x0 - 10, y0 + th + 7, tw + 20, 1, 0xFFD23F);
    R(w, x0 - 10, y0 - 8, 1, th + 16, 0xFFD23F); R(w, x0 + tw + 9, y0 - 8, 1, th + 16, 0xFFD23F);
    Col c = ((int)((float)w->t * 6.0f) & 1) ? 0xFFFFFF : 0xFFD23F;
    for (int i = 0; i < n; i++) { draw57(w, x0 + i * cw + 1, y0 + 1, s[i], U, 0x3A2A08); draw57(w, x0 + i * cw, y0, s[i], U, c); }
}

static void hol_sky(AWWorld *w) {
    if (w->hol == H_NEWYEAR) hol_fireworks(w, 6, 8, 1.15f);
    else if (w->hol == H_NYE) hol_fireworks(w, 1 + (int)(5.0f * nye_build(w)), 8, 1.15f);   /* the show builds up through the evening */
    else if (w->hol == H_CNY) hol_fireworks(w, 4, 3, 1.0f);
}

/* ---------------------------------------------------- the ball tower ---- */
static void hol_ball_tower(AWWorld *w) {
    float t = (float)w->t;
    int tx = (int)(w->vw * 0.90f), gyy = w->gy;
    int H = (int)(w->gy * 0.46f), pole = 24;
    int top = gyy - H;
    /* the tower, with lit windows */
    R(w, tx - 10, top, 21, H, 0x1B2252); R(w, tx - 10, top, 21, 1, 0x4A5A9A); R(w, tx - 10, top, 1, H, 0x33407E); R(w, tx + 10, top, 1, H, 0x10163A);
    for (int wy = top + 14; wy < gyy - 4; wy += 5)
        for (int wx = tx - 7; wx <= tx + 5; wx += 4) {
            uint32_t q = hash2((uint32_t)(wx * 13 + wy), 0x70E5U);
            if ((q & 7u) < 5u) R(w, wx, wy, 2, 3, ((q >> 4) & 3u) == 0 ? 0xFFE9A0 : 0xBFD0FF);
        }
    /* the year, up on the billboard */
    R(w, tx - 13, top + 2, 27, 11, 0x0A0F1E); R(w, tx - 12, top + 3, 25, 9, 0x2A3166);
    char ys[8]; snprintf(ys, sizeof ys, "%d", hol_year(w));
    int sx = tx - 12 + 1;
    for (const char *c = ys; *c; c++) { draw57(w, sx, top + 4, *c, 1, ((int)(t * 2.0f) & 1) ? 0xFFD23F : 0xFFF3C2); sx += 6; }
    /* the pole */
    R(w, tx, top - pole, 1, pole, 0xC8D0E0); R(w, tx - 1, top - pole, 3, 1, 0xFFFFFF); PX(w, tx, top - pole - 1, 0xFF4D6D);
    /* the ball waits at the top, then drops */
    float cyc = fmodf(t, 40.0f), by;
    float y0 = (float)(top - pole + 5), y1 = (float)(top - 4);
    float la = cyc >= 38.0f ? (cyc - 38.0f) / 2.0f : -1.0f;         /* the burst of light when it lands */
    if (w->hol == H_NYE) {                                          /* New Year's Eve: the ball really does fall in the last minute before midnight */
        int left = nye_left(w);
        float u = left >= 60 ? 0.0f : 1.0f - (float)left / 60.0f;
        by = y0 + (y1 - y0) * u;
        la = left <= 3 ? (float)(3 - left) / 3.0f : -1.0f;
    }
    else if (cyc < 30.0f) by = y0; else if (cyc < 38.0f) { float u = (cyc - 30.0f) / 8.0f; by = y0 + (y1 - y0) * u * u * (3.0f - 2.0f * u); } else by = y1;
    int bx = tx, byi = (int)by;
    float glow = 0.5f + 0.5f * sinf(t * 5.0f);
    for (int dy = -9; dy <= 9; dy++) for (int dx = -9; dx <= 9; dx++) {
        int d2 = dx * dx + dy * dy;
        if (d2 > 80 || d2 < 26) continue;
        if (((dx + dy) & 1) == 0) BLEND(w, bx + dx, byi + dy, 0xFFE9A0, (int)(34.0f + 30.0f * glow));
    }
    for (int dy = -5; dy <= 5; dy++) for (int dx = -5; dx <= 5; dx++) {
        if (dx * dx + dy * dy > 28) continue;
        uint32_t q = hash2((uint32_t)((dx + 8) * 7 + (dy + 8)), (uint32_t)(t * 6.0f));
        Col c = (((dx + 8) % 3 == 0) || ((dy + 8) % 3 == 0)) ? 0x8890B8 : 0xE8ECF8;
        if ((q & 15u) < 3u) c = 0xFFFFFF; else if ((q & 15u) == 3u) c = 0xFFB0E8; else if ((q & 15u) == 4u) c = 0xA8F0FF;
        c = mulc(c, 1.08f - 0.07f * (float)(dx * dx + dy * dy) / 28.0f * 3.0f);
        PX(w, bx + dx, byi + dy, c);
    }
    if (la >= 0.0f) {                                      /* landed: a burst of light */
        float a = la;
        for (int i = 0; i < 18; i++) {
            float th = (float)i * 0.349f, r = 6.0f + 26.0f * a;
            if (a < 0.9f) PX(w, bx + (int)(cosf(th) * r), byi + (int)(sinf(th) * r * 0.8f), lerpc(0xFFFFFF, 0xFFD23F, a));
        }
    }
}

/* ------------------------------------------------------ screen-space bits ---- */
static void hol_micro_heart(AWWorld *w, int x, int y, Col c, int big) {
    if (big) { R(w, x, y, 2, 2, c); R(w, x + 3, y, 2, 2, c); R(w, x, y + 1, 5, 2, c); R(w, x + 1, y + 3, 3, 1, c); PX(w, x + 2, y + 4, c); PX(w, x + 1, y, lerpc(c, 0xFFFFFF, 0.5f)); }
    else { PX(w, x, y, c); PX(w, x + 2, y, c); R(w, x, y + 1, 3, 1, c); PX(w, x + 1, y + 2, c); }
}
static void hol_heart(AWWorld *w, int cx, int cy, float sz, Col c) {
    int R_ = (int)ceilf(sz * 1.3f) + 1;
    for (int dy = -R_; dy <= R_; dy++) for (int dx = -R_; dx <= R_; dx++) {
        float fx = (float)dx / sz, fy = -((float)dy + 0.15f * sz) / sz;
        float a = fx * fx + fy * fy - 1.0f;
        if (a * a * a - fx * fx * fy * fy * fy > 0.0f) continue;
        Col cc = c;
        if (dx > R_ / 2) cc = mulc(c, 0.82f);
        if (dx < -R_ / 2 && dy < 0) cc = lerpc(c, 0xFFFFFF, 0.30f);
        PX(w, cx + dx, cy + dy, cc);
    }
}
static void hol_front(AWWorld *w) {
    float t = (float)w->t;
    int soy = w->oy; w->oy = 0;
    int vw = w->vw, vh = w->vh;
    switch (w->hol) {
        case H_VALENTINE:
            for (int i = 0; i < 26; i++) {
                uint32_t q = hash2(w->seed ^ 0x4ea7U, (uint32_t)i);
                float spd = 9.0f + 11.0f * rfn(q, 1);
                float y = (float)vh - fmodf(t * spd + rfn(q, 2) * (float)vh * 1.2f, (float)vh * 1.2f);
                int x = (int)(rfn(q, 0) * (float)vw + sinf(t * 0.8f + (float)i) * 6.0f);
                static const Col HC[4] = { 0xFF3B6B, 0xFF7AA8, 0xFFB0CC, 0xE8203F };
                if (y > (float)w->gy + 6.0f) continue;
                hol_micro_heart(w, x, (int)y, HC[i & 3], i % 3 == 0);
            }
            break;
        case H_NEWYEAR: case H_NYE:
            for (int i = 0, nc = (w->hol == H_NYE) ? 14 + (int)(46.0f * nye_build(w)) : 60; i < nc; i++) {                   /* confetti */
                uint32_t q = hash2(w->seed ^ 0xC0FEU, (uint32_t)i);
                float spd = 12.0f + 14.0f * rfn(q, 1);
                float y = fmodf(t * spd + rfn(q, 2) * (float)vh, (float)vh);
                int x = (int)(rfn(q, 0) * (float)vw + sinf(t * 1.3f + (float)i * 1.7f) * 7.0f);
                static const Col CC[6] = { 0xFFD23F, 0xFF4D6D, 0x7DF9FF, 0xFFFFFF, 0xB58CFF, 0x6CFF8A };
                if ((int)(t * 6.0f + (float)i) & 1) R(w, x, (int)y, 2, 1, CC[i % 6]); else R(w, x, (int)y, 1, 2, CC[(i + 2) % 6]);
            }
            if (w->hol == H_NYE) nye_countdown(w);
            break;
        case H_CNY:
            for (int i = 0; i < 12; i++) {                   /* sky lanterns drifting up */
                uint32_t q = hash2(w->seed ^ 0x1A27U, (uint32_t)i);
                float y = (float)vh - fmodf(t * (4.0f + 3.0f * rfn(q, 1)) + rfn(q, 2) * (float)vh * 1.3f, (float)vh * 1.3f);
                int x = (int)(rfn(q, 0) * (float)vw + sinf(t * 0.5f + (float)i) * 5.0f);
                if (y > (float)w->gy - 10.0f) continue;
                float fl = 0.75f + 0.25f * sinf(t * 9.0f + (float)i * 2.0f);
                for (int dy = -6; dy <= 6; dy++) for (int dx = -6; dx <= 6; dx++)
                    if (dx * dx + dy * dy < 40 && ((dx + dy) & 1) == 0) BLEND(w, x + dx, (int)y + dy, 0xFFB040, (int)(30.0f * fl));
                R(w, x - 2, (int)y - 3, 5, 6, lerpc(0xFF7A1A, 0xFFD060, fl)); R(w, x - 2, (int)y - 3, 5, 1, 0xFFE9A0); PX(w, x, (int)y, 0xFFF6D0);
            }
            break;
        case H_XMAS_EVE: case H_XMAS:
            for (int i = 0; i < 10; i++) {                   /* little stars winking */
                uint32_t q = hash2(w->seed ^ 0x57A7U, (uint32_t)i);
                if (w->hol == H_XMAS) break;
                int x = (int)(rfn(q, 0) * (float)vw), y = (int)(rfn(q, 1) * (float)w->gy * 0.5f);
                if (sinf(t * 2.0f + (float)i * 1.9f) > 0.55f) { PX(w, x, y, 0xFFFFFF); PX(w, x - 1, y, 0xCFD8FF); PX(w, x + 1, y, 0xCFD8FF); PX(w, x, y - 1, 0xCFD8FF); PX(w, x, y + 1, 0xCFD8FF); }
            }
            break;
        case H_HALLOWEEN: {
            for (int i = 0; i < 5; i++) {                                           /* will-o'-the-wisps */
                uint32_t q = hash2(w->seed ^ 0x7155U, (uint32_t)i);
                int x = (int)(rfn(q, 0) * (float)vw + sinf(t * 0.4f + (float)i * 2.0f) * 14.0f), y = w->gy - 6 - (int)(rfn(q, 1) * 26.0f) + (int)(sinf(t * 0.9f + (float)i) * 5.0f);
                float fl = 0.5f + 0.5f * sinf(t * 3.0f + (float)i * 1.3f);
                for (int dy = -5; dy <= 5; dy++) for (int dx = -5; dx <= 5; dx++) if (dx * dx + dy * dy < 26 && ((dx + dy) & 1) == 0) BLEND(w, x + dx, y + dy, 0x7CFF5A, (int)(14.0f * fl) + 4);
                PX(w, x, y, 0xD8FFC0); PX(w, x + 1, y, 0x9CFF6A);
            }
            for (int i = 0; i < 4; i++) {                                           /* ghosts drifting by, half there */
                uint32_t q = hash2(w->seed ^ 0x6057U, (uint32_t)i);
                float span = (float)vw + 60.0f;
                float px = fmodf(t * (3.0f + 2.0f * rfn(q, 1)) + rfn(q, 0) * span, span);
                int gx = (int)(i & 1 ? px : span - px) - 30;
                int gy = 22 + (int)(rfn(q, 2) * (float)w->gy * 0.38f) + (int)(sinf(t * 0.9f + (float)i * 1.7f) * 6.0f);
                hol_ghost(w, gx, gy, i * 3, 120, i & 1);
            }
            for (int i = 0; i < 11; i++) {                                          /* bats */
                uint32_t q = hash2(w->seed ^ 0xBA75U, (uint32_t)i);
                float span = (float)vw + 40.0f, spd = 18.0f + 16.0f * rfn(q, 1);
                float px = fmodf(t * spd + rfn(q, 0) * span, span);
                int bx = (int)((i & 1) ? px : span - px) - 20;
                int by = 8 + (int)(rfn(q, 2) * (float)w->gy * 0.5f) + (int)(sinf(t * 1.9f + (float)i * 2.3f) * 7.0f);
                static const unsigned char FL[4] = { 0, 1, 2, 1 };
                hol_bat(w, bx, by, FL[((int)(t * 9.0f) + i) & 3], 0x07040C, 255);
            }
            for (int i = 0; i < 5; i++) {                                           /* ground fog rolling in */
                uint32_t q = hash2(w->seed ^ 0xF06U, (uint32_t)i);
                float span = (float)vw + 120.0f;
                int fx = (int)fmodf(t * (2.0f + 2.0f * rfn(q, 1)) + rfn(q, 0) * span, span) - 60;
                for (int dy = -5; dy <= 2; dy++) for (int dx = -46; dx <= 46; dx++) {
                    float e = (float)(dx * dx) / 2116.0f + (float)(dy * dy) / 30.0f;
                    if (e < 1.0f && ((dx + dy) & 1) == 0) BLEND(w, fx + dx, w->gy + 1 + dy, 0xC8B8E8, (int)(12.0f * (1.0f - e)));
                }
            }
        } break;
        default: break;
    }
    w->oy = soy;
}

/* ---- the chinese dragon (a paper dragon, with dancers' feet) ---- */
static void hol_dragon(AWWorld *w) {
    float t = (float)w->t;
    int camI = (int)floor(w->cam);
    float span = (float)w->vw + 160.0f;
    float hx = fmodf(t * 17.0f, span) - 50.0f;             /* the head, in screen space */
    const int NSEG = 13, SP = 8;
    for (int i = NSEG; i >= 0; i--) {
        int x = (int)(hx - (float)(i * SP));
        if (x < -20 || x > w->vw + 20) continue;
        int gh = ground_h(w, camI + x);
        if (gh < 0 || road_m(w, camI + x) > 0.0f) continue;
        int base = w->gy - gh;
        float wob = sinf(t * 5.0f - (float)i * 0.9f);
        int top = base - 17 - (int)(wob * 3.0f) - (i == 0 ? 3 : 0);
        Col body = (i & 1) ? 0xE0202C : 0xFFC21F;
        if (i == 0) {                                      /* head */
            R(w, x - 4, top - 2, 15, 12, 0xD01824); R(w, x - 4, top - 2, 15, 1, 0xFF6A5A);
            R(w, x + 8, top + 3, 8, 6, 0xE0202C); R(w, x + 8, top + 7, 8, 2, 0x7A0A14);       /* snout and open mouth */
            R(w, x + 14, top + 5, 2, 1, 0xFFFFFF);
            R(w, x + 2, top + 1, 3, 3, 0xFFFFFF); PX(w, x + 4, top + 2, 0x101010);              /* eye */
            R(w, x - 2, top - 7, 2, 6, 0xFFD23F); R(w, x + 3, top - 8, 2, 7, 0xFFD23F);        /* golden horns */
            for (int m = 0; m < 4; m++) { PX(w, x + 14 + m, top + 8 + (int)(sinf(t * 7.0f + (float)m) * 1.5f), 0xFFE9A0); }   /* whiskers */
            R(w, x - 5, top + 2, 2, 9, 0xFFC21F);
            R(w, x - 6, top + 4, 2, 5, 0xFFC21F);
        } else {
            R(w, x - 3, top, SP, 11, body);
            R(w, x - 3, top, SP, 1, mulc(body, 1.25f)); R(w, x - 3, top + 10, SP, 1, mulc(body, 0.7f));
            for (int s = 0; s < SP; s += 2) PX(w, x - 3 + s, top - 1, 0xFFD23F);              /* scale ridge */
            PX(w, x, top + 4, 0xFFF3C2); PX(w, x + 1, top + 5, 0xFFF3C2);
        }
        /* dancer's legs */
        int sw = ((int)(t * 6.0f) + i) & 1;
        int lh = base - (top + 11);
        if (lh > 0) { R(w, x - 1 + sw, top + 11, 2, lh, 0x2A1A14); R(w, x + 3 - sw, top + 11, 2, lh, 0x2A1A14); R(w, x - 2 + sw, base - 1, 3, 1, 0x101010); R(w, x + 2 - sw, base - 1, 3, 1, 0x101010); }
    }
    {   /* the tail */
        int x = (int)(hx - (float)((NSEG + 1) * SP));
        int gh = ground_h(w, camI + x);
        if (gh >= 0) { int base = w->gy - gh; R(w, x - 2, base - 16 - (int)(sinf(t * 5.0f - 11.0f) * 3.0f), 6, 6, 0xFFC21F); PX(w, x - 3, base - 17, 0xE0202C); PX(w, x - 4, base - 18, 0xE0202C); }
    }
}

/* ------------------------------------------------------------ ground items ---- */
static int hol_flat(AWWorld *w, int wx, int span) {
    int gh = ground_h(w, wx);
    if (gh < 0 || ground_h(w, wx - span) != gh || ground_h(w, wx + span) != gh) return 0;
    if (road_m(w, wx - span - 2) > 0.0f || road_m(w, wx + span + 2) > 0.0f || pier_near(w, (double)wx)) return 0;
    return 1;
}
static void hol_heart(AWWorld *w, int cx, int cy, float sz, Col c);
static void hol_gift(AWWorld *w, int x, int y, int bw, int bh, Col c, Col rb) {
    R(w, x, y - bh, bw, bh, c); R(w, x, y - bh, bw, 1, lerpc(c, 0xFFFFFF, 0.3f)); R(w, x, y - 1, bw, 1, mulc(c, 0.7f));
    R(w, x + bw / 2, y - bh, 1 + (bw > 6), bh, rb); R(w, x, y - bh / 2, bw, 1, rb);
    R(w, x + bw / 2 - 2, y - bh - 2, 2, 2, rb); R(w, x + bw / 2 + 1 + (bw > 6), y - bh - 2, 2, 2, rb); PX(w, x + bw / 2, y - bh - 1, mulc(rb, 0.8f));
}
static void hol_tree(AWWorld *w, int x, int base, uint32_t h, int snowy) {
    float t = (float)w->t;
    int th = 3 + (int)(rfn(h, 5) * 2.0f);
    R(w, x - 1, base - th, 3, th, 0x6B3E1F);
    int y = base - th;
    static const int WD[4] = { 20, 16, 12, 8 };
    for (int i = 0; i < 4; i++) {
        int wd = WD[i], hgt = 10 - i;
        for (int r = 0; r < hgt; r++) {
            int hw = (wd * (r + 1)) / (2 * hgt) + 1;
            Col g = (r & 1) ? 0x1E8A3A : 0x187A32;
            R(w, x - hw, y - hgt + r, hw * 2 + 1, 1, g);
            PX(w, x - hw, y - hgt + r, 0x2FA84C); PX(w, x + hw, y - hgt + r, 0x105A24);
        }
        if (snowy) R(w, x - 2, y - hgt, 5, 1, 0xF4FAFF);
        y -= hgt - 3;
    }
    /* star and lights */
    R(w, x - 1, y - 5, 3, 3, 0xFFD23F); PX(w, x, y - 6, 0xFFE9A0); PX(w, x - 2, y - 4, 0xFFD23F); PX(w, x + 2, y - 4, 0xFFD23F); PX(w, x, y - 3, 0xFFFFFF);
    static const Col LC[4] = { 0xFF3B3B, 0xFFD23F, 0x4FA6F5, 0xFF7AD9 };
    for (int i = 0; i < 16; i++) {
        uint32_t q = hash2(h, (uint32_t)(80 + i));
        float f = (float)(i + 1) / 17.0f;
        int ly = base - th - (int)(f * 28.0f), hw = (int)((1.0f - f) * 8.0f) + 2;
        int lx = x - hw + (int)(rfn(q, 0) * (float)(hw * 2));
        int on = ((int)(t * 2.4f) + i) % 3 != 0;
        Col c = LC[i & 3];
        PX(w, lx, ly, on ? c : mulc(c, 0.45f));
        if (on) { BLEND(w, lx + 1, ly, c, 70); BLEND(w, lx - 1, ly, c, 70); BLEND(w, lx, ly - 1, c, 70); }
    }
}
static void hol_santa(AWWorld *w, int x, int base, int dir) {
    float t = (float)w->t;
    int wave = (int)floorf(sinf(t * 6.0f) * 1.5f + 0.5f);
    R(w, x - 3, base - 4, 3, 4, 0x1A1410); R(w, x + 1, base - 4, 3, 4, 0x1A1410);                 /* boots */
    R(w, x - 4, base - 15, 9, 11, 0xD42A2A); R(w, x - 4, base - 15, 1, 11, 0xE85050); R(w, x + 4, base - 15, 1, 11, 0xA01C1C);   /* coat */
    R(w, x - 4, base - 5, 9, 2, 0xFFFFFF); R(w, x - 1, base - 15, 3, 11, 0xFFFFFF);               /* trim */
    R(w, x - 4, base - 10, 9, 2, 0x1A1410); R(w, x - 1, base - 10, 3, 2, 0xFFD23F);              /* belt */
    R(w, x - 4 * dir - (dir > 0 ? 2 : 0), base - 12 + wave, 2, 5, 0xD42A2A);                     /* near arm, resting */
    R(w, x + 4 * dir - (dir < 0 ? 1 : 0), base - 18 + wave, 2, 6, 0xD42A2A); R(w, x + 4 * dir - (dir < 0 ? 1 : 0), base - 19 + wave, 2, 2, 0xFFE0C0);   /* waving arm */
    R(w, x - 3, base - 21, 7, 6, 0xFFE0C0);                                                       /* face */
    R(w, x - 3, base - 18, 7, 4, 0xFFFFFF); R(w, x - 2, base - 15, 5, 1, 0xFFFFFF);              /* beard */
    PX(w, x - 2, base - 20, 0x1A1410); PX(w, x + 2, base - 20, 0x1A1410); PX(w, x, base - 19, 0xF08A8A);
    R(w, x - 4, base - 24, 9, 4, 0xD42A2A); R(w, x - 4, base - 22, 9, 2, 0xFFFFFF);              /* hat */
    R(w, x + 3 * dir, base - 26, 3, 3, 0xD42A2A); R(w, x + 4 * dir, base - 27, 2, 2, 0xFFFFFF);
}
static void hol_reindeer(AWWorld *w, int x, int base, int dir, int rudolph, int ph) {
    float t = (float)w->t;
    int nod = ((int)(t * 2.0f) + ph) & 1;
    #define RD(v) (x + dir * (v))
    Col fur = 0x9A6A3A, dk = 0x6E4824;
    R(w, RD(-6) - (dir < 0 ? 12 : 0), base - 11, 13, 6, fur);                                   /* body */
    R(w, RD(-6) - (dir < 0 ? 12 : 0), base - 11, 13, 1, 0xB88450); R(w, RD(-6) - (dir < 0 ? 12 : 0), base - 6, 13, 1, dk);
    for (int l = 0; l < 4; l++) { int lx = RD(-5 + (l & 1) * 2 + (l >> 1) * 8) - (dir < 0 ? 1 : 0); R(w, lx, base - 5, 2, 5, l < 2 ? dk : fur); R(w, lx, base - 1, 2, 1, 0x2A1A10); }
    R(w, RD(6) - (dir < 0 ? 3 : 0), base - 16 + nod, 4, 7, fur);                                 /* neck */
    R(w, RD(7) - (dir < 0 ? 6 : 0), base - 18 + nod, 7, 5, fur);                                 /* head */
    R(w, RD(13) - (dir < 0 ? 1 : 0), base - 16 + nod, 2, 3, rudolph ? 0xFF2A2A : 0x2A1A10);     /* nose */
    if (rudolph && ((int)(t * 4.0f) & 1)) BLEND(w, RD(13), base - 15 + nod, 0xFF4040, 110);
    PX(w, RD(10), base - 17 + nod, 0x101010);
    R(w, RD(-6) - (dir < 0 ? 1 : 0), base - 12, 2, 2, 0xF4F4F4);                                 /* tail */
    for (int a = 0; a < 2; a++) {                                                                /* antlers */
        int ax = RD(8 + a * 2) - (dir < 0 ? 1 : 0);
        R(w, ax, base - 23 + nod, 1, 5, 0xD8C8A0); R(w, ax - dir, base - 21 + nod, 1, 1, 0xD8C8A0); R(w, ax + dir, base - 24 + nod, 1, 2, 0xD8C8A0);
    }
    #undef RD
}
static void hol_rose_bush(AWWorld *w, int x, int base, uint32_t h) {
    R(w, x - 7, base - 6, 15, 6, 0x2F8A3A); R(w, x - 5, base - 9, 11, 3, 0x2F8A3A); R(w, x - 7, base - 6, 15, 1, 0x4CB05A);
    static const Col RC[3] = { 0xE8203F, 0xFF4D7A, 0xFFB0CC };
    for (int i = 0; i < 7; i++) {
        uint32_t q = hash2(h, (uint32_t)(30 + i));
        int rx = x - 6 + (int)(rfn(q, 0) * 12.0f), ry = base - 9 + (int)(rfn(q, 1) * 7.0f);
        Col c = RC[i % 3];
        R(w, rx, ry, 3, 3, c); PX(w, rx + 1, ry + 1, mulc(c, 0.7f)); PX(w, rx, ry, lerpc(c, 0xFFFFFF, 0.35f));
    }
}
static void hol_heart_tree(AWWorld *w, int x, int base, uint32_t h) {
    float t = (float)w->t;
    R(w, x - 1, base - 12, 3, 12, 0x6B3E1F); R(w, x - 1, base - 12, 1, 12, 0x8A5A2B);
    int cy = base - 24;
    Col c = (rfn(h, 5) < 0.5f) ? 0xFF4D7A : 0xE8203F;
    hol_heart(w, x, cy, 9.0f, c);
    if (sinf(t * 2.5f + (float)(h & 15u)) > 0.8f) PX(w, x - 4, cy - 4, 0xFFFFFF);
}
static void hol_turkey(AWWorld *w, int x, int base, int dir, int ph) {
    float t = (float)w->t;
    int peck = (((int)(t * 2.5f) + ph) & 3) == 0;
    #define TD(v) (x + dir * (v))
    static const Col FC[5] = { 0x9A3A12, 0xD8661A, 0xF0B02A, 0xC4501A, 0x6E2A10 };
    for (int i = 0; i < 5; i++) {                                                               /* the fan of tail feathers */
        float a = -2.55f + (float)i * 0.45f * -1.0f;
        for (int r = 4; r < 13; r++) {
            int fx = (int)(cosf(a) * (float)r * -1.0f), fy = (int)(sinf(a) * (float)r);
            R(w, TD(-4 + fx), base - 10 + fy, 2, 2, (r > 9) ? 0xF4E0A0 : FC[(i + r / 3) % 5]);
        }
    }
    ell_fill(w, TD(0), base - 8, 5.2f, 4.4f, 0, 0x7A4A24, BIGY);                                 /* body */
    ell_fill(w, TD(1), base - 7, 3.4f, 2.8f, 0, 0x9A6434, BIGY);
    R(w, TD(-1) - (dir < 0 ? 1 : 0), base - 4, 2, 4, 0xE0A030); R(w, TD(2) - (dir < 0 ? 1 : 0), base - 4, 2, 4, 0xE0A030);   /* legs */
    R(w, TD(-2) - (dir < 0 ? 2 : 0), base - 1, 4, 1, 0xE0A030); R(w, TD(1) - (dir < 0 ? 2 : 0), base - 1, 4, 1, 0xE0A030);
    int hy = peck ? base - 8 : base - 14;
    R(w, TD(4) - (dir < 0 ? 1 : 0), hy + 1, 2, peck ? 2 : 6, 0xC0805A);                        /* neck */
    R(w, TD(4) - (dir < 0 ? 2 : 0), hy - 1, 4, 4, 0xC0805A);                                     /* head */
    R(w, TD(8) - (dir < 0 ? 1 : 0), hy + 1, 2, 1, 0xF0B02A);                                     /* beak */
    R(w, TD(6) - (dir < 0 ? 1 : 0), hy + 2, 2, 3, 0xE02A2A);                                     /* wattle */
    PX(w, TD(6) - (dir < 0 ? 0 : 0), hy, 0x101010);
    #undef TD
}
static void hol_pumpkin(AWWorld *w, int x, int base, int r) {
    ell_fill(w, x, base - r, (float)r + 2.0f, (float)r, 0, 0xE8742A, BIGY);
    R(w, x - 1, base - r, 1, r, 0xC4561A); R(w, x + r / 2, base - r + 1, 1, r - 1, 0xC4561A); R(w, x - r / 2 - 1, base - r + 1, 1, r - 1, 0xC4561A);
    PX(w, x - r + 1, base - r - 1, 0xFFA060); R(w, x - 1, base - 2 * r - 1, 2, 2, 0x3F7A2A);
}
static void hol_flag(AWWorld *w, int x, int base, int ph, int ht, int fw) {
    float t = (float)w->t;
    R(w, x, base - ht, 2, ht, 0xE8E8F0); R(w, x, base - ht, 1, ht, 0xFFFFFF);
    disc(w, x, base - ht - 1, 1, 0xFFD23F);
    for (int cx = 0; cx < fw; cx++) {
        int wv = (int)floorf(sinf((float)cx * 0.45f - t * 4.5f + (float)ph) * 1.3f * ((float)cx / (float)fw) + 0.5f);
        for (int r = 0; r < 13; r++) {
            Col c = (r & 1) ? 0xFFFFFF : 0xD6283A;
            if (cx < fw * 2 / 5 && r < 7) { c = 0x23408E; if ((cx & 1) == 0 && (r & 1) == 0 && cx > 0 && r > 0) c = 0xFFFFFF; }
            if (cx > fw / 2) c = lerpc(c, 0x203060, 0.10f);
            PX(w, x + 2 + cx, base - ht + 1 + r + wv, c);
        }
    }
}
static void hol_poppy(AWWorld *w, int x, int base, uint32_t h) {
    int hgt = 5 + (int)(rfn(h, 3) * 5.0f);
    R(w, x, base - hgt, 1, hgt, 0x3A8A3A); PX(w, x + 1, base - hgt / 2, 0x3A8A3A);
    R(w, x - 2, base - hgt - 3, 5, 4, 0xE02020); R(w, x - 1, base - hgt - 4, 3, 1, 0xE02020); PX(w, x - 2, base - hgt - 3, 0xFF5A4A);
    R(w, x, base - hgt - 2, 1, 1, 0x1A1010); PX(w, x - 1, base - hgt - 1, 0x1A1010);
}
static void hol_lantern(AWWorld *w, int x, int y, float sway) {
    int sx = x + (int)floorf(sway + 0.5f);
    R(w, sx, y - 3, 1, 3, 0xFFD23F);
    R(w, sx - 4, y, 9, 2, 0xFFD23F);
    R(w, sx - 5, y + 2, 11, 9, 0xE0202C); R(w, sx - 5, y + 2, 11, 1, 0xFF6A5A); R(w, sx + 3, y + 2, 3, 9, 0xB0141E);
    R(w, sx - 2, y + 2, 1, 9, 0xFF4A4A); R(w, sx + 1, y + 2, 1, 9, 0xFF4A4A);
    R(w, sx - 1, y + 5, 3, 3, 0xFFD23F); PX(w, sx, y + 6, 0xE0202C);
    R(w, sx - 4, y + 11, 9, 2, 0xFFD23F);
    R(w, sx, y + 13, 1, 5, 0xFFD23F); R(w, sx - 1, y + 17, 3, 3, 0xFF4A4A);
    BLEND(w, sx, y + 6, 0xFFE9A0, 60);
}


/* ------------------------------------------------------------- Halloween ---- */
static void hol_pxa(AWWorld *w, int x, int y, Col c, int a) { if (a >= 255) PX(w, x, y, c); else BLEND(w, x, y, c, a); }
static void hol_ra(AWWorld *w, int x, int y, int ww, int hh, Col c, int a) { for (int j = 0; j < hh; j++) for (int i = 0; i < ww; i++) hol_pxa(w, x + i, y + j, c, a); }

/* a jack-o'-lantern, the candle flickering inside */
static void hol_jack(AWWorld *w, int x, int base, int r, int ph) {
    float t = (float)w->t;
    int fl = (sinf(t * 7.0f + (float)ph * 1.7f) + sinf(t * 11.3f + (float)ph)) > 0.7f;
    Col gl = fl ? 0xFFF0A0 : 0xFFC21F;
    if (r >= 4) for (int dy = -r - 5; dy <= r + 5; dy++) for (int dx = -r - 7; dx <= r + 7; dx++)
        if (dx * dx + dy * dy < (r + 5) * (r + 5) + 6 && ((dx + dy) & 1) == 0) BLEND(w, x + dx, base - r + dy, 0xFF9A20, fl ? 20 : 12);
    ell_fill(w, x, base - r, (float)r + 2.0f, (float)r, 0, 0xE8742A, BIGY);
    R(w, x - 1, base - r - r + 1, 1, 2 * r - 2, 0xC4561A); R(w, x + r / 2 + 1, base - r - r + 2, 1, 2 * r - 4, 0xC4561A); R(w, x - r / 2 - 2, base - r - r + 2, 1, 2 * r - 4, 0xC4561A);
    PX(w, x - r + 1, base - r - 2, 0xFFA060); R(w, x - 1, base - 2 * r - 1, 2, 2, 0x3F7A2A);
    if (r >= 4) {
        R(w, x - r / 2 - 1, base - r - 2, 2, 2, gl); R(w, x + r / 2, base - r - 2, 2, 2, gl);                     /* eyes */
        PX(w, x - r / 2 - 1, base - r - 3, gl); PX(w, x + r / 2 + 1, base - r - 3, gl);
        R(w, x - r + 2, base - r + 1, 2 * r - 3, 1, gl);                                                           /* the grin */
        for (int i = 0; i < 2 * r - 3; i += 2) PX(w, x - r + 2 + i, base - r + 2, gl);
    } else { PX(w, x - 1, base - r - 1, gl); PX(w, x + 1, base - r - 1, gl); R(w, x - 1, base - r + 1, 3, 1, gl); }
}

/* a bat, three wing positions */
static void hol_bat(AWWorld *w, int x, int y, int flap, Col c, int a) {
    hol_pxa(w, x, y, c, a); hol_pxa(w, x, y + 1, c, a); hol_pxa(w, x - 1, y - 1, c, a); hol_pxa(w, x + 1, y - 1, c, a);
    if (flap == 0) {                                   /* wings up */
        for (int i = 1; i <= 4; i++) { hol_pxa(w, x - i - 1, y - i, c, a); hol_pxa(w, x + i + 1, y - i, c, a); hol_pxa(w, x - i, y - i + 1, c, a); hol_pxa(w, x + i, y - i + 1, c, a); }
        hol_pxa(w, x - 3, y, c, a); hol_pxa(w, x + 3, y, c, a);
    } else if (flap == 1) {                            /* level */
        for (int i = 1; i <= 5; i++) { hol_pxa(w, x - i, y, c, a); hol_pxa(w, x + i, y, c, a); }
        hol_pxa(w, x - 2, y + 1, c, a); hol_pxa(w, x + 2, y + 1, c, a); hol_pxa(w, x - 4, y + 1, c, a); hol_pxa(w, x + 4, y + 1, c, a); hol_pxa(w, x - 6, y + 1, c, a); hol_pxa(w, x + 6, y + 1, c, a);
    } else {                                           /* down */
        for (int i = 1; i <= 4; i++) { hol_pxa(w, x - i - 1, y + i, c, a); hol_pxa(w, x + i + 1, y + i, c, a); hol_pxa(w, x - i, y + i - 1, c, a); hol_pxa(w, x + i, y + i - 1, c, a); }
        hol_pxa(w, x - 2, y + 1, c, a); hol_pxa(w, x + 2, y + 1, c, a);
    }
    if (a >= 255) { PX(w, x - 1, y, 0xFF3030); PX(w, x + 1, y, 0xFF3030); }
}

/* a ghost: white sheet, wobbling hem, dark eyes and an O of a mouth. y is where the hem hangs. a < 255 makes it see-through. */
static void hol_ghost(AWWorld *w, int x, int y, int ph, int a, int sz) {
    float t = (float)w->t;
    int hw = 5 + sz, hh = 11 + 3 * sz;
    int wave = (int)floorf(sinf(t * 3.4f + (float)ph) * 1.2f + 0.5f);
    Col body = 0xF2F4FF, shade = 0xC4C8E4;
    for (int j = 0; j < hh; j++) {
        float yy = (float)j / (float)hh;
        int rowhw = hw;
        if (j < hw) rowhw = (int)(sqrtf((float)(hw * hw - (hw - j) * (hw - j))) + 0.5f);
        for (int i = -rowhw; i <= rowhw; i++) {
            Col c = body;
            if (i > rowhw - 2 || (i > hw / 2 && yy > 0.3f)) c = shade;
            if (j == 0 || i == -rowhw) c = lerpc(c, 0xFFFFFF, 0.5f);
            hol_pxa(w, x + i, y - hh + j, c, a);
        }
    }
    for (int i = -hw; i <= hw; i++) {                                                              /* the hem, rippling */
        int hl = 2 + (int)floorf(sinf((float)i * 1.15f + t * 4.0f + (float)ph) * 1.5f + 1.5f);
        for (int j = 0; j < hl; j++) hol_pxa(w, x + i, y + j, (i > hw / 2) ? shade : body, a);
    }
    for (int j = 0; j < 4; j++) {                                                                  /* little arms held out */
        hol_pxa(w, x - hw - 1 - (j < 2), y - hh / 2 + wave - j / 2, body, a); hol_pxa(w, x + hw + 1 + (j < 2), y - hh / 2 - wave - j / 2, shade, a);
    }
    int ey = y - hh + hw - 1, fa = a >= 255 ? 255 : a + 70;
    hol_ra(w, x - hw / 2 - 1, ey, 2, 3 + sz, 0x20203A, fa); hol_ra(w, x + hw / 2 - 1, ey, 2, 3 + sz, 0x20203A, fa);
    hol_ra(w, x - 1, ey + 4 + sz, 3, 2 + sz, 0x20203A, fa);
    if (a >= 255) { PX(w, x - hw / 2 - 1, ey, 0x6A6AAA); PX(w, x + hw / 2 - 1, ey, 0x6A6AAA); }
}

/* the black cat, back arched, tail up, eyes that glow and blink */
static void hol_cat(AWWorld *w, int x, int base, int dir, int ph) {
    float t = (float)w->t;
    #define CX(v) (x + dir * (v))
    #define CR(v, yy, ww, hh, c) R(w, (dir > 0) ? x + (v) : x - (v) - (ww) + 1, (yy), (ww), (hh), (c))
    Col fur = 0x17121F, rim = 0x5A4A7C;
    int tw = (int)floorf(sinf(t * 2.2f + (float)ph) * 2.0f + 0.5f);
    CR(-11, base - 20, 2, 12, fur); CR(-11 + tw, base - 24, 2, 5, fur); CR(-10 + tw, base - 25, 2, 2, fur); PX(w, CX(-11), base - 20, rim);      /* the tail */
    CR(-9, base - 6, 2, 6, fur); CR(-5, base - 6, 2, 6, fur); CR(4, base - 6, 2, 6, fur); CR(8, base - 6, 2, 6, fur);                              /* legs */
    ell_fill(w, CX(-1), base - 10, 10.0f, 5.0f, 0, fur, BIGY);
    ell_fill(w, CX(-2), base - 14, 6.5f, 3.5f, 0, fur, BIGY);                                                                                         /* the arch */
    for (int i = -7; i <= 3; i += 2) PX(w, CX(i), base - 17 - (i > -5 && i < 1), rim);                                                                 /* fur standing on end */
    ell_fill(w, CX(11), base - 11, 4.4f, 4.0f, 0, fur, BIGY);
    CR(8, base - 17, 2, 3, fur); CR(12, base - 17, 2, 3, fur); PX(w, CX(8), base - 17, rim); PX(w, CX(13), base - 17, rim);                           /* ears */
    int blink = fmodf(t * 0.5f + (float)ph * 0.37f, 3.0f) < 0.12f;
    if (!blink) { CR(9, base - 12, 2, 2, 0xFFE040); CR(13, base - 12, 2, 2, 0xFFE040); PX(w, CX(10), base - 12, 0x101010); PX(w, CX(14), base - 12, 0x101010); }
    PX(w, CX(15), base - 9, 0xF08A9A);
    for (int i = 0; i < 3; i++) PX(w, CX(16 + i), base - 10 + i - 1, 0xC8C0E0);                                                                       /* whiskers */
    #undef CX
    #undef CR
}

/* the witch: black dress, green face, hat; her broom leans beside her */
static void hol_witch(AWWorld *w, int x, int base, int dir, int ph) {
    float t = (float)w->t;
    int sway = (int)floorf(sinf(t * 1.6f + (float)ph) * 0.8f + 0.5f);
    #define WR(v, yy, ww, hh, c) R(w, (dir > 0) ? x + (v) : x - (v) - (ww) + 1, (yy), (ww), (hh), (c))
    WR(-3, base - 2, 3, 2, 0x16101E); WR(1, base - 2, 3, 2, 0x16101E);                                  /* boots */
    for (int i = 0; i < 16; i++) { int hw = 2 + i / 3; WR(-hw, base - 18 + i, 2 * hw + 1, 1, (i == 15 || (i > 8 && (i & 1))) ? 0x3A2058 : 0x211232); }
    R(w, x - 5, base - 3, 11, 1, 0x4A2A6A);
    WR(-3, base - 17, 7, 1, 0x7A2EA8);                                                                  /* a purple sash */
    WR(-5 + sway, base - 17, 2, 6, 0x211232);                                                           /* arms */
    WR(-5 + sway, base - 12, 2, 2, 0x7ACB5A);
    WR(-2, base - 24, 5, 6, 0x7ACB5A); WR(-2, base - 24, 5, 1, 0x9AE87A); WR(3, base - 22, 2, 2, 0x7ACB5A);                 /* face and a long nose */
    PX(w, x + dir * 0, base - 22, 0x101010); PX(w, x + dir * 2, base - 22, 0x101010); WR(0, base - 19, 3, 1, 0x3A1A2A);
    WR(-3, base - 23, 1, 6, 0xE8742A); WR(3, base - 23, 1, 4, 0xE8742A);                                   /* orange hair */
    WR(-6, base - 25, 13, 2, 0x16101E);                                                                 /* hat brim */
    for (int j = 0; j < 11; j++) { int ww = 7 - (j * 7) / 11; if (ww < 1) ww = 1; int bend = j > 6 ? (j - 6) : 0; WR(-ww / 2 + bend, base - 26 - j, ww, 1, (j == 1 || j == 2) ? 0x7A2EA8 : 0x16101E); }
    WR(-1, base - 28, 3, 1, 0xFFD23F);                                                                  /* buckle */
    /* the broom, bristles at the bottom */
    WR(9, base - 28, 1, 26, 0x6B3E1F); WR(7, base - 8, 5, 8, 0xC8A050); WR(7, base - 8, 5, 1, 0x8A6A2A); WR(7, base - 5, 5, 1, 0xA8843A);
    for (int i = 0; i < 3; i++) WR(7 + i * 2, base - 1, 1, 1, 0x8A6A2A);
    #undef WR
}
static void hol_cauldron(AWWorld *w, int x, int base, int ph) {
    float t = (float)w->t;
    for (int i = -2; i <= 2; i++) { int fh = 2 + (int)floorf(sinf(t * 9.0f + (float)(i * 3 + ph)) * 1.5f + 1.5f); R(w, x + i * 2, base - fh, 2, fh, (i & 1) ? 0xFFD23F : 0xFF7A1A); }
    ell_fill(w, x, base - 9, 8.0f, 6.5f, 0, 0x1C1C26, BIGY); ell_fill(w, x - 2, base - 11, 4.0f, 2.5f, 0, 0x34344A, BIGY);
    R(w, x - 8, base - 15, 17, 2, 0x2C2C3A); R(w, x - 8, base - 15, 17, 1, 0x4A4A60);
    R(w, x - 7, base - 14, 15, 1, 0x7CFF3A);
    for (int i = 0; i < 3; i++) {                                                                       /* bubbles popping */
        float f = fmodf(t * 0.9f + (float)i * 0.37f + (float)ph * 0.1f, 1.0f);
        int bx = x - 4 + i * 4, by = base - 15 - (int)(f * 9.0f);
        if (f < 0.9f) { PX(w, bx, by, 0xB8FF8A); PX(w, bx + 1, by, 0x7CFF3A); if (f > 0.6f) PX(w, bx, by - 1, 0xE0FFC0); }
    }
    for (int dy = -9; dy <= 4; dy++) for (int dx = -11; dx <= 11; dx++) if (dx * dx + dy * dy * 2 < 120 && ((dx + dy) & 1) == 0) BLEND(w, x + dx, base - 13 + dy, 0x6CFF3A, 12);
}
static void hol_skeleton(AWWorld *w, int x, int base, int ph) {
    float t = (float)w->t;
    float s = sinf(t * 7.0f + (float)ph);
    int sw = (int)floorf(s * 2.0f + 0.5f), up = s > 0.0f;
    Col bone = 0xF0ECD8, sh = 0xB8B49C;
    int hipy = base - 12;
    rope_line(w, x - 1, hipy, x - 4 - sw, base - 6, bone); rope_line(w, x - 4 - sw, base - 6, x - 5 - sw * 2, base - 1, bone);          /* legs, kicking */
    rope_line(w, x + 1, hipy, x + 4 + sw, base - 6, bone); rope_line(w, x + 4 + sw, base - 6, x + 5 + sw * 2, base - 1, bone);
    R(w, x - 6 - sw * 2, base - 1, 3, 1, bone); R(w, x + 4 + sw * 2, base - 1, 3, 1, bone);
    R(w, x - 2, hipy - 1, 5, 2, sh); R(w, x - 3, hipy, 7, 1, bone);                                                                    /* pelvis */
    R(w, x, hipy - 9, 1, 8, bone);                                                                                                       /* spine */
    for (int i = 0; i < 3; i++) R(w, x - 3, hipy - 9 + i * 2, 7, 1, (i & 1) ? sh : bone);                                               /* ribs */
    rope_line(w, x - 3, hipy - 9, x - 7, up ? hipy - 15 : hipy - 5, bone); rope_line(w, x + 3, hipy - 9, x + 7, up ? hipy - 5 : hipy - 15, bone);   /* arms, a jig */
    PX(w, x - 7, up ? hipy - 16 : hipy - 4, bone); PX(w, x + 7, up ? hipy - 4 : hipy - 16, bone);
    int hy = hipy - 15 + (int)(floorf(sinf(t * 14.0f + (float)ph) * 0.6f + 0.5f));                                                       /* the skull rattles */
    R(w, x - 3, hy - 4, 7, 5, bone); R(w, x - 2, hy + 1, 5, 2, bone); R(w, x - 3, hy - 4, 7, 1, 0xFFFFFF);
    R(w, x - 2, hy - 2, 2, 2, 0x16101E); R(w, x + 1, hy - 2, 2, 2, 0x16101E); PX(w, x, hy, 0x16101E);
    PX(w, x - 1, hy + 2, 0x16101E); PX(w, x + 1, hy + 2, 0x16101E);
    BLEND(w, x, hipy - 6, 0xBFD0FF, 16);
}
static void hol_vampire(AWWorld *w, int x, int base, int ph) {
    float t = (float)w->t;
    for (int i = 0; i < 20; i++) {                                                                      /* the cape, wide open */
        int hw = 3 + (i * 3) / 4;
        int hem = (i > 16) ? (int)floorf(sinf((float)i + t * 3.0f + (float)ph) * 1.2f + 0.5f) : 0;
        R(w, x - hw + hem, base - 24 + i, 2 * hw + 1, 1, (i % 5 == 4) ? 0x2A1830 : 0x16101E);
        if (i > 3) { R(w, x - 2, base - 24 + i, 5, 1, 0x9A1028); }
    }
    for (int i = 0; i < 6; i++) { R(w, x - 12 + i, base - 8 + i, 1, 1, 0x9A1028); R(w, x + 12 - i, base - 8 + i, 1, 1, 0x9A1028); }
    R(w, x - 3, base - 2, 3, 2, 0x0A0A10); R(w, x + 1, base - 2, 3, 2, 0x0A0A10);
    R(w, x - 2, base - 16, 5, 14, 0x24203A);                                                            /* suit */
    R(w, x - 1, base - 16, 3, 3, 0xF0F0F8); PX(w, x, base - 15, 0xC82030);                              /* shirt and bow */
    R(w, x - 5, base - 26, 2, 5, 0x16101E); R(w, x + 4, base - 26, 2, 5, 0x16101E); R(w, x - 4, base - 23, 9, 2, 0x16101E);   /* the high collar */
    R(w, x - 2, base - 29, 5, 6, 0xE6E6F0); R(w, x - 3, base - 30, 7, 2, 0x101018); PX(w, x, base - 28, 0x101018); PX(w, x - 1, base - 29, 0x101018); PX(w, x + 1, base - 29, 0x101018);
    PX(w, x - 1, base - 26, 0xFF2020); PX(w, x + 1, base - 26, 0xFF2020); PX(w, x - 1, base - 24, 0xFFFFFF); PX(w, x + 1, base - 24, 0xFFFFFF);
}
static void hol_mummy(AWWorld *w, int x, int base, int dir, int ph) {
    float t = (float)w->t;
    #define MR(v, yy, ww, hh, c) R(w, (dir > 0) ? x + (v) : x - (v) - (ww) + 1, (yy), (ww), (hh), (c))
    int st = (int)floorf(sinf(t * 3.4f + (float)ph) * 1.8f + 0.5f);
    Col wr = 0xE8DDB8, dk = 0xB8AC82;
    MR(-3 + st, base - 9, 3, 9, wr); MR(1 - st, base - 9, 3, 9, wr);
    for (int j = base - 8; j < base; j += 2) { MR(-3 + st, j, 3, 1, dk); MR(1 - st, j, 3, 1, dk); }
    MR(-4, base - 20, 9, 11, wr); for (int j = base - 19; j < base - 9; j += 2) MR(-4, j, 9, 1, dk);
    MR(-4, base - 20, 9, 1, 0xFFF4D0);
    MR(3, base - 18, 8, 3, wr); MR(3, base - 17, 8, 1, dk); MR(3, base - 14, 8, 3, wr); MR(3, base - 13, 8, 1, dk);   /* arms out in front */
    for (int i = 0; i < 5; i++) PX(w, x + dir * (5 + i), base - 11 + i / 2 + (int)floorf(sinf(t * 3.0f + (float)i) * 0.6f + 0.5f), dk);   /* a loose strip trailing */
    MR(-3, base - 27, 7, 8, wr); for (int j = base - 26; j < base - 19; j += 2) MR(-3, j, 7, 1, dk);
    MR(-3, base - 27, 7, 1, 0xFFF4D0);
    MR(-3, base - 24, 7, 3, 0x1A1018); MR(-2, base - 24, 2, 2, 0xFFE040); MR(1, base - 24, 2, 2, 0xFFE040);
    #undef MR
}
/* a little trick-or-treater in a sheet with a pumpkin bucket */
static void hol_trick(AWWorld *w, int x, int base, int dir, int ph) {
    float t = (float)w->t;
    int st = (int)floorf(sinf(t * 5.0f + (float)ph) * 1.0f + 0.5f);
    R(w, x - 3 + st, base - 2, 2, 2, 0x4A3A2A); R(w, x + 1 - st, base - 2, 2, 2, 0x4A3A2A);
    for (int j = 0; j < 11; j++) { int hw = 3 + j / 5; R(w, x - hw, base - 12 + j, 2 * hw + 1, 1, (j > 7 && (j & 1)) ? 0xD8DCF0 : 0xF2F4FF); }
    R(w, x - 4, base - 14, 9, 3, 0xF2F4FF); R(w, x - 3, base - 15, 7, 1, 0xF2F4FF);
    R(w, x - 2, base - 12, 2, 2, 0x16101E); R(w, x + 1, base - 12, 2, 2, 0x16101E);
    int bx = x + dir * 7;
    R(w, bx - 2, base - 8, 5, 4, 0xE8742A); R(w, bx - 2, base - 8, 5, 1, 0xFFA060); PX(w, bx - 1, base - 6, 0x16101E); PX(w, bx + 1, base - 6, 0x16101E);
    PX(w, bx - 2, base - 9, 0xE02A4A); PX(w, bx, base - 10, 0xFFD23F); PX(w, bx + 1, base - 9, 0x4FA6F5);
    rope_line(w, bx - 2, base - 8, x + dir * 4, base - 10, 0x3A2A1A);
}
static void hol_tomb(AWWorld *w, int x, int base, int kind) {
    Col g = 0x8A8CA0, gh = 0xB4B6CC, gd = 0x5E6078;
    if (kind == 0) {
        R(w, x - 6, base - 15, 13, 15, g); ell_fill(w, x, base - 15, 6.5f, 4.5f, 0, g, BIGY);
        R(w, x - 6, base - 15, 1, 15, gh); R(w, x + 6, base - 14, 1, 14, gd); R(w, x - 7, base - 1, 15, 2, gd);
        text35(w, x - 5, base - 12, "RIP", 1, 0x3A3C50);
        PX(w, x - 2, base - 19, gh); PX(w, x - 3, base - 18, gh);
    } else if (kind == 1) {
        R(w, x - 1, base - 18, 3, 18, g); R(w, x - 5, base - 14, 11, 3, g); R(w, x - 1, base - 18, 1, 18, gh); R(w, x - 5, base - 14, 11, 1, gh); R(w, x + 1, base - 17, 1, 17, gd);
        R(w, x - 4, base - 1, 9, 2, gd);
    } else {
        R(w, x - 4, base - 10, 9, 10, g); ell_fill(w, x, base - 10, 4.5f, 3.0f, 0, g, BIGY); R(w, x - 4, base - 10, 1, 10, gh); R(w, x + 4, base - 9, 1, 9, gd);
        PX(w, x, base - 7, gd); PX(w, x + 1, base - 6, gd); PX(w, x + 1, base - 5, gd); PX(w, x + 2, base - 4, gd); R(w, x - 5, base - 1, 11, 2, gd);
    }
}
static void hol_zombie_hand(AWWorld *w, int x, int base, int ph) {
    float t = (float)w->t;
    int rise = 5 + (int)floorf(sinf(t * 1.1f + (float)ph) * 2.0f + 2.0f);
    R(w, x - 4, base - 1, 9, 2, 0x3A2A1E);                                                              /* disturbed earth */
    R(w, x - 1, base - rise - 5, 3, rise + 4, 0x6AA85A); R(w, x - 1, base - rise - 5, 1, rise + 4, 0x8ACB76); R(w, x + 1, base - rise - 1, 1, 3, 0x4A7A3A);
    R(w, x - 3, base - rise - 9, 7, 5, 0x6AA85A); R(w, x - 3, base - rise - 9, 7, 1, 0x8ACB76);       /* the palm */
    for (int i = -1; i <= 1; i++) { int fl = 4 + (int)floorf(sinf(t * 5.0f + (float)(i * 2 + ph)) * 1.0f + 1.0f); R(w, x + i * 2, base - rise - 9 - fl, 1, fl, 0x6AA85A); PX(w, x + i * 2, base - rise - 10 - fl, 0xD8E8B0); }
    R(w, x - 5, base - rise - 8 - (int)floorf(sinf(t * 4.0f + (float)ph) * 0.8f + 0.8f), 2, 3, 0x6AA85A); PX(w, x - 5, base - rise - 9 - (int)floorf(sinf(t * 4.0f + (float)ph) * 0.8f + 0.8f), 0xD8E8B0);   /* the thumb */
}
static void hol_deadtree(AWWorld *w, int x, int base, uint32_t h) {
    float t = (float)w->t;
    Col bk = 0x2A1C30, hi = 0x4A3A5A;
    R(w, x - 2, base - 30, 5, 30, bk); R(w, x - 2, base - 30, 1, 30, hi); R(w, x - 4, base - 2, 9, 2, bk);
    rope_line(w, x, base - 24, x - 12, base - 36, bk); rope_line(w, x - 12, base - 36, x - 17, base - 34, bk); rope_line(w, x - 8, base - 31, x - 8, base - 41, bk);
    rope_line(w, x + 1, base - 20, x + 13, base - 31, bk); rope_line(w, x + 13, base - 31, x + 18, base - 38, bk); rope_line(w, x + 9, base - 27, x + 16, base - 25, bk);
    rope_line(w, x, base - 30, x + 3, base - 41, bk);
    if (rfn(h, 7) < 0.6f) {                                                                             /* an owl on a branch */
        int ox = x + 12, oy = base - 31;
        ell_fill(w, ox, oy - 4, 3.5f, 4.5f, 0, 0x7A5A3A, BIGY); R(w, ox - 3, oy - 9, 2, 2, 0x7A5A3A); R(w, ox + 2, oy - 9, 2, 2, 0x7A5A3A);
        int bl = fmodf(t * 0.4f + (float)(h & 7u), 3.0f) < 0.15f;
        if (!bl) { R(w, ox - 2, oy - 7, 2, 2, 0xFFD23F); R(w, ox + 1, oy - 7, 2, 2, 0xFFD23F); PX(w, ox - 1, oy - 7, 0x101010); PX(w, ox + 2, oy - 7, 0x101010); }
        else { R(w, ox - 2, oy - 6, 2, 1, 0x101010); R(w, ox + 1, oy - 6, 2, 1, 0x101010); }
        PX(w, ox, oy - 5, 0xE8A030);
    }
    for (int i = 0; i < 2; i++) {                                                                       /* bats asleep, upside down */
        int bx = x - 8 + i * 17, by = base - (i ? 24 : 35);
        R(w, bx - 1, by, 3, 4, 0x16101E); PX(w, bx - 1, by + 4, 0x16101E); PX(w, bx + 1, by + 4, 0x16101E); PX(w, bx - 1, by - 1, 0x2A2030);
        PX(w, bx - 1, by + 3, 0xFF3030);
    }
}

typedef struct { const char *l1, *l2; Col cloth, edge, ink; } HolBanner;
static HolBanner hol_banner(int h) {
    switch (h) {
        case H_XMAS_EVE: { HolBanner b = { "MERRY", "CHRISTMAS EVE", 0xC4202C, 0x1E8A3A, 0xFFF3C2 }; return b; }
        case H_XMAS:     { HolBanner b = { "MERRY", "CHRISTMAS", 0xC4202C, 0x1E8A3A, 0xFFF3C2 }; return b; }
        case H_VALENTINE:{ HolBanner b = { "HAPPY", "VALENTINES DAY", 0xE8406E, 0xFFB0CC, 0xFFFFFF }; return b; }
        case H_THANKS:   { HolBanner b = { "HAPPY", "THANKSGIVING", 0xB8601C, 0xF0B02A, 0xFFF3C2 }; return b; }
        case H_CNY:      { HolBanner b = { "GONG XI", "FA CAI", 0xD01824, 0xFFC21F, 0xFFE9A0 }; return b; }
        case H_VETS:     { HolBanner b = { "THANK YOU", "VETERANS", 0x23408E, 0xD6283A, 0xFFFFFF }; return b; }
        case H_HALLOWEEN:{ HolBanner b = { "HAPPY", "HALLOWEEN", 0x2B1346, 0xE8742A, 0xFF9A30 }; return b; }
        case H_NYE:      { HolBanner b = { "HAPPY", "NEW YEARS EVE", 0x141E4D, 0xFFD23F, 0xFFE9A0 }; return b; }
        default:         { HolBanner b = { "HAPPY", "NEW YEAR", 0x141E4D, 0xFFD23F, 0xFFE9A0 }; return b; }
    }
}
static void hol_banner_draw(AWWorld *w, int xc, int base) {
    HolBanner b = hol_banner(w->hol);
    float t = (float)w->t;
    int S = 2;
    int w1 = text35_w(b.l1, S), w2 = text35_w(b.l2, S);
    int bw = (w1 > w2 ? w1 : w2) + 12, bh = 2 * 5 * S + 3 + 8;
    int ht = bh + 14;
    int x0 = xc - bw / 2;
    R(w, x0 - 1, base - ht, 3, ht, 0x6B3E1F); R(w, x0 - 1, base - ht, 1, ht, 0x8A5A2B);
    R(w, x0 + bw - 2, base - ht, 3, ht, 0x6B3E1F); R(w, x0 + bw - 2, base - ht, 1, ht, 0x8A5A2B);
    int by = base - ht + 2;
    R(w, x0, by, bw, bh, b.edge); R(w, x0 + 2, by + 2, bw - 4, bh - 4, b.cloth);
    R(w, x0 + 2, by + 2, bw - 4, 1, lerpc(b.cloth, 0xFFFFFF, 0.25f));
    text35(w, xc - w1 / 2, by + 5, b.l1, S, b.ink);
    text35(w, xc - w2 / 2, by + 5 + 5 * S + 3, b.l2, S, b.ink);
    /* the fringe flutters a little */
    for (int i = 2; i < bw - 2; i += 3) PX(w, x0 + i, by + bh + (int)floorf(sinf(t * 3.0f + (float)i) * 0.6f + 0.6f), b.edge);
    int nl = (w->hol == H_NEWYEAR || w->hol == H_NYE || w->hol == H_CNY || w->hol == H_XMAS_EVE || w->hol == H_XMAS);
    if (nl) for (int i = 0; i < bw; i += 4) { Col lc = FW_COL[(i / 4 + (int)(t * 2.0f)) % 5]; PX(w, x0 + i, by - 1, lc); }
    if (w->hol == H_HALLOWEEN) { static const Col OL[3] = { 0xFF8A1A, 0xA060F0, 0x6CFF3A }; for (int i = 0; i < bw; i += 4) PX(w, x0 + i, by - 1, OL[(i / 4 + (int)(t * 1.5f)) % 3]); }
}

static void draw_holiday_ground(AWWorld *w) {
    if (!w->hol) return;
    int camI = (int)floor(w->cam);
    const int S = 24;
    int k0 = floordiv(camI - 30, S), k1 = floordiv(camI + w->vw + 30, S);
    int hol = w->hol;
    for (int k = k0; k <= k1; k++) {
        uint32_t h = hash2(w->seed ^ 0x401D4U ^ ((uint32_t)hol * 0x9E3779B1U), (uint32_t)k);
        if (rfn(h, 0) > 0.58f) continue;
        int wx = k * S + 4 + (int)(rfn(h, 1) * (float)(S - 8));
        if (!hol_flat(w, wx, 6)) continue;
        int x = wx - camI, base = w->gy - ground_h(w, wx);
        float v = rfn(h, 2);
        int dir = rfn(h, 3) < 0.5f ? 1 : -1;
        int ph = (int)(rfn(h, 4) * 8.0f);
        switch (hol) {
            case H_XMAS_EVE: case H_XMAS:
                if (v < 0.30f) hol_tree(w, x, base, h, 1);
                else if (v < 0.48f) { hol_gift(w, x - 8, base, 9, 7, 0xD42A2A, 0xFFD23F); hol_gift(w, x + 1, base, 8, 9, 0x1E8A3A, 0xE8302A); hol_gift(w, x - 4, base - 7, 7, 5, 0x3A6FD8, 0xFFFFFF); }
                else if (v < 0.60f) {                                    /* candy cane */
                    for (int i = 0; i < 16; i++) R(w, x, base - 1 - i, 2, 1, ((i / 2) & 1) ? 0xFFFFFF : 0xE8302A);
                    for (int i = 0; i < 4; i++) R(w, x + 1 + i, base - 17 - (i == 3 ? 1 : 0) + (i > 1 ? 1 : 0), 2, 1, ((i) & 1) ? 0xFFFFFF : 0xE8302A);
                    R(w, x + 4, base - 16, 2, 3, 0xE8302A);
                }
                else if (v < 0.72f) hol_santa(w, x, base, dir);
                else if (v < 0.90f) hol_reindeer(w, x, base, dir, (k & 3) == 0, ph);
                else {                                                   /* a street lamp with a bow */
                    R(w, x, base - 26, 2, 26, 0x2A2A34); R(w, x - 2, base - 29, 6, 4, 0xFFE9A0); BLEND(w, x + 1, base - 27, 0xFFE9A0, 90);
                    for (int dy = -8; dy <= 8; dy++) for (int dx = -8; dx <= 8; dx++) if (dx * dx + dy * dy < 64 && ((dx + dy) & 1) == 0) BLEND(w, x + 1 + dx, base - 27 + dy, 0xFFE9A0, 14);
                    R(w, x - 2, base - 14, 6, 2, 0xE8302A); R(w, x - 3, base - 15, 3, 3, 0xE8302A); R(w, x + 2, base - 15, 3, 3, 0xE8302A);
                    R(w, x - 3, base - 19, 8, 1, 0x1E8A3A); R(w, x - 2, base - 18, 6, 1, 0x1E8A3A);
                }
                break;
            case H_VALENTINE:
                if (v < 0.30f) hol_rose_bush(w, x, base, h);
                else if (v < 0.54f) hol_heart_tree(w, x, base, h);
                else if (v < 0.76f) {                                    /* two heart balloons on a stake */
                    float t = (float)w->t;
                    R(w, x, base - 8, 1, 8, 0x8A5A2B);
                    for (int i = 0; i < 2; i++) {
                        int bx = x + (i ? 7 : -7) + (int)floorf(sinf(t * 0.9f + (float)i * 2.0f) * 1.5f);
                        int by = base - 26 - i * 5 + (int)floorf(sinf(t * 1.2f + (float)i) * 1.2f);
                        rope_line(w, x, base - 8, bx, by + 6, 0x7A5A6A);
                        hol_heart(w, bx, by, 6.0f, i ? 0xFF4D7A : 0xE8203F);
                    }
                }
                else {                                                   /* a heart box of chocolates with a rose */
                    hol_gift(w, x - 7, base, 13, 7, 0xC42A4A, 0xFFD23F);
                    R(w, x + 5, base - 12, 1, 6, 0x2F8A3A); R(w, x + 4, base - 15, 3, 3, 0xE8203F); PX(w, x + 5, base - 14, 0xA01028);
                }
                break;
            case H_THANKS:
                if (v < 0.24f) hol_turkey(w, x, base, dir, ph);
                else if (v < 0.46f) { hol_pumpkin(w, x - 7, base, 4); hol_pumpkin(w, x + 2, base, 6); hol_pumpkin(w, x + 10, base, 3); }
                else if (v < 0.64f) {                                    /* corn stalks */
                    for (int i = -1; i <= 1; i++) {
                        int cx = x + i * 4, hh = 18 + (i & 1) * 3;
                        R(w, cx, base - hh, 1, hh, 0x7AAA3A); R(w, cx - 3, base - hh / 2, 3, 1, 0x7AAA3A); R(w, cx + 1, base - hh / 2 - 3, 3, 1, 0x7AAA3A);
                        R(w, cx + 1, base - hh + 5, 2, 5, 0xF0C030); PX(w, cx + 1, base - hh + 4, 0xA8C850);
                        PX(w, cx, base - hh - 1, 0xC8A060); PX(w, cx - 1, base - hh - 2, 0xC8A060); PX(w, cx + 1, base - hh - 2, 0xC8A060);
                    }
                }
                else if (v < 0.76f) {                                    /* hay bale */
                    R(w, x - 8, base - 9, 17, 9, 0xE0C060); R(w, x - 8, base - 9, 17, 1, 0xF4DC88); R(w, x - 8, base - 1, 17, 1, 0xB89440);
                    R(w, x - 4, base - 9, 1, 9, 0xA06A2A); R(w, x + 3, base - 9, 1, 9, 0xA06A2A);
                    for (int i = 0; i < 7; i++) { uint32_t q = hash2(h, (uint32_t)(20 + i)); PX(w, x - 7 + (int)(rfn(q, 0) * 15.0f), base - 8 + (int)(rfn(q, 1) * 7.0f), 0xF4DC88); }
                }
                else if (v < 0.90f) {                                    /* the feast table */
                    R(w, x - 14, base - 11, 29, 2, 0xF4F0E0); R(w, x - 14, base - 9, 29, 1, 0xD8D0B8);
                    R(w, x - 12, base - 9, 2, 9, 0x6B3E1F); R(w, x + 11, base - 9, 2, 9, 0x6B3E1F);
                    ell_fill(w, x - 3, base - 15, 6.0f, 4.0f, 0, 0xA85A24, BIGY); ell_fill(w, x - 3, base - 16, 4.0f, 2.0f, 0, 0xC87A38, BIGY);
                    R(w, x - 10, base - 15, 3, 3, 0xF4F0E0); R(w, x + 3, base - 15, 3, 3, 0xF4F0E0);
                    ell_fill(w, x + 8, base - 13, 4.0f, 2.0f, 0, 0xD88A2A, BIGY); PX(w, x + 7, base - 14, 0xFFF0C0);
                    R(w, x - 13, base - 14, 1, 3, 0xFFFFFF); PX(w, x - 13, base - 15, ((int)(w->t * 6.0f) & 1) ? 0xFFD23F : 0xFF8A2A);
                }
                else {                                                   /* a scarecrow */
                    R(w, x, base - 24, 2, 24, 0x6B3E1F); R(w, x - 8, base - 18, 18, 2, 0x6B3E1F);
                    R(w, x - 4, base - 18, 10, 9, 0x3A6FA8); R(w, x - 3, base - 16, 3, 3, 0xE0A030);
                    R(w, x - 3, base - 25, 8, 6, 0xF0C890); PX(w, x - 1, base - 23, 0x1A1410); PX(w, x + 2, base - 23, 0x1A1410); R(w, x - 1, base - 21, 3, 1, 0x1A1410);
                    R(w, x - 5, base - 27, 12, 2, 0x5A3A1A); R(w, x - 2, base - 31, 6, 4, 0x5A3A1A);
                    for (int i = 0; i < 3; i++) { R(w, x - 9 - i, base - 17 + i, 2, 1, 0xE8D070); R(w, x + 9 + i, base - 17 + i, 2, 1, 0xE8D070); }
                }
                break;
            case H_CNY:
                if (v < 0.30f) {                                         /* lantern post */
                    R(w, x, base - 36, 2, 36, 0x7A1A1A); R(w, x - 12, base - 36, 26, 2, 0x7A1A1A); R(w, x - 12, base - 38, 2, 3, 0xFFC21F); R(w, x + 12, base - 38, 2, 3, 0xFFC21F);
                    float t = (float)w->t;
                    hol_lantern(w, x - 10, base - 36, sinf(t * 1.3f + (float)ph) * 1.4f); hol_lantern(w, x + 12, base - 36, sinf(t * 1.3f + (float)ph + 1.0f) * 1.4f);
                }
                else if (v < 0.50f) {                                    /* plum blossom tree */
                    R(w, x - 1, base - 14, 3, 14, 0x3A2418); R(w, x - 6, base - 18, 6, 1, 0x3A2418); R(w, x + 2, base - 20, 7, 1, 0x3A2418); R(w, x - 8, base - 22, 1, 5, 0x3A2418);
                    for (int i = 0; i < 18; i++) { uint32_t q = hash2(h, (uint32_t)(50 + i)); int bx = x - 11 + (int)(rfn(q, 0) * 22.0f), by = base - 28 + (int)(rfn(q, 1) * 14.0f);
                        R(w, bx, by, 2, 2, (i & 1) ? 0xFFB0CC : 0xFF7AA8); PX(w, bx, by, 0xFFFFFF); }
                }
                else if (v < 0.66f) { for (int i = 0; i < 3; i++) { R(w, x - 8 + i * 6, base - 9 - (i == 1 ? 3 : 0), 5, 8, 0xD01824); R(w, x - 8 + i * 6, base - 9 - (i == 1 ? 3 : 0), 5, 1, 0xFF6A5A); R(w, x - 7 + i * 6, base - 6 - (i == 1 ? 3 : 0), 3, 3, 0xFFC21F); } }
                else if (v < 0.80f) {                                    /* a fu diamond on a stake */
                    R(w, x, base - 10, 1, 10, 0x7A1A1A);
                    for (int dy = -7; dy <= 7; dy++) { int hw = 7 - abs(dy); R(w, x - hw, base - 18 + dy, hw * 2 + 1, 1, hw > 5 ? 0xFFC21F : 0xD01824); }
                    R(w, x - 3, base - 18, 7, 1, 0xFFC21F); R(w, x, base - 22, 1, 9, 0xFFC21F); R(w, x - 2, base - 20, 5, 1, 0xFFC21F); R(w, x - 2, base - 16, 5, 1, 0xFFC21F); R(w, x + 1, base - 14, 2, 1, 0xFFC21F);
                }
                else if (v < 0.90f) {                                    /* gold ingots */
                    for (int i = 0; i < 3; i++) { int ix = x - 7 + i * 6, iy = base - (i == 1 ? 6 : 0); R(w, ix, iy - 4, 8, 3, 0xFFC21F); R(w, ix - 1, iy - 5, 10, 2, 0xFFE27A); R(w, ix + 1, iy - 1, 6, 1, 0xC08A10); }
                    for (int i = 0; i < 2; i++) { int ix = x - 3 + i * 6, iy = base - 9; R(w, ix, iy - 4, 8, 3, 0xFFC21F); R(w, ix - 1, iy - 5, 10, 2, 0xFFE27A); R(w, ix + 1, iy - 1, 6, 1, 0xC08A10); }
                }
                else {                                                   /* a potted mandarin tree */
                    R(w, x - 5, base - 7, 11, 7, 0xC4202C); R(w, x - 5, base - 7, 11, 1, 0xFFC21F); R(w, x - 5, base - 1, 11, 1, 0x8A1018);
                    R(w, x, base - 12, 1, 5, 0x3A2418);
                    for (int dy = -6; dy <= 6; dy++) for (int dx = -7; dx <= 7; dx++) if (dx * dx + dy * dy * 2 < 44) PX(w, x + dx, base - 17 + dy, ((dx + dy) & 3) ? 0x2F8A3A : 0x4CB05A);
                    for (int i = 0; i < 5; i++) { uint32_t q = hash2(h, (uint32_t)(60 + i)); R(w, x - 6 + (int)(rfn(q, 0) * 11.0f), base - 21 + (int)(rfn(q, 1) * 8.0f), 2, 2, 0xFF8A1A); }
                }
                break;
            case H_VETS:
                if (v < 0.34f) hol_flag(w, x, base, ph, 40, 21);
                else if (v < 0.58f) { for (int i = -1; i <= 1; i++) hol_flag(w, x + i * 9, base, ph + i, 12, 8); }
                else if (v < 0.82f) { for (int i = -2; i <= 2; i++) hol_poppy(w, x + i * 4, base, hash2(h, (uint32_t)(i + 9))); }
                else {                                                   /* a bunting garland between two posts */
                    R(w, x - 20, base - 20, 2, 20, 0x6B3E1F); R(w, x + 20, base - 20, 2, 20, 0x6B3E1F);
                    for (int i = 0; i < 20; i++) {
                        int bx = x - 19 + i * 2, sag = (int)(4.0f * sinf((float)i / 19.0f * 3.1416f));
                        Col c = (i % 3 == 0) ? 0xD6283A : ((i % 3 == 1) ? 0xFFFFFF : 0x23408E);
                        PX(w, bx, base - 19 + sag, 0x4A3A2A);
                        if (i % 2 == 0) { R(w, bx - 1, base - 18 + sag, 3, 2, c); PX(w, bx, base - 16 + sag, c); }
                    }
                }
                break;
            case H_HALLOWEEN:
                if (v < 0.12f) { hol_jack(w, x - 10, base, 4, ph); hol_jack(w, x, base, 7, ph + 1); hol_jack(w, x + 11, base, 3, ph + 2); }
                else if (v < 0.20f) hol_ghost(w, x, base - 5, ph, 255, (k & 1));
                else if (v < 0.29f) { hol_witch(w, x - 6 * dir, base, dir, ph); hol_cauldron(w, x + 12 * dir, base, ph); }
                else if (v < 0.37f) hol_skeleton(w, x, base, ph);
                else if (v < 0.46f) { hol_cat(w, x - 4 * dir, base, dir, ph); hol_jack(w, x - 15 * dir, base, 4, ph + 3); }
                else if (v < 0.55f) hol_deadtree(w, x, base, h);
                else if (v < 0.65f) { hol_tomb(w, x - 12, base, 2); hol_tomb(w, x, base, 0); hol_tomb(w, x + 12, base, 1); hol_zombie_hand(w, x + 22, base, ph); }
                else if (v < 0.73f) hol_vampire(w, x, base, ph);
                else if (v < 0.81f) hol_mummy(w, x, base, dir, ph);
                else if (v < 0.90f) { hol_trick(w, x - 7, base, 1, ph); hol_trick(w, x + 7, base, -1, ph + 3); }
                else {                                                   /* a pumpkin patch with its vines */
                    for (int i = -7; i <= 7; i++) PX(w, x + i * 2, base - 1 - (int)floorf(sinf((float)i * 0.9f + 1.0f) * 0.8f + 0.8f), 0x3F7A2A);
                    hol_pumpkin(w, x - 12, base, 5); hol_pumpkin(w, x - 3, base, 3); hol_jack(w, x + 5, base, 6, ph); hol_pumpkin(w, x + 16, base, 4);
                    R(w, x - 8, base - 4, 3, 2, 0x3F7A2A); R(w, x + 9, base - 3, 3, 2, 0x3F7A2A);
                }
                break;
            default: /* H_NEWYEAR */
                if (v < 0.26f) {                                         /* a bunch of gold and silver balloons tied to a stake */
                    float t = (float)w->t;
                    R(w, x, base - 6, 1, 6, 0x8A5A2B);
                    static const Col BC[4] = { 0xFFD23F, 0xC8D0E0, 0xFFD23F, 0xE8ECF8 };
                    for (int i = 0; i < 4; i++) {
                        int bx = x + (i - 2) * 5 + (int)floorf(sinf(t * 1.0f + (float)i) * 1.5f), by = base - 26 - (i & 1) * 6;
                        rope_line(w, x, base - 6, bx, by + 6, 0x6A6A7A);
                        ell_fill(w, bx, by, 4.0f, 5.0f, 0, BC[i], BIGY); PX(w, bx - 1, by - 2, 0xFFFFFF); PX(w, bx + 2, by + 1, mulc(BC[i], 0.75f));
                        if (sinf(t * 3.0f + (float)i * 1.6f) > 0.8f) PX(w, bx + 2, by - 3, 0xFFFFFF);
                    }
                }
                else if (v < 0.44f) {                                    /* champagne, the cork popping */
                    float t = (float)w->t;
                    R(w, x - 2, base - 14, 5, 14, 0x1E6A3A); R(w, x - 2, base - 14, 1, 14, 0x3AA85A); R(w, x - 1, base - 18, 3, 4, 0x1E6A3A); R(w, x - 1, base - 19, 3, 1, 0xFFD23F);
                    R(w, x - 2, base - 8, 5, 4, 0xFFF3C2);
                    float ph2 = fmodf(t * 0.8f + (float)(h & 7u), 2.0f);
                    if (ph2 < 0.7f) { PX(w, x, base - 21 - (int)(ph2 * 22.0f), 0xFFD23F); for (int i = 0; i < 5; i++) PX(w, x - 2 + i, base - 22 - (int)(ph2 * 12.0f) - (i & 1), 0xFFFFFF); }
                    for (int i = 0; i < 2; i++) { int gx = x + 8 + i * 7; R(w, gx, base - 10, 4, 5, 0xE8F4FF); R(w, gx + 1, base - 5, 2, 4, 0xD0E0F0); R(w, gx - 1, base - 1, 6, 1, 0xE8F4FF); R(w, gx + 1, base - 9, 2, 3, 0xFFD23F); }
                }
                else if (v < 0.64f) {                                    /* a streamer pole */
                    float t = (float)w->t;
                    R(w, x, base - 30, 2, 30, 0xC8D0E0); disc(w, x, base - 31, 2, 0xFFD23F);
                    static const Col SC[3] = { 0xFF4D7A, 0x7DF9FF, 0xFFD23F };
                    for (int s = 0; s < 3; s++) for (int i = 0; i < 20; i++) PX(w, x + 1 + (int)(sinf(t * 2.5f + (float)i * 0.5f + (float)s * 2.1f) * (1.0f + (float)i * 0.25f)) + (s - 1) * 3, base - 30 + i * 1, SC[s]);
                }
                else if (v < 0.78f) {                                    /* party hats */
                    static const Col HC[3] = { 0xFF4D7A, 0x4FA6F5, 0xFFD23F };
                    for (int i = 0; i < 3; i++) { int hx = x - 8 + i * 8; for (int r = 0; r < 9; r++) R(w, hx + r / 3 - (8 - r) / 3 + 1, base - r - 1, 2 + (r) / 2 > 4 ? 5 : 2 + r / 2, 1, ((r & 2) ? 0xFFFFFF : HC[i])); disc(w, hx + 2, base - 10, 1, 0xFFD23F); }
                }
                else if (hol == H_NYE && v >= 0.90f) {                   /* a big round clock showing the real time: not long now */
                    int cyy = base - 28;
                    R(w, x - 1, base - 16, 3, 16, 0x6B3E1F);
                    disc(w, x, cyy, 13, 0xFFD23F); disc(w, x, cyy, 11, 0xF4F1E0);
                    for (int i = 0; i < 12; i++) {
                        float a = (float)i * 0.5236f; int q3 = (i % 3 == 0);
                        R(w, x + (int)lroundf(sinf(a) * 9.0f), cyy - (int)lroundf(cosf(a) * 9.0f), q3 ? 2 : 1, q3 ? 2 : 1, 0x2A3166);
                    }
                    float am = ((float)w->tm_min + (float)w->tm_sec / 60.0f) / 60.0f * 6.2832f;
                    float ah = ((float)(w->tm_hour % 12) + (float)w->tm_min / 60.0f) / 12.0f * 6.2832f;
                    rope_line(w, x, cyy, x + (int)lroundf(sinf(ah) * 5.0f), cyy - (int)lroundf(cosf(ah) * 5.0f), 0x141E4D);
                    rope_line(w, x, cyy, x + (int)lroundf(sinf(am) * 8.0f), cyy - (int)lroundf(cosf(am) * 8.0f), 0x141E4D);
                    PX(w, x, cyy, 0xFF4D7A);
                }
                else {                                                   /* the year, in lights */
                    char ys[8]; snprintf(ys, sizeof ys, "%d", hol_year(w));
                    int bw = 4 * 12 + 6;
                    R(w, x - bw / 2, base - 24, 2, 24, 0x6B3E1F); R(w, x + bw / 2 - 2, base - 24, 2, 24, 0x6B3E1F);
                    R(w, x - bw / 2 - 2, base - 38, bw + 4, 19, 0xFFD23F); R(w, x - bw / 2, base - 36, bw, 15, 0x141E4D);
                    int sx2 = x - bw / 2 + 4;
                    for (const char *c = ys; *c; c++) { draw57(w, sx2, base - 34, *c, 2, 0xFFD23F); sx2 += 12; }
                    for (int i = 0; i < bw + 4; i += 4) PX(w, x - bw / 2 - 2 + i, base - 38, ((i / 4 + (int)(w->t * 3.0f)) & 1) ? 0xFFFFFF : 0xFF4D7A);
                }
                break;
        }
    }
    /* banner posts at long intervals: so you always know which day it is */
    const int BS = 520;
    int b0 = floordiv(camI - 90, BS), b1 = floordiv(camI + w->vw + 90, BS);
    for (int k = b0; k <= b1; k++) {
        uint32_t h = hash2(w->seed ^ 0xBA22U, (uint32_t)k);
        int wx = k * BS + 70 + (int)(rfn(h, 1) * 240.0f);
        if (!hol_flat(w, wx, 30)) continue;
        hol_banner_draw(w, wx - camI, w->gy - ground_h(w, wx));
    }
    if (hol == H_CNY) hol_dragon(w);
}

/* what holds the sign up on a holiday: Christmas has Santa's sleigh, everything else keeps the balloons and posts */
static void carrier_sleigh(AWWorld *w, int xc, int camI, uint32_t k, int info, int U) {
    (void)camI;
    int pw, ph; panel_dims(w, info, U, &pw, &ph);
    float t = (float)w->t;
    int bob = (int)floorf(sinf(t * 1.1f + (float)k) * 2.0f + 0.5f);
    int sy = (int)(w->gy * 0.10f) + 16 + bob;                 /* sleigh runner line */
    int x0 = xc - pw / 2, x1 = xc + pw / 2;
    int sx = x1 - 26;                                          /* the sleigh sits at the right end, facing left to right? it flies to the right */
    int by = sy + 14 + bob / 2;                                 /* the board top */
    /* the board hangs from the sleigh by two ropes */
    rope_line(w, x0 + 2, by, sx + 2, sy + 4, 0x4A3A2A); rope_line(w, x1 - 2, by, sx + 18, sy + 4, 0x4A3A2A);
    R(w, x0, by - 1, 2, ph + 2, 0x4A3A2A); R(w, x1 - 2, by - 1, 2, ph + 2, 0x4A3A2A); R(w, x0 - 1, by - 2, pw + 2, 1, 0x4A3A2A);
    panel_face(w, x0, by, info, U);
    /* the sleigh: red body, gold runners, a sack of presents, Santa */
    R(w, sx, sy - 6, 22, 8, 0xC42A2A); R(w, sx, sy - 6, 22, 1, 0xE85050); R(w, sx + 20, sy - 10, 3, 8, 0xC42A2A); R(w, sx + 21, sy - 11, 2, 2, 0xFFD23F);
    R(w, sx, sy - 1, 22, 2, 0x8A1A1A); R(w, sx + 3, sy - 4, 16, 1, 0xFFD23F);
    R(w, sx - 2, sy + 4, 26, 1, 0xFFD23F); R(w, sx - 4, sy + 2, 3, 2, 0xFFD23F); R(w, sx + 3, sy + 2, 1, 2, 0xFFD23F); R(w, sx + 16, sy + 2, 1, 2, 0xFFD23F);
    R(w, sx + 1, sy - 13, 8, 8, 0x8A5A2B); R(w, sx + 1, sy - 13, 8, 2, 0xB27A43); R(w, sx + 4, sy - 11, 2, 2, 0xFFD23F);                  /* sack */
    PX(w, sx + 2, sy - 15, 0xFF3B3B); R(w, sx + 6, sy - 16, 3, 3, 0x4FA6F5); PX(w, sx + 7, sy - 17, 0xFFD23F);
    R(w, sx + 12, sy - 13, 7, 7, 0xD42A2A); R(w, sx + 13, sy - 18, 5, 5, 0xFFE0C0); R(w, sx + 13, sy - 15, 5, 3, 0xFFFFFF);          /* Santa */
    R(w, sx + 12, sy - 21, 6, 4, 0xD42A2A); R(w, sx + 12, sy - 19, 6, 1, 0xFFFFFF); R(w, sx + 10, sy - 23, 3, 3, 0xFFFFFF);
    PX(w, sx + 14, sy - 17, 0x1A1410); PX(w, sx + 17, sy - 17, 0x1A1410);
    R(w, sx + 17, sy - 12 + (int)floorf(sinf(t * 7.0f) * 1.2f), 4, 2, 0xD42A2A);
    /* the reindeer team: four of them, Rudolph in front, with a line back to the sleigh */
    for (int i = 0; i < 4; i++) {
        int rx = sx + 28 + i * 17, gal = (int)floorf(sinf(t * 7.0f + (float)i * 0.9f) * 1.6f);
        int ry = sy + gal - 1 - (i & 1);
        rope_line(w, rx - 11, ry - 5, i == 0 ? sx + 22 : rx - 17 + 7, i == 0 ? sy - 3 : ry - 5, 0xCFA45A);
        Col fur = 0x9A6A3A, dk = 0x6E4824;
        R(w, rx - 8, ry - 8, 13, 6, fur); R(w, rx - 8, ry - 8, 13, 1, 0xB88450); R(w, rx - 8, ry - 3, 13, 1, dk);
        int sw = (int)floorf(sinf(t * 7.0f + (float)i * 0.9f) * 3.0f);
        R(w, rx - 7 + sw, ry - 3, 2, 5, dk); R(w, rx - 4 - sw, ry - 3, 2, 5, fur); R(w, rx + 1 + sw, ry - 3, 2, 5, dk); R(w, rx + 4 - sw, ry - 3, 2, 5, fur);
        R(w, rx + 4, ry - 12, 3, 6, fur); R(w, rx + 5, ry - 14, 6, 4, fur);
        PX(w, rx + 8, ry - 13, 0x101010);
        int nose = i == 3;
        R(w, rx + 11, ry - 13, 2, 2, nose ? 0xFF2A2A : 0x2A1A10);
        if (nose) { int fl = ((int)(t * 4.0f) & 1); for (int dy = -5; dy <= 5; dy++) for (int dx = -5; dx <= 5; dx++) if (dx * dx + dy * dy < 24) BLEND(w, rx + 12 + dx, ry - 12 + dy, 0xFF4040, fl ? 40 : 22); }
        R(w, rx + 6, ry - 18, 1, 5, 0xD8C8A0); R(w, rx + 7, ry - 20, 1, 3, 0xD8C8A0); R(w, rx + 5, ry - 20, 1, 2, 0xD8C8A0);
        R(w, rx - 9, ry - 8, 2, 2, 0xF4F4F4);
    }
    /* a trail of sparkles behind them */
    for (int i = 0; i < 12; i++) {
        float f = fmodf(t * 1.4f + (float)i * 0.31f, 1.0f);
        int tx = sx - 2 - (int)(f * 30.0f), ty = sy + 2 + (int)(sinf((float)i * 2.3f) * 5.0f);
        if (f < 0.9f) PX(w, tx, ty, lerpc(0xFFFFFF, 0xFFD23F, f));
    }
}

/* balloon styles for the holidays (indices into the style list) */
static void hol_decorate_sign(AWWorld *w, int x, int y, int pw, int ph) {
    float t = (float)w->t;
    switch (w->hol) {
        case H_XMAS_EVE: case H_XMAS:
            for (int i = -2; i < pw + 2; i += 5) { PX(w, x + i, y - 3, FW_COL[(i / 5 + (int)(t * 2.0f)) % 5]); PX(w, x + i + 2, y - 4, 0x1E8A3A); }
            R(w, x - 3, y - 3, 3, 2, 0x1E8A3A); R(w, x + pw, y - 3, 3, 2, 0x1E8A3A); PX(w, x - 2, y - 4, 0xE8302A); PX(w, x + pw + 1, y - 4, 0xE8302A);
            break;
        case H_VALENTINE:
            hol_micro_heart(w, x - 5, y - 5, 0xFF3B6B, 1); hol_micro_heart(w, x + pw + 1, y - 5, 0xFF7AA8, 1);
            break;
        case H_THANKS:
            hol_pumpkin(w, x - 6, y + ph + 3, 3); hol_pumpkin(w, x + pw + 6, y + ph + 3, 3);
            break;
        case H_CNY: hol_lantern(w, x - 7, y - 4, 0); hol_lantern(w, x + pw + 8, y - 4, 0); break;
        case H_VETS:
            for (int i = 0; i < pw; i += 4) { Col c = ((i / 4) % 3 == 0) ? 0xD6283A : (((i / 4) % 3 == 1) ? 0xFFFFFF : 0x23408E); R(w, x + i, y - 4, 3, 2, c); PX(w, x + i + 1, y - 2, c); }
            break;
        case H_NEWYEAR: case H_NYE:
            for (int i = 0; i < pw; i += 6) if (sinf(t * 4.0f + (float)i) > 0.2f) { PX(w, x + i, y - 3, 0xFFD23F); PX(w, x + i + 3, y - 5, 0xFFFFFF); }
            break;
        case H_HALLOWEEN: {
            hol_jack(w, x - 6, y + ph + 3, 3, (int)(x & 7));  hol_jack(w, x + pw + 6, y + ph + 3, 3, 3);
            int sl = 5 + (int)floorf(sinf(t * 1.4f + (float)x) * 2.0f + 2.0f);                     /* a spider dangling on its thread */
            int sx = x + pw / 2, sy = y + ph + 1;
            R(w, sx, sy, 1, sl, 0xB8B0C8); R(w, sx - 1, sy + sl, 3, 2, 0x16101E); PX(w, sx - 2, sy + sl + 1, 0x16101E); PX(w, sx + 2, sy + sl + 1, 0x16101E);
            PX(w, sx - 2, sy + sl - 1, 0x16101E); PX(w, sx + 2, sy + sl - 1, 0x16101E); PX(w, sx, sy + sl, 0xE02020);
        } break;
        default: break;
    }
}
