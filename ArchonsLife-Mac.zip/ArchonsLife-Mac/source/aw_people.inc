/*
 * Archon's Life v6 - the people who stroll past, and the little terrier with a message.
 * Everyone is built from rectangles; the outfit, hair, skin, colours and extras all come from one 32-bit hash,
 * so every passer-by is different. Included by aw_engine.c after aw_friends.inc.
 */

static int pp_o;   /* 1 while laying the dark outline, 0 while painting the colours */
static void pp_px(AWWorld *w, int x, int y, Col c) {
    if (!pp_o) { PX(w, x, y, c); return; }
    BLEND(w, x - 1, y, 0x1D1020, 70); BLEND(w, x + 1, y, 0x1D1020, 70); BLEND(w, x, y - 1, 0x1D1020, 70); BLEND(w, x, y + 1, 0x1D1020, 70);
}
static void pp_r(AWWorld *w, int x, int y, int ww, int hh, Col c) {
    for (int j = 0; j < hh; j++) for (int i = 0; i < ww; i++) pp_px(w, x + i, y + j, c);
}

/* one person, facing d (+1 right / -1 left), standing on the ground row b, centred on column cx.
   Heights run up from the ground: legs 0-3, body 4-7, head 8-11, hair and hats 12. About 13 px tall. */
static void paint_person(AWWorld *w, int cx, int b, uint32_t h, int d, float t, int moving) {
    static const Col SKIN[6] = { 0xFFD7B5, 0xF1C27D, 0xE0AC69, 0xC68642, 0x8D5524, 0x6B4226 };
    static const Col HAIR[8] = { 0x2A1A10, 0x5A3A22, 0x8A5A2B, 0xE8C36A, 0xB8402A, 0x1D1020, 0xC8C8D0, 0x7A4AC8 };
    static const Col TOPC[10] = { 0xE8442A, 0x4FA6F5, 0xFFD23F, 0x2FC4B2, 0xA77BF0, 0xFF7AA8, 0x7DDB5C, 0xFF8A2A, 0xF4F4FA, 0x2F5FA8 };
    static const Col BOTC[6] = { 0x2F5FA8, 0x1D3A78, 0x6A5A4A, 0x3A3A46, 0xC8B07A, 0x4A6A3A };
    int fem = (int)(h & 1u), outfit = (int)((h >> 20) % 6u), hs = (int)((h >> 24) % 4u);
    Col skin = SKIN[(h >> 1) % 6u], hair = HAIR[(h >> 4) % 8u], top = TOPC[(h >> 8) % 10u], bot = BOTC[(h >> 12) % 6u], top2 = TOPC[(h >> 16) % 10u];
    int pack = ((h >> 28) & 3u) == 0u;                     /* a backpack now and then */
    int step = moving ? (((int)(t * 5.0f)) & 1) : 0;
    int swing = moving ? (step ? 1 : -1) : 0;
    Col dark = 0x2A2F3E, shoe = 0x3A2A22;
    if (outfit == 2) top = dark;                            /* formal wear */
    if (outfit == 4) { top = (h & 2u) ? 0xD6283A : 0xF4F4FA; }   /* a plaid or white work shirt under the overalls */
#define PRF(x, y, ww, hh, c) pp_r(w, (d > 0 ? cx + (x) : cx - (x) - (ww) + 1), b - (y) - (hh), (ww), (hh), (c))
    for (pp_o = 1; pp_o >= 0; pp_o--) {
        Col pants = bot;
        if (outfit == 1) pants = 0x5A5F6E;                  /* joggers */
        if (outfit == 2) pants = dark;
        if (outfit == 4) pants = 0x3F6AC0;                  /* denim overalls */
        if (outfit == 5) pants = 0x3A3A46;
        int shorts = (outfit == 3 && !fem) || (outfit == 0 && fem && (h & 0x10000000u) && !pack);
        int skirt = (outfit == 2 && fem) || (outfit == 3 && fem);
        /* the legs */
        Col lc = (skirt || shorts) ? skin : pants;
        if (step || !moving) { PRF(-2, 0, 2, 4, lc); PRF(1, 0, 2, 4, lc); }
        else PRF(-1, 0, 3, 4, lc);
        if (shorts) { PRF(-2, 2, 2, 2, pants); PRF(1, 2, 2, 2, pants); if (!step && moving) PRF(-1, 2, 3, 2, pants); }
        if (!(outfit == 3)) { PRF(step || !moving ? -2 : -1, 0, 2, 1, shoe); PRF(step || !moving ? 1 : 1, 0, 2, 1, shoe); }
        else { PRF(step || !moving ? -2 : -1, 0, 2, 1, 0xF4F4FA); PRF(1, 0, 2, 1, 0xF4F4FA); }   /* summer sneakers */
        if (outfit == 4) { PRF(-2, 0, 2, 2, 0x6A4A2C); PRF(1, 0, 2, 2, 0x6A4A2C); }              /* boots */
        /* the body */
        PRF(-2, 4, 5, 4, top);
        if (outfit == 1) { PRF(-3, 7, 2, 1, mulc(top, 0.7f)); PRF(-3, 8, 1, 2, mulc(top, 0.7f)); PRF(-1, 4, 3, 1, mulc(top, 0.8f)); }   /* hoodie: hood at the back, pocket */
        if (outfit == 2) {
            if (!fem) { PRF(1, 6, 1, 2, 0xF4F4FA); PRF(1, 5, 1, 2, 0xE8304A); }              /* shirt front and tie */
            else { PRF(0, 7, 3, 1, 0xF4F4FA); }                                             /* blouse collar */
        }
        if (outfit == 3 && fem) { PRF(-2, 4, 5, 4, top2); PRF(-2, 7, 1, 1, skin); PRF(2, 7, 1, 1, skin); PRF(-3, 3, 7, 2, top2); }   /* sundress: bright, flared */
        if (outfit == 3 && !fem) { PRF(-2, 7, 1, 1, skin); PRF(2, 7, 1, 1, skin); PRF(-2, 4, 5, 1, bot); }   /* tank top and swim shorts */
        if (outfit == 4) { PRF(-1, 4, 3, 3, pants); PRF(-1, 7, 1, 1, pants); PRF(1, 7, 1, 1, pants); PRF(0, 5, 1, 1, 0xFFD23F); }   /* overalls bib and straps */
        if (outfit == 5) { PRF(-2, 3, 5, 2, top); PRF(-2, 4, 5, 4, top); PRF(2, 4, 1, 4, mulc(top, 0.78f)); PRF(-2, 7, 5, 1, top2); }   /* long coat and a scarf */
        if (skirt && outfit == 2) { PRF(-2, 3, 5, 2, dark); PRF(-3, 3, 1, 1, dark); PRF(3, 3, 1, 1, dark); }
        /* the arms swing a little */
        Col sl = (outfit == 3) ? skin : (outfit == 0 ? top : (outfit == 4 ? top : top));
        if (outfit == 0 || outfit == 3) { PRF(-3, 5 + (swing > 0 ? 0 : 1), 1, 2, skin); PRF(3, 5 + (swing > 0 ? 1 : 0), 1, 2, skin); PRF(-3, 7, 1, 1, outfit == 0 ? top : skin); PRF(3, 7, 1, 1, outfit == 0 ? top : skin); }
        else { PRF(-3, 4 + (swing > 0 ? 0 : 1), 1, 3, sl); PRF(3, 4 + (swing > 0 ? 1 : 0), 1, 3, sl); PRF(-3, 4 + (swing > 0 ? 0 : 1), 1, 1, skin); PRF(3, 4 + (swing > 0 ? 1 : 0), 1, 1, skin); }
        if (pack) { PRF(-4, 4, 2, 4, top2); PRF(-4, 4, 2, 1, mulc(top2, 0.7f)); PRF(-4, 7, 2, 1, lerpc(top2, 0xFFFFFF, 0.3f)); }
        /* the head */
        PRF(-2, 8, 5, 4, skin);
        PRF(3, 9, 1, 1, skin);                                                                /* a little nose */
        if (!pp_o) { PRF(1, 10, 1, 1, 0x1D1020); PRF(2, 9, 1, 1, lerpc(skin, 0xE8404A, 0.45f)); PRF(2, 10, 1, 1, lerpc(skin, 0xFF8FB8, 0.35f)); }
        /* hair and hats */
        PRF(-2, 12, 5, 1, hair);
        if (hs == 0) { PRF(-3, 10, 1, 2, hair); PRF(-2, 11, 5, 1, hair); if (fem) PRF(-3, 8, 2, 3, hair); }   /* short, or a bob */
        else if (hs == 1) { PRF(-3, fem ? 4 : 9, 2, fem ? 8 : 3, hair); PRF(-2, 11, 5, 1, hair); }          /* long down the back */
        else if (hs == 2) { PRF(-3, 11, 2, 2, hair); PRF(-2, 11, 5, 1, hair); PRF(-4, 12, 2, 2, hair); }  /* a bun on top of the back of the head */
        else { PRF(-2, 12, 5, 1, hair); PRF(-3, 9, 1, 3, hair); PRF(-2, 11, 4, 1, hair); }
        if (!fem && ((h >> 22) & 3u) == 0u) PRF(0, 8, 3, 1, hair);                           /* a beard */
        /* a cap, a straw hat or a beanie for some */
        if (outfit == 4) { PRF(-4, 12, 9, 1, 0xE8C36A); PRF(-2, 13, 5, 1, 0xE8C36A); PRF(-2, 12, 5, 1, 0xC8A040); }
        else if (outfit == 5) { PRF(-3, 12, 6, 2, top2); PRF(-1, 14, 2, 1, 0xF4F4FA); }
        else if (((h >> 14) & 3u) == 0u) { PRF(-2, 12, 5, 2, top2); PRF(2, 12, 3, 1, mulc(top2, 0.8f)); }
    }
    pp_o = 0;
#undef PRF
}

/* the little white terrier carries a wooden sign, painted like the landmark name plaques */
static void draw_sammy_sign(AWWorld *w, int cx, int topy, float t) {
    static const char *const MSG = "I LUV SAMMY";
    int tw = text35_w(MSG, 1), pw = tw + 6;
    int bob = (int)floorf(sinf(t * 2.4f) * 1.0f + 0.5f);
    int x = cx - pw / 2, y = topy - 19 + bob;
    R(w, cx - 7, y + 10, 2, topy + 4 - (y + 10), 0x6B3E1F); R(w, cx + 5, y + 10, 2, topy + 4 - (y + 10), 0x6B3E1F);    /* the posts he carries */
    R(w, x - 1, y - 1, pw + 2, 11, 0x3A2412); R(w, x, y, pw, 9, 0x7A4A24); R(w, x + 1, y + 1, pw - 2, 7, 0x2A1A10);
    text35(w, x + 3, y + 2, MSG, 1, 0xFFF3C2);
    int hb = ((int)(t * 2.0f)) & 1;                                                       /* a heart that beats above the sign */
    Col hc = 0xFF5C9A;
    PX(w, cx - 1, y - 4 - hb, hc); PX(w, cx + 1, y - 4 - hb, hc); R(w, cx - 1, y - 3 - hb, 3, 1, hc); PX(w, cx, y - 2 - hb, hc);
}
