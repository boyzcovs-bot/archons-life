/*
 * Archon's Life - optional live weather for the temperature sign.
 *
 * What it does (and all it does):
 *   1. asks a free IP-geolocation service roughly where this computer is
 *      (city-level; the answer is rounded to 0.1 degree and never stored),
 *   2. asks Open-Meteo (free, no account) for the current temperature there,
 *   3. refreshes about every 20 minutes, only while the saver is actually running.
 * Nothing is written to disk. If the network is unreachable, the saver simply
 * leaves the temperature sign out and shows time and date.
 *
 * A background thread does the fetching so drawing never waits on the network.
 */
#ifndef AW_WEATHER_H
#define AW_WEATHER_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int   valid;      /* 1 once a fresh reading is available */
    float temp_c;
    int   wmo_code;   /* WMO weather code, as used by Open-Meteo */
    int   is_day;
    char  country[3]; /* ISO country code from the geolocation lookup ("" if unknown) */
} AWWeather;

/* Start (or join) the background updater. Safe to call from several views. */
void aw_weather_start(void);
/* Release one reference; the thread parks itself when it is no longer polled. */
void aw_weather_stop(void);
/* Copy the latest reading. Returns 1 if valid. Cheap; call every frame. */
int  aw_weather_get(AWWeather *out);

/* ISO country -> defaults, used only when the system gives no preference. */
int  aw_country_uses_fahrenheit(const char *cc);
int  aw_country_uses_12h(const char *cc);

/* --- pieces exposed for the tests --- */
int  aw_parse_geo(const char *json, double *lat, double *lon, char cc[3]);
int  aw_parse_weather(const char *json, float *temp_c, int *code, int *is_day);

/* Provided by the platform layer (aw_net_win.c / aw_net_mac.c / aw_net_stub.c).
 * HTTPS GET into buf (NUL-terminated). Returns bytes read, or -1 on any failure. Must time out
 * (about 8 s) and must not block forever. */
int  aw_http_get(const char *url, char *buf, int cap);

#ifdef __cplusplus
}
#endif
#endif
