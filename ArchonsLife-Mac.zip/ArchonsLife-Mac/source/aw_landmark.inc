/*
 * Archon's Life - famous places that turn up now and then beside the path.
 * Pisa, the Sphinx and the pyramids, Las Vegas, the Space Needle, the Eiffel Tower, Lady Liberty, Big Ben, the Taj Mahal, Stonehenge and the St. Louis Gateway Arch,
 * and now Sydney's Opera House, the Colosseum, the Great Wall, Mount Fuji, the Golden Gate Bridge, Christ the Redeemer, Chichen Itza, the Parthenon, the Moai,
 * the Burj Khalifa, St. Basil's, the Hollywood sign, the CN Tower, Uluru and Neuschwanstein.
 * Drawn before the ground, so the lawn covers their feet. Included from aw_extra.inc.
 */

enum { LM_PISA, LM_SPHINX, LM_VEGAS, LM_NEEDLE, LM_EIFFEL, LM_LIBERTY, LM_BIGBEN, LM_TAJ, LM_STONE, LM_ARCH,
       LM_SYDNEY, LM_ROME, LM_WALL, LM_FUJI, LM_GOLDEN, LM_CHRIST, LM_CHICHEN, LM_ATHENS, LM_MOAI, LM_BURJ, LM_BASIL, LM_HOLLY, LM_CN, LM_ULURU, LM_SWAN, LM_N };

static void lm_tri(AWWorld *w, int cx, int by, int bw, int hgt, Col lit, Col shade, Col line) {
    for (int r = 0; r < hgt; r++) {
        int hw = (bw * (hgt - r)) / (2 * hgt);
        for (int dx = -hw; dx <= hw; dx++) {
            Col c = dx > hw / 4 ? shade : lit;
            if (r % 4 == 3) c = mulc(c, 0.9f);
            if (dx == -hw) c = lerpc(c, 0xFFFFFF, 0.25f);
            PX(w, cx + dx, by - r, c);
        }
    }
    (void)line;
}

static void lm_pisa(AWWorld *w, int ox, int by, int d) {
    const int H = 62;
    Col stone = 0xEDE3C8, ledge = 0xFFF7DC, dk = 0xB8A988, sh = 0xCFC3A4;
    /* the cathedral beside it */
    int cx = ox - d * 30;
    R(w, cx - 16, by - 20, 32, 20, stone); R(w, cx - 16, by - 20, 32, 1, ledge); R(w, cx + 10, by - 20, 6, 20, sh);
    for (int i = 0; i < 6; i++) { R(w, cx - 14 + i * 5, by - 17, 3, 6, dk); PX(w, cx - 13 + i * 5, by - 18, dk); }
    R(w, cx - 18, by - 22, 36, 2, 0xB8644A);
    ell_fill(w, cx, by - 24, 8.0f, 4.0f, 0, 0xB8644A, by - 22); R(w, cx - 1, by - 30, 2, 4, 0xFFD23F);
    /* the tower, leaning */
    for (int i = 0; i < H; i++) {
        int shift = d * (i * 8) / H;
        int belfry = i >= H - 11;
        int hw = belfry ? 5 : 7;
        int story = i / 8;
        int ledge_row = (i % 8) == 7 && !belfry;
        int x0 = ox + shift - hw - (ledge_row ? 1 : 0), ww = hw * 2 + 1 + (ledge_row ? 2 : 0);
        R(w, x0, by - i, ww, 1, ledge_row ? ledge : stone);
        if (!ledge_row && !belfry && (i % 8) != 0) for (int c = -hw + 1; c <= hw - 1; c += 3) PX(w, ox + shift + c, by - i, ((i % 8) > 5) ? sh : dk);
        if (belfry && (i % 3) == 1) for (int c = -hw + 1; c <= hw - 1; c += 3) PX(w, ox + shift + c, by - i, dk);
        R(w, ox + shift + hw - 1, by - i, 2, 1, mulc(ledge_row ? ledge : stone, 0.84f));
        (void)story;
    }
    int ts = d * 8;
    R(w, ox + ts - 5, by - H - 1, 11, 2, 0xB8644A); R(w, ox + ts - 3, by - H - 3, 7, 2, 0xB8644A);
    PX(w, ox + ts, by - H - 4, 0x6A4A3A); R(w, ox + ts - 1, by - H + 4, 3, 3, 0x6A4A3A);
}

static void lm_sphinx(AWWorld *w, int ox, int by, int d) {
    /* three pyramids and a dune behind */
    ell_fill(w, ox - d * 10, by, 70.0f, 10.0f, 0, 0xE6CC8A, by + 2);
    lm_tri(w, ox + d * 38, by, 100, 64, 0xE8CC84, 0xBF9C56, 0);
    lm_tri(w, ox + d * 84, by, 64, 40, 0xEAD08C, 0xC8A45E, 0);
    lm_tri(w, ox - d * 18, by, 34, 22, 0xEED496, 0xCCA864, 0);
    ell_fill(w, ox + d * 6, by, 60.0f, 6.0f, 0, 0xEBD394, by + 2);
    /* the Sphinx: a lion's body lying down with a man's head, facing d (a big one, so it reads) */
    Col sand = 0xD8B070, lit = 0xF0CE90, dk = 0xA88444;
    int bx = ox - d * 22;
    R(w, bx - 25, by - 16, 50, 16, sand); R(w, bx - 25, by - 16, 50, 1, lit); R(w, bx - 25, by - 1, 50, 1, dk);
    ell_fill(w, bx - d * 17, by - 12, 9.0f, 8.0f, 0, sand, BIGY);                          /* haunch */
    R(w, bx - d * 28 - (d > 0 ? 4 : 0), by - 6, 5, 6, dk);
    int px0 = d > 0 ? bx + 20 : bx - 20 - 21;
    R(w, px0, by - 5, 21, 5, sand); R(w, px0, by - 5, 21, 1, lit); R(w, px0, by - 1, 21, 1, dk); R(w, px0 + 10, by - 5, 1, 5, dk);   /* paws */
    int hx = bx + d * 15;
    R(w, hx - 7, by - 37, 14, 22, sand); R(w, hx - 7, by - 37, 14, 1, lit);                  /* neck and head */
    R(w, hx - 10, by - 34, 4, 19, dk); R(w, hx + 7, by - 34, 4, 19, dk);                         /* headdress flaps */
    for (int i = 0; i < 5; i++) R(w, hx - 7, by - 36 + i * 4, 14, 1, dk);                      /* stripes */
    R(w, hx - 4, by - 32, 9, 11, lit);                                                          /* face */
    PX(w, hx - 3 + (d > 0 ? 1 : 0), by - 29, 0x4A3418); PX(w, hx + 3 - (d > 0 ? 0 : 1), by - 29, 0x4A3418);
    PX(w, hx, by - 26, dk); R(w, hx - 2, by - 23, 5, 1, 0x8A5A30);
}

static void lm_vegas(AWWorld *w, int ox, int by, int d) {
    float t = (float)w->t;
    (void)d;
    /* black pyramid with a beam */
    lm_tri(w, ox - 6, by, 64, 36, 0x2A3050, 0x181C34, 0);
    for (int r = 4; r < 34; r += 5) for (int c = -(30 - r * 6 / 7) / 2; c < (30 - r * 6 / 7) / 2; c += 5) PX(w, ox - 6 + c, by - r, 0x5A6CB0);
    R(w, ox - 7, by - 41, 2, 5, 0xFFF0A0);
    for (int r = 0; r < 60; r++) { int al = 30 - r / 3; if (al > 0 && (r & 1) == 0) { BLEND(w, ox - 7, by - 42 - r, 0xFFF0A0, al); BLEND(w, ox - 6, by - 42 - r, 0xFFF0A0, al / 2); } }
    /* a tall golden casino tower */
    int tx = ox - 70;
    R(w, tx - 9, by - 58, 18, 58, 0xC8A040); R(w, tx - 9, by - 58, 18, 2, 0xFFE27A); R(w, tx + 5, by - 58, 4, 58, 0x9A7A28);
    for (int r = 4; r < 56; r += 4) for (int c = -7; c <= 3; c += 4) R(w, tx + c, by - r, 2, 2, ((r / 4 + c) & 1) ? 0xFFF0B0 : 0x6A8CC8);
    /* the needle tower with its pod */
    int nx = ox + 52;
    R(w, nx - 1, by - 88, 3, 88, 0xD8D8E4); R(w, nx - 1, by - 88, 1, 88, 0xFFFFFF);
    R(w, nx - 8, by - 62, 17, 5, 0xB8B8C8); R(w, nx - 6, by - 66, 13, 4, 0x9AA0B8); R(w, nx - 8, by - 62, 17, 1, 0xFFFFFF);
    R(w, nx - 1, by - 94, 1, 6, 0xD8D8E4); if (((int)(t * 2.0f) & 1)) PX(w, nx - 1, by - 95, 0xFF3030);
    /* a long low casino with neon */
    R(w, ox + 18, by - 20, 26, 20, 0x7A3A8A); R(w, ox + 18, by - 20, 26, 1, 0xC08AD0);
    for (int i = 0; i < 6; i++) R(w, ox + 20 + i * 4, by - 16, 2, 4, ((i + (int)(t * 3.0f)) & 1) ? 0xFFE27A : 0x4A2A5A);
    /* the sign: a neon billboard with a diamond on top */
    int sx = ox - 32, sy = by - 24;
    R(w, sx - 20, sy, 2, 28, 0x6A6A74); R(w, sx + 19, sy, 2, 28, 0x6A6A74);
    R(w, sx - 22, sy - 12, 45, 13, 0x141026); R(w, sx - 22, sy - 12, 45, 1, 0xFF4FA3); R(w, sx - 22, sy, 45, 1, 0xFF4FA3);
    int on = ((int)(t * 3.0f)) & 1;
    text35(w, sx - 18, sy - 9, "LAS VEGAS", 1, on ? 0xFFE27A : 0xFFFFFF);
    for (int i = 0; i < 45; i += 3) PX(w, sx - 22 + i, sy - 13, ((i / 3 + (int)(t * 4.0f)) & 1) ? 0xFFE27A : 0xFF4FA3);
    for (int dy = -5; dy <= 5; dy++) { int hw = 5 - abs(dy); R(w, sx - hw, sy - 24 + dy, hw * 2 + 1, 1, 0xFFE27A); }
}

static void lm_needle(AWWorld *w, int ox, int by, int d) {
    float t = (float)w->t;
    (void)d;
    Col wh = 0xF2F2F2, sh = 0xC8CCD8;
    const int H = 92;
    /* the hourglass legs: three slim curved supports */
    for (int i = 0; i < 60; i++) {
        float f = (float)i / 60.0f;
        int hw = 3 + (int)(13.0f * (1.0f - sinf(f * 2.6f) * 0.8f) * (1.0f - f * 0.15f));
        if (i < 3) hw += 1;
        int y = by - i;
        R(w, ox - hw, y, 2, 1, wh); R(w, ox + hw - 1, y, 2, 1, sh); PX(w, ox, y, sh);
        if (i % 9 == 4) R(w, ox - hw, y, hw * 2 + 1, 1, sh);
    }
    /* the saucer */
    int sy = by - 64;
    ell_fill(w, ox, sy, 21.0f, 4.0f, 0, wh, BIGY); R(w, ox - 20, sy - 1, 41, 2, wh);
    R(w, ox - 18, sy - 5, 37, 4, 0x4A6A98); for (int i = -17; i <= 17; i += 3) PX(w, ox + i, sy - 4, 0xA8C8F0);
    R(w, ox - 20, sy + 1, 41, 2, 0xE8742A);                                                     /* the orange halo */
    ell_fill(w, ox, sy - 7, 14.0f, 3.0f, 0, wh, BIGY); R(w, ox - 9, sy - 9, 19, 3, 0xDDE4F0);
    R(w, ox - 1, by - H, 3, 22, wh); R(w, ox - 1, by - H, 1, 22, 0xFFFFFF);
    R(w, ox, by - H - 6, 1, 6, wh);
    if (((int)(t * 1.6f)) & 1) { PX(w, ox, by - H - 7, 0xFF3030); BLEND(w, ox, by - H - 7, 0xFF3030, 80); }
}

static void lm_eiffel(AWWorld *w, int ox, int by, int d) {
    (void)d;
    Col iron = 0x7A6450, lit = 0xA88C70, dk = 0x4A3A2C;
    const int H = 92;
    for (int i = 0; i < H; i++) {
        float f = (float)i / (float)H;
        int hw = 2 + (int)(powf(1.0f - f, 2.3f) * 22.0f);
        int th = f < 0.30f ? 3 : (f < 0.62f ? 2 : 1);
        R(w, ox - hw, by - i, th, 1, iron); R(w, ox + hw - th + 1, by - i, th, 1, dk);
        PX(w, ox - hw, by - i, lit);
        if (f > 0.16f && f < 0.30f && (i & 1)) R(w, ox - hw + th, by - i, hw * 2 - 2 * th + 1, 1, ((i + hw) & 2) ? iron : dk);
        if (f > 0.34f && f < 0.60f && (i % 3 == 0)) R(w, ox - hw + th, by - i, hw * 2 - 2 * th + 1, 1, iron);
        if (f > 0.64f && (i & 1)) PX(w, ox, by - i, iron);
        if (i % 5 == 2 && f > 0.34f && f < 0.60f) { PX(w, ox - hw + th + (i / 5 % 3), by - i + 1, lit); PX(w, ox + hw - th - (i / 5 % 3), by - i + 1, lit); }
    }
    int p1 = (int)(H * 0.30f), p2 = (int)(H * 0.62f);
    R(w, ox - 14, by - p1 - 1, 29, 3, iron); R(w, ox - 14, by - p1 - 1, 29, 1, lit);
    R(w, ox - 7, by - p2 - 1, 15, 2, iron); R(w, ox - 7, by - p2 - 1, 15, 1, lit);
    R(w, ox - 3, by - (int)(H * 0.80f) - 1, 7, 2, iron);
    R(w, ox, by - H - 5, 1, 6, iron);
    if (((int)(w->t * 2.0f)) & 1) PX(w, ox, by - H - 6, 0xFFE27A);
    /* the arch between the feet */
    for (int dx = -17; dx <= 17; dx++) { int ay = (int)(8.0f * sqrtf(fmaxf(0.0f, 1.0f - (float)(dx * dx) / 306.0f))); if (ay > 0) PX(w, ox + dx, by - 12 - ay, iron); }
}

static void lm_liberty(AWWorld *w, int ox, int by, int d) {
    float t = (float)w->t;
    Col green = 0x6FBFA0, dkg = 0x4A9A80, lg = 0x9AE0C8, stone = 0xA8A8B0;
    /* the star-shaped base and the pedestal */
    R(w, ox - 16, by - 6, 33, 6, 0x8A8A94); R(w, ox - 16, by - 6, 33, 1, 0xB4B4BE);
    R(w, ox - 10, by - 26, 21, 20, stone); R(w, ox - 10, by - 26, 21, 1, 0xCFCFD8); R(w, ox + 6, by - 26, 5, 20, 0x8A8A94);
    R(w, ox - 12, by - 28, 25, 2, 0xB4B4BE);
    for (int i = 0; i < 3; i++) R(w, ox - 6 + i * 5, by - 22, 3, 8, 0x7A7A86);
    /* robe */
    for (int i = 0; i < 30; i++) {
        int hw = 5 + (i < 8 ? 0 : (i < 22 ? 1 : 0)) - (i > 24 ? 1 : 0) - (i < 2 ? 2 : 0) ;
        R(w, ox - hw, by - 28 - i, hw * 2 + 1, 1, green);
        PX(w, ox - hw, by - 28 - i, lg); R(w, ox + hw - 1, by - 28 - i, 2, 1, dkg);
        if (i % 5 == 2) R(w, ox - 2 + (i / 5) % 3 - 1, by - 28 - i, 1, 3, dkg);
    }
    /* the raised arm and the torch */
    int ax = ox + d * 4;
    for (int i = 0; i < 18; i++) R(w, ax + d * (i / 6) - (d < 0 ? 1 : 0), by - 52 - i, 3, 1, green);
    int tx = ax + d * 3;
    R(w, tx - 3, by - 71, 7, 2, 0xFFD23F); R(w, tx - 1, by - 70, 3, 4, 0xD8A820);
    int fl = (int)(sinf(t * 9.0f) * 1.2f + 1.2f);
    R(w, tx - 2, by - 78 - fl, 5, 6 + fl, 0xFFB020); R(w, tx - 1, by - 80 - fl, 3, 3, 0xFFE27A); PX(w, tx, by - 81 - fl, 0xFFFFFF);
    for (int dy = -8; dy <= 8; dy++) for (int dx = -8; dx <= 8; dx++) if (dx * dx + dy * dy < 50 && ((dx + dy) & 1) == 0) BLEND(w, tx + dx, by - 76 + dy, 0xFFD060, 22);
    /* the tablet arm, head and crown */
    R(w, ox - d * 7 - (d > 0 ? 3 : 0), by - 45, 4, 10, dkg); R(w, ox - d * 9 - (d > 0 ? 2 : 0), by - 49, 5, 8, 0xB8E8D4);
    R(w, ox - 3, by - 62, 7, 7, green); R(w, ox - 3, by - 62, 1, 7, lg); PX(w, ox - 1, by - 59, 0x2A5A4A); PX(w, ox + 2, by - 59, 0x2A5A4A);
    for (int i = -3; i <= 3; i++) { R(w, ox + i * 2 - 1 + (i < 0 ? 0 : 1) - 0, by - 66 - (3 - abs(i)) / 1 * 0, 1, 2 + (3 - abs(i)) / 2 + 1, green); }
    R(w, ox - 3, by - 64, 7, 2, dkg);
}

static void lm_bigben(AWWorld *w, int ox, int by, int d) {
    Col st = 0xD6B884, lit = 0xEBD3A0, dk = 0xA88C58;
    /* the Houses of Parliament */
    int px = ox - d * 34;
    R(w, px - 26, by - 20, 52, 20, st); R(w, px - 26, by - 20, 52, 1, lit); R(w, px + 18, by - 20, 8, 20, dk);
    for (int i = 0; i < 12; i++) { R(w, px - 24 + i * 4, by - 16, 2, 6, dk); R(w, px - 24 + i * 4, by - 10, 2, 5, 0xE8D8A8); }
    for (int i = 0; i < 6; i++) { R(w, px - 24 + i * 9, by - 26, 3, 6, st); PX(w, px - 23 + i * 9, by - 28, 0x4A5A4A); PX(w, px - 23 + i * 9, by - 27, 0x4A5A4A); }
    /* the tower */
    R(w, ox - 7, by - 50, 15, 50, st); R(w, ox - 7, by - 50, 1, 50, lit); R(w, ox + 4, by - 50, 4, 50, dk);
    for (int r = 4; r < 46; r += 9) { R(w, ox - 4, by - r - 4, 3, 5, 0x6A5028); R(w, ox + 1, by - r - 4, 3, 5, 0x6A5028); PX(w, ox - 3, by - r - 5, 0x6A5028); PX(w, ox + 2, by - r - 5, 0x6A5028); R(w, ox - 7, by - r + 1, 15, 1, lit); }
    R(w, ox - 9, by - 70, 19, 21, st); R(w, ox - 9, by - 70, 19, 2, lit); R(w, ox - 9, by - 51, 19, 2, dk); R(w, ox + 4, by - 70, 6, 21, dk);
    int cx = ox, cy = by - 60;
    disc(w, cx, cy, 7, 0x6A5028); disc(w, cx, cy, 6, 0xFFF8E0);
    for (int i = 0; i < 12; i++) { float a = (float)i * 0.5236f; PX(w, cx + (int)(cosf(a) * 5.0f), cy + (int)(sinf(a) * 5.0f), 0x3A2A18); }
    float hm = (float)(w->tm_min) / 60.0f * 6.2832f, hh = ((float)(w->tm_hour % 12) + (float)w->tm_min / 60.0f) / 12.0f * 6.2832f;
    for (int i = 0; i <= 5; i++) PX(w, cx + (int)(sinf(hm) * (float)i + 0.5f), cy - (int)(cosf(hm) * (float)i + 0.5f), 0x1A1208);
    for (int i = 0; i <= 3; i++) PX(w, cx + (int)(sinf(hh) * (float)i + 0.5f), cy - (int)(cosf(hh) * (float)i + 0.5f), 0x1A1208);
    R(w, ox - 7, by - 80, 15, 10, st); R(w, ox - 7, by - 80, 1, 10, lit); R(w, ox + 4, by - 80, 4, 10, dk);
    for (int i = 0; i < 3; i++) R(w, ox - 5 + i * 4, by - 78, 2, 6, 0x6A5028);
    R(w, ox - 8, by - 81, 17, 2, 0xFFD23F);
    for (int i = 0; i < 12; i++) { int hw = 6 - i / 2; R(w, ox - hw, by - 82 - i, hw * 2 + 1, 1, i & 1 ? 0x5A6A5A : 0x4A5A4A); PX(w, ox - hw, by - 82 - i, 0x7A8A7A); }
    R(w, ox, by - 98, 1, 4, 0xFFD23F);
}

static void lm_taj(AWWorld *w, int ox, int by, int d) {
    (void)d;
    Col wh = 0xF6F2EA, sh = 0xD8D0C4, dk = 0xB8AE9C;
    R(w, ox - 30, by - 7, 61, 7, 0xE8E0D0); R(w, ox - 30, by - 7, 61, 1, wh);                      /* the platform */
    R(w, ox - 20, by - 33, 41, 26, wh); R(w, ox - 20, by - 33, 41, 1, 0xFFFFFF); R(w, ox + 14, by - 33, 7, 26, sh);
    R(w, ox - 5, by - 30, 11, 22, dk); R(w, ox - 3, by - 28, 7, 19, 0x4A5A78);                   /* the great arch */
    for (int i = 0; i < 4; i++) { int hw = 3 - i; R(w, ox - hw, by - 33 + i - 0, hw * 2 + 1, 1, wh); }
    for (int s = -1; s <= 1; s += 2) { R(w, ox + s * 13 - 2, by - 28, 5, 12, dk); R(w, ox + s * 13 - 1, by - 26, 3, 9, 0x4A5A78); }
    ell_fill(w, ox, by - 40, 14.0f, 14.0f, 0, wh, by - 32);                                     /* the dome */
    for (int i = 0; i < 10; i++) { int y = by - 52 + i; int hw = (int)(13.0f * sqrtf(fmaxf(0.0f, 1.0f - (float)((y - (by - 40)) * (y - (by - 40))) / 196.0f))); R(w, ox + hw / 2, y, hw / 2 + 1, 1, sh); }
    R(w, ox - 3, by - 54, 7, 3, wh); R(w, ox, by - 60, 1, 7, 0xFFD23F); PX(w, ox, by - 61, 0xFFD23F);
    for (int s = -1; s <= 1; s += 2) {
        int mx = ox + s * 28;
        R(w, mx - 2, by - 45, 5, 38, wh); R(w, mx - 2, by - 45, 1, 38, 0xFFFFFF); R(w, mx + 1, by - 45, 2, 38, sh);
        R(w, mx - 3, by - 30, 7, 1, dk); R(w, mx - 3, by - 41, 7, 1, dk);
        ell_fill(w, mx, by - 48, 3.5f, 3.0f, 0, wh, by - 45); R(w, mx, by - 53, 1, 3, 0xFFD23F);
    }
    for (int s = -1; s <= 1; s += 2) { ell_fill(w, ox + s * 12, by - 36, 4.0f, 4.0f, 0, wh, by - 33); R(w, ox + s * 12, by - 42, 1, 3, 0xFFD23F); }
}

static void lm_stone(AWWorld *w, int ox, int by, int d) {
    (void)d;
    Col g = 0x8E8A84, lit = 0xB4B0A8, dk = 0x625E5A;
    static const int X[5] = { -34, -17, 0, 17, 34 };
    for (int i = 0; i < 5; i++) {
        int x = ox + X[i], hgt = 22 - (i == 0 || i == 4 ? 4 : 0);
        R(w, x - 4, by - hgt, 9, hgt, g); R(w, x - 4, by - hgt, 2, hgt, lit); R(w, x + 3, by - hgt, 2, hgt, dk); R(w, x - 4, by - hgt, 9, 1, lit);
        for (int j = 0; j < 4; j++) { uint32_t q = hash2((uint32_t)(i * 7 + j), 0x57AEU); PX(w, x - 2 + (int)(q % 5u), by - 3 - (int)((q >> 8) % (unsigned)(hgt - 4)), dk); }
        if (i == 1 || i == 3) { int lx = x - 12; R(w, lx, by - hgt - 5, i == 1 ? 25 : 25, 5, g); R(w, lx, by - hgt - 5, 25, 1, lit); R(w, lx, by - hgt - 1, 25, 1, dk); }
    }
    R(w, ox - 48, by - 5, 11, 5, g); R(w, ox - 48, by - 5, 11, 1, lit);
    R(w, ox + 40, by - 3, 9, 3, g); R(w, ox - 30, by - 4, 7, 4, dk);
    R(w, ox - 8, by - 5, 17, 2, g);
}

static void lm_arch(AWWorld *w, int ox, int by, int d) {
    /* the Gateway Arch: a flattened catenary of stainless steel, as wide as it is tall, with the Old Courthouse's dome beside it */
    const int HT = 74, HW = 36, LEG = 9;
    const float C = 1.75f, den = coshf(C) - 1.0f;
    Col lit = 0xD6E0EE, shd = 0x7C8AA6;
    int cx = ox + d * 62;                                                                   /* the courthouse */
    R(w, cx - 15, by - 13, 31, 13, 0xE8DCC0); R(w, cx - 15, by - 13, 31, 1, 0xFFF7DC); R(w, cx + 9, by - 13, 7, 13, 0xC8BC9E);
    for (int i = 0; i < 6; i++) { R(w, cx - 13 + i * 5, by - 11, 2, 9, 0xFFF7DC); R(w, cx - 12 + i * 5, by - 11, 1, 9, 0xB8A988); }
    R(w, cx - 12, by - 16, 25, 3, 0xD8CCA8); R(w, cx - 12, by - 16, 25, 1, 0xFFF7DC);
    ell_fill(w, cx, by - 16, 8.0f, 8.0f, 0, 0x78AE96, by - 16); R(w, cx - 7, by - 21, 3, 4, 0x9CC8B0);
    R(w, cx - 2, by - 28, 5, 4, 0xE8DCC0); R(w, cx - 1, by - 31, 3, 3, 0xFFF7DC); PX(w, cx, by - 33, 0xD0402A);
    R(w, ox - HW - 3, by - 2, LEG + 6, 3, 0xB8A888); R(w, ox + HW - LEG - 2, by - 2, LEG + 6, 3, 0xB8A888);   /* the footings */
    for (int x = -HW; x <= HW; x++) {
        float uo = (float)x / (float)HW;
        int yo = (int)lroundf((float)HT * (1.0f - (coshf(C * uo) - 1.0f) / den));
        int yi = 0, HWi = HW - LEG;
        if (abs(x) < HWi) { float ui = (float)x / (float)HWi; yi = (int)lroundf((float)(HT - 6) * (1.0f - (coshf(C * ui) - 1.0f) / den)); }
        for (int y = yi; y <= yo; y++) {
            Col c = lerpc(lit, shd, clampf(0.5f + 0.75f * uo, 0.0f, 1.0f));
            if (y == yo) c = lerpc(c, 0xFFFFFF, 0.6f); else if (y == yi && yi > 0) c = mulc(c, 0.74f);
            if (y % 8 == 7) c = mulc(c, 0.92f);                                             /* the welded sections */
            PX(w, ox + x, by - y, c);
        }
    }
    float t = (float)w->t;
    if (((int)(t * 0.9f)) & 1) { PX(w, ox - 20, by - 41, 0xFFFFFF); PX(w, ox + 14, by - 63, 0xFFFFFF); } else { PX(w, ox - 9, by - 58, 0xFFFFFF); PX(w, ox + 25, by - 30, 0xFFFFFF); }   /* sun on the steel */
}

/* ---------------------------------------------------------------- */
/* the second tour: more famous places from around the world        */
/* ---------------------------------------------------------------- */

/* one sail of the Opera House: a quarter-ellipse shell, tall edge on one side, ribbed */
static void lm_shell(AWWorld *w, int x0, int by, int wid, int hgt, int flip, Col lit, Col rib) {
    for (int i = 0; i < wid; i++) {
        float u = (float)i / (float)wid;
        int hh = (int)((float)hgt * sqrtf(1.0f - u * u));
        int x = flip ? x0 + wid - 1 - i : x0 + i;
        for (int j = 0; j < hh; j++) {
            Col c = lit;
            if (((i * 2 + j) % 9) == 0) c = rib;
            if (j == hh - 1) c = 0xFFFFFF;
            if (j < hgt / 7) c = mulc(c, 0.86f);
            PX(w, x, by - j, c);
        }
    }
}
static void lm_sydney(AWWorld *w, int ox, int by, int d) {
    (void)d;
    Col lit = 0xF4F2EC, rib = 0xD6D2C6;
    R(w, ox - 46, by - 8, 93, 8, 0xC8B8A0); R(w, ox - 46, by - 8, 93, 1, 0xE8DCC4); R(w, ox - 46, by - 1, 93, 1, 0x9A8A70);
    for (int i = 0; i < 12; i++) R(w, ox - 44 + i * 8, by - 6, 1, 5, 0xA89878);                      /* the broad steps */
    R(w, ox - 34, by - 16, 69, 8, 0x7EA4C8); R(w, ox - 34, by - 16, 69, 1, 0xB8D8F0);              /* glass front */
    for (int i = 0; i < 17; i++) R(w, ox - 33 + i * 4, by - 15, 1, 7, 0x4A6E98);
    lm_shell(w, ox - 44, by - 8, 26, 38, 0, lit, rib); lm_shell(w, ox - 29, by - 8, 22, 30, 0, lit, rib); lm_shell(w, ox - 15, by - 8, 18, 22, 0, lit, rib);
    lm_shell(w, ox + 3, by - 8, 18, 22, 1, lit, rib); lm_shell(w, ox + 14, by - 8, 22, 30, 1, lit, rib); lm_shell(w, ox + 19, by - 8, 26, 38, 1, lit, rib);
    lm_shell(w, ox + 6, by - 8, 14, 14, 0, rib, lit);                                                 /* the little restaurant shell */
}

static void lm_rome(AWWorld *w, int ox, int by, int d) {
    /* the Colosseum: three tiers of arches, and a broken wall down one side */
    Col st = 0xDCBE8E, lit = 0xF0D8A8, dk = 0xB09468, hole = 0x4A3A26;
    for (int x = -50; x <= 50; x++) {
        int e = x * d;
        int hh = 36;
        if (e > 16) { hh = 36 - (e - 16) * 5 / 6; hh += (int)(hash2(7u, (uint32_t)x) % 3u); if (hh < 18) hh = 18; }
        if (e > 42) hh = 18 + (int)(hash2(9u, (uint32_t)x) % 4u);
        for (int j = 0; j < hh; j++) {
            Col c = st;
            if (x > 38 || (e > 0 && x > 0 && x % 11 == 0)) c = dk;
            if (j % 12 == 11) c = lit;
            if (x == -50 || x == -49) c = lit;
            PX(w, ox + x, by - j, c);
        }
    }
    for (int tier = 0; tier < 3; tier++) for (int c = -46; c <= 44; c += 7) {
        int e = c * d, topy = tier * 12 + (tier == 2 ? 3 : 2);
        int wl = e > 16 ? 36 - (e - 16) * 5 / 6 : 36;
        if (e > 42) wl = 18;
        if (topy + 8 > wl) continue;
        R(w, ox + c, by - topy - 6, 4, 6, hole); R(w, ox + c + 1, by - topy - 7, 2, 1, hole);
        if (tier == 0) R(w, ox + c - 1, by - topy - 6, 1, 6, dk);
    }
    for (int c = -46; c <= 40; c += 7) { int e = c * d; if (e < 16) R(w, ox + c + 1, by - 35, 2, 2, hole); }          /* the attic windows */
    R(w, ox - 51, by - 37, 103, 1, lit);
}

static void lm_wall(AWWorld *w, int ox, int by, int d) {
    /* the Great Wall: a stone wall rolling along a ridge, with three watchtowers */
    (void)d;
    Col hill = 0x62824A, hl = 0x86A460, stone = 0xA89C88, top = 0xD4C8B2, dk = 0x7E7262;
    for (int x = -72; x <= 72; x++) {
        float ridge = 16.0f + 12.0f * sinf((float)x * 0.065f + 0.9f) + 5.0f * sinf((float)x * 0.17f);
        if (x < -64) ridge *= (float)(x + 73) / 9.0f;
        if (x > 64) ridge *= (float)(73 - x) / 9.0f;
        int rt = (int)ridge;
        for (int j = 0; j < rt; j++) PX(w, ox + x, by - j, j > rt - 4 ? hl : hill);
        if (rt > 5) {
            R(w, ox + x, by - rt - 3, 1, 4, ((x >> 1) & 1) ? stone : top);                                 /* the wall itself */
            if (((x / 3) & 1) == 0) PX(w, ox + x, by - rt - 4, top);                                        /* battlements */
            PX(w, ox + x, by - rt + 1, dk);
        }
    }
    static const int TX[3] = { -52, -2, 46 };
    for (int i = 0; i < 3; i++) {
        int x = TX[i];
        float ridge = 16.0f + 12.0f * sinf((float)x * 0.065f + 0.9f) + 5.0f * sinf((float)x * 0.17f);
        int rt = (int)ridge;
        R(w, ox + x - 5, by - rt - 14, 11, 12, stone); R(w, ox + x - 5, by - rt - 14, 11, 1, top); R(w, ox + x + 3, by - rt - 14, 3, 12, dk);
        R(w, ox + x - 2, by - rt - 10, 2, 3, 0x3A2A22); R(w, ox + x + 2, by - rt - 10, 2, 3, 0x3A2A22);
        R(w, ox + x - 7, by - rt - 17, 15, 3, 0x9A4A32); R(w, ox + x - 5, by - rt - 19, 11, 2, 0xB85A3C); R(w, ox + x - 2, by - rt - 20, 5, 1, 0xD87A50);
    }
}

static void lm_fuji(AWWorld *w, int ox, int by, int d) {
    /* Mount Fuji with a pagoda and a few cherry trees in front */
    Col rock = 0x6A78B0, rd = 0x4E5A92, snow = 0xFFFFFF, sd = 0xD4DCF0;
    for (int x = -82; x <= 82; x++) {
        float f = 1.0f - fabsf((float)x) / 82.0f;
        int hh = (int)(70.0f * powf(f, 1.55f));
        for (int j = 0; j < hh; j++) {
            Col c = x > 4 ? rd : rock;
            int cap = 44 + (int)(5.0f * sinf((float)x * 0.55f)) + (abs(x) % 5 == 0 ? 3 : 0);
            if (j > cap) c = x > 4 ? sd : snow;
            else if (j > cap - 3 && (x & 1)) c = x > 4 ? sd : snow;
            if (j == hh - 1 && j <= cap) c = lerpc(c, 0xFFFFFF, 0.3f);
            PX(w, ox + x, by - j, c);
        }
    }
    for (int i = 0; i < 4; i++) {                                                                           /* a ring of cloud */
        int cy = by - 22 - i * 2;
        for (int x = -70; x <= 70; x += 2) if (((x + i * 5) / 4 + i) % 3 != 0) BLEND(w, ox + x, cy, 0xFFFFFF, 70 - i * 10);
    }
    int px0 = ox - d * 52;                                                                                  /* the pagoda */
    R(w, px0 - 6, by - 6, 13, 6, 0xF0E8D8); R(w, px0 - 7, by - 7, 15, 2, 0xB8442A);
    for (int i = 0; i < 4; i++) { int hw = 6 - i; R(w, px0 - hw, by - 11 - i * 6, hw * 2 + 1, 4, 0xF0E8D8); R(w, px0 - hw - 2, by - 8 - i * 6, hw * 2 + 5, 2, 0xB8442A); R(w, px0 - 1, by - 10 - i * 6, 2, 2, 0x4A3A2A); }
    R(w, px0, by - 36, 1, 5, 0xFFD23F);
    static const int TXS[3] = { 28, 40, 52 };
    for (int i = 0; i < 3; i++) { int tx = ox + d * TXS[i]; R(w, tx, by - 7, 2, 7, 0x5A3A2A); ell_fill(w, tx, by - 11, 6.0f, 5.0f, 0, 0xFF9EC4, by - 4); ell_fill(w, tx - 2, by - 13, 3.0f, 2.0f, 0, 0xFFD0E2, by - 4); }
}

static void lm_golden(AWWorld *w, int ox, int by, int d) {
    /* the Golden Gate Bridge: two tall red-orange towers, swooping cables and a deck, over the bay */
    (void)d;
    Col red = 0xD4502A, lit = 0xF2703E, dkr = 0xA03A1E;
    R(w, ox - 70, by - 12, 141, 12, 0x4E80B6); for (int i = 0; i < 24; i++) R(w, ox - 68 + i * 6, by - 10 + (i % 3) * 3, 3, 1, 0x86B4DC);   /* the bay */
    R(w, ox - 70, by - 20, 141, 3, red); R(w, ox - 70, by - 20, 141, 1, lit); R(w, ox - 70, by - 17, 141, 1, dkr);                           /* the deck */
    static const int TXS[2] = { -34, 34 };
    for (int i = 0; i < 2; i++) {
        int tx = ox + TXS[i];
        R(w, tx - 5, by - 82, 3, 70, red); R(w, tx + 2, by - 82, 3, 70, dkr); R(w, tx - 5, by - 82, 1, 70, lit);
        for (int k = 0; k < 5; k++) R(w, tx - 5, by - 28 - k * 13, 10, 2, red);
        R(w, tx - 6, by - 84, 12, 3, lit); R(w, tx - 6, by - 82, 12, 1, dkr);
    }
    for (int x = -34; x <= 34; x++) {                                                                       /* the main cable */
        float u = (float)x / 34.0f;
        int cy = (int)(26.0f + 56.0f * u * u);
        PX(w, ox + x, by - cy, lit); PX(w, ox + x, by - cy + 1, dkr);
        if (x % 5 == 0) R(w, ox + x, by - cy + 2, 1, cy - 22, red);                                        /* the suspenders */
    }
    for (int i = 0; i < 2; i++) {                                                                           /* the side spans */
        int tx = ox + TXS[i], ex = ox + (i ? 68 : -68), dir = i ? 1 : -1;
        for (int k = 0; k <= 34; k++) {
            float u = (float)k / 34.0f;
            int x = tx + dir * k, cy = (int)(82.0f - 60.0f * sqrtf(u) * 0.9f - 0.0f * u);
            cy = 82 - (int)(58.0f * (1.0f - (1.0f - u) * (1.0f - u)));
            PX(w, x, by - cy, lit);
            if (k % 5 == 0) R(w, x, by - cy + 1, 1, cy - 20, red);
        }
        (void)ex;
    }
    for (int i = 0; i < 8; i++) BLEND(w, ox - 60 + i * 17, by - 60 - (i % 3) * 8, 0xFFFFFF, 40);          /* a little morning fog */
}

static void lm_christ(AWWorld *w, int ox, int by, int d) {
    /* Christ the Redeemer on his mountain top */
    (void)d;
    ell_fill(w, ox, by, 42.0f, 44.0f, 0, 0x5C7C5C, by + 2);
    for (int i = 0; i < 18; i++) { uint32_t q = hash2(0xC815u, (uint32_t)i); int tx = ox - 30 + (int)(q % 61u), ty = by - 4 - (int)((q >> 8) % 28u); if (abs(tx - ox) * 44 < (44 - (by - ty) ) * 42 - 120) R(w, tx, ty, 3, 2, 0x3E6A44); }
    ell_fill(w, ox + 6, by - 8, 28.0f, 30.0f, 0, 0x6E8E6A, by);
    ell_fill(w, ox - 6, by - 30, 12.0f, 10.0f, 0, 0x7EA07A, by - 24);
    int py = by - 43;
    R(w, ox - 6, py - 8, 13, 8, 0xD6D8DC); R(w, ox - 6, py - 8, 13, 1, 0xFFFFFF); R(w, ox + 3, py - 8, 4, 8, 0xA8ACB6);
    R(w, ox - 3, py - 32, 7, 24, 0xEEF2F4); R(w, ox + 2, py - 32, 2, 24, 0xC8CED6); R(w, ox - 3, py - 32, 1, 24, 0xFFFFFF);   /* the robe */
    R(w, ox - 21, py - 30, 43, 4, 0xEEF2F4); R(w, ox - 21, py - 30, 43, 1, 0xFFFFFF); R(w, ox - 21, py - 27, 43, 1, 0xB8BEC8);  /* the open arms */
    R(w, ox - 21, py - 26, 2, 3, 0xEEF2F4); R(w, ox + 20, py - 26, 2, 3, 0xEEF2F4);
    R(w, ox - 2, py - 38, 5, 6, 0xEEF2F4); R(w, ox - 2, py - 38, 1, 6, 0xFFFFFF); R(w, ox + 1, py - 38, 2, 6, 0xC8CED6); PX(w, ox, py - 36, 0x8A929C);
    for (int dy = -9; dy <= 9; dy++) for (int dx = -26; dx <= 26; dx++) if (dx * dx / 3 + dy * dy < 80 && ((dx + dy) & 1) == 0) BLEND(w, ox + dx, py - 28 + dy, 0xFFF3C2, 14);   /* a soft glow */
}

static void lm_chichen(AWWorld *w, int ox, int by, int d) {
    /* El Castillo: a stepped pyramid with a staircase down each face and a little temple on top */
    (void)d;
    Col st = 0xD0C09A, lit = 0xE8DAB4, shd = 0xA89872, dk = 0x6A5A3C;
    for (int t = 0; t < 9; t++) {
        int hw = 36 - t * 3, y = by - 4 - t * 4;
        R(w, ox - hw, y, hw * 2 + 1, 4, st); R(w, ox - hw, y, hw * 2 + 1, 1, lit); R(w, ox + hw - hw / 3, y + 1, hw / 3 + 1, 3, shd);
        R(w, ox - hw, y + 3, hw * 2 + 1, 1, shd);
    }
    R(w, ox - 38, by - 4, 77, 4, shd);
    for (int r = 0; r < 38; r++) { R(w, ox - 3, by - 2 - r, 7, 1, (r & 1) ? 0xF4E8C4 : 0xB8A87C); }       /* the great stair */
    R(w, ox - 4, by - 39, 1, 37, dk); R(w, ox + 4, by - 39, 1, 37, dk);
    R(w, ox - 7, by - 50, 15, 11, st); R(w, ox - 7, by - 50, 15, 1, lit); R(w, ox + 3, by - 50, 5, 11, shd);                              /* the temple */
    R(w, ox - 3, by - 47, 7, 8, 0x3A2A1A); R(w, ox - 8, by - 52, 17, 2, lit); R(w, ox - 5, by - 55, 11, 3, st); R(w, ox - 5, by - 55, 11, 1, lit);
    for (int i = 0; i < 3; i++) { int tx = ox + (i - 1) * 3; (void)tx; }
    for (int s = -1; s <= 1; s += 2) { int tx = ox + s * 48; R(w, tx, by - 9, 2, 9, 0x5A3A22); ell_fill(w, tx, by - 13, 7.0f, 6.0f, 0, 0x2E7A3A, by - 6); ell_fill(w, tx + 2, by - 16, 4.0f, 3.0f, 0, 0x4A9A4A, by - 6); }
}

static void lm_athens(AWWorld *w, int ox, int by, int d) {
    /* the Parthenon on its rock */
    (void)d;
    Col mar = 0xF2EAD8, sh = 0xCFC6B0, dk = 0x8A8070;
    ell_fill(w, ox, by, 50.0f, 15.0f, 0, 0x9A8466, by + 2); ell_fill(w, ox + 10, by - 6, 38.0f, 9.0f, 0, 0xB09A78, by);
    int y0 = by - 14;
    R(w, ox - 44, y0 - 2, 89, 2, mar); R(w, ox - 42, y0 - 4, 85, 2, sh); R(w, ox - 44, y0 - 2, 89, 1, 0xFFFFFF);
    for (int i = 0; i < 8; i++) {
        int cx = ox - 38 + i * 11;
        R(w, cx, y0 - 30, 5, 26, mar); R(w, cx + 3, y0 - 30, 2, 26, sh); R(w, cx, y0 - 30, 1, 26, 0xFFFFFF);
        R(w, cx - 1, y0 - 32, 7, 2, mar); R(w, cx - 1, y0 - 5, 7, 1, mar);
    }
    R(w, ox - 41, y0 - 34, 83, 3, mar); R(w, ox - 41, y0 - 34, 83, 1, 0xFFFFFF); R(w, ox - 41, y0 - 32, 83, 1, dk);
    for (int i = 0; i < 17; i++) R(w, ox - 40 + i * 5, y0 - 33, 2, 1, dk);
    lm_tri(w, ox, y0 - 35, 86, 13, mar, sh, 0); R(w, ox - 10, y0 - 40, 20, 4, 0xDCD2BC);
    for (int i = 0; i < 7; i++) R(w, ox - 38 + i * 11 + 5, y0 - 28, 6, 24, 0x4A4234);                              /* the shadowed cella behind */
}

static void lm_moai(AWWorld *w, int ox, int by, int d) {
    /* the Moai of Easter Island, standing along a stone platform */
    (void)d;
    Col g = 0x7C766A, lit = 0xA09A8C, dk = 0x57524A;
    R(w, ox - 44, by - 7, 89, 7, 0x6A645A); R(w, ox - 44, by - 7, 89, 1, lit); for (int i = 0; i < 9; i++) R(w, ox - 42 + i * 10, by - 5, 1, 4, dk);
    static const int X[5] = { -34, -17, 0, 17, 34 }, H[5] = { 26, 31, 36, 29, 24 };
    for (int i = 0; i < 5; i++) {
        int x = ox + X[i], hh = H[i], y = by - 7 - hh;
        R(w, x - 5, y, 11, hh, g); R(w, x - 5, y, 2, hh, lit); R(w, x + 3, y, 3, hh, dk);
        R(w, x - 6, y + hh / 3, 13, 3, g); R(w, x - 6, y + hh / 3, 13, 1, lit);                                  /* the heavy brow */
        R(w, x - 4, y + hh / 3 + 3, 3, 3, 0x2A2622); R(w, x + 1, y + hh / 3 + 3, 3, 3, 0x2A2622);               /* eye sockets */
        R(w, x - 1, y + hh / 3 + 3, 3, 7, lit); R(w, x + 1, y + hh / 3 + 8, 2, 3, dk);                           /* the long nose */
        R(w, x - 3, y + hh * 2 / 3 + 1, 7, 1, 0x2A2622);                                                           /* the thin mouth */
        R(w, x - 4, y + hh - 6, 9, 1, dk);
        if (i == 2) { R(w, x - 4, y - 3, 9, 3, 0xB8503A); R(w, x - 4, y - 3, 9, 1, 0xD8704A); }                    /* a red topknot */
    }
}

static void lm_burj(AWWorld *w, int ox, int by, int d) {
    /* the Burj Khalifa: a tapering tower that steps in as it climbs */
    (void)d;
    Col gl = 0xB4C8DC, lit = 0xE0ECF8, dk = 0x7A8EAA;
    R(w, ox - 20, by - 10, 41, 10, 0xA8B4C4); R(w, ox - 20, by - 10, 41, 1, lit); for (int i = 0; i < 9; i++) R(w, ox - 18 + i * 4, by - 8, 2, 6, 0x5A7090);
    static const int W[7] = { 11, 9, 8, 6, 5, 3, 2 }, H[7] = { 26, 22, 18, 14, 12, 8, 6 };
    int y = by - 10;
    for (int i = 0; i < 7; i++) {
        R(w, ox - W[i], y - H[i], W[i] * 2 + 1, H[i], gl); R(w, ox - W[i], y - H[i], 1, H[i], lit); R(w, ox + W[i] - W[i] / 2, y - H[i], W[i] / 2 + 1, H[i], dk);
        for (int r = 2; r < H[i]; r += 3) R(w, ox - W[i] + 1, y - H[i] + r, W[i] * 2 - 1, 1, mulc(gl, 0.9f));
        y -= H[i];
    }
    R(w, ox, y - 24, 1, 24, 0xE8ECF4); R(w, ox, y - 24, 1, 2, 0xFF3030);
    if (((int)((float)w->t * 1.4f)) & 1) PX(w, ox, y - 25, 0xFF5050);
}

static void lm_onion(AWWorld *w, int cx, int by, int r, int hh, Col a, Col b) {
    for (int j = 0; j < hh; j++) {
        float u = (float)j / (float)hh;
        float wd = u < 0.55f ? (float)r * (0.55f + 0.45f * sinf(u / 0.55f * 1.5708f)) : (float)r * (1.0f - (u - 0.55f) / 0.45f) * 1.0f;
        int hw = (int)(wd + 0.5f);
        for (int dx = -hw; dx <= hw; dx++) {
            Col c = ((dx + j) / 2 & 1) ? a : b;
            if (dx > hw / 2) c = mulc(c, 0.78f);
            PX(w, cx + dx, by - j, c);
        }
    }
    R(w, cx, by - hh - 4, 1, 4, 0xFFD23F); R(w, cx - 1, by - hh - 3, 3, 1, 0xFFD23F);
}
static void lm_basil(AWWorld *w, int ox, int by, int d) {
    /* St. Basil's Cathedral: a cluster of bright striped domes round a tall tent spire */
    (void)d;
    R(w, ox - 30, by - 20, 61, 20, 0xB8442A); R(w, ox - 30, by - 20, 61, 1, 0xE0846A); R(w, ox + 20, by - 20, 11, 20, 0x8E3220);
    for (int i = 0; i < 9; i++) { R(w, ox - 27 + i * 7, by - 15, 3, 6, 0xF0E8D8); PX(w, ox - 26 + i * 7, by - 16, 0xF0E8D8); R(w, ox - 27 + i * 7, by - 18, 3, 1, 0xF0E8D8); }
    R(w, ox - 6, by - 52, 13, 32, 0xE8DCC0); R(w, ox - 6, by - 52, 13, 1, 0xFFFFFF); R(w, ox + 3, by - 52, 4, 32, 0xC8B898);
    for (int r = 0; r < 14; r++) { int hw = 7 - r / 2; R(w, ox - hw, by - 53 - r, hw * 2 + 1, 1, (r & 1) ? 0x2F9A6A : 0x2A7A5A); }   /* the tent roof */
    R(w, ox, by - 70, 1, 4, 0xFFD23F); R(w, ox - 1, by - 69, 3, 1, 0xFFD23F);
    lm_onion(w, ox - 22, by - 20, 6, 16, 0x2FB06A, 0xFFE27A);
    lm_onion(w, ox - 12, by - 20, 5, 22, 0xE84A3A, 0xFFFFFF);
    lm_onion(w, ox + 12, by - 20, 5, 22, 0x3A78E8, 0xFFE27A);
    lm_onion(w, ox + 23, by - 20, 6, 16, 0xFFD23F, 0xE84A3A);
}

static void lm_holly(AWWorld *w, int ox, int by, int d) {
    /* the Hollywood sign across a dry hillside, with searchlights at night */
    (void)d;
    ell_fill(w, ox, by, 62.0f, 30.0f, 0, 0x8A7A4A, by + 2);
    ell_fill(w, ox - 18, by - 3, 40.0f, 24.0f, 0, 0xA09058, by);
    for (int i = 0; i < 30; i++) { uint32_t q = hash2(0x401Cu, (uint32_t)i); int tx = ox - 52 + (int)(q % 105u), ty = by - 2 - (int)((q >> 9) % 12u); R(w, tx, ty, 3, 2, 0x5A7A3A); }
    static const char *const MSG = "HOLLYWOOD";
    for (int i = 0; i < 9; i++) {
        int lx = ox - 36 + i * 8, ly = by - 38;
        char ch[2] = { MSG[i], 0 };
        R(w, lx + 2, ly + 10, 2, 5, 0xCFCFD8);                                                                  /* a post behind each letter */
        text35(w, lx + 1, ly + 1, ch, 2, 0x606060);
        text35(w, lx, ly, ch, 2, 0xFFFFFF);
    }
    float night = bg_night(w);
    if (night > 0.25f) {
        float sw = sinf((float)w->t * 0.5f);
        for (int b = 0; b < 2; b++) {
            float ang = (b ? 0.42f : -0.42f) + sw * (b ? -0.25f : 0.25f);
            for (int r = 6; r < 80; r++) {
                int hw = 1 + r / 14;
                int bx = ox + (b ? 56 : -56) + (int)(sinf(ang) * (float)r), byy = by - 4 - (int)(cosf(ang) * (float)r);
                for (int k = -hw; k <= hw; k++) BLEND(w, bx + k, byy, 0xFFF8D0, (int)(34.0f * night) - r / 4);
            }
        }
    }
}

static void lm_cn(AWWorld *w, int ox, int by, int d) {
    /* the CN Tower: a tall slim shaft with a round pod and a long antenna */
    (void)d;
    Col con = 0xC8CED8, lit = 0xF0F4FA, dk = 0x8A92A2;
    for (int i = 0; i < 112; i++) {
        float f = (float)i / 112.0f;
        int hw = (int)(7.0f - 4.5f * f); if (i < 10) hw += (10 - i) / 3;
        if (i > 86) hw = 1;
        R(w, ox - hw, by - i, hw * 2 + 1, 1, con); PX(w, ox - hw, by - i, lit); PX(w, ox + hw, by - i, dk);
    }
    for (int s = -1; s <= 1; s += 2) for (int i = 0; i < 18; i++) PX(w, ox + s * (11 - i / 2), by - i, dk);
    int py = by - 78;
    ell_fill(w, ox, py, 14.0f, 4.0f, 0, con, BIGY); ell_fill(w, ox, py - 5, 12.0f, 3.5f, 0, 0x6A8CB8, BIGY); R(w, ox - 11, py - 3, 23, 1, lit);
    ell_fill(w, ox, py - 9, 6.0f, 3.0f, 0, con, BIGY);
    for (int i = 0; i < 12; i++) PX(w, ox - 10 + i * 2, py - 5, 0xBFE8FF);
    R(w, ox, by - 112 - 12, 1, 12, 0xE8ECF4);
    if (((int)((float)w->t * 1.5f)) & 1) { PX(w, ox, by - 125, 0xFF4040); BLEND(w, ox, by - 126, 0xFF4040, 90); }
}

static void lm_uluru(AWWorld *w, int ox, int by, int d) {
    /* Uluru: a huge red sandstone rock rising out of the desert */
    (void)d;
    for (int x = -62; x <= 62; x++) {
        float f = fabsf((float)x) / 62.0f;
        int hh = (int)(38.0f * powf(1.0f - powf(f, 2.4f), 0.55f)) + (int)(2.5f * sinf((float)x * 0.45f));
        if (hh < 1) continue;
        for (int j = 0; j < hh; j++) {
            Col c = 0xC8603A;
            if (((x * 3 + j) / 5) % 7 == 0) c = 0xB04E2C;
            if (x > 14) c = mulc(c, 0.8f);
            if (x < -30 && j > hh - 5) c = 0xE07A4A;
            if (j == hh - 1) c = lerpc(c, 0xFFD0A0, 0.35f);
            if (j < 4) c = mulc(c, 0.86f);
            PX(w, ox + x, by - j, c);
        }
    }
    for (int i = 0; i < 40; i++) { uint32_t q = hash2(0x1B07u, (uint32_t)i); int x = (int)(q % 133u) - 66; R(w, ox + x, by - 1 - (int)((q >> 10) % 4u), 3, 2, (q & 1u) ? 0x7A8A40 : 0x5E7A3A); }
}

static void lm_swan(AWWorld *w, int ox, int by, int d) {
    /* Neuschwanstein: a white fairytale castle on a crag, with slate-blue pointed roofs */
    Col wl = 0xF0EADC, sd = 0xCFC6B0, roof = 0x4A68A0, rl = 0x6A88C0, gold = 0xFFD23F;
    ell_fill(w, ox, by, 46.0f, 26.0f, 0, 0x7A7A68, by + 2); ell_fill(w, ox - 6, by - 6, 32.0f, 20.0f, 0, 0x8A8A74, by);
    for (int i = 0; i < 16; i++) { uint32_t q = hash2(0x5A41u, (uint32_t)i); int tx = ox - 40 + (int)(q % 81u), ty = by - 3 - (int)((q >> 9) % 9u); R(w, tx, ty, 3, 3, 0x3E7A44); }
    int bx = ox - 20, y0 = by - 22;
    R(w, bx, y0 - 22, 42, 22, wl); R(w, bx, y0 - 22, 42, 1, 0xFFFFFF); R(w, bx + 32, y0 - 22, 10, 22, sd);
    for (int i = 0; i < 7; i++) { R(w, bx + 3 + i * 6, y0 - 17, 2, 4, 0x3A4A6A); R(w, bx + 3 + i * 6, y0 - 9, 2, 4, 0x3A4A6A); }
    R(w, bx - 1, y0 - 24, 44, 2, roof);
    for (int r = 0; r < 8; r++) R(w, bx + r, y0 - 26 - r, 42 - r * 2, 1, (r & 1) ? roof : rl);                    /* the main roof */
    /* the tall tower */
    int tx = ox + 14;
    R(w, tx - 6, y0 - 56, 13, 34, wl); R(w, tx - 6, y0 - 56, 1, 34, 0xFFFFFF); R(w, tx + 2, y0 - 56, 5, 34, sd);
    R(w, tx - 2, y0 - 50, 2, 4, 0x3A4A6A); R(w, tx + 2, y0 - 42, 2, 4, 0x3A4A6A); R(w, tx - 2, y0 - 34, 2, 4, 0x3A4A6A);
    for (int r = 0; r < 24; r++) { int hw = 8 - r / 3; R(w, tx - hw, y0 - 57 - r, hw * 2 + 1, 1, (r & 1) ? roof : rl); }
    R(w, tx, y0 - 82, 1, 5, gold); PX(w, tx - 1, y0 - 80, gold); PX(w, tx + 1, y0 - 80, gold);
    /* the little round tower */
    int rx = ox - 24;
    R(w, rx - 4, y0 - 40, 9, 22, wl); R(w, rx - 4, y0 - 40, 1, 22, 0xFFFFFF); R(w, rx + 2, y0 - 40, 3, 22, sd); R(w, rx - 1, y0 - 34, 2, 3, 0x3A4A6A);
    for (int r = 0; r < 14; r++) { int hw = 5 - r / 3; R(w, rx - hw, y0 - 41 - r, hw * 2 + 1, 1, (r & 1) ? roof : rl); }
    R(w, rx, y0 - 59, 1, 3, gold);
    for (int i = 0; i < 3; i++) { int sx = ox - 4 + i * 6; R(w, sx, y0 - 30, 4, 8, wl); for (int r = 0; r < 5; r++) R(w, sx + r / 2, y0 - 31 - r, 4 - r / 2 * 2 > 0 ? 4 - r / 2 * 2 : 1, 1, roof); }
}

static const char *const LM_NAME[LM_N] = { "PISA ITALY", "GIZA EGYPT", "LAS VEGAS NEVADA", "SEATTLE WASHINGTON", "PARIS FRANCE", "NEW YORK", "LONDON ENGLAND", "AGRA INDIA", "WILTSHIRE ENGLAND", "ST LOUIS MISSOURI",
    "SYDNEY AUSTRALIA", "ROME ITALY", "GREAT WALL CHINA", "MOUNT FUJI JAPAN", "SAN FRANCISCO", "RIO DE JANEIRO", "CHICHEN ITZA MEXICO", "ATHENS GREECE", "EASTER ISLAND", "DUBAI UAE", "MOSCOW RUSSIA", "LOS ANGELES", "TORONTO CANADA", "ULURU AUSTRALIA", "BAVARIA GERMANY" };

static void lm_draw(AWWorld *w, int kind, int ox, int by, int d) {
    switch (kind) {
        case LM_PISA: lm_pisa(w, ox, by, d); break;
        case LM_SPHINX: lm_sphinx(w, ox, by, d); break;
        case LM_VEGAS: lm_vegas(w, ox, by, d); break;
        case LM_NEEDLE: lm_needle(w, ox, by, d); break;
        case LM_EIFFEL: lm_eiffel(w, ox, by, d); break;
        case LM_LIBERTY: lm_liberty(w, ox, by, d); break;
        case LM_BIGBEN: lm_bigben(w, ox, by, d); break;
        case LM_TAJ: lm_taj(w, ox, by, d); break;
        case LM_ARCH: lm_arch(w, ox, by, d); break;
        case LM_SYDNEY: lm_sydney(w, ox, by, d); break;
        case LM_ROME: lm_rome(w, ox, by, d); break;
        case LM_WALL: lm_wall(w, ox, by, d); break;
        case LM_FUJI: lm_fuji(w, ox, by, d); break;
        case LM_GOLDEN: lm_golden(w, ox, by, d); break;
        case LM_CHRIST: lm_christ(w, ox, by, d); break;
        case LM_CHICHEN: lm_chichen(w, ox, by, d); break;
        case LM_ATHENS: lm_athens(w, ox, by, d); break;
        case LM_MOAI: lm_moai(w, ox, by, d); break;
        case LM_BURJ: lm_burj(w, ox, by, d); break;
        case LM_BASIL: lm_basil(w, ox, by, d); break;
        case LM_HOLLY: lm_holly(w, ox, by, d); break;
        case LM_CN: lm_cn(w, ox, by, d); break;
        case LM_ULURU: lm_uluru(w, ox, by, d); break;
        case LM_SWAN: lm_swan(w, ox, by, d); break;
        default: lm_stone(w, ox, by, d); break;
    }
}

/* the little name plaque in front, drawn after the ground (so it sits on the lawn) */
static void lm_plaque(AWWorld *w, int kind, int ox, int base) {
    int tw = text35_w(LM_NAME[kind], 1), pw = tw + 6;
    int x = ox - pw / 2, y = base - 14;
    R(w, x + 2, y + 9, 2, 6, 0x6B3E1F); R(w, x + pw - 4, y + 9, 2, 6, 0x6B3E1F);
    R(w, x - 1, y - 1, pw + 2, 11, 0x3A2412); R(w, x, y, pw, 9, 0x7A4A24); R(w, x + 1, y + 1, pw - 2, 7, 0x2A1A10);
    text35(w, x + 3, y + 2, LM_NAME[kind], 1, 0xFFF3C2);
}

static int lm_slot(AWWorld *w, int k, int *wxo, int *kind, int *dir);
#define lm_slot_ok lm_slot
/* how far each place spreads from its centre (px): behind it, in front of it, and whether it faces a way at all.
   Used to keep the time / date / weather signs from ever hanging in front of one. */
static const signed char LM_EXT[LM_N][3] = {
    { 48, 18, 1 }, { 80, 118, 1 }, { 82, 64, 0 }, { 24, 24, 0 }, { 26, 26, 0 }, { 20, 20, 0 }, { 62, 12, 1 }, { 34, 34, 0 }, { 52, 52, 0 }, { 40, 80, 1 },
    { 48, 48, 0 }, { 52, 52, 0 }, { 74, 74, 0 }, { 84, 84, 0 }, { 72, 72, 0 }, { 44, 44, 0 }, { 42, 42, 0 }, { 46, 46, 0 }, { 46, 46, 0 }, { 22, 22, 0 }, { 34, 34, 0 }, { 40, 40, 0 }, { 16, 16, 0 }, { 64, 64, 0 }, { 48, 48, 0 },
};
/* the world-x span a landmark (and its name plaque) covers */
static void lm_span(int kind, int ox, int d, int *lo, int *hi) {
    int back = LM_EXT[kind][0], fwd = LM_EXT[kind][1];
    if (LM_EXT[kind][2] && d < 0) { int t = back; back = fwd; fwd = t; }
    *lo = ox - back; *hi = ox + fwd;
    int ph = text35_w(LM_NAME[kind], 1) / 2 + 6;
    if (ox + 4 - ph < *lo) *lo = ox + 4 - ph;
    if (ox + 4 + ph > *hi) *hi = ox + 4 + ph;
}
static int lm_span_at(AWWorld *w, int k, int *lo, int *hi) {   /* the k-th landmark slot's span, if it has one (k = -99: the pinned test one) */
    int wx, kind, dir;
    if (k == -99) { kind = (w->lm_force - 1) % LM_N; wx = (int)floor(w->cam) + (int)(w->vw * 0.60f); dir = 1; }
    else if (!lm_slot_ok(w, k, &wx, &kind, &dir)) return 0;
    lm_span(kind, wx, dir, lo, hi);
    return 1;
}
/* does the world span [a, b] touch any landmark? */
static int lm_hit(AWWorld *w, int a, int b) {
    int lo, hi;
    if (w->lm_force) return lm_span_at(w, -99, &lo, &hi) && !(b < lo || a > hi);
    const int LW = 1300;
    for (int k = floordiv(a - 320, LW); k <= floordiv(b + 320, LW); k++)
        if (lm_span_at(w, k, &lo, &hi) && !(b < lo || a > hi)) return 1;
    return 0;
}
/* A sign centred at world x wx (half = half its width plus a little sway) must not hang in front of a landmark.
   (pwm is the widest sign board.) Returns 0 if it is clear, 1 if it has been moved to just beside it (*out), -1 if it should be left out for now.
   wxL / wxR are where the neighbouring signs would be, so a moved one never lands on top of another. */
static int lm_panel_shift(AWWorld *w, int wx, int pwm, int wxL, int wxR, int *out) {
    int half = pwm * 13 / 20 + 22, gap = pwm + 30;   /* the widest a sign's carrier (blimp hull, balloons, flock) and its sway can reach, and a gap to the next sign */
    *out = wx;
    if (!lm_hit(w, wx - half, wx + half)) return 0;
    int best = 0, bestd = 1 << 30;
    int lo, hi;
    for (int pass = 0; pass < 2; pass++) {
        int cand[2] = { 0, 0 }, nc = 0;
        for (int k = floordiv(wx - 320, 1300); k <= floordiv(wx + 320, 1300); k++) {
            int on = w->lm_force ? (k == floordiv(wx, 1300) && lm_span_at(w, -99, &lo, &hi)) : lm_span_at(w, k, &lo, &hi);
            if (!on || (wx + half < lo) || (wx - half > hi)) continue;
            cand[0] = lo - half - 4; cand[1] = hi + half + 4; nc = 2;
            break;
        }
        (void)pass;
        for (int i = 0; i < nc; i++) {
            int x = cand[i];
            if (lm_hit(w, x - half, x + half)) continue;
            if (abs(x - wxL) < gap && !lm_hit(w, wxL - half, wxL + half)) continue;
            if (abs(x - wxR) < gap && !lm_hit(w, wxR - half, wxR + half)) continue;
            if (abs(x - wx) < bestd) { bestd = abs(x - wx); best = x; }
        }
        break;
    }
    if (!bestd || bestd == (1 << 30)) return -1;
    *out = best;
    return 1;
}

static int lm_slot(AWWorld *w, int k, int *wxo, int *kind, int *dir) {
    const int LW = 1300;
    uint32_t h = hash2(w->seed ^ 0x1A4D3U, (uint32_t)k);
    if (rfn(h, 0) > 0.55f) return 0;
    *wxo = k * LW + 160 + (int)(rfn(h, 1) * (float)(LW - 320));
    int kd = (int)(rfn(h, 2) * (float)LM_N) % LM_N;
    uint32_t hp = hash2(w->seed ^ 0x1A4D3U, (uint32_t)(k - 1));       /* never the same one twice in a row */
    if (rfn(hp, 0) <= 0.55f && (int)(rfn(hp, 2) * (float)LM_N) % LM_N == kd) kd = (kd + 1 + (int)(rfn(h, 5) * 7.0f)) % LM_N;
    *kind = kd; *dir = rfn(h, 3) < 0.5f ? 1 : -1;
    int g0 = ground_h(w, *wxo);
    if (g0 < 0 || g0 > 4 || ground_h(w, *wxo - 28) > 5 || ground_h(w, *wxo + 28) > 5 || ground_h(w, *wxo - 28) < 0 || ground_h(w, *wxo + 28) < 0) return 0;
    if (road_m(w, *wxo - 40) > 0.0f || road_m(w, *wxo + 40) > 0.0f || pier_near(w, (double)*wxo)) return 0;
    return 1;
}
static void draw_landmarks(AWWorld *w, int front) {
    int camI = (int)floor(w->cam);
    if (w->lm_force) {
        int kind = (w->lm_force - 1) % LM_N, ox = (int)(w->vw * 0.60f);
        if (!front) lm_draw(w, kind, ox, w->gy + 3, 1); else lm_plaque(w, kind, ox + 4, w->gy + 8);
        return;
    }
    const int LW = 1300;
    int k0 = floordiv(camI - 150, LW), k1 = floordiv(camI + w->vw + 150, LW);
    for (int k = k0; k <= k1; k++) {
        int wx, kind, dir;
        if (!lm_slot(w, k, &wx, &kind, &dir)) continue;
        int ox = wx - camI;
        if (ox < -130 || ox > w->vw + 130) continue;
        if (!front) lm_draw(w, kind, ox, w->gy - ground_h(w, wx) + 3, dir); else lm_plaque(w, kind, ox + 4, w->gy - ground_h(w, wx) + 8);
    }
}
