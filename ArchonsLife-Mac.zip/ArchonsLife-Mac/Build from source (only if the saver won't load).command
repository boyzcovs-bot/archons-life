#!/bin/bash
# Fallback: compiles the saver natively on THIS Mac with Apple's own compiler, then installs it.
# Needs the free Xcode Command Line Tools (macOS offers to install them if missing).
cd "$(dirname "$0")" || exit 1
if ! command -v clang >/dev/null 2>&1; then
  echo "Apple's developer tools are needed once. A window will pop up - click Install,"
  echo "wait for it to finish, then run this script again."
  xcode-select --install; exit 1
fi
OUT="build/ArchonsLife.saver"
rm -rf "$OUT"; mkdir -p "$OUT/Contents/MacOS" "$OUT/Contents/Resources"
cp ArchonsLife.saver/Contents/Info.plist ArchonsLife.saver/Contents/PkgInfo "$OUT/Contents/"
cp ArchonsLife.saver/Contents/Resources/* "$OUT/Contents/Resources/"
echo "Compiling..."
clang -O2 -bundle -arch arm64 -arch x86_64 -mmacosx-version-min=10.13 -fvisibility=hidden \
      -Isource source/mac_saver.c source/aw_engine.c source/aw_weather.c source/aw_net_mac.c -lm \
      -o "$OUT/Contents/MacOS/ArchonsLife" || { echo "Compile failed."; read -n1 -r -p "Press any key"; exit 1; }
codesign --force --deep --sign - "$OUT"
DEST="$HOME/Library/Screen Savers"; mkdir -p "$DEST"
rm -rf "$DEST/ArchonsLife.saver"; cp -R "$OUT" "$DEST/"; xattr -cr "$DEST/ArchonsLife.saver" 2>/dev/null
killall legacyScreenSaver 2>/dev/null || true
echo "Installed. Opening Screen Saver settings..."
open "x-apple.systempreferences:com.apple.ScreenSaver-Settings.extension" 2>/dev/null \
  || open "/System/Library/PreferencePanes/DesktopScreenEffectsPref.prefPane" 2>/dev/null
sleep 2
