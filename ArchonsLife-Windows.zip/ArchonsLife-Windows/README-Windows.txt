ARCHON'S LIFE  -  Windows screen saver  (v2.2)
===============================================

Archon travels through an endless, always-changing pixel world - meadows, deserts,
forests, dusk villages, ember wastes, starry nights, crystal twilight, frozen peaks -
while the TIME, DATE and TEMPERATURE drift past on signposts, blimps, balloon banners,
satellites and even underground and underwater. The seasons turn on their own, in an
order that never repeats: spring blossom, summer green, autumn leaves, winter snow.

Every so often Archon changes how he travels: he sprouts wings, drives a flying car,
blasts off in a rocket (a different one every trip; pad countdown, up through the
clouds, a cruise past the planets, then a landing), floats in a hot-air balloon, rides a
magic carpet, flies a helicopter or straps on a jetpack. He can also go DOWN: he drives
a drill-nosed digger deep underground (hedgehogs, worms, moles and beetles live in
little cave pockets down there), dives in a yellow submarine past fish, jellyfish,
turtles, crabs, octopuses and the odd whale, or heads out on the water in a sailboat, a
tugboat, a jet ski, a speedboat, a duck floatie or a cruise ship (the dolphin likes to
race them). On the road he pedals a bicycle, rides a motorbike, a skateboard or a
Segway, drives a roadster, an electric car, a pickup with hay bales, a forklift, a semi
truck or a school bus. Backdrops change too: mountains, rolling hills, forests, a city
skyline, a suburb, farmland and mesas. The clock, date and temperature are carried by
signposts, blimps, drones, flocks of birds and balloons of all kinds (a beating heart, a
fox, a rocket, a mirror ball, a sleepy moon, even Archon himself), each sign in its own
LED colour. And now and then someone unexpected shows up above ground: a fox, a corgi, a
dalmatian, a husky, a slime, a robot, a friend who looks just like Archon, wisps of
fire/water/earth/air, a ghost, a flock of birds, a wizard on a crescent moon, a dragon,
a UFO... You never know what's next.

NEW IN 2.2
----------
* The ground is full of rocks, crystals, fossils, dinosaur bones and little caves with stalagmites
  and stalactites - and now and then a dog bone, a worm or a mole.
* Archon goes deep sea in scuba gear or a snorkel: squid, octopuses, a sunken pirate ship, a
  giant clam and schools of small fish.
* He drives a 4x4 jeep up and down hills once in a while.
* Famous landmarks drift past at random: the Leaning Tower of Pisa, the Sphinx, Las Vegas, the
  Space Needle, the Eiffel Tower, the Statue of Liberty, Big Ben, the Taj Mahal, Stonehenge and the
  St. Louis Gateway Arch.
* The date is spelled out with the month, and sometimes shows the year.
* Be on the lookout for special holiday easter eggs! They follow your computer's calendar.

INSTALL (Windows 10 / 11, 64-bit)
---------------------------------
1. Unzip this folder (don't run it from inside the zip).
2. Double-click  ArchonsLife.scr  and click  Yes  when it asks "Install it as a screen saver?".
   If Windows says "Windows protected your PC", click "More info" -> "Run anyway".
   Windows asks for permission once: click Yes. Archon's Life copies itself into
   C:\Windows\System32 (that is how Windows keeps a screen saver), then Screen Saver
   Settings opens with "ArchonsLife" selected.
3. Set how long Windows waits before starting it, click OK. Done.
   (Even if you close that window without clicking OK, ArchonsLife stays in the
   screen saver list from now on.)

Please don't use right-click -> Install on ArchonsLife.scr: that only points Windows at
the folder you unzipped it in, and the saver drops out of the list again when you close
the window or move that folder.

To just try it first: double-click ArchonsLife.scr and click No. It runs full screen.
Move the mouse or press any key to close it.

If the install box doesn't appear, copy ArchonsLife.scr into C:\Windows\System32 yourself
(Windows asks for permission), then choose ArchonsLife in Screen Saver Settings.

SETTINGS  (Screen Saver Settings -> "Settings...")
--------------------------------------------------
* Show the temperature   on / off
* Temperature units      Automatic, Fahrenheit or Celsius
* Clock                  Automatic, 12-hour or 24-hour
"Automatic" follows your Windows regional settings.

ABOUT THE TEMPERATURE - PLEASE READ
-----------------------------------
The temperature sign is the only thing that uses the internet. While the saver is
running it:
  1. asks a free IP-geolocation service (ipwho.is, or get.geojs.io as a backup)
     roughly where your internet connection is - city level, no account;
  2. asks Open-Meteo (open-meteo.com, free, no account) for the current weather at that
     spot, rounded to 0.1 degree, and refreshes about every 20 minutes.
Nothing is saved to your PC and nothing else is sent. If you are offline, or you switch
the option off in Settings, the temperature sign is simply left out and the saver shows
time and date only. (A VPN will make it show the weather near the VPN server.)
Only your regional/units choices are stored (in HKEY_CURRENT_USER\Software\ArchonsLife).
The little preview in the Settings window never goes online.

"WINDOWS PROTECTED YOUR PC" / SMARTSCREEN
-----------------------------------------
The file is not code-signed (signing certificates cost money), so Windows may
warn you the first time. Click "More info" -> "Run anyway". If the unzipped file
is blocked: right-click it -> Properties -> tick "Unblock" -> OK.
A firewall may ask whether ArchonsLife may reach the internet - that is the
temperature lookup; say No if you prefer, and everything else still works.

NOTES
-----
* Works on every monitor you have - each screen gets its own world.
* To remove: Settings -> Personalization -> Lock screen -> Screen saver settings
  -> choose (None), then delete C:\Windows\System32\ArchonsLife.scr
  (and, optionally, the registry key mentioned above).
